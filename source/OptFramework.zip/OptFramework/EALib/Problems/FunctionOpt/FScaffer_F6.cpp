/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 21 July 2011
// Last modified:
#include "FScaffer_F6.h"

FScaffer_F6::FScaffer_F6(){
    //ctor
}
FScaffer_F6::FScaffer_F6(const int rId, const int rDim, char *rName):BenchmarkFunction(rId, 2, rName){

    setSearchRange<double>(-100,100);

     initialize();
}
FScaffer_F6::FScaffer_F6(const int rId,  char *rName, double rL, double rU):BenchmarkFunction(rId, 2, rName){
    setSearchRange<double>(rL,rU);
    initialize();
}
FScaffer_F6::FScaffer_F6(const int rId,  char *rName, double *rL, double *rU):BenchmarkFunction(rId, 2, rName){

    setSearchRange<double>(rL,rU);
    initialize();
}
FScaffer_F6::~FScaffer_F6(){
    //dtor
}

void FScaffer_F6::initialize(){

    setOriginalGlobalOpt();
    setGlobalOpt();
    setAccuracy(1.0e-2);

}

double FScaffer_F6::evaluate_(double const *x){

	double fitness=0;
	fitness=0.5+(sin(sqrt(x[0]*x[0]+x[1]*x[1]))*sin(sqrt(x[0]*x[0]+x[1]*x[1]))-0.5)/((1+0.001*(x[0]*x[0]+x[1]*x[1]))*(1+0.001*(x[0]*x[0]+x[1]*x[1])));

	 return fitness+m_bias;

}
