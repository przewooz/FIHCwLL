# include "Matrix.h"
#include "Global.h"

Matrix::Matrix():cow(Global::g_dimNumber),row(Global::g_dimNumber){
	if(row==0) return;
	vec=new MyVector[row];
	for(int i=0;i<row;i++)
		vec[i].Initialization(cow);

}
Matrix::Matrix(const int c, const int r):cow(c),row(r){
	vec=new MyVector[row];
	for(int i=0;i<row;i++)
		vec[i].Initialization(cow);

}
void Matrix::Set_Data(const double *d,const int &c,const int &r){
	if(r!=row) return;
	for(int i=0;i<row;i++)
		for(int j=0;j<cow;j++)
			vec[i].data[j]=d[j];
}
void Matrix::Set_Data(const double * const * d){
	for(int i=0;i<row;i++)
		for(int j=0;j<cow;j++)
			vec[i].data[j]=d[i][j];
}
Matrix::~Matrix(){
	delete [] vec;
	vec=0;
}
void Matrix::operator *(const Matrix &m){

	if(cow!=m.row) Throw(Logic_error("can not *, cow of 1st matrix must be equal to row of 2nd matrix"));

	Matrix r(m.cow,row);
	for(int i=0;i<row;i++){
		for(int j=0;j<m.cow;j++){
			r.vec[i].data[j]=0;
			for(int k=0;k<cow;k++)
				r.vec[i].data[j]+=vec[i].data[k]*m.vec[k].data[j];
		}
	}
	*this=r;
}
void Matrix::operator *(const double x){
	for(int i=0;i<row;i++){
		for(int j=0;j<cow;j++){
			vec[i].data[j]*=x;
		}
	}

}
Matrix&Matrix::operator =(const Matrix &m){
	if(row!=m.row||cow!=m.cow) return *this;
	if(this==&m) return *this;
	for(int i=0;i<row;i++)
		for(int j=0;j<cow;j++)
			vec[i].data[j]=m.vec[i].data[j];
	return *this;
}
bool Matrix::Identity(){
	if(row!=cow) return false;
	for(int i=0;i<row;i++)
		for(int j=0;j<cow;j++)
			vec[i].data[j]= (j==i);

	return true;
}
bool Matrix::isIdentity(){
    if(row!=cow) return false;
    for(int i=0;i<row;i++){
        for(int j=0;j<cow;j++) {
        if(vec[i].data[j]!=(i==j)){
                return false;
            }
        }
    }
    return true;
}
void Matrix::Diagonal(const double CondiNum ){
	if(row!=cow) Throw(Logic_error("can not be diagonal, matrix must be squre"));

	double min,max;
	double *r=new double[row];
	for(int i=0;i<row;i++)	r[i]=gRandFloat(1,row,false);

	min=max=r[0];
	for(int i=0;i<row;i++)	{
		if(min>r[i])min=r[i];
		if(max<r[i]) max=r[i];
	}
	for(int i=0;i<row;i++)
		for(int j=0;j<cow;j++)
			if(j!=i) vec[i].data[j]=0.;
			else vec[i].data[j]=pow(CondiNum,(r[i]-min)/(max-min));
	delete []r;
}
void Matrix::InitialToZero(){
	for(int i=0;i<row;i++)
		for(int j=0;j<cow;j++)
			vec[i].data[j]=0.;
}
void Matrix::Set_Rotation(const int &r, const int &c,const double &angle){
	Identity();
	vec[r].data[r]=cos(angle);
	vec[r].data[c]=-sin(angle);
	vec[c].data[r]=sin(angle);
	vec[c].data[c]=cos(angle);
}


void Matrix::GenerateRotationMatrix(const double CondiNum,bool rMode){

	Matrix ortholeft,orthoright,diagonal;
	ortholeft.Randomize(rMode);
	ortholeft.Orthonormalization();
	orthoright.Randomize(rMode);
	orthoright.Orthonormalization();
	diagonal.Diagonal(CondiNum);
	ortholeft*diagonal;
	ortholeft*orthoright;
	*this=ortholeft;

}
void Matrix::Randomize(bool rMode){
	for(int i=0;i<row;i++)
		for(int j=0;j<cow;j++)
			vec[i].data[j]=gRandFloat(-1,1,rMode);
}
void Matrix::Orthonormalization(){
	if(row!=cow) Throw(Logic_error("can not orthonormalization, matrix must be squre"));

	MyVector t1(cow),t2(cow);
	//Gram�Schmidt process
	for(int i=1;i<row;i++){
		t1=vec[i];
		t2=vec[i];
		for(int j=0;j<i;j++){
			t1.ProjectionToV(vec[j]);
			t2-t1;
			t1=vec[i];
		}
		vec[i]=t2;
	}
	// Normalization each vector
	for(int i=0;i<row;i++) vec[i].Normalization();
}
void Matrix::Transpose(){
	double t;
	for(int i=0;i<row;i++)
		for(int j=0;j<i;j++){
			t=vec[i].data[j];
			vec[i].data[j]=vec[j].data[i];
			vec[j].data[i]=t;
		}

}

