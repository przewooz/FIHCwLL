/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 11 May 2011
// Last modified:




#include "Global.h"

int  Global::g_dimNumber;

Cauchy *Global::gp_cauchyPro;
Normal *Global::gp_normalPro;
Uniform *Global::gp_uniformPro;
Levy *Global::gp_levyPro;
Cauchy *Global::gp_cauchyAlg;
Normal *Global::gp_normalAlg;
Uniform *Global::gp_uniformAlg;
Levy *Global::gp_levyAlg;

ProblemTag Global::g_proNumber;
AlgorithmTag  Global::g_algNumber;
Problem *Global::gp_problem=0;
Algorithm *Global::gp_algorithm=0;

float Global::g_sigma=0.0001;

int Global::g_numRuns;
int Global::g_tEvals;
int Global::g_changeFre;
int Global::g_sampleFre;
int Global::g_runIdx=0;

int Global::g_gPopsize;
int Global::g_subSize;
float Global::g_overlapDegree;
float Global::g_diversityDegree;


void gInitializeRandomArray(int * a,const int &dim,const bool mode){
	int * temp=new int[dim];
	for(int i=0;i<dim;i++)	temp[i]=i;
	int d=dim;
	for(int i=0;i<dim;i++){
		int t;
		if(mode)t=	(int)(d*Global::gp_uniformAlg->Next());
		else t=	(int)(d*Global::gp_uniformPro->Next());
		a[i]=temp[t];
		for(int k=t;k<d-1;k++)
			temp[k]=temp[k+1];
		d--;
	}
	delete []temp;
}

int gSign(const double x){
	if(x>0) return 1;
	else if(x<0) return -1;
	else return 0;
}

int gRandInt( const int min, const int max,const bool mode){
	if(mode)
	return static_cast<int>(min+(max-min)*Global::gp_uniformAlg->Next());
	else
	return static_cast<int>(min+(max-min)*Global::gp_uniformPro->Next());
}
double gRandFloat(const double min, const double max,const bool mode){
	if(mode)
	return min+(max-min)*Global::gp_uniformAlg->Next();
	else
		return min+(max-min)*Global::gp_uniformPro->Next();

}
void gCreateRandPro(double seed){

	 Global::gp_cauchyPro=new Cauchy(seed);
	 Global::gp_normalPro=new Normal(seed);
	 Global::gp_uniformPro=new Uniform(seed);
	 Global::gp_levyPro=new Levy(1.4,seed);

}
void gCreateRandAlg(double seed){

	 Global::gp_cauchyAlg=new Cauchy(seed);
	 Global::gp_normalAlg=new Normal(seed);
	 Global::gp_uniformAlg=new Uniform(seed);
	 Global::gp_levyAlg=new Levy(1.4,seed);;

}
void gDeleteRandPro(){
	delete  Global::gp_cauchyPro;
	delete 	Global::gp_normalPro;
	delete 	Global::gp_uniformPro;
	delete 	Global::gp_levyPro;

}


void gDeleteRandAlg(){

	delete 	Global::gp_cauchyAlg;
	delete 	Global::gp_normalAlg;
	delete 	Global::gp_uniformAlg;
	delete 	Global::gp_levyAlg;
}

bool gIsTerminate(){
    if(Global::gp_problem->getEvaluations()>=Global::g_tEvals) return true;
    else return false;
}
bool gIsDynamicAlg(){
	if(Global::g_algNumber==ALG_CPSO||Global::g_algNumber==ALG_CPSOR||Global::g_algNumber==ALG_CDER||Global::g_algNumber==ALG_ESCA)
	return true;
	else return false;
}
