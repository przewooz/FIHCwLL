#include "LinkageImproverOptimizer.h"
#include "P3.h"

#include "CommandParam.h"
#include "FloatCommandParam.h"
#include "UIntCommandParam.h"
#include "StringUtils.h"

#include <algorithm>
#include <functional>
#include <vector>


using namespace LinkImproverOpt;

//---------------------------------------------CLinkageImproverOptimizer-------------------------------------------------------
uint32_t CLinkageImproverOptimizer::iERROR_PARENT_CLinkImprove_Optimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_CLinkImprove_Optimizer");
uint32_t CLinkageImproverOptimizer::iERROR_CODE_CLinkImprove_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_CLinkImprove_GENOTYPE_LEN_BELOW_0");



CLinkageImproverOptimizer::CLinkageImproverOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{

}//CLinkageImproverOptimizer::CLinkageImproverOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



CLinkageImproverOptimizer::CLinkageImproverOptimizer(CLinkageImproverOptimizer *pcOther) : CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "Implementation missing: CLinkageImproverOptimizer::CLinkageImproverOptimizer(CLinkageImproverOptimizer *pcOther) : CBinaryOptimizer(pcOther)", "No implementation", MB_OK);
}//CLinkageImproverOptimizer::CLinkageImproverOptimizer(CLinkageImproverOptimizer *pcOther) : CBinaryOptimizer(pcOther)


CLinkageImproverOptimizer::~CLinkageImproverOptimizer()
{
	delete  pc_linkage_optimizer;
	delete  pc_optimizer;
}//CLinkageImproverOptimizer::~CLinkageImproverOptimizer()


void  CLinkageImproverOptimizer::vExecuteBeforeEnd()
{
	//prw remove 2020.12.30
	if  (pc_linkage_optimizer->pcGetAnalyzer()->dGetOutsideLinkageQuality() >= 0)
		pc_linkage_optimizer->pcGetAnalyzer()->vCreatePairsReportAndFlushDependentPairs();
	else
	{
		if (i_mode == LINKAGE_IMPROVER_MODE_STANDARD)  pc_linkage_optimizer->vReportLinkage();
	}//else  if  (pc_linkage_optimizer->pcGetAnalyzer()->dGetOutsideLinkageQuality() >= 0)
	pc_optimizer->vReportLinkage();
}//void  CLinkageImproverOptimizer::vExecuteBeforeEnd()




CString  CLinkageImproverOptimizer::sLinkageSummaryReport()
{
	CString  s_res;
	CString  s_link_optimizer, s_optimizer;

	
	s_link_optimizer = pc_linkage_optimizer->sLinkageSummaryReport();
	s_optimizer = pc_optimizer->sLinkageSummaryReport();
	
	//s_res = "Optimizer:" + s_optimizer + "\t LinkOpt: <empty!!!>\t";// +s_link_optimizer;
	//s_res = "Optimizer:" + s_optimizer + "\t LinkOpt: \t" + s_link_optimizer;
	s_res = s_optimizer;

	return(s_res);
};//CString  CLinkageImproverOptimizer::sLinkageSummaryReport()



CError CLinkageImproverOptimizer::eConfigure(istream *psSettings)
{
	CError  c_err(iERROR_PARENT_CLinkImprove_Optimizer);
	CString  s_buf;

	c_err = CBinaryOptimizer::eConfigureLinkageImprover(psSettings);

	i_mode = LINKAGE_IMPROVER_MODE_STANDARD;
	if (!c_err)
	{
		CUIntCommandParam p_max_pyramid_level(LINKAGE_IMPROVER_ARGUMENT_MODE, false);

		i_mode = p_max_pyramid_level.iGetValue(psSettings, &c_err);
		if (p_max_pyramid_level.bHasValue() == false)  i_mode = LINKAGE_IMPROVER_MODE_STANDARD;
	}//if (!c_error)


	pc_linkage_optimizer = new CP3(pc_problem, pc_log, i_random_seed);
	c_err = pc_linkage_optimizer->eConfigure(psSettings);
	if (c_err)  return(c_err);

	pc_optimizer = OptimizerUtils::pcGetOptimizer(pc_problem, pc_log, i_random_seed, psSettings, &c_err, true);
	if (c_err)  return(c_err);

	return(c_err);
}//CError CLinkageImproverOptimizer::eConfigure(istream *psSettings)



void CLinkageImproverOptimizer::vInitialize()
{
	CBinaryOptimizer::vInitialize();
	c_optimizer_timer.vSetStartNow();

	CError  c_err(iERROR_PARENT_CLinkImprove_Optimizer);
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	if (i_templ_length <= 0)
	{
		c_err.vSetError(CLinkageImproverOptimizer::iERROR_CODE_CLinkImprove_GENOTYPE_LEN_BELOW_0);
		return;
	}//if  (i_templ_length  <=  0)


	pc_log->vPrintLine("Initializing...", true);

	pc_linkage_optimizer->vInitialize();
	pc_linkage_optimizer->vSetNoBiasLinkageImprover(true);
	pc_linkage_optimizer->vSetImproverInfo(true);

	pc_optimizer->vInitialize();
	pc_optimizer->vSetImproverInfo(false);


	pc_log->vPrintLine("DONE...", true);

	d_ffe_linkage_optimizer = 0;
	d_ffe_optimizer = 0;

	c_time_counter.vSetStartNow();
	c_linkage_test_report_period.vSetStartNow();
}//void CLinkageImproverOptimizer::vInitialize(time_t tStartTime);



bool CLinkageImproverOptimizer::b_update_best_individual(uint32_t iIterationNumber, COptimizer<CBinaryCoding, CBinaryCoding> *pcOptimizer)
{
	bool  b_res;

	CBinaryCoding *pc_genotype;
	pc_genotype = pcOptimizer->pcGetBestIndividual()->pcGetGenotype();


	double  d_fit;
	d_fit = pc_problem->pcGetEvaluation()->dEvaluate(pc_genotype);
	b_res = CBinaryOptimizer::b_update_best_individual(iIterationNumber, pc_genotype->piGetBits(), d_fit);

	return(b_res);
}//bool CLinkageImproverOptimizer::b_update_best_individual(COptimizer<CBinaryCoding, CBinaryCoding>  pcOptimizer) 


bool CLinkageImproverOptimizer::bRunIteration(uint32_t iIterationNumber)
{
	double  d_ffe_start, d_ffe_end;

	CString  s_buf;
	

	//s_buf.Format("LIquality: %.2lf  OptimizerQuality: %.2lf", pc_linkage_optimizer->pcGetAnalyzer()->dGetOutsideLinkageQuality(), pc_optimizer->pcGetAnalyzer()->dGetOutsideLinkageQuality());
	//::Tools::vShow(s_buf);
	


	if (i_mode == LINKAGE_IMPROVER_MODE_STANDARD)
	{
		s_buf.Format("linkOpt: %.0lf / Opt: %.0lf", d_ffe_linkage_optimizer, d_ffe_optimizer);
		pc_log->vPrintLine(s_buf, true);

		d_ffe_start = pc_problem->pcGetEvaluation()->iGetFFE();


		if (d_ffe_linkage_optimizer <= d_ffe_optimizer)
			//if (1==1)asd
			//if (d_ffe_linkage_optimizer <= 750100100)
		{
			pc_linkage_optimizer->bRunIteration(iIterationNumber);
			b_update_best_individual(iIterationNumber, pc_linkage_optimizer);

			d_ffe_end = pc_problem->pcGetEvaluation()->iGetFFE();

			d_ffe_linkage_optimizer += d_ffe_end - d_ffe_start;
		}//if (d_ffe_linkage_optimizer <= d_ffe_optimizer)asdasd
		else
		{
			pc_optimizer->bRunIteration(iIterationNumber);
			pc_optimizer->bRunIterationSeparateLinkage(iIterationNumber, pc_linkage_optimizer->pcGetAnalyzer());

			b_update_best_individual(iIterationNumber, pc_optimizer);

			d_ffe_end = pc_problem->pcGetEvaluation()->iGetFFE();

			d_ffe_optimizer += d_ffe_end - d_ffe_start;
		}//else  if (d_ffe_linkage_optimizer <= d_ffe_optimizer)
	}//if (i_mode == LINKAGE_IMPROVER_MODE_STANDARD)


	if (i_mode == LINKAGE_IMPROVER_MODE_OUTSIDE_LINKAGE)
	{
		if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetDSM_Sets()->size() == 0)
		{
			pc_linkage_optimizer->bRunIteration(iIterationNumber);


			pc_linkage_optimizer->pcGetAnalyzer()->vSetOutsideLinkage(0, 1, i_templ_length);


			//pc_linkage_optimizer->pcGetAnalyzer()->vCreatePairsReportAndFlushDependentPairs();
			//pc_linkage_optimizer->pcGetAnalyzer()->vSaveLinkageReportJOINT("________testLink_JOINT.txt");
			//pc_linkage_optimizer->pcGetAnalyzer()->vSaveLinkageReport("________testLink3.txt", "OUtside");
		}//if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetDSM_Sets()->size() == 0)


		


		//::Tools::vShow("DONE");
		if (pc_optimizer->pcGetAnalyzer() == NULL)
		{
			//PRW 2022.05.24: only for dsmga2
			pc_optimizer->bRunIterationSeparateLinkage(iIterationNumber, pc_linkage_optimizer->pcGetAnalyzer());
		}//if (pc_optimizer->pcGetAnalyzer() == NULL)
		else
		{
			if (pc_optimizer->pcGetAnalyzer()->iGetOutsideLinkageMode() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_FIXED_LINKAGE)
				pc_optimizer->bRunIterationSeparateLinkage(iIterationNumber, pc_linkage_optimizer->pcGetAnalyzer());
			else
				pc_optimizer->bRunIterationSeparateLinkage(iIterationNumber, pc_optimizer->pcGetAnalyzer());
		}//else  if (pc_optimizer->pcGetAnalyzer() == NULL)
		
		b_update_best_individual(iIterationNumber, pc_optimizer);
	}//if (i_mode == LINKAGE_IMPROVER_MODE_OUTSIDE_LINKAGE)


	if (i_mode == LINKAGE_IMPROVER_MODE_TEST_LINKAGE)
	{
		bool  b_run_finish = false;

		pc_stop_condition->vSetIgnoreOptimalAtStop(true);
		
		pc_linkage_optimizer->bRunIteration(iIterationNumber);
		b_update_best_individual(iIterationNumber, pc_linkage_optimizer);
		pc_linkage_optimizer->pcGetAnalyzer()->vUpdateSingleMemorySet();
		
		if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->size() > 0)
		{
			if (c_linkage_test_report_period.dGetTimePassed() > LINKAGE_IMPROVER_MODE_TEST_LINKAGE_REPORT_LINK_QUALITY_INTERVAL_SECONDS)
			{
				s_buf.Format("minFILL: min:%.2lf avr:%.2lf med:%.2lf", pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(0)->d_fill_min, pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(0)->d_fill_avr, pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(0)->d_fill_median);
				pc_log->vPrintLine(s_buf, true);
				c_linkage_test_report_period.vSetStartNow();
			}//if  (c_linkage_test_report_period.dGetTimePassed() > LINKAGE_IMPROVER_MODE_TEST_LINKAGE_REPORT_LINK_QUALITY_INTERVAL_SECONDS)

			if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(0)->d_fill_min >= 1)
			{
				s_buf.Format("minFILL: min:%.2lf avr:%.2lf med:%.2lf", pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(0)->d_fill_min, pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(0)->d_fill_avr, pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(0)->d_fill_median);
				pc_log->vPrintLine(s_buf, true);
				c_linkage_test_report_period.vSetStartNow();

				b_run_finish = true;
			}//if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->size() - 1)->d_fill_min >= 1)
		}//if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->size() > 0)

		if (b_run_finish == true)
		{
			//pc_linkage_optimizer->pcGetAnalyzer()->vSaveLinkageReport("Improver"+ pc_log->sGetLogFile(), "");
			//pc_linkage_optimizer->vReportPopStats("Improver_popSTATS_" + pc_log->sGetLogFile() + ".txt");

			/*CBinaryCoding c_genotype(i_templ_length);
			double  d_fit;

			for (int ii = 0; ii < i_templ_length; ii++)
				c_genotype.piGetBits()[ii] = ii % 1;

			d_fit = pc_problem->pcGetEvaluation()->dEvaluate(&c_genotype);
*/
			

			pc_optimizer->bRunIteration(iIterationNumber);
			//b_update_best_individual(iIterationNumber, tStartTime, pc_optimizer);
			//CBinaryOptimizer::b_update_best_individual(iIterationNumber, tStartTime, c_genotype.piGetBits(), d_fit);
			pc_stop_condition->vSetStopNow(true);
		}//if (b_run_finish == true)

		
		/*bool  b_run_iteration;

		b_run_iteration = true;
		if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->size() > 0)
		{
			if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->size() - 1)->d_fill_min >= 1)
			{
				b_run_iteration = false;
			}//if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->at(pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->size() - 1)->d_fill_min >= 1)
		}//if (pc_linkage_optimizer->pcGetAnalyzer()->pvGetMemorySets()->size() > 0)

		if (b_run_iteration == true)
		{
			pc_linkage_optimizer->bRunIteration(iIterationNumber, tStartTime);
			b_update_best_individual(iIterationNumber, tStartTime, pc_linkage_optimizer);
		}//if (b_run_iteration == true)
		else
		{

			CBinaryCoding c_genotype(i_templ_length);
			double  d_fit;

			for (int ii = 0; ii < i_templ_length; ii++)
				c_genotype.piGetBits()[ii] = 1;

			d_fit = pc_problem->pcGetEvaluation()->dEvaluate(&c_genotype);

			CBinaryOptimizer::b_update_best_individual(iIterationNumber, tStartTime, c_genotype.piGetBits(), d_fit);

		}//else  if (b_run_iteration == true)*/
	}//if (i_mode == LINKAGE_IMPROVER_MODE_TEST_LINKAGE)

	


	
	
	/*//LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_NONE
	if ( (pc_linkage_optimizer->pcGetAnalyzer()->iGetPairsDetection(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_NONE) > 0)|| (pc_linkage_optimizer->pcGetAnalyzer()->iGetPairsDetection(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_NONE) ==  -1) )
	{
		pc_linkage_optimizer->bRunIteration(iIterationNumber, tStartTime);
		b_update_best_individual(iIterationNumber, tStartTime, pc_linkage_optimizer);
	}//if (pc_linkage_optimizer->pcGetAnalyzer()->iGetPairsDetection(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_NONE) > 0)
	else
	{
		pc_log->vPrintLine("LINKAGE IMPROVEMENT ENDED");
		//pc_optimizer->bRunIteration(iIterationNumber, tStartTime);

		pc_optimizer->bRunIterationSeparateLinkage(iIterationNumber, tStartTime, pc_linkage_optimizer->pcGetAnalyzer());

		b_update_best_individual(iIterationNumber, tStartTime, pc_optimizer);
	}//else  if (pc_linkage_optimizer->pcGetAnalyzer()->iGetPairsDetection(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_NONE) > 0)*/

	return(true);
}//bool CLinkageImproverOptimizer::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

