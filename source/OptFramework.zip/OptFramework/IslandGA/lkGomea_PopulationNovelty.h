#pragma once

#include <cmath>
#include <iostream> 
#include <vector>
using namespace std;

#include "lkGomea_Individual.h"
#include "lkGomea_Config.h"
#include "lkGomea_shared.h"
#include "lkGomea_problems.h"
#include "lkGomea_FOS.h"
#include "lkGomea_PopulationNovelGeneral.h"

class C_lkGomea_PopulationNovelty: public C_lkGomea_PopulationNovelGeneral
{
public:

	C_lkGomea_PopulationNovelty(C_lkGomea_Config *config_, C_lkGomea_Problem *problemInstance_, C_lkGomea_sharedInformation *sharedInformationPointer_, size_t populationIndex_, size_t populationSize_):
		C_lkGomea_PopulationNovelGeneral(config_, problemInstance_, sharedInformationPointer_, populationIndex_, populationSize_){};
	
	~C_lkGomea_PopulationNovelty();

	bool  b_makeOffspring();
	void generateOffspring();
	bool b_learnFOS(C_lkGomea_FOS *FOSInstance);
	bool b_learnIndividualFOS(C_lkGomea_FOS *FOSInstance, size_t population_idx);
	bool b_learnClusterFOS(C_lkGomea_FOS *FOSInstance, size_t population_idx);
	bool b_learnIndividualBootstrapFOS(C_lkGomea_FOS *FOSInstance, size_t population_idx);
	bool GOM(size_t offspringIndex, C_lkGomea_Individual *backup);
	bool conditionalGOM(size_t offspringIndex, C_lkGomea_Individual *backup, vector<vector<int> > &neighbors);

};