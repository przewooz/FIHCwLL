#include <iostream>
#include <fstream>
using namespace std;

#include "lkGomea_gomeaLSNoveltyIMS.h"
#include "lkGomea_utils.h"

C_lkGomea_gomeaLSNoveltyIMS::C_lkGomea_gomeaLSNoveltyIMS(C_lkGomea_Config *config_): C_lkGomea_GOMEA(config_)
{
  //prepareFolder(config->folder);
  //initElitistFile(config->folder, config->populationScheme, config->populationSize);
  config->writeOverviewToFile();

  maximumNumberOfGOMEAs         = config->maximumNumberOfGOMEAs;
  IMSsubgenerationFactor        = config->IMSsubgenerationFactor;
  basePopulationSize            = config->basePopulationSize;
  subscheme                     = config->populationScheme;
  currentPopulationSize         = basePopulationSize;
  currentRunCount               = 1;
  numberOfGOMEAs                = 0;
  numberOfGenerationsIMS        = 0;
  minimumGOMEAIndex             = 0;
  numberOfGenerationsIMS        = 0;
  generationsWithoutImprovement = 0;
  step                          = 0;

  createProblemInstance(config->problemIndex, config->numberOfVariables, config, &problemInstance, config->problemInstancePath);
  #ifdef DEBUG
    cout << "Problem Instance created! Problem number is " << config->problemIndex << endl;
  #endif

  sharedInformationInstance = new C_lkGomea_sharedInformation(config->maxArchiveSize);
  #ifdef DEBUG
    cout << "Shared Information instance created!\n";
  #endif

  //if (config->useVTR)
  //  sharedInformationInstance->vtr = readVTR();

}

C_lkGomea_gomeaLSNoveltyIMS::~C_lkGomea_gomeaLSNoveltyIMS()
{
  for (int i = 0; i < numberOfGOMEAs; ++i)
    delete GOMEAs[i];

  delete problemInstance;
  delete sharedInformationInstance;
}



bool C_lkGomea_gomeaLSNoveltyIMS::bRunSingleIteration()
{
	if (numberOfGOMEAs < maximumNumberOfGOMEAs || (subscheme == -2 && numberOfGOMEAs * currentRunCount < maximumNumberOfGOMEAs))
	{
		initializeNewGOMEA();
	}
	if (b_generationalStepAllGOMEAs() == false)  return(false);

	numberOfGenerationsIMS++;

	return(true);
}//void C_CGomea_gomeaP3_MI::vRunSingleIteration()


C_lkGomea_Individual  *C_lkGomea_gomeaLSNoveltyIMS::pcGetBestInd()
{
	if (this->sharedInformationInstance == NULL)  return(NULL);
	return(&(this->sharedInformationInstance->elitist));
}//C_lkGomea_Individual  *C_CGomea_gomeaP3_MI::pcGetBestInd()


bool C_lkGomea_gomeaLSNoveltyIMS::b_run()
{
  #ifdef DEBUG
    cout << "IMS started!\n";
  #endif

  bool emittedMaxGomeasHit = false;

  while(!checkTermination())
  {
    if (numberOfGOMEAs < maximumNumberOfGOMEAs || (subscheme == -2 && numberOfGOMEAs * currentRunCount < maximumNumberOfGOMEAs))
    {
      initializeNewGOMEA();
    }
    else if (!emittedMaxGomeasHit)
    {
      cout << "Hit maximum number of simultaneous GOMEAs" << endl;
      emittedMaxGomeasHit = true;
    }

	if (b_generationalStepAllGOMEAs() == false)  return(false);

    numberOfGenerationsIMS++;
  }

  return(true);
}

bool C_lkGomea_gomeaLSNoveltyIMS::checkTermination()
{
  int i;

  if (numberOfGOMEAs == maximumNumberOfGOMEAs)
  {
    for (i = 0; i < maximumNumberOfGOMEAs; i++)
    {
      if (!GOMEAs[i]->terminated)
        return false;
    }

    return true;
  }
  
  return false;
}

void C_lkGomea_gomeaLSNoveltyIMS::initializeNewGOMEA()
{
  #ifdef DEBUG
    cout << "Current number Of GOMEAs is " << numberOfGOMEAs << " | Creating New GOMEA!\n";
  #endif


  C_lkGomea_PopulationNovelty *newPopulation = NULL;
  for (size_t i = 0; i < currentRunCount; ++i)
  {
    newPopulation = new C_lkGomea_PopulationNovelty(config, problemInstance, sharedInformationInstance, numberOfGOMEAs, currentPopulationSize);
    
    GOMEAs.push_back(newPopulation);
    numberOfGOMEAs++;
  }

  if (subscheme >= -1)
  {
    this->currentPopulationSize *= 2;
  }
  else if (subscheme == -2)
  {
    if (step % 2 == 0)
    {
      this->currentPopulationSize *= 2;
    }
    else
    {
      this->currentRunCount *= 2;
      // this->currentPopulationSize += this->currentPopulationSize / 2;
      this->currentPopulationSize += 16;
    }
  }

  step += 1;
}

bool C_lkGomea_gomeaLSNoveltyIMS::b_generationalStepAllGOMEAs()
{
  int GOMEAIndexSmallest, GOMEAIndexBiggest;

  GOMEAIndexBiggest  = numberOfGOMEAs - 1;
  GOMEAIndexSmallest = 0;
  while(GOMEAIndexSmallest <= GOMEAIndexBiggest)
  {
    if (!GOMEAs[GOMEAIndexSmallest]->terminated)
      break;

    GOMEAIndexSmallest++;
  }

  if (subscheme == -1)
  {
	  if (b_generationalStepSmallestGOMEAUntilAllTerminated(GOMEAIndexSmallest, GOMEAIndexBiggest) == false)  return(false);
  }
  else if (subscheme >= 0)
  {
	  if (b_GOMEAGenerationalStepAllGOMEAsRecursiveFold(GOMEAIndexSmallest, GOMEAIndexBiggest) == false)  return(false);
  }
  else if (subscheme == -2)
  {
	  if (b_generationalStepAllEvenlyGOMEAUntilAllTerminated(GOMEAIndexSmallest, GOMEAIndexBiggest) == false)  return(false);
  }

  return(true);
}

bool C_lkGomea_gomeaLSNoveltyIMS::b_generationalStepSmallestGOMEAUntilAllTerminated(int GOMEAIndexSmallest, int GOMEAIndexBiggest)
{
  for (int GOMEAIndex = GOMEAIndexSmallest; GOMEAIndex <= GOMEAIndexBiggest; ++GOMEAIndex)
  {
    cout << "Starting population of size: " << GOMEAs[GOMEAIndex]->populationSize << "." << endl;
    while (!GOMEAs[GOMEAIndex]->terminated)
    {
      GOMEAs[GOMEAIndex]->calculateAverageFitness();
      double fitness_before = sharedInformationInstance->elitist.fitness;

	  if (GOMEAs[GOMEAIndex]->b_makeOffspring() == false)  return(false);

      GOMEAs[GOMEAIndex]->copyOffspringToPopulation();

      GOMEAs[GOMEAIndex]->endGeneration();

      GOMEAs[GOMEAIndex]->calculateAverageFitness();
      double fitness_after = sharedInformationInstance->elitist.fitness;

      GOMEAs[GOMEAIndex]->numberOfGenerations++;

      GOMEAs[GOMEAIndex]->terminated = checkTerminationGOMEA(GOMEAIndex);

      if (GOMEAs[GOMEAIndex]->numberOfGenerations >= config->maxGenerations)
      {
        cout << "Max Generations hit!" << endl;
        GOMEAs[GOMEAIndex]->terminated = true;
      }
    }
  }

  return(true);
}

bool C_lkGomea_gomeaLSNoveltyIMS::b_generationalStepAllEvenlyGOMEAUntilAllTerminated(int GOMEAIndexSmallest, int GOMEAIndexBiggest)
{
  bool any_unterminated = true;
  cout << "Starting population of size " << currentPopulationSize << " and " << currentRunCount << " simultaneous runs." << endl;

  if (GOMEAIndexSmallest > GOMEAIndexBiggest)
  {
    cout << "!!!" << endl;
    exit(1);
  }

  while (any_unterminated)
  {
    any_unterminated = false;
    for (int GOMEAIndex = GOMEAIndexSmallest; GOMEAIndex <= GOMEAIndexBiggest; ++GOMEAIndex)
    {
      any_unterminated |= !GOMEAs[GOMEAIndex]->terminated;

      // Skip over terminated subpopulations.
      if (GOMEAs[GOMEAIndex]->terminated) continue;

      GOMEAs[GOMEAIndex]->calculateAverageFitness();
      double fitness_before = sharedInformationInstance->elitist.fitness;

	  if (GOMEAs[GOMEAIndex]->b_makeOffspring() == false)  return(false);

      GOMEAs[GOMEAIndex]->copyOffspringToPopulation();

      GOMEAs[GOMEAIndex]->endGeneration();

      GOMEAs[GOMEAIndex]->calculateAverageFitness();
      double fitness_after = sharedInformationInstance->elitist.fitness;

      GOMEAs[GOMEAIndex]->numberOfGenerations++;

      GOMEAs[GOMEAIndex]->terminated = checkTerminationGOMEA(GOMEAIndex);

      if (GOMEAs[GOMEAIndex]->numberOfGenerations >= config->maxGenerations)
      {
        cout << "Max Generations hit!" << endl;
        GOMEAs[GOMEAIndex]->terminated = true;
      }
    }
  }
  return(true);
}

bool C_lkGomea_gomeaLSNoveltyIMS::b_GOMEAGenerationalStepAllGOMEAsRecursiveFold(int GOMEAIndexSmallest, int GOMEAIndexBiggest)
{
  int i, GOMEAIndex;

  for(i = 0; i < IMSsubgenerationFactor-1; i++)
  {
    for(GOMEAIndex = GOMEAIndexSmallest; GOMEAIndex <= GOMEAIndexBiggest; GOMEAIndex++)
    {
      if(!GOMEAs[GOMEAIndex]->terminated)
        GOMEAs[GOMEAIndex]->terminated = checkTerminationGOMEA(GOMEAIndex);

      //#if DEBUG || DEBUG_GOM
      //  cout << "GOMEA #" << GOMEAIndex << " terminated=" << GOMEAs[GOMEAIndex]->terminated << endl;
      //#endif

      if((!GOMEAs[GOMEAIndex]->terminated) && (GOMEAIndex >= minimumGOMEAIndex))
      {
        GOMEAs[GOMEAIndex]->calculateAverageFitness();
        double fitness_before = sharedInformationInstance->elitist.fitness;
        //cout << GOMEAIndex << " | avgFitness " << GOMEAs[GOMEAIndex]->averageFitness << endl;

		if (GOMEAs[GOMEAIndex]->b_makeOffspring() == false)  return(false);

        GOMEAs[GOMEAIndex]->copyOffspringToPopulation();

        GOMEAs[GOMEAIndex]->endGeneration();

        GOMEAs[GOMEAIndex]->calculateAverageFitness();
        double fitness_after = sharedInformationInstance->elitist.fitness;
        //cout <<  GOMEAs[GOMEAIndex]->numberOfGenerations << " " << sharedInformationInstance->numberOfEvaluations / 1000000 << endl;
        // if (fitness_after <= fitness_before)
        // {
        //   //cout << "fitness after " << fitness_after << " equals to fitness before"  << fitness_before << " terminating\n";
        //   generationsWithoutImprovement++;
        //   cout << "generations without improvement: " << generationsWithoutImprovement << endl;
        //   if (generationsWithoutImprovement >= config->maxGenerationsWithoutImprovement)
        //     GOMEAs[GOMEAIndex]->terminated = true;
        // }
        // else
        //   generationsWithoutImprovement = 0;
        // cout << GOMEAIndex << " generation " << GOMEAs[GOMEAIndex]->numberOfGenerations << " | avgFitness " << GOMEAs[GOMEAIndex]->averageFitness << " " << sharedInformationInstance->numberOfEvaluations << endl;

        GOMEAs[GOMEAIndex]->numberOfGenerations++;

        if (GOMEAs[GOMEAIndex]->numberOfGenerations >= config->maxGenerations)
          GOMEAs[GOMEAIndex]->terminated = true;
      }
    }

	for (GOMEAIndex = GOMEAIndexSmallest; GOMEAIndex < GOMEAIndexBiggest; GOMEAIndex++)
	{
		if  (b_GOMEAGenerationalStepAllGOMEAsRecursiveFold(GOMEAIndexSmallest, GOMEAIndex) == false)  return(false);
	}//
  }

  return(true);
}

bool C_lkGomea_gomeaLSNoveltyIMS::checkTerminationGOMEA(int GOMEAIndex)
{
  for (int i = GOMEAIndex+1; i < numberOfGOMEAs; i++)
  {    
    if (GOMEAs[i]->averageFitness > GOMEAs[GOMEAIndex]->averageFitness &&
      abort_smaller_populations_with_worse_average_fitness)
    {
      // cout << "Terminated GOMEA " << GOMEAIndex << " as average fitness " << GOMEAs[GOMEAIndex]->averageFitness << " is worse than population " << i << " with average fitness: " << GOMEAs[GOMEAIndex]->averageFitness << "." << endl;
      minimumGOMEAIndex = GOMEAIndex+1;
      return true;
    }
  }

  if (config->noImprovementStretchLimit > 0)
  {
    for (size_t i = 1; i < GOMEAs[GOMEAIndex]->populationSize; i++)
    {
      if (GOMEAs[GOMEAIndex]->noImprovementStretches[i] < config->noImprovementStretchLimit)
      {
        return false;
      }
    }
    // Maybe!
    cout << "Improvement Stretch Limit hit!" << endl;
    return true;
  }

  for (size_t i = 1; i < GOMEAs[GOMEAIndex]->populationSize; i++)
  {
    auto individual = GOMEAs[GOMEAIndex]->population[i];
    auto individual_n = GOMEAs[GOMEAIndex]->getPopulationGraphForIndex(i);
	C_lkGomea_Individual *reference;
    
    if (perform_cluster_aware_convergence_detection)
    {
      if (individual_n.size() == 0)
      {
        // std::cout << "Missing neighborhood..." << std::endl;
        continue;
      }
      else
      {
        reference = GOMEAs[GOMEAIndex]->population[individual_n[0]];
      }
    }
    else
    {
      reference = GOMEAs[GOMEAIndex]->population[0];
    }

    for (size_t j = 0; j < config->numberOfVariables; j++)
    {
      if (individual->genotype[j] != reference->genotype[j])
        return false;
    }
  }

  cout << "CONVERGED!\n";
  return true;
}
