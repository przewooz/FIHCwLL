#ifndef GENE_PATTERN_TREE_H
#define GENE_PATTERN_TREE_H

#include "GenePattern.h"

#include <cstdint>
#include <utility>
#include <vector>

using namespace std;

namespace Linkage
{
	class CGenePatternTree
	{
	public:
		CGenePatternTree(vector<pair<uint32_t, uint32_t>*> *pvClusterIndexes);
		CGenePatternTree(uint16_t iSignificantIndex, vector<pair<uint32_t, uint32_t>*> *pvClusterIndexes);
		
		~CGenePatternTree();

		CGenePattern *pcGetClosestGenePattern(CGenePattern *pcGenePattern, uint16_t iMaxSize = UINT16_MAX);
		CGenePattern *pcGetClosestGenePattern(vector<uint16_t> *pvGenePatternElements, uint16_t iMaxSize = UINT16_MAX);
		CGenePattern *pcGetClosestGenePattern(uint16_t *piGenePatternElements, uint16_t iNumberOfGenePatternElements, uint16_t iMaxSize = UINT16_MAX);

		vector<CGenePattern*> *pvGetAllGenePatterns() { return &v_all_gene_patterns; }

	private:
		void v_init_leaves(uint16_t iNumberOfLeaves);
		void v_init_nodes(vector<pair<uint32_t, uint32_t>*> *pvClusterIndexes);

		uint16_t i_significant_index;

		vector<CGenePattern*> v_all_gene_patterns;

		CGenePattern *pc_root;
		vector<CGenePattern*> v_leaves;
	};//class CGenePatternTree
}//namespace Linkage

#endif//GENE_PATTERN_TREE_H