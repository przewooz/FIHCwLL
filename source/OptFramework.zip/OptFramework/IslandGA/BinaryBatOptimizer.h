#pragma once
#include "BinaryOptimizer.h"
#include "PopulationSizingOptimizer.h"
#include <random>
#include <vector>

#define BINARY_BAT_OPTIMIZER_ARGUMENT_POPULATION_SIZE "population_size"
#define BINARY_BAT_OPTIMIZER_ARGUMENT_LOUDNESS_A "loudness_A"
#define BINARY_BAT_OPTIMIZER_ARGUMENT_PULSE_RATE_R "pulse_rate_r"
#define BINARY_BAT_OPTIMIZER_ARGUMENT_FREQUENCY_Q_MIN "frequency_q_min"
#define BINARY_BAT_OPTIMIZER_ARGUMENT_FREQUENCY_Q_MAX "frequency_q_max"
#define BINARY_BAT_OPTIMIZER_ARGUMENT_STALE_DETECTION "stale_detection"


class CBinaryBatIndividual;

class CBinaryBatOptimizer : public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>
{
public:
	static uint32_t iERROR_PARENT_CBinaryBatOptimizer;
	static const float F_DEFAULT_LOUDNESS_A;
	static const float F_DEFAULT_PULSE_RATE_R;
	static const float F_DEFAULT_FREQUENCY_Q_MIN;
	static const float F_DEFAULT_FREQUENCY_Q_MAX;
	static const double D_DEFAULT_ALPHA;
	static const double D_DEFAULT_LOWER_BOUND;
	static const double D_DEFAULT_UPPER_BOUND;
	CBinaryBatOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog* pcLog, uint32_t iRandomSeed);


	CBinaryBatOptimizer(CBinaryBatOptimizer* pcOther);
	~CBinaryBatOptimizer();

	COptimizer<CBinaryCoding, CBinaryCoding>* pcCopy() override;

	bool bRunIteration(uint32_t iIterationNumber) override;

	CError eConfigure(istream* psSettings) override;

	CBinaryBatIndividual* pcGetRandomIndividual();

	double dComputeAverageFitnessValue() override;
	bool bIsSteadyState() override;
	uint32_t iGetPopulationSize() override { return i_population_size; }
	void vSetPopulationSize(uint32_t iPopulationSize) override { i_population_size = iPopulationSize; }
	void vDeleteIndividuals();
	void vEvaluate(uint32_t iIterationNumber);
	double dEvaluate(CBinaryBatIndividual& cIndividual);
	void vInitializeIndividuals();
	void vInitialize() override;
	bool bMaybeUpdateBest(CBinaryBatIndividual& cPossiblyNewBest, uint32_t iIterationNumber);
	
protected:
	uniform_real_distribution<double> c_position_distribution;
	uniform_real_distribution<double> c_uniform_zero_one_distribution;
	default_random_engine c_random_engine;

	bool b_is_initialized;
	uint16_t i_genotype_length;
	uint32_t i_population_size;
	double d_loudness_a;
	double d_pulse_rate_r;
	double d_frequency_q_min;
	double d_frequency_q_max;
	double d_lower_bound;
	double d_upper_bound;
	bool b_use_stale_detection;
	vector<CBinaryBatIndividual*> v_population;
	CBinaryBatIndividual* pc_best;
	double d_alpha;
};//class CBinaryBatOptimizer : public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>

class CBinaryBatIndividual
{
public:
	friend class CBinaryBatOptimizer;
	CBinaryBatIndividual(uint16_t iGenotypeLength);
	static CBinaryBatIndividual* pcGetRandomIndividual(
		uint16_t iGenotypeLength, double dFMin, double dFMax,
		double dMaxPulseRateR, double dMaxLoudnessA, uniform_real_distribution<double>& cPositionDistribution,
		uniform_real_distribution<double>& cUniformDistribution, default_random_engine& cRandomEngine);
	void vUpdatePosition();
	void vUpdateVelocity(CBinaryBatIndividual& cGlobalBest);
	void vUpdateFrequency(
		double dFMin, double dFMax, uniform_real_distribution<double>& cUniformDistribution, default_random_engine& cRandomEngine);

	void vUpdatePulseRateR(double dAlpha, double dBasePulseRate, uint32_t iIterationNumber);
	void vUpdateLoudnessA(double dAlpha, double dBaseLoudness);
protected:
	void v_transform_sigmoid(uniform_real_distribution<double>& cThresholdDistribution, default_random_engine& cRandomEngine);
	void v_check_bounds(double dLowerBound, double dUpperBound);
	double d_frequency;
	double d_base_pulse_rate;
	double d_pulse_rate_r;
	double d_loudness_a;
	double d_fitness;
	vector<double> v_position;
	vector<double> v_velocity;
	vector<int32_t> v_genotype;
};//class CBinaryBatIndividual