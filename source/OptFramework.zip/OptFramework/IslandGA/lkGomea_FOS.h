#pragma once

#include <vector>
#include <string>
#include <algorithm>
#include <fstream>
#include <cmath>
#include <deque>
#include <random>
using namespace std;

#include "lkGomea_Individual.h"
#include "lkGomea_utils.h"
#include "lkGomea_problems.h"

class C_lkGomea_FOS
{	
public:
	vector<vector<int> > FOSStructure;	
	size_t numberOfVariables;
	vector<int> alphabetSize;
	vector<vector<int> > graph;
	
	vector<int> improvementCounters;
	vector<int> usageCounters;

	C_lkGomea_FOS(C_lkGomea_Config *config_, size_t numberOfVariables_, vector<int> &alphabetSize_): numberOfVariables(numberOfVariables_), alphabetSize(alphabetSize_)
	{
		config = config_;
	}

	virtual ~C_lkGomea_FOS(){};

	size_t FOSSize()
	{
		return FOSStructure.size();
	}

	size_t FOSElementSize(int i)
	{
		return FOSStructure[i].size();
	}
	
	virtual bool  b_learnFOS(vector<C_lkGomea_Individual*> &population, vector<vector<int> > *VIG = NULL, mt19937 *rng = NULL) = 0;
	void writeToFileFOS(string folder, int populationIndex, int generation);
	void writeFOSStatistics(string folder, int populationIndex, int generation);
	void setCountersToZero();
	void shuffleFOS(vector<int> &indices, mt19937 *rng);
	void sortFOSAscendingOrder(vector<int> &indices);
	void sortFOSDescendingOrder(vector<int> &indices);
	void orderFOS(int orderingType, vector<int> &indices, mt19937 *rng);

	virtual void buildGraph(double thresholdValue, mt19937 *rng){};
	virtual void buildGraphGlobal(double thresholdValue){};

	virtual void writeMIMatrixToFile(string folder, int populationIndex, int generation){};


	
	/* BEGIN: CHANGES FOR MEMORY USAGE REDUCTION */
	virtual void shrinkMemoryUsage(){};
	/* END: CHANGES FOR MEMORY USAGE REDUCTION */

	bool b_checkTimeLimit_OK();

protected:
	C_lkGomea_Config *config;
};

class C_lkGomea_ProblemFOS: public C_lkGomea_FOS
{
public:
	C_lkGomea_ProblemFOS(C_lkGomea_Config *config_, size_t numberOfVariables_, vector<int> &alphabetSize_, C_lkGomea_Problem *problem);
	// FOS is initialized once, using the current problem.
	bool  b_learnFOS(vector<C_lkGomea_Individual*> &population, vector<vector<int> > *VIG = NULL, mt19937 *rng = NULL) { return(true); };
};


class C_lkGomea_LTFOS: public C_lkGomea_FOS
{
private:
	vector<vector<double> > MI_Matrix;
	vector<vector<double> > S_Matrix;
	bool filtered;
	int similarityMeasure;
	int determineNearestNeighbour(int index, vector< vector< int > > &mpm);
	bool b_computeMIMatrix(vector<C_lkGomea_Individual*> &population);
	bool  b_computeNMIMatrix(vector<C_lkGomea_Individual*> &population);
	bool  b_computeRandomMatrix(mt19937 *rng);
	void estimateParametersForSingleBinaryMarginal(vector<C_lkGomea_Individual*> &population, vector<size_t> &indices, size_t  &factorSize, vector<double> &result);
	void prepareMatrices();


public:	
	C_lkGomea_LTFOS(C_lkGomea_Config *config_, size_t numberOfVariables_, vector<int> &alphabetSize_, int similarityMeasure, bool filtered=false);
	~C_lkGomea_LTFOS(){};

	bool b_learnFOS(vector<C_lkGomea_Individual*> &population, vector<vector<int> > *VIG = NULL, mt19937 *rng = NULL);
	void buildGraph(double thresholdValue, mt19937 *rng);
	void buildGraphGlobal(double thresholdValue);
	void buildGraphStatTest(C_lkGomea_solutionsArchive *solutions, double p_value_threshold);
	void writeMIMatrixToFile(string folder, int populationIndex, int generation);
	void shrinkMemoryUsage();
};

bool lkGomea_FOSNameByIndex(size_t FOSIndex, string &FOSName);
void createFOSInstance(C_lkGomea_Config *config_, size_t FOSIndex, C_lkGomea_FOS **FOSInstance, size_t numberOfVariables, vector<int> &alphabetSize, int similarityMeasure, C_lkGomea_Problem *problem);
