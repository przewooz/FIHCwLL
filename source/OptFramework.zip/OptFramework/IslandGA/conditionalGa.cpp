#include "conditionalGa.h"
#include "BinaryEvaluation.h" //temporary



using  namespace nConditionalGA;



uint32_t CConditionalGA::iERROR_PARENT_CConditionalGA = CError::iADD_ERROR_PARENT("iERROR_PARENT_CConditionalGA");
uint32_t CConditionalGA::iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0");


uint32_t CConditionalGASinglePop::iERROR_PARENT_CConditionalGASinglePop = CError::iADD_ERROR_PARENT("iERROR_PARENT_CConditionalGASinglePop");
uint32_t CConditionalGASinglePop::iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0");



//---------------------------------------------CConditionalGA-------------------------------------------------------
CConditionalGA::CConditionalGA(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	i_pop_size = 0;
	pc_evaluation_individual = NULL;
	//pc_best = NULL;
	pc_best_pop = NULL;
	pc_dsm = new CConditionalGA_DSM(this);

	pc_sll_computation = new CLinkageAnalyzer();
	pc_linkage_pack = NULL;

	i_sett_clusters = 0;

	

	pc_sll_computation->bLinkagePackCreate(&pc_linkage_pack);
	pc_evaluation_individual = new CBinaryCoding(pcProblem->pcGetEvaluation()->iGetNumberOfElements());
	pc_linkage_pack->vConfigure(pcProblem->pcGetEvaluation(), pc_log, pc_evaluation_individual);
	//pc_sll_computation->vResetProbabilities(evaluation->iGetNumberOfElements());
};//CConditionalGA::CConditionalGA(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



CConditionalGA::CConditionalGA(CConditionalGA *pcOther) : CBinaryOptimizer(pcOther)
{
	::Tools::vShow("NO IMPLEMENTATION: CConditionalGA::CConditionalGA(CConditionalGA *pcOther)");
}//CConditionalGA::CConditionalGA(CConditionalGASinglePop *pcOther) : CBinaryOptimizer(pcOther)



CConditionalGA::~CConditionalGA()
{
	delete  pc_sll_computation;
	delete  pc_evaluation_individual;
	delete  pc_linkage_pack;
	//if (pc_best != NULL)  delete  pc_best;
	if (pc_best_pop != NULL)  delete  pc_best_pop;
	if (pc_dsm != NULL)  delete  pc_dsm;
	if (pc_base_pop != NULL)  delete  pc_base_pop;

	if  (pc_tool_ind != NULL)  delete  pc_tool_ind;

}//CConditionalGA::~CConditionalGA()


void  CConditionalGA::vInitialize()
{
	c_time_counter.vSetStartNow();
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();
	
	i_next_pop_size = 2;

	pc_dsm->bSetSize(i_templ_length);

	if  (i_sett_perfect_linkage == 1)  pc_dsm->bGetTrueLinkage(pc_problem);

	pc_base_pop = new CConditionalGASinglePop(pc_problem, pc_log, i_random_seed, this);
	//pc_best = new CConditionalGAIndividual(i_templ_length, pc_problem, pc_base_pop);

	pc_best_pop = new CConditionalGASinglePop(pc_base_pop);
	pc_best_pop->vSetPopulationSize(1);
	pc_best_pop->vInitialize();
	pc_best_pop->pc_parent = this;


	pc_tool_ind = new CConditionalGAIndividual(i_templ_length, pc_problem, pc_base_pop);
	pc_tool_ind->vRandomizeGenotype();
	pc_tool_ind->dComputeFitnessOptimize(NULL);


	bool b_updated = b_update_best_individual(0, pc_tool_ind->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_tool_ind->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});


	//pc_dsm->bSave("zzzzz_dsm_test.txt");
	//vSavePopTest();
}//void  CConditionalGA::vInitialize(time_t tStartTime)


void  CConditionalGA::vGetClusters(vector<CConditionalGAIndividual *> *pvPop, CConditionalGAIndividual  *pcIndToOpt, vector<CConditionalGA_Mask *> *pvMasks, bool  bAdd_Sll_Dled)
{
	if (i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_RANDOM)
		v_get_clusters_random(pvMasks);

	if (i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_SLL)
		v_get_clusters_sll(pvMasks, pvPop, false);

	if (i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_CONDITIONAL_SLL_DLED)
		v_get_clusters_sll(pvMasks, pvPop, bAdd_Sll_Dled);  //the population is filtered on the base of DLED



	/*if (pvPop->size() > 10)
	{
		FILE  *pf_test = fopen("zzzzz_conditinnal_masks.txt", "w+");
		for (int ii = 0; ii < pvMasks->size(); ii++)
			pvMasks->at(ii)->vReport(pf_test);
		fclose(pf_test);
		::Tools::vShow("CConditionalGA::vGetClusters");//
	}//if  (pvPop->size() > 100)*/

}//void  CConditionalGA::vGetClusters(vector<CConditionalGAIndividual *> *pvPop, CConditionalGAIndividual  *pcIndToOpt, vector<CConditionalGA_Mask *> *pvMasks)


void  CConditionalGA::v_get_clusters_sll(vector<CConditionalGA_Mask *> *pvMasks, vector<CConditionalGAIndividual *> *pvPop, bool  bAdd_Sll_Dled)
{
	int i_problem_size = pc_problem->pcGetEvaluation()->iGetNumberOfElements();
	int  i_clusters_after_sll, i_clusters_after_dled, i_clusters_after_hll;

	vector<int*> v_pop;

	/*for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)
	{
		v_pop.push_back(pvPop->at(i_ind)->piGetGenotype());
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)*/


	pc_linkage_pack->vSetPopulationGeneral(&v_pop);
	pc_linkage_pack->vSetSLL_GenerateDSMfromPop();
	pc_linkage_pack->vComputeDSM_SLL(false);
	i_clusters_after_sll = pc_linkage_pack->pcGetSingleLinkage()->pvGetP3Clusters()->size();

	if (bAdd_Sll_Dled == true)
	{
		//pc_linkage_pack->pcGetSingleLinkage()->vSetOutsideLinkage_DLED(pc_dsm->piGetDSM(), i_problem_size, false);
		/*for (int ix = 0; ix < i_problem_size; ix++)
		{
			for (int iy = 0; iy < i_problem_size; iy++)
				pc_linkage_pack->piGet_DSM_DLED()[ix][iy] = pc_dsm->piGetDSM()[ix][iy];
		}//for  (int ix = 0; ix < i_problem_size; ix++)*/
		

		/*CString  s_line, s_buf;
		::Tools::vReportInFile("zzzz_dsm_masks.txt", "", true);
		for (int ix = 0; ix < i_problem_size; ix++)
		{
			s_line.Format("%.3d:  ", ix);
			for (int iy = 0; iy < i_problem_size; iy++)
			{
				if (pc_linkage_pack->piGet_DSM_DLED()[ix][iy] > 0)
				{
					s_buf.Format("%d,", iy);
					s_line += s_buf;
				}//if (pc_linkage_pack->piGet_DSM_DLED()[ix][iy] > 0)
			}//for (int iy = 0; iy < i_problem_size; iy++)

			::Tools::vReportInFile("zzzz_dsm_masks.txt", s_line);				
		}//for  (int ix = 0; ix < i_problem_size; ix++)*/

		pc_linkage_pack->vComputeDSM_HLL_DLED_SLL(false);
	}//if (bAdd_Sll_Dled == true)


	CConditionalGA_Mask  *pc_mask_new;
	for (int ii = 0; ii < i_clusters_after_sll; ii++)
	{
		pc_mask_new = new CConditionalGA_Mask(i_problem_size);
		pc_mask_new->v_mask = pc_linkage_pack->pcGetSingleLinkage()->pvGetP3Clusters()->at(ii);
		pvMasks->push_back(pc_mask_new);
	}//for (int ii = 0; ii < i_problem_size; ii++)

	//::Tools::vShow(i_clusters_after_sll);
}//void  CConditionalGA::v_get_clusters_sll(vector<CConditionalGA_Mask *> *pvMasks)





void  CConditionalGA::v_get_clusters_random(vector<CConditionalGA_Mask *> *pvMasks)
{
	vector<CConditionalGA_Mask *> v_front_masks;
	int i_problem_size = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	CConditionalGA_Mask  *pc_mask_new;
	for (int ii = 0; ii < i_problem_size; ii++)
	{
		pc_mask_new = new CConditionalGA_Mask(i_problem_size);
		pc_mask_new->v_mask.push_back(ii);
		pvMasks->push_back(pc_mask_new);
		v_front_masks.push_back(pc_mask_new);
	}//for (int ii = 0; ii < i_problem_size; ii++)

	int  i_mask_off;
	CConditionalGA_Mask  *pc_mask_0, *pc_mask_1;
	while (v_front_masks.size() > 1)
	{
		i_mask_off = ::RandUtils::iRandNumber(0, v_front_masks.size() - 1);
		pc_mask_0 = v_front_masks.at(i_mask_off);
		v_front_masks.erase(v_front_masks.begin() + i_mask_off);

		i_mask_off = ::RandUtils::iRandNumber(0, v_front_masks.size() - 1);
		pc_mask_1 = v_front_masks.at(i_mask_off);
		v_front_masks.erase(v_front_masks.begin() + i_mask_off);
		

		pc_mask_new = new CConditionalGA_Mask(i_problem_size);
		for (int ii = 0; ii < pc_mask_0->v_mask.size(); ii++)
			pc_mask_new->v_mask.push_back(pc_mask_0->v_mask.at(ii));

		for (int ii = 0; ii < pc_mask_1->v_mask.size(); ii++)
			pc_mask_new->v_mask.push_back(pc_mask_1->v_mask.at(ii));

		if (pc_mask_new->v_mask.size() < i_problem_size)
		{
			pvMasks->push_back(pc_mask_new);
			v_front_masks.push_back(pc_mask_new);
		}//if (pc_mask_new->v_mask.size() < i_problem_size)
		else
			delete  pc_mask_new;
		
	}//while (v_front_masks.size() > 1)

}//void  CConditionalGA::v_get_random_clusters(vector<CConditionalGA_Mask *> *pvMasks)

CConditionalGAIndividual  *CConditionalGA::pcGetBest()
{
	if  (pc_best_pop == NULL)  return(NULL);
	if (pc_best_pop->v_pop.size() == 0)  return(NULL);

	CConditionalGAIndividual  *pc_best;
	pc_best = pc_best_pop->v_pop.at(0);

	for (int ii = 1; ii < pc_best_pop->v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < pc_best_pop->v_pop.at(ii)->dComputeFitness())  pc_best  =  pc_best_pop->v_pop.at(ii);
	}//for (int ii = 0; ii < pc_best_pop->v_pop.size(); ii++)

	return(pc_best);
}//CConditionalGAIndividual  *CConditionalGA::pcGetBest()



void  CConditionalGA::vInsertToBestPop_FitnessLevels(CConditionalGASinglePop  *pcSinglePop)
{
	double  d_best_fitness;

	//int  i_best_pop_size_start, i_best_pop_size_end;
	
	//i_best_pop_size_start = pc_best_pop->v_pop.size();
	d_best_fitness = pcSinglePop->pcGetBest()->dComputeFitness();

	for (int ii = 0; ii < pcSinglePop->v_pop.size(); ii++)
	{
		if (pcSinglePop->v_pop.at(ii)->dComputeFitness() >= d_best_fitness)
		{
			vInsertToBestPop_FitnessLevels(pcSinglePop->v_pop.at(ii));
		}//if (pcSinglePop->v_pop.at(ii)->dComputeFitness() == d_best_fitness)
	}//for (int ii = 0; ii < pcSinglePop->v_pop.size(); ii++)

	//i_best_pop_size_end = pc_best_pop->v_pop.size();

}//void  CConditionalGA::vInsertToBestPop(CConditionalGASinglePop  *pcSinglePop)



void  CConditionalGA::vInsertToBestPop_FitnessLevels(CConditionalGAIndividual  *pcNewInd)
{
	if (pc_best_pop->v_pop.at(0)->dComputeFitness() == pcNewInd->dComputeFitness())
	{
		for (int ii = 0; ii < pc_best_pop->v_pop.size(); ii++)
		{
			if (pc_best_pop->v_pop.at(ii)->bIsTheSame(pcNewInd) == true)  return;
		}//for (int ii = 0; ii < pc_best_pop->v_pop.size(); ii++)

		int  i_ind_to_replace_offset;
		if (
			( (i_sett_global_number_limit == 0) &&(pc_best_pop->v_pop.size() < v_pop_running.at(v_pop_running.size() - 1)->v_pop.size()) )
			||
			(pc_best_pop->v_pop.size() < i_sett_global_number_limit)
			)
		{
			pc_best_pop->v_pop.push_back(new CConditionalGAIndividual(i_templ_length, pc_problem, pc_best_pop));
			i_ind_to_replace_offset = pc_best_pop->v_pop.size() - 1;
		}//if ((i_sett_global_number_limit < 0) || (pc_best_pop->v_pop.size() < i_sett_global_number_limit))
		else
			i_ind_to_replace_offset = ::RandUtils::iRandNumber(0, pc_best_pop->v_pop.size() - 1);

		pc_best_pop->v_pop.at(i_ind_to_replace_offset)->vCopyFrom(pcNewInd);		
		pc_best_pop->vSetPopulationSize(pc_best_pop->v_pop.size());
	}//if (pc_best_pop->v_pop.at(0)->dComputeFitness() == pcNewInd->dComputeFitness())

	if (pc_best_pop->v_pop.at(0)->dComputeFitness() < pcNewInd->dComputeFitness())
	{
		pc_best_pop->vSetPopulationSize(1);
		pc_best_pop->v_pop.at(0)->vCopyFrom(pcNewInd);

		for (int ii = 1; ii < pc_best_pop->v_pop.size(); ii++)
			delete  pc_best_pop->v_pop.at(ii);
		while (pc_best_pop->v_pop.size() > 1)
			pc_best_pop->v_pop.erase(pc_best_pop->v_pop.begin() + pc_best_pop->v_pop.size() - 1);

		for (int ii = 1; ii < pc_best_pop->v_pop_copy.size(); ii++)
			delete  pc_best_pop->v_pop_copy.at(ii);
		while (pc_best_pop->v_pop_copy.size() > 1)
			pc_best_pop->v_pop_copy.erase(pc_best_pop->v_pop_copy.begin() + pc_best_pop->v_pop_copy.size() - 1);
	}//if (pc_best_pop->v_pop.at(0)->dComputeFitness() < pcNewInd->dComputeFitness())
}//CConditionalGA::vInsertToBestPop(CConditionalGAIndividual  *pcNewInd)



void  CConditionalGA::vInsertToBestPop_Simple(CConditionalGAIndividual  *pcNewInd)
{
	pc_best_pop->v_pop.push_back(new CConditionalGAIndividual(i_templ_length, pc_problem, pc_best_pop));
	pc_best_pop->v_pop.at(pc_best_pop->v_pop.size() - 1)->vCopyFrom(pcNewInd);
}//void  CConditionalGA::vInsertToBestPop_Simple(CConditionalGAIndividual  *pcNewInd)




CError CConditionalGA::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_CConditionalGA);


	c_err = COptimizer::eConfigure(psSettings);

	CUIntCommandParam p_pop_scheme(s_OPTIMIZER_CONDITIONAL_GA_POP_SCHEME);
	i_sett_pop_scheme = p_pop_scheme.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	CUIntCommandParam p_perfect_linkage(s_OPTIMIZER_CONDITIONAL_GA_PERFECT_LINKAGE);
	i_sett_perfect_linkage = p_perfect_linkage.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_clusters_type(s_OPTIMIZER_CONDITIONAL_GA_CLUSTERS_TYPE);
	i_sett_clusters = p_clusters_type.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
		
	CUIntCommandParam p_donor_improvement(s_OPTIMIZER_CONDITIONAL_GA_DONOR_IMPROVEMENT);
	i_sett_donor_improvement = p_donor_improvement.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	CUIntCommandParam p_global_best_improvement(s_OPTIMIZER_CONDITIONAL_GA_GLOBAL_BEST_IMPROVEMENT);
	i_sett_global_best_improvement = p_global_best_improvement.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	CUIntCommandParam p_global_number_limit(s_OPTIMIZER_CONDITIONAL_GA_GLOBAL_BEST_LIMIT);
	i_sett_global_number_limit = p_global_number_limit.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_global_best_pop_run(s_OPTIMIZER_CONDITIONAL_GA_GLOBAL_BEST_POP_RUN);
	i_sett_global_best_pop_run = p_global_best_pop_run.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_uniform_crossover_for_slide(s_OPTIMIZER_CONDITIONAL_GA_UNIFORM_CROSSOVER_FOR_SLIDE);
	i_sett_uniform_crossover_for_slide = p_uniform_crossover_for_slide.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	
	return c_err;
};//CError CConditionalGA::eConfigure(istream *psSettings)




bool CConditionalGA::bRunIteration(uint32_t iIterationNumber)
{
	if  (i_sett_pop_scheme == 0)  return(bRunIteration_P3(iIterationNumber));
	if (i_sett_pop_scheme == 1)  return(bRunIteration_sGA(iIterationNumber));
	return(false);
	//return(bRunIteration_sGA(iIterationNumber, tStartTime));
}//bool CConditionalGA::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



bool CConditionalGA::b_p3_the_same_exists(CConditionalGAIndividual  *pcIndToAdd)
{
	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
	{
		for (int i_ind = 0; i_ind < v_pyramid.at(i_lev)->v_pop.size(); i_ind++)
		{
			if (v_pyramid.at(i_lev)->v_pop.at(i_ind)->bIsTheSame(pcIndToAdd))  return(false);
		}//for (int i_ind = 0; i_ind < v_pyramid.at(i_lev)->v_pop.size(); i_ind++)
	}//for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
	return(true);
}//bool CConditionalGA::b_p3_the_same_exists(CConditionalGAIndividual  *pcIndToAdd)

bool CConditionalGA::b_p3_add_to_level(int iLevel, CConditionalGAIndividual  *pcIndToAdd)
{
	while (v_pyramid.size() <= iLevel)
	{
		CConditionalGASinglePop  *pc_new_pop;

		pc_new_pop = new CConditionalGASinglePop(pc_base_pop);
		pc_new_pop->vSetPopulationSize(0);
		pc_new_pop->vInitialize();
		pc_new_pop->pc_parent = this;

		v_pyramid.push_back(pc_new_pop);
	}//while (v_pyramid.size() <= iLevel)


	if (b_p3_the_same_exists(pcIndToAdd) == false)  return(false);

	pcIndToAdd->pc_parent = v_pyramid.at(iLevel);
	v_pyramid.at(iLevel)->v_pop.push_back(pcIndToAdd);
	return(true);
}//void CConditionalGA::v_p3_add_to_level(int iLevel, CConditionalGAIndividual*pcIndToAdd)



int  CConditionalGA::iGetPopLevel(CConditionalGASinglePop  *pcPopToCheck)
{
	for (int ii = 0; ii < v_pyramid.size(); ii++)
	{
		if (v_pyramid.at(ii) == pcPopToCheck)  return(ii);
	}//for (int ii = 0; ii < v_pyramid.size(); ii++)

	return(-1);
}//int  CConditionalGA::iGetPopLevel(CConditionalGASinglePop  *pcPopToCheck)


int  CConditionalGA::iP3GetPyramidIndNumber()
{
	int  i_result = 0;

	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
		i_result += v_pyramid.at(i_lev)->v_pop.size();

	return(i_result);
}//int  CConditionalGA::iP3GetPyramidIndNumber()


bool CConditionalGA::bRunIteration_P3(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CConditionalGA);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();

	bool  b_print = false;
	if (iIterationNumber % 100 == 0)  b_print = true;



	CConditionalGAIndividual  *pc_climber;
	pc_climber = new CConditionalGAIndividual(i_templ_length, pc_problem, pc_base_pop);
	pc_climber->vRandomizeGenotype();
	pc_climber->dComputeFitnessOptimize(NULL);


	
	if (i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_CONDITIONAL_SLL_DLED)
	{
		int  i_gene_for_decomp;

		bool  b_total_decomp = false;
		for (int i_trial = 0; (i_trial < 1)&&(b_total_decomp == false); i_trial++)
		{
			b_total_decomp = true;

			i_gene_for_decomp = ::RandUtils::iRandNumber(0, i_templ_length - 1);

			if (pc_dsm->bDLED_forInd(i_gene_for_decomp, pc_climber) == true)
			//pc_dsm->bDLED_forInd(i_gene_for_decomp, pc_climber);
			{
				CConditionalGAIndividual  *pc_dled_ind;
				pc_dled_ind = new CConditionalGAIndividual(i_templ_length, pc_problem, pc_base_pop);
				pc_dled_ind->vCopyFrom(pc_climber);

				v_dled_inds.push_back(pc_dled_ind);
				//pc_dsm->bSave("zzzz_dsm_test.txt");
				//::Tools::vShow("zzzz_dsm_test.txt");
			}//if (pc_dsm->bDLED(i_gene_for_decomp, pc_climber) == true)
		}//for (int i_trial = 0; i_trial < 5; i_trial++)



		if (pc_climber->v_dependent_genes.size() == 0)
		{
			//s_buf.Format(" --------no dependencies found");
			//pc_log->vPrintLine(s_buf, true);
			return(true);
		}//if (pc_climber->v_dependent_genes.size() == 0)


	}//if (i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_CONDITIONAL_SLL_DLED)


	


	CConditionalGAIndividual *pc_copy;
	pc_copy = new CConditionalGAIndividual(i_templ_length, pc_problem, pc_base_pop);
	pc_copy->vCopyFrom(pc_climber);


	CConditionalGA_ProbingData  c_prob_data(this, pc_tool_ind);
	pc_dsm->bGetProbingData(pc_climber, &c_prob_data);
	


	if (b_p3_add_to_level(0, pc_copy) == false) delete  pc_copy;



	vector<CConditionalGA_Mask *> v_last_successful_masks;

	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
	{
		if (v_pyramid.at(i_lev)->iDonateToIndividual_PxByLen(pc_climber, &c_prob_data, &v_last_successful_masks, b_print) == 1)
		{
			pc_copy = new CConditionalGAIndividual(i_templ_length, pc_problem, pc_base_pop);
			pc_copy->vCopyFrom(pc_climber);

			if (b_p3_add_to_level(i_lev + 1, pc_copy) == false)  delete  pc_copy;

		}//if (v_pyramid.at(i_lev)->bDonateToIndividual_PxByLen(pc_climber) == true)
	}//for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)


	double  d_fitness_best_start;

	if (pcGetBest() != NULL)
		d_fitness_best_start = pcGetBest()->dComputeFitness();
	else
		d_fitness_best_start = 0;

	//filter bests that make sense
	vector<CConditionalGAIndividual *> v_bests_to_process;
	for (int ii = 0; ii < pc_best_pop->v_pop.size(); ii++)
	{
		//d_pairs_matching_perc = pvPop->at(ii)->dDepedentPairsMatching(pc_parent->pc_parent->pc_linkage_pack->piGet_DSM_DLED());
		//if (d_pairs_matching_perc > 0.99)  v_pop_filtered.push_back(pvPop->at(ii));

		//s_buf.Format("[%.4lf %d] ", d_pairs_matching_perc, pvPop->at(ii)->v_dependent_genes.size());
		//s_pop_filter_info += s_buf;
		if (pc_best_pop->v_pop.at(ii)->dDepedentPairsMatching(pc_linkage_pack->piGet_DSM_DLED()) > 0.99)  v_bests_to_process.push_back(pc_best_pop->v_pop.at(ii));
	}//for (int ii = 0; ii < pvPop->size(); ii++)


	
	if (v_bests_to_process.size() == 0)
		vInsertToBestPop_Simple(pc_climber);
	else
	{
		int  i_res_single;

		CConditionalGAIndividual *pc_result;
		pc_result = new CConditionalGAIndividual(i_templ_length, pc_problem, pc_base_pop);
		pc_result->vCopyFrom(pc_climber);

		//first crossing
		for (int i_best_ind = 0; i_best_ind < v_bests_to_process.size(); i_best_ind++)
		{
			/*if (pc_climber->dComputeFitness() > v_bests_to_process.at(i_best_ind)->dComputeFitness())
			{
				//IMPROVE  pc_climber

				for (int i_mask = 0; i_mask < v_last_successful_masks.size(); i_mask++)
				{
					i_res_single = pc_climber->iConditionalMixing_ByMask(v_bests_to_process.at(i_best_ind), v_last_successful_masks.at(i_mask), pc_result);

					if (i_res_single >= 0)
					{
						if (pc_climber->dComputeFitness() < pc_result->dComputeFitness())
						{
							s_buf.Format("  ClimbUp %.8lf -> %.8lf  (bestProcessed: %d)", pc_climber->dComputeFitness(), pc_result->dComputeFitness(), v_bests_to_process.size());
							pc_log->vPrintLine(s_buf, true);
						}//if (pc_climber->dComputeFitness() < pc_result->dComputeFitness())
						

						pc_result->v_dependent_genes = pc_climber->v_dependent_genes;
						pc_climber->vCopyFrom(pc_result);
					}//if (i_res_single >= 0)					
				}//for (int i_mask = 0; i_mask < v_last_successful_masks.size(); i_mask++)
			}//if (pc_climber->dComputeFitness() > pc_best_pop->v_pop.at(i_best_ind)->dComputeFitness())
			else*/
			{
				//IMPROVE  v_bests_to_process.at(i_best_ind)

				for (int i_mask = 0; i_mask < v_last_successful_masks.size(); i_mask++)
				{
					i_res_single = v_bests_to_process.at(i_best_ind)->iConditionalMixing_ByMask(pc_climber, v_last_successful_masks.at(i_mask), pc_result);

					if (i_res_single >= 0)
					{
						if (v_bests_to_process.at(i_best_ind)->dComputeFitness() < pc_result->dComputeFitness())
						{
							s_buf.Format("  BestUp %.8lf -> %.8lf  (bestProcessed: %d)", v_bests_to_process.at(i_best_ind)->dComputeFitness(), pc_result->dComputeFitness(), v_bests_to_process.size());
							pc_log->vPrintLine(s_buf, true);
						}//if (pc_climber->dComputeFitness() < pc_result->dComputeFitness())

						pc_result->v_dependent_genes = v_bests_to_process.at(i_best_ind)->v_dependent_genes;
						v_bests_to_process.at(i_best_ind)->vCopyFrom(pc_result);
					}//if (i_res_single >= 0)					
				}//for (int i_mask = 0; i_mask < v_last_successful_masks.size(); i_mask++)
			}//else  if (pc_climber->dComputeFitness() > pc_best_pop->v_pop.at(i_best_ind)->dComputeFitness())
		}//for (int i_best_ind = 0; i_best_ind < pc_best_pop->v_pop.size(); i_best_ind++)


		//SECOND - insert climber and/or reduce current bests
		CConditionalGAIndividual *pc_best_of_bests = v_bests_to_process.at(0);
		for (int i_best_ind = 1; i_best_ind < v_bests_to_process.size(); i_best_ind++)
		{
			if (pc_best_of_bests->dComputeFitness() < v_bests_to_process.at(i_best_ind)->dComputeFitness())  pc_best_of_bests = v_bests_to_process.at(i_best_ind);
		}//for (int i_best_ind = 1; i_best_ind < v_bests_to_process.size(); i_best_ind++)

		for (int i_best_ind = 0; i_best_ind < v_bests_to_process.size(); i_best_ind++)
		{
			if (v_bests_to_process.at(i_best_ind) != pc_best_of_bests)  pc_best_pop->bRemoveIndividual(v_bests_to_process.at(i_best_ind));
		}//for (int i_best_ind = 0; i_best_ind < v_bests_to_process.size(); i_best_ind++)
		v_bests_to_process.clear();

		if (pc_climber->dComputeFitness() >= pc_best_of_bests->dComputeFitness())
		{
			pc_best_pop->bRemoveIndividual(pc_best_of_bests);
			vInsertToBestPop_Simple(pc_climber);
		}//if (pc_climber->dComputeFitness() >= pc_best_of_bests->dComputeFitness())


		/*bool  b_climber_to_add;
		b_climber_to_add = false;
		for (int i_best_ind = 0; i_best_ind < v_bests_to_process.size(); i_best_ind++)
		{
			if (v_bests_to_process.at(i_best_ind)->dComputeFitness() < pc_climber->dComputeFitness())
			{
				pc_best_pop->bRemoveIndividual(v_bests_to_process.at(i_best_ind));
				b_climber_to_add = true;
			}//if (v_bests_to_process.at(i_best_ind)->dComputeFitness() < pc_climber->dComputeFitness())
		}//for (int i_best_ind = 0; i_best_ind < v_bests_to_process.size(); i_best_ind++)

		if (b_climber_to_add == true)  vInsertToBestPop_Simple(pc_climber);//*/
	}//else  if (v_bests.size() == 0)  */

	


	for (int ii = 0; ii < v_last_successful_masks.size(); ii++)
		delete  v_last_successful_masks.at(ii);
	v_last_successful_masks.clear();

	double d_fitness_best_end;
	d_fitness_best_end = pcGetBest()->dComputeFitness();

	if (d_fitness_best_start < d_fitness_best_end)
	{
		s_buf.Format("prev: %.4lf  ->  %.4lf", pcGetBest()->dComputeFitness(), d_fitness_best_end);
		//::Tools::vShow(s_buf);
		//asdsadvInsertToBestPop_FitnessLevels(pc_climber);
		//pc_best->vCopyFrom(pc_climber);
		b_print = true;


		if (i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_CONDITIONAL_SLL_DLED)
		{
			pcGetBest()->v_dependent_genes.clear();
			pc_dsm->bDLED_forInd(-1, pcGetBest());

			CConditionalGAIndividual  *pc_dled_ind;
			pc_dled_ind = new CConditionalGAIndividual(i_templ_length, pc_problem, pc_base_pop);
			pc_dled_ind->vCopyFrom(pcGetBest());

			v_dled_inds.push_back(pc_dled_ind);

			s_buf.Format("  Best decomp dep pairs: %d", pcGetBest()->v_dependent_genes.size());
			pc_log->vPrintLine(s_buf, true);
		}//if (i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_CONDITIONAL_SLL_DLED)
	}//if (pc_best->dComputeFitness() < pc_climber->dComputeFitness())
	



	bool b_updated = b_update_best_individual(iIterationNumber, pcGetBest()->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pcGetBest()->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"pyramid: %d  PyrInds: %d  best: %.8lf (%d)  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf] [%diterations]",
		v_pyramid.size(), iP3GetPyramidIndNumber(), pcGetBest()->dComputeFitness(), pc_best_pop->v_pop.size(),
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE(), iIterationNumber
	);

	if (b_print)
	{
		pc_log->vPrintLine(s_buf, true);

		//CString  s_linkage;
		//s_linkage = pc_dsm->sLinkageSummaryReport();
		//pc_log->vPrintLine(s_linkage, true);

		pc_log->vPrintLine("", true);
	}//if (b_print)
	

	//delete  pc_climber;


	return(true);
}//bool CConditionalGA::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



void  CConditionalGA::v_global_best_pop_run()
{
	CString  s_buf;

	double  d_fit_start, d_fit_end;

	d_fit_start = pc_best_pop->pcGetBest()->dComputeFitness();
	pc_log->vPrintLine("BEST POP run:", true);
	pc_best_pop->bRunIteration_sGA(1);
	d_fit_end = pc_best_pop->pcGetBest()->dComputeFitness();
	   	
	if (d_fit_start < d_fit_end)
	{
		s_buf.Format("BEST POP RUN SUCC: %.8lf -> %.8lf", d_fit_start, d_fit_end);
		pc_log->vPrintLine(s_buf, true);
		pc_log->vPrintLine("", true);

		vInsertToBestPop_FitnessLevels(pc_best_pop->pcGetBest());
	}//if (d_fit_start < d_fit_end)

}//void  CConditionalGA::v_global_best_pop_run()


void CConditionalGA::v_global_best_improvement()
{
	CString  s_buf;

	bool  i_donated = 1;
	double  d_best_fit_start, d_best_fit_end;
	int  i_epx_res;
	CConditionalGAIndividual *pc_ind_buffer;
	CConditionalGAIndividual *pc_best_current;

	while (i_donated > 0)
	{
		i_donated = 0;

		for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)
		{
			for (int i_best_pop_ind = 0; i_best_pop_ind < pc_best_pop->v_pop.size(); i_best_pop_ind++)
			{
				pc_best_current = pc_best_pop->v_pop.at(i_best_pop_ind);

				d_best_fit_start = pc_best_current->dComputeFitness();
				if (v_pop_running.at(i_pop)->pc_individual_buffer == NULL)  v_pop_running.at(i_pop)->pc_individual_buffer = new CConditionalGAIndividual(i_templ_length, pc_problem, v_pop_running.at(i_pop));
				pc_ind_buffer = v_pop_running.at(i_pop)->pc_individual_buffer;
				pc_ind_buffer->vCopyFrom(pc_best_current);

				i_epx_res = pc_best_current->iConditionalMixing(&(v_pop_running.at(i_pop)->v_pop), NULL, pc_ind_buffer, NULL);
				if (i_epx_res > 0)
				{
					vInsertToBestPop_FitnessLevels(pc_ind_buffer);
					d_best_fit_end = pcGetBest()->dComputeFitness();
					i_donated = 1;

					s_buf.Format
					(
						"GLOBAL BEST DONATED %.8lf -> %.8lf  BestPopSize:%d   donatorPopSize: %d",
						d_best_fit_start, d_best_fit_end,
						pc_best_pop->v_pop.size(), 
						v_pop_running.at(i_pop)->v_pop.size()
					);
					pc_log->vPrintLine(s_buf, true);
					pc_log->vPrintLine("", true);
				}//if (i_epx_buf > 0)

				//we slide
				if (i_epx_res == 0)
				{
					vInsertToBestPop_FitnessLevels(pc_ind_buffer);
					d_best_fit_end = pcGetBest()->dComputeFitness();

					s_buf.Format
					(
						"Global best SLIDED %.8lf -> %.8lf  BestPopSize:%d   donatorPopSize: %d",
						d_best_fit_start, d_best_fit_end,
						pc_best_pop->v_pop.size(),
						v_pop_running.at(i_pop)->v_pop.size()
					);
					pc_log->vPrintLine(s_buf, true);
					pc_log->vPrintLine("", true);

					//::Tools::vShow("Best SLIDE!!!!!");
				}//if (i_epx_buf > 0)
			}//for (int i_best_pop_ind = 0; i_best_pop_ind < pc_best_pop->v_pop.size(); i_best_pop_ind++)
		}//for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)

		//if (i_donated == 2)
		//{
		//	for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
		//	{
		//		if (v_pops_obsolete.at(i_pop_obs)->bDonateToIndividual_PxByLen(pc_best) == true)  i_donated = 2;
		//	}//for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
		//}//if (i_donated == 2)

	}//if (b_donated == true)*/
}//bool CConditionalGA::v_global_best_improvement()




bool CConditionalGA::bRunIteration_sGA(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CConditionalGA);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();



	if (v_pop_running.size() == 0)
	{
		CConditionalGASinglePop  *pc_new_pop;

		pc_new_pop = new CConditionalGASinglePop(pc_base_pop);
		pc_new_pop->vSetPopulationSize(i_next_pop_size);
		i_next_pop_size = i_next_pop_size * 2;
		pc_new_pop->vInitialize();
		pc_new_pop->pc_parent = this;

		v_pop_running.push_back(pc_new_pop);
	}//if (v_pop_running.size() == 0)


	
	for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)
	{
		v_pop_running.at(i_pop)->bRunIteration_sGA(iIterationNumber);
		//if (pc_best->dComputeFitness() < v_pop_running.at(i_pop)->pcGetBest()->dComputeFitness())  pc_best->vCopyFrom(v_pop_running.at(i_pop)->pcGetBest());
		if (pcGetBest()->dComputeFitness() < v_pop_running.at(i_pop)->pcGetBest()->dComputeFitness())  vInsertToBestPop_FitnessLevels(v_pop_running.at(i_pop));

		if (v_pop_running.at(i_pop)->bIsSteadyState() == true)
		{
			v_pops_obsolete.push_back(v_pop_running.at(i_pop));
			v_pop_running.erase(v_pop_running.begin() + i_pop);
		}//if (v_pop_running.at(i_pop)->bIsSteadyState() == true)
	}//for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)


	if  (i_sett_global_best_improvement == 1)  v_global_best_improvement();

	if  (i_sett_global_best_pop_run == 1)  v_global_best_pop_run();


	
	bool b_updated = b_update_best_individual(iIterationNumber, pcGetBest()->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pcGetBest()->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"pops: %d  runningPops: %d  best: %.8lf (bestPopSize:%d)  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pops_obsolete.size() + v_pop_running.size(), v_pop_running.size(), pcGetBest()->dComputeFitness(), pc_best_pop->v_pop.size(),
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);
	pc_log->vPrintLine("", true);



	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CConditionalGA::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



double CConditionalGA::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_compute_fitness_value(piBits);
	return(d_fitness_value);
}//double CConditionalGA::dComputeFitness(int32_t *piBits)



CString  CConditionalGA::sAdditionalSummaryInfo()
{
	CString  s_buf;

	return(s_buf);
};//CString  CConditionalGA::sAdditionalSummaryInfo() 



CString  CConditionalGA::sLinkageSummaryReport()
{
	CString  s_res;
	s_res = pc_dsm->sLinkageSummaryReport();
	return(s_res);
}//CString  CConditionalGA::sLinkageSummaryReport()

















//---------------------------------------------CConditionalGASinglePop-------------------------------------------------------
CConditionalGASinglePop::CConditionalGASinglePop(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed, CConditionalGA  *pcParent)
	: CPopulationSizingSingleOptimizer(pcProblem, pcLog, iRandomSeed)
{
	i_pop_size = 0;
	pc_evaluation_individual = NULL;
	pc_individual_buffer = NULL;
	pi_genotope_buffer_tool_0 = NULL;
	pi_genotope_buffer_tool_1 = NULL;

	pc_best = NULL;
	b_steady_state = false;

	pc_parent = pcParent;

	if (pc_parent == NULL)
		pc_dsm = new CConditionalGA_DSM(pc_parent);
	else
		pc_dsm = pc_parent->pcGetDSM();

};//CConditionalGASinglePop::CConditionalGASinglePop(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



CConditionalGASinglePop::CConditionalGASinglePop(CConditionalGASinglePop *pcOther) : CPopulationSizingSingleOptimizer(pcOther)
{
	pc_evaluation_individual = NULL;
	pc_individual_buffer = NULL;
	pi_genotope_buffer_tool_0 = NULL;
	pi_genotope_buffer_tool_1 = NULL;

	pc_best = NULL;
	pc_problem = pcOther->pc_problem;
	pc_log = pcOther->pc_log;
	b_steady_state = false;

	pc_parent = pcOther->pc_parent;
	if (pc_parent == NULL)
		pc_dsm = new CConditionalGA_DSM(pc_parent);
	else
		pc_dsm = pc_parent->pcGetDSM();

}//CConditionalGASinglePop::CConditionalGASinglePop(CConditionalGASinglePop *pcOther) : CBinaryOptimizer(pcOther)



CConditionalGASinglePop::~CConditionalGASinglePop()
{
	for (int ii = 0; ii < v_pop.size(); ii++)
		delete  v_pop.at(ii);

	for (int ii = 0; ii < v_pop_copy.size(); ii++)
		delete  v_pop_copy.at(ii);

	
	if (pc_evaluation_individual != NULL)  delete  pc_evaluation_individual;

	if (pc_best != NULL)  delete  pc_best;

	if (pi_genotope_buffer_tool_0 != NULL)  delete  pi_genotope_buffer_tool_0;
	if (pi_genotope_buffer_tool_1 != NULL)  delete  pi_genotope_buffer_tool_1;

	if (pc_parent == NULL)
	{
		if (pc_dsm != NULL)  delete  pc_dsm;
	}//if (pc_parent == NULL)
}//CConditionalGASinglePop::~CConditionalGASinglePop()


void  CConditionalGASinglePop::vInitialize()
{
	c_time_counter.vSetStartNow();
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();



	pc_best = new CConditionalGAIndividual(i_templ_length, pc_problem, this);
	pc_individual_buffer = new CConditionalGAIndividual(i_templ_length, pc_problem, this);
	pi_genotope_buffer_tool_0 = new int[i_templ_length];
	pi_genotope_buffer_tool_1 = new int[i_templ_length];

	i_slide_number = 0;

	//pc_dsm->bSetSize(i_templ_length);
	//pc_dsm->bGetTrueLinkage(pc_problem);
	//pc_dsm->bSave("zzzzz_dsm_test.txt");
	//vSavePopTest();


	CConditionalGAIndividual  *pc_indiv_new;
	while  (v_pop.size() < i_pop_size)
	{
		//int i_ffe_start, i_ffe_end;
		//i_ffe_start = pc_problem->pcGetEvaluation()->iGetFFE();

		pc_indiv_new = new CConditionalGAIndividual(i_templ_length, pc_problem, this);
		pc_indiv_new->vRandomizeGenotype();
		
		/*::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", "START: \n");
		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", pc_indiv_new->sToStr());
		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", "\n\n\n\n");*/

		//pc_indiv_new->dComputeFitness();
		pc_indiv_new->dComputeFitnessOptimize(NULL);
		//pc_indiv_new->dComputeFitnessOptimize(NULL, true);

		/*i_ffe_end = pc_problem->pcGetEvaluation()->iGetFFE();

		CString  s_buf;
		s_buf.Format("\n\n\n%d\n%d\n%d\n", i_ffe_start, i_ffe_end, i_ffe_end - i_ffe_start);

		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", s_buf);
		::Tools::vReportInFile("zzzzz_ind_opt_summ.txt", pc_indiv_new->sToStr());
		::Tools::vShow("zzzzz_ind_opt_darkGr.txt");//*/

		v_pop.push_back(pc_indiv_new);
	}//while  (v_pop.size() < i_pop_size)


	

	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();



	CString  s_buf;

	s_buf.Format
	(
		"INIT size: %d  best: %.8lf avr: %.8lf  [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	//pc_log->vPrintLine(s_buf, true);
}//void  CConditionalGASinglePop::vInitialize(time_t tStartTime)



void  CConditionalGASinglePop::vGetClusters(vector<CConditionalGAIndividual *> *pvPop, CConditionalGAIndividual  *pcIndToOpt, vector<CConditionalGA_Mask *> *pvMasks, bool  bAdd_Sll_Dled)
{
	pc_parent->vGetClusters(pvPop, pcIndToOpt, pvMasks, bAdd_Sll_Dled);
}//void  CConditionalGASinglePop::vComputeSLLforPop(vector<CConditionalGAIndividual *> *pvPop)


bool  CConditionalGASinglePop::bRemoveIndividual(CConditionalGAIndividual *pcIndToRem)
{
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pcIndToRem == v_pop.at(ii))
		{
			delete  v_pop.at(ii);
			v_pop.erase(v_pop.begin() + ii);
			return(true);
		}//if (pcIndToRem == v_pop.at(ii))
	}//for (int ii = 0; ii < i_pop_size; ii++)

	return(false);
}//void  CConditionalGASinglePop::vRemoveIndividual(CConditionalGAIndividual *pcIndToRem)

void  CConditionalGASinglePop::vSavePopTest()
{
	FILE  *pf_dest;
	pf_dest = fopen("zzz_test_pop.txt", "w+");

	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		fprintf(pf_dest, "%s\n", v_pop.at(ii)->sToStr());
	}//for (int ii = 0; ii < i_pop_size; ii++)

	fclose(pf_dest);

	::Tools::vShow("void  CConditionalGA::vSavePopTest()");
}//void  CConditionalGASinglePop::vSavePopTest()



void  CConditionalGASinglePop::vCopyFrom(CConditionalGASinglePop *pcOther)
{
	i_pop_size = pcOther->i_pop_size;
	i_templ_length = pcOther->i_templ_length;

	v_pop.clear();
	for (size_t ii = 0; ii < pcOther->v_pop.size(); ii++)
	{
		if (pcOther->v_pop[ii] != nullptr)
		{
			v_pop.push_back(new CConditionalGAIndividual(*(pcOther->v_pop[ii])));
		}//if (pcOther->v_population[ii] != nullptr)
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void  CConditionalGASinglePop::vCopyForm(CConditionalGASinglePop *pcOther)



COptimizer<CBinaryCoding, CBinaryCoding> *CConditionalGASinglePop::pcCopy()
{
	CConditionalGASinglePop  *pc_res = new CConditionalGASinglePop(this);

	pc_res->vCopyFrom(this);

	return(pc_res);
}//COptimizer<CBinaryCoding, CBinaryCoding> *CConditionalGASinglePop::pcCopy()


bool CConditionalGASinglePop::bIsSteadyState()
{
	return(b_steady_state);
	//return(false);
}//bool CConditionalGASinglePop::bIsSteadyState()


double CConditionalGASinglePop::dComputeAverageFitnessValue()
{
	double  d_avr = 0;
	for (size_t ii = 0; ii < v_pop.size(); ii++)
	{
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (size_t ii = 0; ii < v_population.size(); ii++)

	return(d_avr / v_pop.size());
}//double CConditionalGASinglePop::dComputeAverageFitnessValue()



CError CConditionalGASinglePop::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_CConditionalGASinglePop);


	c_err = COptimizer::eConfigure(psSettings);


	CUIntCommandParam p_pop_size(OPTIMIZER_ARGUMENT_POP_SIZE);
	i_pop_size = p_pop_size.iGetValue(psSettings, &c_err);
	if (p_pop_size.bHasValue() == false)  i_pop_size = 0;
	if (c_err)  return(c_err);

	return c_err;
};//CError CConditionalGASinglePop::eConfigure(istream *psSettings)







bool CConditionalGASinglePop::bRunIteration_sGA(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CConditionalGASinglePop);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();


	//save current individuals
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (v_pop_copy.size() <= ii)
			v_pop_copy.push_back(new CConditionalGAIndividual(i_templ_length, pc_problem, this));

		v_pop_copy.at(ii)->vCopyFrom(v_pop.at(ii));
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	i_uniform_donations = 0;

	for (int ii = 0; ii < v_pop.size(); ii++)//it must be v_pop.size() here because we assured that v_pop_next is at least of the size of v_pop
	{
		//i_epx_buf = v_pop_copy.at(ii)->iMixing_ePX_ByMaskLen(&v_pop_copy, v_pop.at(ii));
		i_epx_buf = iDonateToIndividual_PxByLen(v_pop_copy.at(ii), false);

		if (i_epx_buf > 0)
		{
			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	for (int ii = 0; ii < v_pop.size(); ii++)
		v_pop.at(ii)->vCopyFrom(v_pop_copy.at(ii));


	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();




	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	if (i_epx_succ == 0)  b_steady_state = true;//asdasd

	s_buf.Format
	(
		"size: %d  best: %.8lf avr: %.8lf  epx[SUCC/min/max]: %d/%d/%d  Uniform Donations: %d Slides:%d iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		i_epx_succ, i_epx_min, i_epx_max, i_uniform_donations, i_slide_number,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	if (b_steady_state == true)  s_buf += "   STEADY STATE";
	pc_log->vPrintLine(s_buf, true);

	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CConditionalGASinglePop::bRunIteration_sGA(uint32_t iIterationNumber)







bool CConditionalGASinglePop::bRunIteration(uint32_t iIterationNumber)
{
	return(bRunIteration_sGA(iIterationNumber));

	return(true);
}//bool CConditionalGASinglePop::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)




int  CConditionalGASinglePop::iDonateToIndividual_PxByLen(CConditionalGAIndividual  *pcReceiver, CConditionalGA_ProbingData  *pcProbData, vector<CConditionalGA_Mask *> *pvLastSuccessfulMasks, bool bPrint)
{
	if (v_pop.size() == 0)  return(-1);

	double  d_fitness_start, d_fitness_end;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();

	d_fitness_start = pcReceiver->dComputeFitness();


	if (pc_individual_buffer == NULL)  pc_individual_buffer = new CConditionalGAIndividual(i_templ_length, pc_problem, this);


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	


	i_epx_buf = pcReceiver->iConditionalMixing(&v_pop, pcProbData, pc_individual_buffer, pvLastSuccessfulMasks);
	if (i_epx_buf > 0)
	{
		//copying is a part of iConditionalMixing
		//pcReceiver->vCopyFrom(pc_individual_buffer);

		i_epx_succ++;
		if (i_epx_min < 0)  i_epx_min = i_epx_buf;
		if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
		if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;

		return(1);
	}//if (i_epx_buf > 0)

	//we slide
	if (i_epx_buf == 0)
	{
		//copying is a part of iConditionalMixing
		//pcReceiver->vCopyFrom(pc_individual_buffer);

		i_slide_number++;
		if (i_epx_min < 0)  i_epx_min = i_epx_buf;
		if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
		if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;

		return(0);
	}//if (i_epx_buf > 0)


	/*d_fitness_end = pcReceiver->dComputeFitness();


	CString  s_buf, s_change;
	if (d_fitness_start < d_fitness_end)  s_change = "CHANGE!!!";


	s_buf.Format
	(
		"Donate toindividual PxByLen: size: %d  %s: %.8lf -> %.8lf      epx[SUCC/min/max]: %d/%d/%d  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(),
		s_change,
		d_fitness_start, d_fitness_end,
		i_epx_succ, i_epx_min, i_epx_max,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);

	if  (bPrint == true)  pc_log->vPrintLine(s_buf, true);*/

	return(-1);
}//bool  CConditionalGASinglePop::bDonateToIndividual(CConditionalGAIndividual  *pcReceiver)


bool  CConditionalGASinglePop::bDonateToIndividual(CConditionalGAIndividual  *pcReceiver)
{
	double  d_fitness_start, d_fitness_end;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();

	d_fitness_start = pcReceiver->dComputeFitness();


	if (pc_individual_buffer == NULL)  pc_individual_buffer = new CConditionalGAIndividual(i_templ_length, pc_problem, this);
	

	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;

	i_epx_buf = 1;
	while  (i_epx_buf > 0)
	{
		i_epx_buf = pcReceiver->iConditionalMixing(&v_pop, NULL, pc_individual_buffer, NULL);

		if (i_epx_buf > 0)
		{
			pcReceiver->vCopyFrom(pc_individual_buffer);

			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
		else
		{

		}//else if (i_epx_buf > 0)
	}//while  (i_epx_succ  == 1)


	d_fitness_end = pcReceiver->dComputeFitness();


	CString  s_buf, s_change;
	if (d_fitness_start < d_fitness_end)  s_change = "CHANGE!!!";

	
	s_buf.Format
	(
		"Donate toindividual: size: %d  %s: %.8lf -> %.8lf      epx[SUCC/min/max]: %d/%d/%d  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(),
		s_change,
		d_fitness_start, d_fitness_end,
		i_epx_succ, i_epx_min, i_epx_max,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);

	if  (i_epx_succ  > 0)  return(true);

	return(false);
}//bool  CConditionalGASinglePop::bDonateToIndividual(CConditionalGAIndividual  *pcReceiver)



void  CConditionalGASinglePop::vGetGenotypeBufferTools(int  **piTool_0, int  **piTool_1)
{
	if (pi_genotope_buffer_tool_0 == NULL)  pi_genotope_buffer_tool_0 = new int[i_templ_length];
	if (pi_genotope_buffer_tool_1 == NULL)  pi_genotope_buffer_tool_1 = new int[i_templ_length];
	
	*piTool_0 = pi_genotope_buffer_tool_0;
	*piTool_1 = pi_genotope_buffer_tool_1;
}//int  *CConditionalGASinglePop::piGetGenotypeBufferTool()


double CConditionalGASinglePop::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_evaluate(piBits);
	return(d_fitness_value);
}//double CConditionalGASinglePop::dComputeFitness(int32_t *piBits)


double CConditionalGASinglePop::dComputeFitnessDouble(int32_t *piBits)
{
	double d_fitness_value = d_evaluate_double(piBits);
	return(d_fitness_value);
}//double CConditionalGASinglePop::dComputeFitness(int32_t *piBits)




double CConditionalGASinglePop::d_evaluate(int32_t *piBits)
{
	if (pc_evaluation_individual == NULL)
	{
		pc_evaluation_individual = new CIndividual<CBinaryCoding, CBinaryCoding>(new CBinaryCoding(pc_problem->pcGetEvaluation()->iGetNumberOfElements(), nullptr), pc_problem->pcGetEvaluation(), nullptr, nullptr, pc_problem->pcGetTransformation());
	}//if (pc_evaluation_tool == NULL)
		
	pc_evaluation_individual->pcGetGenotype()->vSetBits(piBits);
	pc_evaluation_individual->vIsEvaluated(false);
	pc_evaluation_individual->vEvaluate();

	return pc_evaluation_individual->dGetFitnessValue();
}//double CConditionalGASinglePop::d_evaluate(CBinaryPSOIndividual * pc_individual)



double CConditionalGASinglePop::d_evaluate_double(int32_t *piBits)
{
	if (pc_evaluation_individual == NULL)
	{
		pc_evaluation_individual = new CIndividual<CBinaryCoding, CBinaryCoding>(new CBinaryCoding(pc_problem->pcGetEvaluation()->iGetNumberOfElements(), nullptr), pc_problem->pcGetEvaluation(), nullptr, nullptr, pc_problem->pcGetTransformation());
	}//if (pc_evaluation_tool == NULL)

	pc_evaluation_individual->pcGetGenotype()->vSetBits(piBits);
	pc_evaluation_individual->vIsEvaluated(false);
	pc_evaluation_individual->vEvaluateDouble();

	return pc_evaluation_individual->dGetFitnessValue();
}//double CConditionalGASinglePop::d_evaluate(CBinaryPSOIndividual * pc_individual)






CString  CConditionalGASinglePop::sAdditionalSummaryInfo()
{
	CString  s_buf;

	return(s_buf);
};//CString  CConditionalGASinglePop::sAdditionalSummaryInfo() 





//---------------------------------------------CConditionalGA_DSM-------------------------------------------------------

CConditionalGA_DSM::CConditionalGA_DSM(CConditionalGA  *pcParent)
{
	pi_dsm = NULL;
	pc_source_inds = NULL;
	i_prob_size = -1;
	pc_individual_tool = NULL;
	pi_gene_dep_numbers = NULL;

	i_cost_ffe = 0;
	d_cost_time = 0;

	pc_parent = pcParent;
}//CConditionalGA_DSM::CConditionalGA_DSM(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem)


CConditionalGA_DSM::~CConditionalGA_DSM()
{
	if (pi_dsm != NULL)
	{
		for (int ii = 0; ii < i_prob_size; ii++)
			delete  pi_dsm[ii];
		delete  pi_dsm;
	}//if (pi_dsm != NULL)

	if (pc_source_inds != NULL)
	{
		for (int ix = 0; ix < i_prob_size; ix++)
		{
			for (int iy = ix + 1; iy < i_prob_size; iy++)
			{
				if (pc_source_inds[ix][iy] != NULL)  delete  pc_source_inds[ix][iy];
			}//for (int iy = ix + 1; iy < i_prob_size; iy++)
		}//for (int ix = 0; ix < i_prob_size; ix++)

		for (int ii = 0; ii < i_prob_size; ii++)
			delete  pc_source_inds[ii];
		delete  pc_source_inds;
	}//if (pi_dsm != NULL)

	if (pi_gene_dep_numbers != NULL)  delete  pi_gene_dep_numbers;


	if (pc_individual_tool != NULL)  delete  pc_individual_tool;
	if (pi_hop_tool != NULL)  delete  pi_hop_tool;
}//CConditionalGA_DSM::CConditionalGA_DSM(int  iProblemSize)


bool  CConditionalGA_DSM::bSetSize(int  iProbSize)
{
	if (i_prob_size > 0)  return(false);

	i_prob_size = iProbSize;
	pi_dsm = new int*[i_prob_size];
	for (int ii = 0; ii < i_prob_size; ii++)
		pi_dsm[ii] = new int[i_prob_size];

	pc_source_inds = new CConditionalGAIndividual**[i_prob_size];
	for (int ii = 0; ii < i_prob_size; ii++)
		pc_source_inds[ii] = new CConditionalGAIndividual*[i_prob_size];

	for (int iy = 0; iy < i_prob_size; iy++)
	{
		for (int ix = 0; ix < i_prob_size; ix++)
		{
			pi_dsm[ix][iy] = 0;
			pc_source_inds[ix][iy] = NULL;
		}//for (int ix = 0; ix < i_prob_size; ix++)
	}//for (int iy = 0; iy < i_prob_size; iy++)


	pi_gene_dep_numbers = new int[i_prob_size];
	for (int ii = 0; ii < i_prob_size; ii++)
		pi_gene_dep_numbers[ii] = 0;

	pi_hop_tool = new int[i_prob_size];
		

	return(true);
}//bool  CConditionalGA_DSM::bSetSize(int  iProbSize)



bool  CConditionalGA_DSM::bSave(CString  sDest)
{
	FILE  *pf_dest;

	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return(false);
	bSave(pf_dest);
	fclose(pf_dest);

	return(true);
}//bool  CConditionalGA_DSM::bSave(CString  sDest)


bool  CConditionalGA_DSM::bSave(FILE  *pfDest)
{
	CString  s_line, s_buf;

	s_line = " \t ";
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		s_buf.Format("%d\t", ii);
		s_line += s_buf;
	}//for (int ii = 0; ii < i_prob_size; ii++)
	s_line += "\n";
	fprintf(pfDest, s_line);

	for (int iy = 0; iy < i_prob_size; iy++)
	{
		s_line.Format("%d\t", iy);
		for (int ix = 0; ix < i_prob_size; ix++)
		{
			s_buf.Format("%d\t", pi_dsm[ix][iy]);
			s_line += s_buf;
		}//for (int ix = 0; ix < i_prob_size; ix++)
		s_line += "\n";
		fprintf(pfDest, s_line);
	}//for (int iy = 0; iy < i_prob_size; iy++)
}//bool  CConditionalGA_DSM::bSave(FILE  *pfDest)



bool  CConditionalGA_DSM::bGetTrueLinkage(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem)
{
	vector<vector <int>>  v_dependent_genes;
	pcProblem->vGetTrueGeneDependencies(&v_dependent_genes);


	/*CString  s_line, s_buf;
	FILE  *pf_test;
	pf_test = fopen("zzzz_trueLink.txt", "w+");
	for (int i_set = 0; i_set < v_dependent_genes.size(); i_set++)
	{
		s_line.Format("[%d]:", i_set);
		for (int i_off = 0; i_off < v_dependent_genes.at(i_set).size(); i_off++)
		{
			s_buf.Format("%d, ", v_dependent_genes.at(i_set).at(i_off));
			s_line += s_buf;
		}//for (int i_off = 0; i_off < v_dependent_genes.at(i_set).size(); i_off++)

		s_line += "\n";
		fprintf(pf_test, s_line);
	}//for (int ii = 0; ii < v_dependent_genes.size(); ii++)
	fclose(pf_test);
	::Tools::vShow("aaaa");//*/


	for (int i_gene_this = 0; i_gene_this < v_dependent_genes.size(); i_gene_this++)
	{
		for (int i_gene_other_offset = 0; i_gene_other_offset < v_dependent_genes.at(i_gene_this).size(); i_gene_other_offset++)
		{
			pi_dsm[i_gene_this][v_dependent_genes.at(i_gene_this).at(i_gene_other_offset)] = 1;
		}//for (int i_gene_other = 0; i_gene_other < v_dependent_genes.at(i_gene_this).size(); i_gene_other++)
	}//for (int i_gene = 0; i_gene < v_dependent_genes.size(); i_gene++)

	//bSave("zzzz_true_dsm.txt");
	//::Tools::vShow("trueLink");

		

	return(true);
}//bool  CConditionalGA_DSM::bGetTrueLinkage(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem)


CString  CConditionalGA_DSM::sLinkageSummaryReport()
{
	vector<vector <int>>  v_dependent_genes;
	pc_parent->pc_problem->vGetTrueGeneDependencies(&v_dependent_genes);

	int  i_cur_fill;
	double  d_fill_perc_cur, d_fill_perc_min, d_fill_perc_max, d_fill_perc_avr;
	int  i_true_dependent_genes;
	for (int i_gene = 0; i_gene < i_prob_size; i_gene++)
	{
		i_cur_fill = 0;
		
		for (int i_other = 0; i_other < i_prob_size; i_other++)
		{
			if (i_gene != i_other)
			{
				if (pi_dsm[i_gene][i_other] > 0)  i_cur_fill++;
			}//if (i_gene != i_other)
		}//for (int i_other = 0; i_other < i_prob_size; i_other++)

		i_true_dependent_genes = 0;
		for (int ii = 0; ii < v_dependent_genes.at(i_gene).size(); ii++)
		{
			if (v_dependent_genes.at(i_gene).at(ii) != i_gene)  i_true_dependent_genes++;
		}//for (int ii = 0; ii < v_dependent_genes.at(i_gene).size(); ii++)


		

		d_fill_perc_cur = i_cur_fill;
		if (v_dependent_genes.at(i_gene).size() > 0)
			d_fill_perc_cur = d_fill_perc_cur / i_true_dependent_genes;
		else
			d_fill_perc_cur = 1;

		if (i_gene == 0)
		{
			d_fill_perc_min = d_fill_perc_cur;
			d_fill_perc_max = d_fill_perc_cur;
			d_fill_perc_avr = d_fill_perc_cur;
		}//if (i_gene == 0)
		else
		{
			if (d_fill_perc_cur < d_fill_perc_min)  d_fill_perc_min = d_fill_perc_cur;
			if (d_fill_perc_cur > d_fill_perc_max)  d_fill_perc_max = d_fill_perc_cur;
			d_fill_perc_avr += d_fill_perc_cur;
		}//else  if (i_gene == 0)
	}//for (int i_gene = 0; i_gene < i_prob_size; i_gene++)

	d_fill_perc_avr = d_fill_perc_avr / i_prob_size;

	CString  s_res;
	s_res.Format
		(
			"\t%s\t%.8lf\t%s\t%.8lf\t%s\t%.8lf\t%s\t%.2lf\t%s\t%d", 
			OPT_LINK_QUALITY_FILL_MIN, d_fill_perc_min, OPT_LINK_QUALITY_FILL_MAX, d_fill_perc_max, OPT_LINK_QUALITY_FILL_AVR, d_fill_perc_avr, 
			OPT_LINK_COST_TIME, d_cost_time, OPT_LINK_COST_FFE, i_cost_ffe
		);
	return(s_res);
}//CString  CConditionalGA_DSM::sLinkageSummaryReport()



void  CConditionalGA_DSM::vDarkGrayMapDependentGenes(int  iGeneOffset, int  *piMask)
{
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		if ((pi_dsm[iGeneOffset][ii] > 0) && (iGeneOffset != ii))
		{
			piMask[ii] = 1;
		}//if ((pi_dsm[iGeneOffset][ii] > 0) && (iGeneOffset != ii))
	}//for (int ii = 0; ii < i_prob_size; ii++)

}//void  CConditionalGA_DSM::vDarkGrayMapDependentGenes(int  iGeneOffset, int  *piMask)



void  CConditionalGA_DSM::vGetCommonDirectlyDependentGenes(int  iGeneFirst, int  iGeneSecond, vector<int>  *pvCommonDirectlyDependentGenes)
{
	for (int i_dep_gene = 0; i_dep_gene < i_prob_size; i_dep_gene++)
	{
		if ( (pi_dsm[iGeneFirst][i_dep_gene] > 0)&&(pi_dsm[iGeneSecond][i_dep_gene] > 0) )
		{
			pvCommonDirectlyDependentGenes->push_back(i_dep_gene);
		}//if (pi_dsm[i_gene][i_dep_gene] > 0)
	}//for (int i_gene = 0; i_gene < i_prob_size; i_gene++)

}//void  CConditionalGA_DSM::vGetCommonDirectlyDependentGenes(int  iGeneFirst, int  iGeneSecond, vector<int>  *pvCommonDirectlyDependentGenes)


void  CConditionalGA_DSM::vGetDependentGenes(int  iSourceGene, vector<int>  *pvDependentGenes, int iHopNumber)
{
	for (int ii = 0; ii < i_prob_size; ii++)
		pi_hop_tool[ii] = -1;

	pi_hop_tool[iSourceGene] = 0;
	int  i_counter = 1;
	for  (int  i_hop = 1; (i_hop < iHopNumber+1)&&(i_counter > 0); i_hop++)
		i_counter = i_mark_dependent_genes(pi_hop_tool, i_hop);

	for (int ii = 0; ii < i_prob_size; ii++)
	{
		if (pi_hop_tool[ii] == iHopNumber)  pvDependentGenes->push_back(ii);
	}//for (int ii = 0; ii < i_prob_size; ii++)*/

	/*CString  s_buf;
	FILE  *pf_test = fopen("zzzzz_hopsDetails.txt", "w+");
	s_buf.Format("First:%d\n", iSourceGene);
	fprintf(pf_test, s_buf);
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		s_buf.Format("%d,", pi_hop_tool[ii]);
		fprintf(pf_test, s_buf);
	}//for (int ii = 0; ii < v_dependent_genes.size(); ii++)
	fclose(pf_test);
	::Tools::vShow("CConditionalGA_DSM::vGetDependentGenes");//*/
}//void  CConditionalGA_DSM::vGetDependentGenes(int  iSourceGene, vector<int>  *pvDependentGenes, int iHopNumber)




int  CConditionalGA_DSM::i_mark_dependent_genes(int  *piHopTool, int iHop)
{
	int  i_counter = 0;
	for (int i_gene = 0; i_gene < i_prob_size; i_gene++)
	{
		if (piHopTool[i_gene] == iHop - 1)
		{
			for (int i_dep_gene = 0; i_dep_gene < i_prob_size; i_dep_gene++)
			{
				if (piHopTool[i_dep_gene] < 0)
				{
					if (pi_dsm[i_gene][i_dep_gene] > 0)
					{
						piHopTool[i_dep_gene] = iHop;
						i_counter++;
					}//if (pi_dsm[i_gene][i_dep_gene] > 0)
				}//if (piHopTool[i_gene] < 0)
			}//for (int i_dep_gene = 0; i_dep_gene < i_prob_size; i_dep_gene++)
		}//if (piHopTool[i_gene] == iHop - 1)
	}//for (int i_gene = 0; i_gene < i_prob_size; i_gene++)

	return(i_counter);
}//int  CConditionalGA_DSM::i_mark_dependent_genes(int  *piHopTool, int iHop)



//int  CConditionalGA_DSM::i_flip_gene(int i_baseVal)
//{
//	if (i_baseVal == 0)  return(1);
//	return(0);
//}//int  CConditionalGA_DSM::i_flip_gene(int i_baseVal)




bool  CConditionalGA_DSM::bDLED_forInd(int  iGeneForDecomp, CConditionalGAIndividual *pcSource)
{
	bool  b_result;

	double  d_linkage_cost_single_time;
	int  i_linkage_cost_single_ffe;

	double  d_start_time;
	int  i_start_ffe;

	d_start_time = pc_parent->c_time_counter.dGetTimePassed();
	i_start_ffe = pc_parent->pc_problem->pcGetEvaluation()->iGetFFE();

	if (iGeneForDecomp >= 0)
	{
		b_result = false;
		v_dled_genes_to_run.push_back(iGeneForDecomp);
	}//if  (iGeneForDecomp >= 0)
	else
	{
		for  (int  i_gene = 0; i_gene < i_prob_size; i_gene++)
			v_dled_genes_to_run.push_back(i_gene);

		b_result = true;
	}//else  if  (iGeneForDecomp >= 0)

	int  i_gene_for_decomp;
	while (v_dled_genes_to_run.size() > 0)
	{
		i_gene_for_decomp = v_dled_genes_to_run.at(0);
		v_dled_genes_to_run.erase(v_dled_genes_to_run.begin());

		//bDLED_base_forInd(i_gene_for_decomp, pcSource);
		//if (b_result == false)
		if ((bDLED_base_forInd(i_gene_for_decomp, pcSource) == true) && (b_result == false))
		{
			b_result = true;

			v_dled_genes_to_run.clear();
			::Tools::vProducePermutation(&v_dled_genes_to_run, 0, i_prob_size-1);

			for (int ii = 0; ii < v_dled_genes_to_run.size(); ii++)
			{
				if (v_dled_genes_to_run.at(ii) == i_gene_for_decomp)
				{
					v_dled_genes_to_run.erase(v_dled_genes_to_run.begin() + ii);
					ii--;
				}//if (v_dled_genes_to_run.at(ii) == i_gene_for_decomp)
			}//for (int ii = 0; ii < i_prob_size; ii++)
		}//if ((bDLED_base(i_gene_for_decomp, pcSource) == true) && (b_result == false))
	}//while (v_dled_genes_to_run.size() > 0)


	double  d_end_time;
	int  i_end_ffe;

	d_end_time = pc_parent->c_time_counter.dGetTimePassed();
	i_end_ffe = pc_parent->pc_problem->pcGetEvaluation()->iGetFFE();

	d_cost_time += d_end_time - d_start_time;
	i_cost_ffe += i_end_ffe - i_start_ffe;

	return(b_result);
}//bool  CConditionalGA_DSM::bDLED(int  iGeneForDecomp, CConditionalGAIndividual *pcSource)





bool  CConditionalGA_DSM::bDLED_base_forInd(int  iGeneForDecomp, CConditionalGAIndividual *pcSource)
{
	bool  b_result;

	double  d_fit_bo_oo, d_fit_ba_oo;
	double  d_fit_bo_oa, d_fit_ba_oa;

	pcSource->b_fitness_actual = false;
	d_fit_bo_oo = pcSource->dComputeFitness();

	pcSource->piGetGenotype()[iGeneForDecomp] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[iGeneForDecomp]);
	pcSource->b_fitness_actual = false;
	d_fit_ba_oo = pcSource->dComputeFitness();

	pcSource->piGetGenotype()[iGeneForDecomp] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[iGeneForDecomp]);//flip back
	pcSource->d_fitnes_buf = d_fit_bo_oo;
	pcSource->b_fitness_actual = true;

	int i_rel_bo, i_rel_ba;
	int i_rel_oo, i_rel_oa;

	b_result = false;
	for (int i_gene_other = 0; i_gene_other < i_prob_size; i_gene_other++)
	{
		if (i_gene_other != iGeneForDecomp)
		{
			//if (pi_dsm[iGeneForDecomp][i_gene_other] == 0)
			{
				pcSource->piGetGenotype()[i_gene_other] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[i_gene_other]);
				pcSource->b_fitness_actual = false;
				d_fit_bo_oa = pcSource->dComputeFitness();

				pcSource->piGetGenotype()[iGeneForDecomp] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[iGeneForDecomp]);
				pcSource->b_fitness_actual = false;
				d_fit_ba_oa = pcSource->dComputeFitness();

				pcSource->piGetGenotype()[i_gene_other] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[i_gene_other]);//flip back
				pcSource->piGetGenotype()[iGeneForDecomp] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[iGeneForDecomp]);//flip back
				pcSource->d_fitnes_buf = d_fit_bo_oo;
				pcSource->b_fitness_actual = true;


				if (d_fit_bo_oo > d_fit_bo_oa)  i_rel_bo = 1;
				if (d_fit_bo_oo == d_fit_bo_oa)  i_rel_bo = 0;
				if (d_fit_bo_oo < d_fit_bo_oa)  i_rel_bo = -1;

				if (d_fit_ba_oo > d_fit_ba_oa)  i_rel_ba = 1;
				if (d_fit_ba_oo == d_fit_ba_oa)  i_rel_ba = 0;
				if (d_fit_ba_oo < d_fit_ba_oa)  i_rel_ba = -1;

				if (d_fit_bo_oo > d_fit_ba_oo)  i_rel_oo = 1;
				if (d_fit_bo_oo == d_fit_ba_oo)  i_rel_oo = 0;
				if (d_fit_bo_oo < d_fit_ba_oo)  i_rel_oo = -1;

				if (d_fit_bo_oa > d_fit_ba_oa)  i_rel_oa = 1;
				if (d_fit_bo_oa == d_fit_ba_oa)  i_rel_oa = 0;
				if (d_fit_bo_oa < d_fit_ba_oa)  i_rel_oa = -1;

				if ((i_rel_bo != i_rel_ba) || (i_rel_oo != i_rel_oa))
				{
					if (pi_dsm[iGeneForDecomp][i_gene_other] == 0)  b_result = true;


					pi_dsm[iGeneForDecomp][i_gene_other] = 1;
					pi_dsm[i_gene_other][iGeneForDecomp] = 1;

					(pi_gene_dep_numbers[i_gene_other])++;
					(pi_gene_dep_numbers[iGeneForDecomp])++;

					pcSource->bDependentPair_Insert(iGeneForDecomp, i_gene_other);
					//pcSource->v_dependent_genes.push_back(CConditionalGA_DependentGenesPair(iGeneForDecomp, i_gene_other));
				}//if ((i_rel_bo != i_rel_ba) || (i_rel_oo != i_rel_oa))
			}//if (pi_dsm[iGeneForDecomp][i_gene_other] == 0)
		}//if (i_gene_other != iGeneForDecomp)
	}//for (int i_gene_other = 0; i_gene_other < i_prob_size; i_gene_other++)


	return(b_result);
}//bool  CConditionalGA_DSM::bDLED_base_forInd(int  iGeneForDecomp, CConditionalGAIndividual *pcSource)


bool  CConditionalGA_DSM::bDLED(int  iGeneForDecomp, CConditionalGAIndividual *pcSource)
{
	bool  b_result; 

	b_result = false;
	v_dled_genes_to_run.push_back(iGeneForDecomp);

	int  i_gene_for_decomp;
	while (v_dled_genes_to_run.size() > 0)
	{
		i_gene_for_decomp = v_dled_genes_to_run.at(0);
		v_dled_genes_to_run.erase(v_dled_genes_to_run.begin());

		if (bDLED_base(i_gene_for_decomp, pcSource) == true)  b_result = true;
	}//while (v_dled_genes_to_run.size() > 0)

	return(b_result);
}//bool  CConditionalGA_DSM::bDLED(int  iGeneForDecomp, CConditionalGAIndividual *pcSource)



bool  CConditionalGA_DSM::bDLED_base(int  iGeneForDecomp, CConditionalGAIndividual *pcSource)
{
	bool  b_result;

	double  d_fit_bo_oo, d_fit_ba_oo;
	double  d_fit_bo_oa, d_fit_ba_oa;

	pcSource->b_fitness_actual = false;
	d_fit_bo_oo = pcSource->dComputeFitness();

	pcSource->piGetGenotype()[iGeneForDecomp] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[iGeneForDecomp]);
	pcSource->b_fitness_actual = false;
	d_fit_ba_oo = pcSource->dComputeFitness();

	pcSource->piGetGenotype()[iGeneForDecomp] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[iGeneForDecomp]);//flip back
	pcSource->d_fitnes_buf = d_fit_bo_oo;
	pcSource->b_fitness_actual = true;

	int i_rel_bo, i_rel_ba;
	int i_rel_oo, i_rel_oa;

	b_result = false;
	for (int i_gene_other = 0; i_gene_other < i_prob_size; i_gene_other++)
	{
		if (i_gene_other != iGeneForDecomp)
		{
			if (pi_dsm[iGeneForDecomp][i_gene_other] == 0)
			{
				pcSource->piGetGenotype()[i_gene_other] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[i_gene_other]);
				pcSource->b_fitness_actual = false;
				d_fit_bo_oa = pcSource->dComputeFitness();

				pcSource->piGetGenotype()[iGeneForDecomp] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[iGeneForDecomp]);
				pcSource->b_fitness_actual = false;
				d_fit_ba_oa = pcSource->dComputeFitness();

				pcSource->piGetGenotype()[i_gene_other] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[i_gene_other]);//flip back
				pcSource->piGetGenotype()[iGeneForDecomp] = CConditionalGAIndividual::iFlipGene(pcSource->piGetGenotype()[iGeneForDecomp]);//flip back
				pcSource->d_fitnes_buf = d_fit_bo_oo;
				pcSource->b_fitness_actual = true;


				if (d_fit_bo_oo > d_fit_bo_oa)  i_rel_bo = 1;
				if (d_fit_bo_oo == d_fit_bo_oa)  i_rel_bo = 0;
				if (d_fit_bo_oo < d_fit_bo_oa)  i_rel_bo = -1;

				if (d_fit_ba_oo > d_fit_ba_oa)  i_rel_ba = 1;
				if (d_fit_ba_oo == d_fit_ba_oa)  i_rel_ba = 0;
				if (d_fit_ba_oo < d_fit_ba_oa)  i_rel_ba = -1;

				if (d_fit_bo_oo > d_fit_ba_oo)  i_rel_oo = 1;
				if (d_fit_bo_oo == d_fit_ba_oo)  i_rel_oo = 0;
				if (d_fit_bo_oo < d_fit_ba_oo)  i_rel_oo = -1;

				if (d_fit_bo_oa > d_fit_ba_oa)  i_rel_oa = 1;
				if (d_fit_bo_oa == d_fit_ba_oa)  i_rel_oa = 0;
				if (d_fit_bo_oa < d_fit_ba_oa)  i_rel_oa = -1;

				if ((i_rel_bo != i_rel_ba) || (i_rel_oo != i_rel_oa))
				{
					pi_dsm[iGeneForDecomp][i_gene_other] = 1;
					pi_dsm[i_gene_other][iGeneForDecomp] = 1;

					CConditionalGAIndividual *pc_source_copy;
					pc_source_copy = new CConditionalGAIndividual(i_prob_size, pcSource->pc_problem, NULL);
					pc_source_copy->vCopyFrom(pcSource);

					pc_source_inds[iGeneForDecomp][i_gene_other] = pc_source_copy;
					pc_source_inds[i_gene_other][iGeneForDecomp] = pc_source_copy;

					(pi_gene_dep_numbers[i_gene_other])++;
					(pi_gene_dep_numbers[iGeneForDecomp])++;

					v_dled_genes_to_run.push_back(i_gene_other);

					b_result = true;
				}//if ((i_rel_bo != i_rel_ba) || (i_rel_oo != i_rel_oa))
			}//if (pi_dsm[iGeneForDecomp][i_gene_other] == 0)
		}//if (i_gene_other != iGeneForDecomp)
	}//for (int i_gene_other = 0; i_gene_other < i_prob_size; i_gene_other++)


	return(b_result);
}//void  CConditionalGA_DSM::vDLED(int  iGeneForDecomp, CConditionalGAIndividual pcSource)



bool  CConditionalGA_DSM::bGetProbingData(CConditionalGAIndividual *pcSource, CConditionalGA_ProbingData *pcProbingData)
{
	pcProbingData->i_probing_gene_0 = -1;
	pcProbingData->i_probing_gene_1 = -1;
	pcProbingData->pc_probing_ind = NULL;


	vector<int>  v_choices_0;
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		if (pi_gene_dep_numbers[ii] > 0)  v_choices_0.push_back(ii);
	}//for (int ii = 0; ii < i_prob_size; ii++)

	if (v_choices_0.size() == 0)  return(false);


	int  i_choice_0_offset;
	int  i_prob_0;
	i_choice_0_offset = ::RandUtils::iRandNumber(0, v_choices_0.size() - 1);
	i_prob_0 = v_choices_0.at(i_choice_0_offset);



	vector<int>  v_choices_1;
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		if (pi_dsm[i_prob_0][ii] > 0)  v_choices_1.push_back(ii);
	}//for (int ii = 0; ii < i_prob_size; ii++)

	if (v_choices_1.size() == 0)  return(false);


	int  i_choice_1_offset;
	int  i_prob_1;

	bool  b_dependency_found;

	b_dependency_found = false;
	while ( (b_dependency_found == false)&&(v_choices_1.size() > 0) )
	{
		i_choice_1_offset = ::RandUtils::iRandNumber(0, v_choices_1.size() - 1);
		i_prob_1 = v_choices_1.at(i_choice_1_offset);
		v_choices_1.erase(v_choices_1.begin() + i_choice_1_offset);
		
		pcProbingData->i_probing_gene_0 = i_prob_0;
		pcProbingData->i_probing_gene_1 = i_prob_1;
		pcProbingData->pc_probing_ind = pc_source_inds[i_prob_0][i_prob_1];

		b_dependency_found = pcProbingData->bCheckDependencyFor(pcSource);
	}//while ( (b_dependency_found == false)&&(v_choices_1.size() > 0) )
	

	if (b_dependency_found == false)
	{
		pcProbingData->i_probing_gene_0 = -1;
		pcProbingData->i_probing_gene_1 = -1;
		pcProbingData->pc_probing_ind = NULL;
	}//if (b_dependency_found == false)


	return(b_dependency_found);
}//bool  CConditionalGA_DSM::bGetProbingData(CConditionalGAIndividual *pcSource, int  *piProbingGene0, int  *piProbingGene1, CConditionalGAIndividual *pcProbingInd)



bool  CConditionalGA_ProbingData::bCheckDependencyFor(CConditionalGAIndividual *pcIndToTest)
{
	if (pc_probing_ind == NULL)  return(true);  //if conditions are empty, then any individuals fits to them

	if (pcIndToTest->bProbingDependenciesConfirmed_Check(this) == true)  return(true);

	pc_tool_ind->vCopyFrom(pcIndToTest);

	/*CConditionalGA_DSM *pc_dsm = pc_parent->pcGetDSM();
	for (int ii = 0; ii < pc_parent->i_templ_length; ii++)
	{
		if (
			(pc_dsm->piGetDSM()[i_probing_gene_0][ii] > 0) ||
			(pc_dsm->piGetDSM()[i_probing_gene_1][ii] > 0)
			)
		{
			pc_tool_ind->piGetGenotype()[ii] = pc_probing_ind->piGetGenotype()[ii];
		}//if (
	}//for (int ii = 0; ii < pc_parent->i_templ_length; ii++)*/

	if (pc_tool_ind->bCheckGenesDependent(i_probing_gene_0, i_probing_gene_1) == true)
	{
		pcIndToTest->bProbingDependenciesConfirmed_Insert(this);
		return(true);
	}//if (pc_tool_ind->bCheckGenesDependent(i_probing_gene_0, i_probing_gene_1) == true)

	return(false);
}//bool  CConditionalGA_ProbingData::bCheckDependencyFor(CConditionalGAIndividual *pcIndToTest)


bool  CConditionalGA_ProbingData::bEqual(CConditionalGA_ProbingData  *pcOther)
{
	if (pc_probing_ind != pcOther->pc_probing_ind)  return(false);

	if  (
		((i_probing_gene_0 == pcOther->i_probing_gene_0)&& (i_probing_gene_1 == pcOther->i_probing_gene_1) )||
		((i_probing_gene_0 == pcOther->i_probing_gene_1) && (i_probing_gene_1 == pcOther->i_probing_gene_0))
		)
		return(true);

	return(false);
}//bool  CConditionalGA_ProbingData::bEqual(CConditionalGA_ProbingData  *pcOther)



bool  CConditionalGA_DependentGenesPair::bEqual(int  iGene0, int iGene1)
{
	if (
		((i_probing_gene_0 == iGene0) && (i_probing_gene_1 == iGene1)) ||
		((i_probing_gene_0 == iGene1) && (i_probing_gene_1 == iGene0))
		)
		return(true);

	return(false);
}//bool  CConditionalGA_DependentGenesPair::bEqual(int  iGene0, int iGene1)





void  CConditionalGA_DSM::vUpdateDSM()
{
	/*CString  s_buf;

	int  i_ffe_start, i_ffe_end;
	double  d_time_spent;

	CTimeCounter  c_timer_local;
	i_ffe_start = pc_parent->pcGetProblem()->pcGetEvaluation()->iGetFFE();
	c_timer_local.vSetStartNow();

	int  *pi_dled_extraction_mask;
	pi_dled_extraction_mask = new int[i_prob_size];

	for (int ii = 0; ii < i_prob_size; ii++)
		pi_dled_extraction_mask[ii] = 2;//2->the context gene to check

	for (int i_mask_off = 0; i_mask_off < pcMask->v_mask.size(); i_mask_off++)
		pi_dled_extraction_mask[pcMask->v_mask.at(i_mask_off)] = 1;//1->the gene from the mask (block gene)

	for (int ii = 0; ii < i_prob_size; ii++)
	{
		if  (pcMask->pc_parent_0->piGetGenotype()[ii] == pcMask->pc_parent_1->piGetGenotype()[ii])  pi_dled_extraction_mask[ii] = -1;
	}//for (int ii = 0; ii < i_prob_size; ii++)

	
	int  i_new_pairs_detected = 0;
	for (int i_gene_context = 0; i_gene_context < i_prob_size; i_gene_context++)
	{
		for (int i_gene_block = 0; i_gene_block < i_prob_size; i_gene_block++)
		{
			if ((pi_dled_extraction_mask[i_gene_context] == 2) && (pi_dled_extraction_mask[i_gene_block] == 1))
			{
				v_extract_dled_for_gene_pair(i_gene_block, i_gene_context, pi_dled_extraction_mask, pcMask->pc_parent_0, &i_new_pairs_detected);
				v_extract_dled_for_gene_pair(i_gene_block, i_gene_context, pi_dled_extraction_mask, pcMask->pc_parent_1, &i_new_pairs_detected);
			}//if ((pi_dled_extraction_mask[i_gene_context] == 2) && (pi_dled_extraction_mask[i_gene_block] == 1))
		}//for (int i_gene_block = 0; i_gene_block < i_prob_size; i_gene_block++)
	}//for (int i_context_gene = 0; i_context_gene < i_prob_size; i_context_gene++)

	i_ffe_end = pc_parent->pcGetProblem()->pcGetEvaluation()->iGetFFE();
	d_time_spent = c_timer_local.dGetTimePassed();

	d_cost_time += d_time_spent;
	i_cost_ffe += (i_ffe_end - i_ffe_start);

	delete  pi_dled_extraction_mask;

	//bSave("zzz_dsm_afeter.txt");
	//::Tools::vShow("zzz_dsm_afeter.txt");


	CString  s_dled_cost_report;
	s_dled_cost_report.Format("DSM update info: newConnections:%d cost: %.16lfs(Total: %.16lf) %dffe(Total: %d)", i_new_pairs_detected, d_time_spent, d_cost_time, (i_ffe_end - i_ffe_start), i_cost_ffe);
	//pc_parent->pcGetLog()->vPrintLine(s_dled_cost_report, true);*/
	
}//void  CConditionalGA_DSM::vUpdateDSM(CConditionalGAPxMask  *pcMask)



bool  CConditionalGA_DSM::b_check_if_true_linkage(int iGeneBlock, int  iGeneContext)
{
	vector<vector <int>>  v_dependent_genes;
	pc_parent->pc_problem->vGetTrueGeneDependencies(&v_dependent_genes);

	for (int i_other_gene_off = 0; i_other_gene_off < v_dependent_genes.at(iGeneBlock).size(); i_other_gene_off++)
	{
		if (v_dependent_genes.at(iGeneBlock).at(i_other_gene_off) == iGeneContext)  return(true);
	}//for (int i_other_gene_off = 0; i_other_gene_off < v_dependent_genes.at(iGeneBlock).size(); i_other_gene_off++)

	return(false);
}//bool  CConditionalGA_DSM::b_check_if_true_linkage(int iGeneBlock, int  iGeneContext)



void  CConditionalGA_DSM::v_extract_dled_for_gene_pair(int iGeneBlock, int  iGeneContext, int  *piDledExtractionMask, CConditionalGAIndividual  *pcExtractionIndividual, int *piNewPairsDetected)
{
	if (pi_dsm[iGeneContext][iGeneBlock] > 0)  return;
	if ((piDledExtractionMask[iGeneBlock] < 0) || (piDledExtractionMask[iGeneContext] < 0))  return;

	pcExtractionIndividual->dComputeFitness();

	int  i_gene_block_value_orig, i_gene_block_value_alter;
	int  i_gene_context_value_orig, i_gene_context_value_alter;


	i_gene_block_value_orig = pcExtractionIndividual->pi_genotype[iGeneBlock];
	i_gene_block_value_alter = i_gene_block_value_orig * (-1) + 1;

	i_gene_context_value_orig = pcExtractionIndividual->pi_genotype[iGeneContext];
	i_gene_context_value_alter = i_gene_context_value_orig * (-1) + 1;


	double  d_fitness_bo_co, d_fitness_bo_ca;
	double  d_fitness_ba_co, d_fitness_ba_ca;


	d_fitness_bo_co = pcExtractionIndividual->dComputeFitness();
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co:", true);
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_alter;
	pcExtractionIndividual->b_fitness_actual = false;
	d_fitness_bo_ca = pcExtractionIndividual->dComputeFitness();
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_ca:");
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_alter;
	pcExtractionIndividual->b_fitness_actual = false;
	d_fitness_ba_ca = pcExtractionIndividual->dComputeFitness();
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_ca:");
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_orig;
	pcExtractionIndividual->b_fitness_actual = false;
	d_fitness_ba_co = pcExtractionIndividual->dComputeFitness();
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_co:");
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	//now we only restore the original genotype we do not have to compute fitness, because we know it (it is in d_fitness_bo_co)
	pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_orig;
	pcExtractionIndividual->b_fitness_actual = true;
	pcExtractionIndividual->d_fitnes_buf = d_fitness_bo_co;


	int  i_block_orig_relation, i_block_alter_relation;
	int  i_context_orig_relation, i_context_alter_relation;

	if (d_fitness_bo_co < d_fitness_bo_ca)  i_block_orig_relation = -1;
	if (d_fitness_bo_co == d_fitness_bo_ca)  i_block_orig_relation = 0;
	if (d_fitness_bo_co > d_fitness_bo_ca)  i_block_orig_relation = 1;

	if (d_fitness_ba_co < d_fitness_ba_ca)  i_block_alter_relation = -1;
	if (d_fitness_ba_co == d_fitness_ba_ca)  i_block_alter_relation = 0;
	if (d_fitness_ba_co > d_fitness_ba_ca)  i_block_alter_relation = 1;


	if (d_fitness_bo_co < d_fitness_ba_co)  i_context_orig_relation = -1;
	if (d_fitness_bo_co == d_fitness_ba_co)  i_context_orig_relation = 0;
	if (d_fitness_bo_co > d_fitness_ba_co)  i_context_orig_relation = 1;

	if (d_fitness_bo_ca < d_fitness_ba_ca)  i_context_alter_relation = -1;
	if (d_fitness_bo_ca == d_fitness_ba_ca)  i_context_alter_relation = 0;
	if (d_fitness_bo_ca > d_fitness_ba_ca)  i_context_alter_relation = 1;


	if (
		(i_block_orig_relation != i_block_alter_relation) ||
		(i_context_orig_relation != i_context_alter_relation)
		)
	{
		pi_dsm[iGeneContext][iGeneBlock] = 1;
		pi_dsm[iGeneBlock][iGeneContext] = 1;

		(*piNewPairsDetected)++;

		/*CString  s_buf;
		if (b_check_if_true_linkage(iGeneBlock, iGeneContext) == false)
		{
			pcExtractionIndividual->b_fitness_actual = true;
			d_fitness_bo_co = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co:", true);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_co = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co_AGAIN:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_alter;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_ca = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_ca:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_alter;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_ba_ca = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_ca:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_orig;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_ba_co = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_co:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			//now we only restore the original genotype we do not have to compute fitness, because we know it (it is in d_fitness_bo_co)
			pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_orig;
			pcExtractionIndividual->b_fitness_actual = true;
			pcExtractionIndividual->d_fitnes_buf = d_fitness_bo_co;



			CString  s_mut_line, s_sing;
			for (int ii = 0; ii < i_prob_size; ii++)
			{
				s_sing = "_";
				if  (ii == iGeneBlock)  s_sing = "b";
				if (ii == iGeneContext)  s_sing = "c";
				s_mut_line += s_sing;
			}//for (int ii = 0; ii < i_prob_size; ii++)
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_mut_line);


			s_buf.Format("d_fitness_bo_co, d_fitness_bo_ca: %.16lf  %.16lf", d_fitness_bo_co, d_fitness_bo_ca);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("d_fitness_ba_co, d_fitness_ba_ca: %.16lf  %.16lf", d_fitness_ba_co, d_fitness_ba_ca);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("i_block_orig_relation, i_block_alter_relation: %d  %d", i_block_orig_relation, i_block_alter_relation);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("i_context_orig_relation, i_context_alter_relation: %d  %d", i_context_orig_relation, i_context_alter_relation);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);








			::Tools::vReportInFile("zzz_dsm_individuals.txt", "DOUBLE fitness \n\n\n\n\n");

			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_co = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_co = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co_AGAIN:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_alter;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_ca = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_ca:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_alter;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_ba_ca = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_ca:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_orig;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_ba_co = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_co:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			//now we only restore the original genotype we do not have to compute fitness, because we know it (it is in d_fitness_bo_co)
			pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_orig;
			pcExtractionIndividual->b_fitness_actual = true;
			pcExtractionIndividual->d_fitnes_buf = d_fitness_bo_co;


			if (d_fitness_bo_co < d_fitness_bo_ca)  i_block_orig_relation = -1;
			if (d_fitness_bo_co == d_fitness_bo_ca)  i_block_orig_relation = 0;
			if (d_fitness_bo_co > d_fitness_bo_ca)  i_block_orig_relation = 1;

			if (d_fitness_ba_co < d_fitness_ba_ca)  i_block_alter_relation = -1;
			if (d_fitness_ba_co == d_fitness_ba_ca)  i_block_alter_relation = 0;
			if (d_fitness_ba_co > d_fitness_ba_ca)  i_block_alter_relation = 1;


			if (d_fitness_bo_co < d_fitness_ba_co)  i_context_orig_relation = -1;
			if (d_fitness_bo_co == d_fitness_ba_co)  i_context_orig_relation = 0;
			if (d_fitness_bo_co > d_fitness_ba_co)  i_context_orig_relation = 1;

			if (d_fitness_bo_ca < d_fitness_ba_ca)  i_context_alter_relation = -1;
			if (d_fitness_bo_ca == d_fitness_ba_ca)  i_context_alter_relation = 0;
			if (d_fitness_bo_ca > d_fitness_ba_ca)  i_context_alter_relation = 1;



			for (int ii = 0; ii < i_prob_size; ii++)
			{
				s_sing = "_";
				if (ii == iGeneBlock)  s_sing = "b";
				if (ii == iGeneContext)  s_sing = "c";
				s_mut_line += s_sing;
			}//for (int ii = 0; ii < i_prob_size; ii++)
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_mut_line);


			s_buf.Format("d_fitness_bo_co, d_fitness_bo_ca: %.16lf  %.16lf", d_fitness_bo_co, d_fitness_bo_ca);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("d_fitness_ba_co, d_fitness_ba_ca: %.16lf  %.16lf", d_fitness_ba_co, d_fitness_ba_ca);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("i_block_orig_relation, i_block_alter_relation: %d  %d", i_block_orig_relation, i_block_alter_relation);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("i_context_orig_relation, i_context_alter_relation: %d  %d", i_context_orig_relation, i_context_alter_relation);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

			s_buf.Format("%d NOTdep %d", iGeneBlock, iGeneContext);
			::Tools::vShow(s_buf);
		}//if (b_check_if_true_linkage(iGeneBlock, iGeneContext) == true)*/

		//CString  s_buf;
		//s_buf.Format("%d/%d", iGeneBlock, iGeneContext);
		//::Tools::vReportInFile("zzzzz_missing_linkage.txt", s_buf);
	}//if  (

	/*CString  s_mut_line, s_sing;
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		s_sing = "_";
		if  (ii == iGeneBlock)  s_sing = "b";
		if (ii == iGeneContext)  s_sing = "c";
		s_mut_line += s_sing;
	}//for (int ii = 0; ii < i_prob_size; ii++)
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_mut_line);

	CString  s_buf;
	s_buf.Format("d_fitness_bo_co, d_fitness_bo_ca: %.2lf  %.2lf", d_fitness_bo_co, d_fitness_bo_ca);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
	s_buf.Format("d_fitness_ba_co, d_fitness_ba_ca: %.2lf  %.2lf", d_fitness_ba_co, d_fitness_ba_ca);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

	s_buf.Format("i_block_orig_relation, i_block_alter_relation: %d  %d", i_block_orig_relation, i_block_alter_relation);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

	s_buf.Format("i_context_orig_relation, i_context_alter_relation: %d  %d", i_context_orig_relation, i_context_alter_relation);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vShow("CConditionalGA_DSM::v_extract_dled_for_gene_pair");*/



}//void  CConditionalGA_DSM::v_extract_dled_for_gene_pair(int  iGeneContext, int iGeneBlock, CConditionalGAIndividual  *pcExtractionIndividual)





//---------------------------------------------CConditionalGAIndividual-------------------------------------------------------
int  CConditionalGAIndividual::iFlipGene(int i_baseVal)
{
	if (i_baseVal == 0)  return(1);
	return(0);
}//static int  CConditionalGAIndividual::iFlipGene(int i_baseVal)


CConditionalGAIndividual::CConditionalGAIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CConditionalGASinglePop  *pcParent)
{
	i_templ_length = iTemplLength;
	pc_parent = pcParent;

	pi_genotype = new int[i_templ_length];

	pc_problem = pcProblem;

	d_fitnes_buf = -1;
	b_fitness_actual = false;


	vRandomizeGenotype();
}//CConditionalGAIndividual::CConditionalGAIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CConditionalGA  *pcParent)


CConditionalGAIndividual::CConditionalGAIndividual(CConditionalGAIndividual &pcOther)
{
	::Tools::vShow("No implementation: CConditionalGAIndividual::CConditionalGAIndividual(CConditionalGAIndividual &pcOther) ");
};//CConditionalGAIndividual::CConditionalGAIndividual(CConditionalGAIndividual &pcOther)


CConditionalGAIndividual::~CConditionalGAIndividual()
{
	delete  pi_genotype;
};//CConditionalGAIndividual::~CConditionalGAIndividual()


void  CConditionalGAIndividual::vCopyFrom(CConditionalGAIndividual  *pcOther)
{
	this->pc_parent = pcOther->pc_parent;
	this->i_templ_length = pcOther->i_templ_length;
	this->v_opt_order = pcOther->v_opt_order;
	this->d_fitnes_buf = pcOther->d_fitnes_buf;
	this->b_fitness_actual = pcOther->b_fitness_actual;
	this->pc_problem = pcOther->pc_problem;


	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = pcOther->pi_genotype[ii];

	v_dependent_genes = pcOther->v_dependent_genes;
}//void  CConditionalGAIndividual::vCopyFrom(CConditionalGAIndividual  *pcOther)


bool  CConditionalGAIndividual::bTheSameFragment(CConditionalGAIndividual  *pcIndOther, vector<int>  *pvMask)
{
	for (int ii = 0; ii < pvMask->size(); ii++)
	{
		if (pi_genotype[pvMask->at(ii)] != pcIndOther->pi_genotype[pvMask->at(ii)])  return(false);
	}//for (int ii = 0; ii < pvMask->size(); ii++)
		
	return(true);
}//bool  CConditionalGAIndividual::bTheSameFragment(CConditionalGAIndividual  *pcIndOther, vector<int>  *pvMask)


void  CConditionalGAIndividual::v_clear_masks(vector<CConditionalGA_Mask *> *pvMasks)
{
	for (int ii = 0; ii < pvMasks->size(); ii++)
		delete  pvMasks->at(ii);
	pvMasks->clear();
}//void  CConditionalGAIndividual::v_clear_masks(vector<CConditionalGA_Mask *> *pvMasks)



CString CConditionalGAIndividual::s_get_masks_quality(vector<vector<vector<int>>>  *pvDependenciesMultistruct, vector<CConditionalGA_Mask *> *pvMasks)
{
	CString  s_result;
	CString  s_result_for_struct;
	CString  s_buf;

	bool  b_block_ok;
	int  i_blocks_ok;
	
	for (int i_struct = 0; i_struct < pvDependenciesMultistruct->size(); i_struct++)
	{
		s_result_for_struct.Format("Str[%d]:", i_struct);

		i_blocks_ok = 0;
		for (int i_block = 0; i_block < pvDependenciesMultistruct->at(i_struct).size(); i_block++)
		{
			pvDependenciesMultistruct->at(i_struct).at(i_block).push_back(i_block);

			b_block_ok = false;
			for (int i_mask = 0; (i_mask < pvMasks->size()) && (b_block_ok == false); i_mask++)
			{
				b_block_ok = pvMasks->at(i_mask)->bFitsBlock(&(pvDependenciesMultistruct->at(i_struct).at(i_block)));
			}//for (int i_mask = 0; i_mask < pvMasks->size(); i_mask++)

			if (b_block_ok == true)  i_blocks_ok++;
		}//for (int i_block = 0; i_block < pvDependenciesMultistruct->at(i_struct).size(); i_block++)

		s_buf.Format("%d/%d", i_blocks_ok, pvDependenciesMultistruct->at(i_struct).size());
		s_result_for_struct += s_buf;
		s_result_for_struct += "   ";

		s_result += s_result_for_struct;
	}//for (int i_struct = 0; i_struct < pvDependenciesMultistruct->size(); i_struct++)


	return(s_result);
}//CString CConditionalGAIndividual::s_get_masks_quality(vector<vector<vector<int>>>  *pvDependenciesMultistruct, vector<CConditionalGA_Mask *> *pvMasks)


int  CConditionalGAIndividual::iConditionalMixing(vector<CConditionalGAIndividual *> *pvPop, CConditionalGA_ProbingData  *pcProbData, CConditionalGAIndividual  *pcResult, vector<CConditionalGA_Mask *> *pvLastSuccessfulMasks)
{
	CString  s_buf;
	//CString  s_pop_filter_info;
	//CString  s_pop_link;

	vector<CConditionalGA_Mask *> v_masks;
	int i_problem_size = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	vector<CConditionalGAIndividual *> v_pop_filtered;

	if (pc_parent->pc_parent->i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_CONDITIONAL_SLL_DLED)
	{
		vector<CConditionalGAIndividual *> v_dled_inds_filtered;

		bool  b_added;
		for (int ii = 0; ii < pc_parent->pc_parent->v_dled_inds.size(); ii++)
		{
			b_added = false;

			for (int i_pair = 0; (i_pair < v_dependent_genes.size())&&(b_added == false); i_pair++)
			{
				if (pc_parent->pc_parent->v_dled_inds.at(ii)->bDependentPair_Check(v_dependent_genes.at(i_pair).i_probing_gene_0, v_dependent_genes.at(i_pair).i_probing_gene_1) == true)
				{
					v_dled_inds_filtered.push_back(pc_parent->pc_parent->v_dled_inds.at(ii));
					b_added = true;
				}//if (pc_parent->pc_parent->v_dled_inds.at(ii)->bDependentPair_Check(v_dependent_genes.at(i_pair).i_probing_gene_0, v_dependent_genes.at(i_pair).i_probing_gene_1) == true)
			}//for (int i_pair = 0; i_pair < v_dependent_genes.size(); i_pair++)

			//if  (pc_parent->pc_parent->v_dled_inds.at(ii)->bDependentPair_Check(pcProbData->i_probing_gene_0, pcProbData->i_probing_gene_1) == true)
				//v_dled_inds_filtered.push_back(pc_parent->pc_parent->v_dled_inds.at(ii));
		}//for (int ii = 0; ii < pvPop->size(); ii++)

		for (int ix = 0; ix < i_problem_size; ix++)
		{
			for (int iy = 0; iy < i_problem_size; iy++)
				pc_parent->pc_parent->pc_linkage_pack->piGet_DSM_DLED()[ix][iy] = 0;
		}//for  (int ix = 0; ix < i_problem_size; ix++)

		for (int i_ind = 0; i_ind < v_dled_inds_filtered.size(); i_ind++)
		{
			v_dled_inds_filtered.at(i_ind)->vInsertDependentPairIntoDSM(pc_parent->pc_parent->pc_linkage_pack->piGet_DSM_DLED());
		}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)


		double  d_pairs_matching_perc;
		for (int ii = 0; ii < pvPop->size(); ii++)
		{
			d_pairs_matching_perc = pvPop->at(ii)->dDepedentPairsMatching(pc_parent->pc_parent->pc_linkage_pack->piGet_DSM_DLED());
			if  (d_pairs_matching_perc > 0.99)  v_pop_filtered.push_back(pvPop->at(ii));

			//s_buf.Format("[%.4lf %d] ", d_pairs_matching_perc, pvPop->at(ii)->v_dependent_genes.size());
			//s_pop_filter_info += s_buf;
			//if (pvPop->at(ii)->dDepedentPairsMatching(pc_parent->pc_parent->pc_linkage_pack->piGet_DSM_DLED()) > 0.99)  v_pop_filtered.push_back(pvPop->at(ii));
		}//for (int ii = 0; ii < pvPop->size(); ii++)*/
		//if (v_pop_filtered.size() == 0)  v_pop_filtered = *pvPop;


		//s_pop_link.Format("DLED inds: %d / %d    PopFiltered: %d / %d", v_dled_inds_filtered.size(), pc_parent->pc_parent->v_dled_inds.size(), v_pop_filtered.size(), pvPop->size());
		
		if (v_pop_filtered.size() > 0)
		{
			this->pc_parent->vGetClusters(&v_pop_filtered, this, &v_masks, true);

			for (int ii = 0; ii < v_masks.size(); ii++)
			{
				if (v_masks.at(ii)->v_mask.size() == 1)
				{
					delete  v_masks.at(ii);
					v_masks.erase(v_masks.begin() + ii);
					ii--;
				}//if  (v_masks.at(ii)->v_mask.size() == 1)
			}//for (int ii = 0; ii < v_masks.size(); ii++)

			/*CString s_line;

			for (int i_ind = 0; i_ind < v_pop_filtered.size(); i_ind++)
			{
				for (int ii = 0; ii < v_pop_filtered.at(i_ind)->v_dependent_genes.size(); ii++)
				{
					if (
						(v_pop_filtered.at(i_ind)->v_dependent_genes.at(ii).i_probing_gene_0 == 0) ||
						(v_pop_filtered.at(i_ind)->v_dependent_genes.at(ii).i_probing_gene_1 == 0)
						)
					{
						if (v_pop_filtered.at(i_ind)->v_dependent_genes.at(ii).i_probing_gene_0 != 0)  s_buf.Format("%d,", v_pop_filtered.at(i_ind)->v_dependent_genes.at(ii).i_probing_gene_0);
						if (v_pop_filtered.at(i_ind)->v_dependent_genes.at(ii).i_probing_gene_1 != 0)  s_buf.Format("%d,", v_pop_filtered.at(i_ind)->v_dependent_genes.at(ii).i_probing_gene_1);

						s_line += s_buf;
					}//if (
				}//for (int ii = 0; ii < v_pop_filtered.at(0)->v_dependent_genes.size(); ii++)
			}//for  (int i_ind = 0; i_ind < v_pop_filtered.size(); i_ind++)

			::Tools::vReportInFile("zzzz_0_dependent.txt", s_line);
			//::Tools::vShow(s_line);*/
		}//if (v_pop_filtered.size() > 0)

		


		/*for (int ii = 0; ii < pvPop->size(); ii++)
		{
			if (pcProbData->bCheckDependencyFor(pvPop->at(ii)) == true)  v_pop_filtered.push_back(pvPop->at(ii));
		}//for (int ii = 0; ii < pvPop->size(); ii++)
		
		CString  s_buf;
		s_buf.Format("%d / %d  (%.4lf)   ", v_pop_filtered.size(), pvPop->size(), dComputeFitness());
		

		if (v_pop_filtered.size() > 0)  this->pc_parent->vGetClusters(&v_pop_filtered, this, &v_masks, false);*/


		/*vector<vector<vector<int>>>  v_dependencies_multistruct;
		((CMultiStruct_Trap*)
			((CBinaryDeceptiveConcatenationEvaluation*)pc_parent->pc_problem->pcGetEvaluation())->pcGetDeceptiveFuncConc()->pvGetComProblems()->at(0)
			)->vGetDependenciesMultiStruct(&v_dependencies_multistruct);

		CString  s_masks_quality;
		s_masks_quality = s_get_masks_quality(&v_dependencies_multistruct, &v_masks);//*/
		//::Tools::vReportInFile("zzzz_pop_for_link_test.txt", s_pop_link + "     " + s_pop_filter_info);


		/*FILE  *pf_dest;
		pf_dest = fopen("zzzz_masks_test.txt", "w+");
		for (int ii = 0; ii < v_masks.size(); ii++)
		{
			if  (v_masks.at(ii)->v_mask.size() == 6)
				v_masks.at(ii)->vReportShort(pf_dest);
		}//for (int ii = 0; ii < v_masks.size(); ii++)
		fclose(pf_dest);*/

		/*CString  s_line;
		for (int ii = 0; ii < v_dependencies_multistruct.at(0).at(0).size(); ii++)
		{
			s_buf.Format("%d, ", v_dependencies_multistruct.at(0).at(0).at(ii));
			s_line += s_buf;
		}//for (int ii = 0; ii < v_dependencies.at(i_gene_0).size(); ii++)

		::Tools::vShow(s_line);*/
	}//if (pc_parent->pc_parent->i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_CONDITIONAL_SLL_DLED)
	else
	{
		v_pop_filtered = *pvPop;
		if (v_pop_filtered.size() > 0)  this->pc_parent->vGetClusters(&v_pop_filtered, this, &v_masks, false);
	}//else  if (pc_parent->pc_parent->i_sett_clusters == i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_CONDITIONAL_SLL_DLED)



	int  i_res_final, i_res_single;
	int  i_donor_offset;

	CConditionalGAIndividual *pc_donor;

	bool  b_different_found;
	i_res_final = -1;

	if (v_pop_filtered.size() > 0)
	{
		pcResult->v_dependent_genes = this->v_dependent_genes;

		std::sort(v_masks.begin(), v_masks.end(), [](const CConditionalGA_Mask *pcVal0, const CConditionalGA_Mask * pcVal1) -> bool { return(pcVal0->v_mask.size() < pcVal1->v_mask.size()); });
		for (int i_mask_off = 0; i_mask_off < v_masks.size(); i_mask_off++)
		{
			i_donor_offset = ::RandUtils::iRandNumber(0, v_pop_filtered.size() - 1);
			pc_donor = v_pop_filtered.at(i_donor_offset);

			if (pc_donor->bIsTheSame(this) == false)  b_different_found = true;

			if (b_different_found == true)
			{
				i_res_single = iConditionalMixing_ByMask(pc_donor, v_masks.at(i_mask_off), pcResult);

				if (i_res_single == 1)
				{
					this->vCopyFrom(pcResult);
					i_res_final = 1;
					//v_clear_masks(&v_masks);
					//return(1);
				}//if (i_res_single == 1)


				if (i_res_single == 0)
				{
					this->vCopyFrom(pcResult);
					i_res_final = 0;
				}//if (i_res_single == 1)
			}//if  (b_different_found == true)

			/*if (v_donors.size() > 0)
			{
				b_different_found = false;
				while ((b_different_found == false) && (v_donors.size() > 1))
				{
					i_donor_offset = ::RandUtils::iRandNumber(0, v_donors.size() - 1);
					pc_donor = v_donors.at(i_donor_offset);
					v_donors.erase(v_donors.begin() + i_donor_offset);

					if (pc_donor->bIsTheSame(this) == false)  b_different_found = true;

					if (b_different_found == true)
					{
						i_res_single = iConditionalMixing_ByMask(pc_donor, v_masks.at(i_mask_off), pcResult);

						if (i_res_single == 1)
						{
							this->vCopyFrom(pcResult);
							i_res_final = 1;
							//v_clear_masks(&v_masks);
							//return(1);
						}//if (i_res_single == 1)


						if (i_res_single == 0)
						{
							this->vCopyFrom(pcResult);
							i_res_final = 0;
						}//if (i_res_single == 1)
					}//if  (b_different_found == true)
				}//while ( (b_different_found == false)&&(v_donors.size() > 1) )
			}//if (v_donors.size() > 0)*/
		}//for (int ii = 0; ii < pv_masks->size(); ii++)

		
		if (pvLastSuccessfulMasks != NULL)
		{
			if (i_res_single > 0)
			{
				v_clear_masks(pvLastSuccessfulMasks);
				*pvLastSuccessfulMasks = v_masks;				
			}//if (i_res_single > 0)
			else
				v_clear_masks(&v_masks);
		}//if (pvLastSuccessfulMasks != NULL)
		else
			v_clear_masks(&v_masks);

		
	}//if  (v_pop_filtered.size() > 0)

	s_buf.Format("  results: %d", i_res_final);
	//::Tools::vReportInFile("zzzz_pop_for_link_test.txt", s_buf);
	//::Tools::vReportInFile("zzzz_pop_for_link_test.txt", s_buf + "  ||  " + s_pop_link + "     " + s_pop_filter_info);

	return(i_res_final);
}//int  CConditionalGAIndividual::iConditionalMixing(vector<CConditionalGAIndividual *> *pvPop, CConditionalGAIndividual  *pcResult)




int   CConditionalGAIndividual::iConditionalMixing_ByMask(CConditionalGAIndividual  *pcDonor, CConditionalGA_Mask *pcMask, CConditionalGAIndividual  *pcResult)
{

	for (int ii = 0; ii < i_templ_length; ii++)
		pcResult->pi_genotype[ii] = pi_genotype[ii];

	for (int i_offset = 0; i_offset < pcMask->v_mask.size(); i_offset++)
		pcResult->pi_genotype[pcMask->v_mask.at(i_offset)] = pcDonor->pi_genotype[pcMask->v_mask.at(i_offset)];

	double  d_fitness_result;
	pcResult->b_fitness_actual = false;
	d_fitness_result = pcResult->dComputeFitness();

	//::Tools::vReportInFile("zzzzzz_mix_px_log.txt", sToStr());
	//::Tools::vReportInFile("zzzzzz_mix_px_log.txt", pcResult->sToStr());
	//::Tools::vReportInFile("zzzzzz_mix_px_log.txt", "\n");

	if (dComputeFitness() < d_fitness_result)  return(1);
	if (dComputeFitness() == d_fitness_result)  return(0);

	return(-1);
}//int   CConditionalGAIndividual::iConditionalMixing_ByMask(CConditionalGAIndividual  *pcDonor, CConditionalGA_Mask *pcMask, CConditionalGAIndividual  *pcResult)


int  CConditionalGAIndividual::iGetPopLevel()
{
	int  i_pop_level;
	i_pop_level = pc_parent->pc_parent->iGetPopLevel(pc_parent);
	return(i_pop_level);
}//int  CConditionalGAIndividual::iGetPopLevel()




CString  CConditionalGAIndividual::sToStr()
{
	CString  s_res, s_buf;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		s_buf.Format("%d", pi_genotype[ii]);
		s_res += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)

	s_buf.Format("  %.8lf", dComputeFitness());
	s_res += s_buf;

	return(s_res);
}//CString  CConditionalGAIndividual::sToStr()


bool  CConditionalGAIndividual::bIsTheSame(CConditionalGAIndividual  *pcOther)
{
	if ((pi_genotype == NULL))  return(false);
	if ((pcOther->pi_genotype == NULL))  return(false);

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] != pcOther->pi_genotype[ii])  return(false);
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(true);
}//bool  CConditionalGAIndividual::bIsTheSame(CConditionalGAIndividual  *pcOther)


double  CConditionalGAIndividual::dGetSimilarity(CConditionalGAIndividual  *pcOther, int  *piGenesTheSame)
{
	int  i_genes_the_same;
	if (piGenesTheSame == NULL)  piGenesTheSame = &i_genes_the_same;
	*piGenesTheSame = 0;

	if ((pi_genotype == NULL))  return(0);
	if ((pcOther->pi_genotype == NULL))  return(0);


	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] == pcOther->pi_genotype[ii])  (*piGenesTheSame)++;
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	double  d_res;
	d_res = *piGenesTheSame;
	d_res = d_res / i_templ_length;

	return(d_res);
}//double  CConditionalGAIndividual::dGetSimilarity(CConditionalGAIndividual  *pcOther, int  *piGenesTheSame)




void  CConditionalGAIndividual::vRandomizeGenotype()
{
	d_fitnes_buf = -1;
	b_fitness_actual = false;

	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = RandUtils::iRandNumber(0, 1);

};//void  CConditionalGAIndividual::vRandomizeGenotype()


double  CConditionalGAIndividual::dComputeFitness()
{
	if (b_fitness_actual == true)  return(d_fitnes_buf);

	d_fitnes_buf = pc_parent->dComputeFitness(pi_genotype);
	b_fitness_actual = true;

	return(d_fitnes_buf);
};//double  CConditionalGAIndividual::dComputeFitness()


double  CConditionalGAIndividual::dComputeFitnessDouble()
{
	if (b_fitness_actual == true)  return(d_fitnes_buf);

	d_fitnes_buf = pc_parent->dComputeFitnessDouble(pi_genotype);
	b_fitness_actual = true;

	return(d_fitnes_buf);
};//double  CConditionalGAIndividual::dComputeFitness()



void  CConditionalGAIndividual::v_create_opt_order(vector<int>  *pvOrder)
{
	vector<int>  v_temp;

	pvOrder->clear();

	for (int ii = 0; ii < i_templ_length; ii++)
		v_temp.push_back(ii);

	int  i_pos;
	while (v_temp.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_temp.size() - 1);
		pvOrder->push_back(v_temp.at(i_pos));
		v_temp.erase(v_temp.begin() + i_pos);
	}//while  (v_temp.size() > 0)
}//void  CConditionalGAIndividual::v_create_opt_order(vector<int>  *pvOrder)




double  CConditionalGAIndividual::d_optimize_single_gene(int  iOptGene)
{
	double  d_fitness_current, d_fit_new;
	d_fitness_current = dComputeFitness();

	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;

	b_fitness_actual = false;
	d_fit_new = dComputeFitness();

	if (d_fit_new > d_fitness_current)  return(d_fit_new);


	//flip back...
	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;
	b_fitness_actual = true;
	this->d_fitnes_buf = d_fitness_current;

	return(this->d_fitnes_buf);
}//double  CConditionalGAIndividual::d_optimize_single_gene(int  iOptGene)



double  CConditionalGAIndividual::dComputeFitnessOptimize(vector<int>  *pvOrder /*= NULL*/, bool  bDarkGray /*= false*/, int  *piDarkGrayModifiedGenes /*= NULL*/)
{
	
	CString  s_buf;

	if (pvOrder == NULL)  pvOrder = &v_opt_order;
	if (pvOrder->size() != i_templ_length)  v_create_opt_order(pvOrder);

	
		

	if (pc_parent == NULL)
	{
		::MessageBox(NULL, "if (pc_parent == NULL)    double  CConditionalGAIndividual::dComputeFitnessOptimizeDarkGray(vector<int>  *pvOrder = NULL)", "if (pc_parent == NULL)  double  CConditionalGAIndividual::dComputeFitnessOptimizeDarkGray(vector<int>  *pvOrder = NULL)", MB_OK);
		return(-1);
	}//if (pc_parent == NULL)

	int  *pi_genes_to_check_current, *pi_genes_changed;

	
	if (bDarkGray == true)
	{
		pc_parent->vGetGenotypeBufferTools(&pi_genes_to_check_current, &pi_genes_changed);

		if (piDarkGrayModifiedGenes != NULL)
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_changed[ii] = piDarkGrayModifiedGenes[ii];
		}//if (piDarkGrayModifiedGenes != NULL)
		else
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_changed[ii] = 1;
		}//else  if (piDarkGrayModifiedGenes != NULL)
	}//if (bDarkGray == true)
	else
	{
		pi_genes_to_check_current = NULL;
		pi_genes_changed = NULL;
	}//else  if (bDarkGray == true)

	
	int  i_opt_gene;
	int  i_orig_gene_val;
	bool  b_changed;

	b_changed = true;

	//::Tools::vShow("IN");


	bool  b_gene_consider;
	int  i_opt_counter = 0;
	while (b_changed == true)
	{
		//double  d_start, d_end;
		//d_start = dComputeFitness();
		//int i_ffe_start, i_ffe_end;
		//i_ffe_start = pc_problem->pcGetEvaluation()->iGetFFE();



		i_opt_counter++;
		b_changed = false;

		if (bDarkGray == true)
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_to_check_current[ii] = 0;

			for (int ii = 0; ii < i_templ_length; ii++)
			{
				if  (pi_genes_changed[ii] == 1)  pc_parent->pcGetDSM()->vDarkGrayMapDependentGenes(ii, pi_genes_to_check_current);
			}//for (int ii = 0; ii < i_templ_length; ii++)

			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_changed[ii] = 0;
		}//if (bDarkGray == true)

		
		for (int ii = 0; ii < pvOrder->size(); ii++)
		{
			i_opt_gene = pvOrder->at(ii);

			b_gene_consider = false;
			if (bDarkGray == true)
			{
				if  (pi_genes_to_check_current[ii] == 1)  b_gene_consider = true;
			}//if (bDarkGray == true)
			else
				b_gene_consider = true;


			if (b_gene_consider == true)
			{
				i_orig_gene_val = pi_genotype[i_opt_gene];
				d_optimize_single_gene(i_opt_gene);

				if (i_orig_gene_val != pi_genotype[i_opt_gene])
				{
					//if  (b_changed == false)  ::Tools::vShow("b_changed = true;");
					b_changed = true;
					if  (pi_genes_changed  != NULL)  pi_genes_changed[i_opt_gene] = 1;
				}//if (i_orig_gene_val != pi_genotype[i_opt_gene])
			}//if  (b_gene_consider == true)
		}//for  (int  i_opt_traj = 0; i_opt_traj < i_number_of_pairs; i_opt_traj++)


		//d_end = dComputeFitness();
		//s_buf.Format("%.8lf -> %.8lf", d_start, d_end);
		//::Tools::vShow(s_buf);

		/*i_ffe_end = pc_problem->pcGetEvaluation()->iGetFFE();
		s_buf.Format("%d\n%d\n%d\n", i_ffe_start, i_ffe_end, i_ffe_end - i_ffe_start);

		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", s_buf);
		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", sToStr());*/


	}//while (b_changed == true)
	
	
	return(dComputeFitness());
};//double  CConditionalGAIndividual::dComputeFitnessOptimize()




bool  CConditionalGAIndividual::bCheckGenesDependent(int  iGeneBase, int  iGeneOther)
{
	bool  b_result;

	double  d_fit_bo_oo, d_fit_ba_oo;
	double  d_fit_bo_oa, d_fit_ba_oa;

	b_fitness_actual = false;
	d_fit_bo_oo = dComputeFitness();

	pi_genotype[iGeneBase] = iFlipGene(pi_genotype[iGeneBase]);
	b_fitness_actual = false;
	d_fit_ba_oo = dComputeFitness();

	pi_genotype[iGeneBase] = iFlipGene(pi_genotype[iGeneBase]);//flip back
	d_fitnes_buf = d_fit_bo_oo;
	b_fitness_actual = true;

	int i_rel_bo, i_rel_ba;
	int i_rel_oo, i_rel_oa;

	pi_genotype[iGeneOther] = iFlipGene(pi_genotype[iGeneOther]);
	b_fitness_actual = false;
	d_fit_bo_oa = dComputeFitness();

	pi_genotype[iGeneBase] = iFlipGene(pi_genotype[iGeneBase]);
	b_fitness_actual = false;
	d_fit_ba_oa = dComputeFitness();

	pi_genotype[iGeneOther] = iFlipGene(pi_genotype[iGeneOther]);//flip back
	pi_genotype[iGeneBase] = iFlipGene(pi_genotype[iGeneBase]);//flip back
	d_fitnes_buf = d_fit_bo_oo;
	b_fitness_actual = true;


	if (d_fit_bo_oo > d_fit_bo_oa)  i_rel_bo = 1;
	if (d_fit_bo_oo == d_fit_bo_oa)  i_rel_bo = 0;
	if (d_fit_bo_oo < d_fit_bo_oa)  i_rel_bo = -1;

	if (d_fit_ba_oo > d_fit_ba_oa)  i_rel_ba = 1;
	if (d_fit_ba_oo == d_fit_ba_oa)  i_rel_ba = 0;
	if (d_fit_ba_oo < d_fit_ba_oa)  i_rel_ba = -1;

	if (d_fit_bo_oo > d_fit_ba_oo)  i_rel_oo = 1;
	if (d_fit_bo_oo == d_fit_ba_oo)  i_rel_oo = 0;
	if (d_fit_bo_oo < d_fit_ba_oo)  i_rel_oo = -1;

	if (d_fit_bo_oa > d_fit_ba_oa)  i_rel_oa = 1;
	if (d_fit_bo_oa == d_fit_ba_oa)  i_rel_oa = 0;
	if (d_fit_bo_oa < d_fit_ba_oa)  i_rel_oa = -1;


	if ((i_rel_bo != i_rel_ba) || (i_rel_oo != i_rel_oa))
	{
		return(true);
	}//if ((i_rel_bo != i_rel_ba) || (i_rel_oo != i_rel_oa))
	   

	return(false);
}//bool  CConditionalGAIndividual::bCheckGenesDependent(int  iGene0, int  iGene1)


bool  CConditionalGAIndividual::bProbingDependenciesConfirmed_Check(CConditionalGA_ProbingData  *pcProbingToCheck)
{
	for (int ii = 0; ii < v_probing_dependencies_confirmed.size(); ii++)
	{
		if (v_probing_dependencies_confirmed.at(ii).bEqual(pcProbingToCheck) == true)  return(true);
	}//for (int ii = 0; ii < v_probing_dependencies_confirmed.size(); ii++)

	return(false);
}//bool  CConditionalGAIndividual::bProbingDependenciesConfirmed_Check(CConditionalGA_ProbingData  *pcProbingToCheck)


bool  CConditionalGAIndividual::bProbingDependenciesConfirmed_Insert(CConditionalGA_ProbingData  *pcProbingToInsert)
{
	if (bProbingDependenciesConfirmed_Check(pcProbingToInsert) == true)  return(false);

	v_probing_dependencies_confirmed.push_back(*pcProbingToInsert);
	return(true);
}//bool  CConditionalGAIndividual::bProbingDependenciesConfirmed_Insert(CConditionalGA_ProbingData  *pcProbingToInsert)


bool  CConditionalGAIndividual::bDependentPair_Check(int  iGene0, int iGene1)
{
	for (int ii = 0; ii < v_dependent_genes.size(); ii++)
	{
		if (v_dependent_genes.at(ii).bEqual(iGene0, iGene1) == true)  return(true);
	}//for (int ii = 0; ii < v_probing_dependencies_confirmed.size(); ii++)

	return(false);
}//bool  CConditionalGAIndividual::bDependentPair_Insert(CConditionalGA_DependentGenesPair *pcPairToInsert)


bool  CConditionalGAIndividual::bDependentPair_Insert(int  iGene0, int iGene1)
{
	if (bDependentPair_Check(iGene0, iGene1) == true)  return(false);

	v_dependent_genes.push_back(CConditionalGA_DependentGenesPair(iGene0, iGene1));
	return(true);
}//bool  CConditionalGAIndividual::bDependentPair_Check(CConditionalGA_DependentGenesPair *pcPairToCheck)



void  CConditionalGAIndividual::vInsertDependentPairIntoDSM(int  **piDSM)
{
	for (int ii = 0; ii < v_dependent_genes.size(); ii++)
	{
		piDSM[v_dependent_genes.at(ii).i_probing_gene_0][v_dependent_genes.at(ii).i_probing_gene_1] = 1;
		piDSM[v_dependent_genes.at(ii).i_probing_gene_1][v_dependent_genes.at(ii).i_probing_gene_0] = 1;
	}//for (int ii = 0; ii < v_probing_dependencies_confirmed.size(); ii++)
}//void  CConditionalGAIndividual::vInsertDependentPairIntoDSM(int  **piDSM)


double  CConditionalGAIndividual::dDepedentPairsMatching(int **piDSM)
{
	double  d_count;
	d_count = 0;

	if (v_dependent_genes.size() > 0)
	{
		for (int ii = 0; ii < v_dependent_genes.size(); ii++)
		{
			if (piDSM[v_dependent_genes.at(ii).i_probing_gene_0][v_dependent_genes.at(ii).i_probing_gene_1] > 0)  d_count += 1;
		}//for (int ii = 0; ii < v_dependent_genes.size(); ii++)

		d_count = d_count / v_dependent_genes.size();
	}//if (v_dependent_genes.size() > 0)

	return(d_count);
}//double  CConditionalGAIndividual::dDepedentPairsMatching(int **piDSM)


//---------------------------------------------CConditionalGA-------------------------------------------------------




void  CConditionalGA_Mask::vReport(CString  sDest)
{
	FILE  *pf_dest;
	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;
	vReport(pf_dest);
	fclose(pf_dest);
}//void  CConditionalGA_Mask::vReport(CString  sDest)



void  CConditionalGA_Mask::vReportShort(FILE  *pfDest)
{
	CString  s_line, s_buf;
	
	s_line.Format("size: [%d]:", v_mask.size());
	for (int i_off = 0; i_off < v_mask.size(); i_off++)
	{
		s_buf.Format("%d,", v_mask.at(i_off));
		s_line += s_buf;
	}//for (int i_off = 0; i_off < v_mask.size(); i_off++)

	fprintf(pfDest, "%s\n", s_line);

}//void  CConditionalGA_Mask::vReportTest()


void  CConditionalGA_Mask::vReport(FILE  *pfDest)
{
	int  *pi_tool = new int[i_problem_size];

	for (int ii = 0; ii < i_problem_size; ii++)
		pi_tool[ii] = 0;

	for (int i_off = 0; i_off < v_mask.size(); i_off++)
		pi_tool[v_mask.at(i_off)] = 1;


	CString  s_line, s_buf;
	for (int ii = 0; ii < i_problem_size; ii++)
	{
		if (pi_tool[ii] == 0)  s_buf = "_";
		if (pi_tool[ii] == 1)  s_buf = "1";
		s_line += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)
	fprintf(pfDest, "%s\n", s_line);

	s_line.Format("size: [%d]:", v_mask.size());
	for (int i_off = 0; i_off < v_mask.size(); i_off++)
	{
		s_buf.Format("%d,", v_mask.at(i_off));
		s_line += s_buf;
	}//for (int i_off = 0; i_off < v_mask.size(); i_off++)

	fprintf(pfDest, "%s\n", s_line);


	delete  pi_tool;

	//::Tools::vShow(12345);//*/
}//void  CConditionalGA_Mask::vReportTest()



bool  CConditionalGA_Mask::bFitsBlock(vector<int>  *pvBlock)
{
	std::sort(pvBlock->begin(), pvBlock->end(), [](const int  iVal0, const int  iVal1) -> bool { return(iVal0 < iVal1); });
	std::sort(v_mask.begin(), v_mask.end(), [](const int  iVal0, const int  iVal1) -> bool { return(iVal0 < iVal1); });

	/*if (v_mask.size() == 5)
	{
		//::Tools::vShow("if (v_mask.size() == 5)");
		if ((v_mask.at(0) == 8) && (v_mask.at(1) == 15) && (v_mask.at(2) == 82) && (v_mask.at(3) == 88) && (v_mask.at(4) == 136))
		{
			CString  s_line, s_buf;
			for (int ii = 0; ii < pvBlock->size(); ii++)
			{
				s_buf.Format("%d,", pvBlock->at(ii));
				s_line += s_buf;
			}//for (int ii = 0; ii < pvBlock->size(); ii++)

			::Tools::vShow(s_line);

		}//if ((v_mask.at(0) == 8) && (v_mask.at(0) == 15) && (v_mask.at(0) == 82) && (v_mask.at(0) == 88) && (v_mask.at(0) == 136))
	}//if (v_mask.size() == 5)*/

	if (pvBlock->size() != v_mask.size())  return(false);

	for (int ii = 0; ii < v_mask.size(); ii++)
	{
		if (v_mask.at(ii) != pvBlock->at(ii))  return(false);
	}//for (int ii = 0; ii < v_mask.size(); ii++)

	return(true);
}//bool  CConditionalGA_Mask::bFitsBlock(vector<int>  *pvBlock)


CString  CConditionalGA_Mask::sToStr()
{
	CString  s_result;

	int  *pi_tool = new int[i_problem_size];

	for (int ii = 0; ii < i_problem_size; ii++)
		pi_tool[ii] = 0;

	for (int i_off = 0; i_off < v_mask.size(); i_off++)
		pi_tool[v_mask.at(i_off)] = 1;


	CString  s_buf;
	for (int ii = 0; ii < i_problem_size; ii++)
	{
		if (pi_tool[ii] == 0)  s_buf = "_";
		if (pi_tool[ii] == 1)  s_buf = "1";
		s_result += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)


	delete  pi_tool;


	return(s_result);
};//CString  CConditionalGA_Mask::sToStr()