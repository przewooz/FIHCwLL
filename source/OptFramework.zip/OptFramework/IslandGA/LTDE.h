#ifndef LTDE_H
#define LTDE_H

#include "DSMCreation.h"
#include "Error.h"
#include "GenePattern.h"
#include "GenePatternTree.h"
#include "HierarchicalClustering.h"
#include "Log.h"
#include "MutationUtils.h"
#include "Optimizer.h"
#include "PopulationOptimizer.h"
#include "Problem.h"
#include "RealCoding.h"
#include "RealMutation.h"

#include <ctime>
#include <cstdint>
#include <istream>
#include <vector>

using namespace Clustering;
using namespace Linkage;

using namespace std;

class CLTDE : public CPopulationOptimizer<CRealCoding, CRealCoding>
{
public:
	CLTDE(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
	CLTDE(CLTDE *pcOther);

	virtual ~CLTDE();

	virtual CError eConfigure(istream *psSettings);

	virtual COptimizer<CRealCoding, CRealCoding> *pcCopy() { return new CLTDE(this); };

	virtual void vInitialize();
	virtual bool bRunIteration(uint32_t iIterationNumber);

private:
	void v_init();
	void v_clear_params();

	void v_run_iteration(CIndividual<CRealCoding, CRealCoding> **ppcIndividual, uint32_t iIndividualIndex, vector<CGenePattern*> *pvGenePatterns);
	void v_run_iteration(CIndividual<CRealCoding, CRealCoding> **ppcIndividual, uint32_t iIndividualIndex, CGenePattern *pcGenePattern);

	void v_mutation(CIndividual<CRealCoding, CRealCoding> *pcIndividual, uint32_t iIndividualIndex, CGenePattern *pcGenePattern);
	void v_crossover(CIndividual<CRealCoding, CRealCoding> *pcSource, CIndividual<CRealCoding, CRealCoding> *pcDonor, CGenePattern *pcGenePattern);

	double d_get_mutation_factor(uint16_t iGeneIndex, CGenePattern *pcGenePattern);

	void v_fill_genotypes();

	CRealFactorMutation *pc_mutation;

	CRealCoding **ppc_genotypes;

	double **ppd_dsm;
	double **ppd_mutation_factor_adaptation;

	CDSMCreation<CRealCoding> *pc_dsm_creation;
	CBiggestBucketDSMCreation c_mutation_factor_adaptation;
};//class CLTDE : public COptimizer<CRealCoding, CRealCoding>

#endif//LTDE_H