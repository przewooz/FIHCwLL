#pragma once
using namespace std;

#include "lkGomea_Config.h"
#include "lkGomea_Individual.h"
#include "lkGomea_shared.h"

//prw added include:
#include "lkGomea_problems.h"

class C_lkGomea_BitflipLS {
public:
	C_lkGomea_BitflipLS(C_lkGomea_Config *config_, C_lkGomea_sharedInformation *info_, C_lkGomea_Problem *problem_);
    ~C_lkGomea_BitflipLS();
    void optimize(C_lkGomea_Individual *individual_, size_t populationSize);
    // void shuffle_order(mt19937 *rng);
    bool b_evaluateSolution(C_lkGomea_Individual *new_solution, C_lkGomea_Individual *orig_solution, vector<int> &changedGenes, size_t populationSize);
    void checkVTR(C_lkGomea_Individual *solution, size_t populationSize);
    bool b_checkTimeLimit_OK();

	C_lkGomea_Config *config;
	C_lkGomea_sharedInformation *info;
	C_lkGomea_Problem *problem;
    vector<size_t> sequence;
};