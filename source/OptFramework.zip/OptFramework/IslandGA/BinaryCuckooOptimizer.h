#pragma once
#include "PopulationSizingOptimizer.h"
#include <vector>
#include <math.h>
#include <random>

#define BINARY_CUCKOO_OPTIMIZER_ARGUMENT_LAMBDA "lambda"
#define BINARY_CUCKOO_OPTIMIZER_ARGUMENT_ALPHA "alpha"
#define BINARY_CUCKOO_OPTIMIZER_ARGUMENT_NMUT "n_mut"
#define BINARY_CUCKOO_OPTIMIZER_ARGUMENT_PA "pa"
#define BINARY_CUCKOO_OPTIMIZER_ARGUMENT_POPULATION_SIZE "population_size"
#define BINARY_CUCKOO_OPTIMIZER_ARGUMENT_STALE_DETECTION "stale_detection"

class CBinaryCuckooIndividual;

class CBinaryCuckooOptimizer:
	public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>
{
public:
	static uint32_t  iERROR_PARENT_CBinaryCuckooOptimizer;
	static const uint32_t I_DEFAULT_N_MUT;
	static const float F_DEFAULT_ALPHA;
	static const float F_DEFAULT_LAMBDA;
	static const float F_DEFAULT_PA;
	static const double D_DEFAULT_LOWER_BOUND;
	static const double D_DEFAULT_UPPER_BOUND;
	static const uint32_t I_DEFAULT_POPULATION_SIZE;
	static const double D_DEFAULT_LEVY_BETA;

	CBinaryCuckooOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog* pcLog, uint32_t iRandomSeed);
	CBinaryCuckooOptimizer(CBinaryCuckooOptimizer* pcOther);

	virtual ~CBinaryCuckooOptimizer();

	COptimizer<CBinaryCoding, CBinaryCoding>* pcCopy() override;
	CError eConfigure(istream* psSettings) override;

	bool bRunIteration(uint32_t iIterationNumber) override;
	void vInitialize() override;
	void vEvaluate();

	bool bIsSteadyState() override;
	double dComputeAverageFitnessValue() override;
	uint32_t iGetPopulationSize() override { return i_population_size; }
	void vSetPopulationSize(uint32_t iPopulationSize) override { i_population_size = iPopulationSize; };

protected:
	void v_delete_population();
	void v_initialize_population();
	double d_evaluate(CBinaryCuckooIndividual* pc_individual);
	void v_update_best();
	void v_mutate();
	void v_replace();
	void v_levy_flight();

	uniform_real_distribution<double> c_individual_distribution;
	uniform_real_distribution<double> c_uniform_distribution;
	default_random_engine c_random_engine;

	vector<CBinaryCuckooIndividual*> v_population;
	uint16_t i_genotype_length;
	double d_lambda;
	double d_alpha;
	uint32_t i_nmut;
	double d_pa;
	double d_lower_bound;
	double d_upper_bound;
	double d_levy_beta;
	double d_levy_sigma;
	bool b_use_stale_detection;
	uint32_t i_population_size;
	CBinaryCuckooIndividual* pc_best;
	double d_best_fitness;
};//class CBinaryCuckooOptimizer

class CBinaryCuckooIndividual
{
public:
	friend class CBinaryCuckooOptimizer;

	CBinaryCuckooIndividual(uint16_t iGenotypeLength, double dLowerBound, double dUpperBound);
	CBinaryCuckooIndividual(CBinaryCuckooIndividual* pcOther);

	static CBinaryCuckooIndividual* pcGetRandomIndividual(
		uint16_t iGenotypeLength,
		double dLowerBound,
		double dUpperBound,
		uniform_real_distribution<double>& cIndividualDistribution,
		default_random_engine& cRandomEngine);

	void vGenotypeProbing();

protected:
	void v_clip_to_bounds();

	double d_fitness;
	double d_lower_bound;
	double d_upper_bound;
	vector<double> v_eggs;
	vector<int32_t> v_genotype;
};//class CBinaryCuckooIndividual

