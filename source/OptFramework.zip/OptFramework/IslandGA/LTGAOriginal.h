#ifndef LTGA_ORIGINAL_H
#define LTGA_ORIGINAL_H

#define LTGA_ORIGINAL_ARGUMENT_DO_LOCAL_SEARCH "opt_at_init_LTgomea(0-randInit; 1-fihcInit; 2-LS_wLL_NO_LL; 3-LS_wLL; 4-fihc_wLL)"
#define LTGA_ORIGINAL_ARGUMENT_LOCAL_SEARCH_ONE_ITERATION "local_search_one_iteration"
#define LTGA_ORIGINAL_ARGUMENT_WITHOUT_TOURNAMENT_SELECTION "without_tournament_selection"
#define LTGA_ORIGINAL_ARGUMENT_LINKAGE_TREE_RANDOM_ORDER "linkage_tree_random_order"

#define LTGA_ORIGINAL_ARGUMENT_AVOID_FI "avoid_fi"

#include "BinaryCoding.h"
#include "Error.h"
#include "Log.h"
#include "Optimizer.h"
#include "Problem.h"

#include "../LTGA/LTGA.h"

#include <ctime>
#include <cstdint>
#include <istream>
#include <vector>

using namespace std;



class CLTGAOriginal : public COptimizer<CBinaryCoding, CBinaryCoding>
{
public:
	CLTGAOriginal(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
	CLTGAOriginal(CLTGAOriginal *pcOther);

	virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CLTGAOriginal(this); };

	virtual CError eConfigure(istream *psSettings);

	virtual void vInitialize();
	virtual bool bRunIteration(uint32_t iIterationNumber);
	virtual bool bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage);
	bool bRunIteration(uint32_t iIterationNumber, CIndividual<CBinaryCoding, CBinaryCoding> *pcBestIndividual);
	bool bRunIterationSeparateLinkage(uint32_t iIterationNumber, CIndividual<CBinaryCoding, CBinaryCoding> *pcBestIndividual, CLinkageAnalyzer  *pcSeparateLinkage);

	virtual void vRun();

	bool bAreAllIndividualsTheSame() { return c_ltga.areAllSolutionsTheSame(); }
	double dComputeAverageFitnessValue() { return c_ltga.computeAverageObjectiveValue(); }

	uint32_t iGetPopulationSize() { return (uint32_t)c_ltga.getPopulationSize(); }
	void vSetPopulationSize(uint32_t iPopulationSize) { c_ltga.setPopulationSize((int)iPopulationSize); }
	void  vSetVIG(CLTGAVig  *pcVIG) { c_ltga.vSetVIG(pcVIG); }

	double  **pdGetDSM() { return(c_ltga.pdGetDSM()); }
	int  iGetDSMSize() { return(c_ltga.iGetDSMSize()); }

	CLinkageInformationPack  *pcGetLinkagePack() { return(c_ltga.pcGetLinkagePack()); }

	void  vExecuteBeforeEnd() override;
	void  vReportLinkage() override;

	void  vGetSlideInformation(double  *pdSlides, double  *pdBlockedSlides) { *pdSlides = c_ltga.iGetSlideOK(); *pdBlockedSlides = c_ltga.iGetSlideBlocked(); };


private:
	using COptimizer<CBinaryCoding, CBinaryCoding>::b_update_best_individual;
	bool b_update_best_individual(uint32_t iIterationNumber);

	NLTGA::LTGA c_ltga;
	vector<char> v_ltga_individual;
};//class CLTGAOriginal : public COptimizer<CBinaryCoding, CBinaryCoding>

#endif//LTGA_ORIGINAL_H