#include "LinkageAnalyzer.h"
#include "util\timer.h"




uint32_t CLinkageAnalyzer::iERROR_PARENT_CLinkageAnalyzer = CError::iADD_ERROR_PARENT("iERROR_PARENT_CLinkageAnalyzer");
uint32_t CLinkageInformationPack::iERROR_PARENT_CLinkageInformationPack = CError::iADD_ERROR_PARENT("iERROR_PARENT_CLinkageInformationPack");

uint32_t CLinkageInformationPack::iERROR_CLinkageInformationPack_SAVE_ERR = CError::iADD_ERROR("iERROR_CLinkageInformationPack_SAVE_ERR");


CLinkageAnalyzer::CLinkageAnalyzer()
{
	s_name = "";
	pc_linkage_to_share = NULL;

	i_analyzer_iterations_frequency = 0;
	i_registered_iterations = 0;

	d_outside_linkage_quality = -1;
	d_outside_linkage_diverse = -1;
	i_outside_linkage_mode = OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_FIXED_LINKAGE;
	i_outside_linkage_representation = OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_LINKAGE_REPRESENTATION_LTREE;

	pd_linkage_gathering_probabilities = NULL;
	pi_no_linkage_for_gene = NULL;
	pc_p3_linkage_pack = NULL;

	d_linkage_cost_ffe = 0;
	d_linkage_cost_time = 0;
}//CLinkageAnalyzer::CLinkageAnalyzer()



CLinkageAnalyzer::~CLinkageAnalyzer()
{
	for (int ii = 0; ii < v_dsm_sets.size(); ii++)
		delete  v_dsm_sets.at(ii);

	if (pc_linkage_to_share != NULL)  delete  pc_linkage_to_share;

	for (int ii = 0; ii < v_global_linkage_scraps.size(); ii++)
		delete  v_global_linkage_scraps.at(ii);
	
	if (pd_linkage_gathering_probabilities != NULL)  delete  pd_linkage_gathering_probabilities;
	if (pi_no_linkage_for_gene != NULL)  delete  pi_no_linkage_for_gene;
	
}//CLinkageAnalyzer::~CLinkageAnalyzer()



void  CLinkageAnalyzer::vSetTrueLinkage(vector<vector <int>>  *pvDependentGenes)
{
	if (pvDependentGenes == NULL)  return;

	v_true_linkage = *pvDependentGenes;
}//void  CLinkageAnalyzer::vGetTrueLinkage(vector<vector <int>>  *pvDependentGenes)


CError CLinkageAnalyzer::eConfigure(istream *psSettings)
{
	CError  c_err(iERROR_PARENT_CLinkageAnalyzer);

	CUIntCommandParam p_linkage_analyzer_frequency(OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_FREQUENCY);
	i_analyzer_iterations_frequency = p_linkage_analyzer_frequency.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);


	CUIntCommandParam p_linkage_force_full_report(OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_FORCE_FULL_REPORT);
	i_linkage_force_full_report = p_linkage_force_full_report.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);


	d_outside_linkage_quality = -1;
	d_outside_linkage_diverse = -1;


	if (!c_err)
	{
		CUIntCommandParam p_linkage_analyzer_outside_linkage_mode(OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_LINKAGE_MODE);
		i_outside_linkage_mode = p_linkage_analyzer_outside_linkage_mode.iGetValue(psSettings, &c_err);

		
		if (p_linkage_analyzer_outside_linkage_mode.bHasValue() == false)  i_outside_linkage_mode = OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_FIXED_LINKAGE;

		d_outside_linkage_quality = -1;
		d_outside_linkage_diverse = -1;
		if (i_outside_linkage_mode == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_FIXED_LINKAGE)
		{
			if (!c_err)
			{
				CFloatCommandParam p_linkage_analyzer_outside_quality(OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY);
				d_outside_linkage_quality = p_linkage_analyzer_outside_quality.fGetValue(psSettings, &c_err);
				if (p_linkage_analyzer_outside_quality.bHasValue() == false)  d_outside_linkage_quality = -1;

				CFloatCommandParam p_linkage_analyzer_outside_diverse(OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_DIVERSE);
				d_outside_linkage_diverse = p_linkage_analyzer_outside_diverse.fGetValue(psSettings, &c_err);
				if (p_linkage_analyzer_outside_diverse.bHasValue() == false)  d_outside_linkage_diverse = -1;
				
			}//if (!c_error)
		}//if (i_outside_linkage_mode == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_FIXED_LINKAGE)

		CUIntCommandParam p_linkage_analyzer_linkage_repersentation(OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_LINKAGE_REPRESENTATION);
		i_outside_linkage_representation = p_linkage_analyzer_linkage_repersentation.iGetValue(psSettings, &c_err);
		if (p_linkage_analyzer_linkage_repersentation.bHasValue() == false)  i_outside_linkage_representation = OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_LINKAGE_REPRESENTATION_LTREE;
		
	}//if (!c_error)

	

	
	
	

	return(c_err);
}//CError CLinkageAnalyzer::eConfigure(istream *psSettings)





void  CLinkageAnalyzer::vRecomputeDiscretizedDSM(int  iLinkLevel)
{
	if ((0 <= iLinkLevel) && (iLinkLevel < v_dsm_sets.size()))
	{
		v_dsm_sets.at(iLinkLevel)->vRecomputeDiscretizedDSM();
	}//if ((0 <= iLinkLevel) && (iLinkLevel < v_dsm_sets.size()))

}//void  CLinkageAnalyzer::vRecomputeDiscretizedDSM(int  iLinkLevel)


void  CLinkageAnalyzer::vRecomputeDSM_PairingRankings(int  iLinkLevel)
{
	if ((0 <= iLinkLevel) && (iLinkLevel < v_dsm_sets.size()))
	{
		v_dsm_sets.at(iLinkLevel)->vRecomputeDSM_PairingRankings();
	}//if ((0 <= iLinkLevel) && (iLinkLevel < v_dsm_sets.size()))
}//void  CLinkageAnalyzer::vRecomputeDSM_PairingRankings(int  iLinkLevel)



void  CLinkageAnalyzer::vGetReproducedDSM_P3(int  iLinkLevel, unordered_map<int, unordered_map<int, double> > *pcDestination)
{
	if ((0 <= iLinkLevel) && (iLinkLevel < v_dsm_sets.size()))
	{
		v_dsm_sets.at(iLinkLevel)->vGetReproducedDSM_P3(pcDestination);
	}//if ((0 <= iLinkLevel) && (iLinkLevel < v_dsm_sets.size()))
}//void  CLinkageAnalyzer::vGetReproducedDSM_P3(int  iLinkLevel, unordered_map<int, unordered_map<int, double> > *pcDestination)


vector<vector<int> > *CLinkageAnalyzer::pvGetP3Clusters(int  iLinkLevel)
{
	if (iLinkLevel >= v_dsm_sets.size())  return(NULL);
	if (iLinkLevel >= 0)
		return(v_dsm_sets.at(iLinkLevel)->pvGetP3Clusters());
	else
	{
		if (pc_linkage_to_share == NULL)  return(NULL);
		return(pc_linkage_to_share->pvGetP3Clusters());
	}//else  if (iLinkLevel > 0)

	return(NULL);
}//vector<vector<int> > *CLinkageAnalyzer::pvGetP3Clusters(int  iLinkLevel)



vector<int> * CLinkageAnalyzer::pvGetP3ClusterOrdering(int  iLinkLevel)
{
	if (iLinkLevel >= v_dsm_sets.size())  return(NULL);
	if (iLinkLevel >= 0)
		return(v_dsm_sets.at(iLinkLevel)->pvGetP3ClusterOrdering());
	else
	{
		if (pc_linkage_to_share == NULL)  return(NULL);
		return(pc_linkage_to_share->pvGetP3ClusterOrdering());
	}//else  if (iLinkLevel > 0)

	return(NULL);

}//vector<int> * CLinkageAnalyzer::pvGetP3ClusterOrdering(int  iLinkLevel)


void  CLinkageAnalyzer::vSetP3Clusters(int  iLinkLevel, vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering)
{
	CLinkageAnalyzerSingleDSM  *pc_new_dsm_set;
	

	if (iLinkLevel >= 0)
	{
		while (v_dsm_sets.size() <= iLinkLevel)
		{
			pc_new_dsm_set = new CLinkageAnalyzerSingleDSM(this);
			v_dsm_sets.push_back(pc_new_dsm_set);
		}//while (v_dsm_sets.size() <= iLinkLevel)

		v_dsm_sets.at(iLinkLevel)->vSetP3Clusters(pvClusters, pvClusterOrdering);
	}//if (iLinkLevel >= 0)
	else
	{
		if (pc_linkage_to_share == NULL)  pc_linkage_to_share = new CLinkageAnalyzerSingleDSM(this);
		pc_linkage_to_share->vSetP3Clusters(pvClusters, pvClusterOrdering);
	}//else  if (iLinkLevel >= 0)
}//void  CLinkageAnalyzer::vSetP3Clusters(int  iLinkLevel, vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering)


void  CLinkageAnalyzer::vSetDSMGA2_DSM(int  iLinkLevel, int  iSize, TriMatrix<double> *pvDSM, int iDSM_size)
{
	CLinkageAnalyzerSingleDSM  *pc_new_dsm_set;

	if (iLinkLevel >= 0)
	{
		while (v_dsm_sets.size() <= iLinkLevel)
		{
			pc_new_dsm_set = new CLinkageAnalyzerSingleDSM(this);
			v_dsm_sets.push_back(pc_new_dsm_set);
		}//while (v_dsm_sets.size() <= iLinkLevel)

		v_dsm_sets.at(iLinkLevel)->vSetDSMGA2_DSM(pvDSM, iDSM_size);
		v_dsm_sets.at(iLinkLevel)->vSetPopSize(iSize);
	}//if (iLinkLevel >= 0)
	else
	{
		if (pc_linkage_to_share == NULL)  pc_linkage_to_share = new CLinkageAnalyzerSingleDSM(this);

		pc_linkage_to_share->vSetDSMGA2_DSM(pvDSM, iDSM_size);
		pc_linkage_to_share->vSetPopSize(iSize);
	}//else  if (iLinkLevel >= 0)
}//void  CLinkageAnalyzer::vSetDSMGA2_DSM(int  iLinkLevel, int  iSize, TriMatrix<double> *pvDSM)


void  CLinkageAnalyzer::vSetLinkDataPackDSM(int  iLinkLevel, int  iSize, double **pdDSM, int iDSM_size, CString  sAdditionalName)
{
	CLinkageAnalyzerSingleDSM  *pc_new_dsm_set;



	if (iLinkLevel >= 0)
	{
		while (v_dsm_sets.size() <= iLinkLevel)
		{
			pc_new_dsm_set = new CLinkageAnalyzerSingleDSM(this, sAdditionalName);
			v_dsm_sets.push_back(pc_new_dsm_set);
		}//while (v_dsm_sets.size() <= iLinkLevel)

		v_dsm_sets.at(iLinkLevel)->vSetLinkDataPackDSM(pdDSM, iDSM_size);
		v_dsm_sets.at(iLinkLevel)->vSetPopSize(iSize);
	}//if (iLinkLevel >= 0)
	else
	{
		if (pc_linkage_to_share == NULL)  pc_linkage_to_share = new CLinkageAnalyzerSingleDSM(this);

		pc_linkage_to_share->vSetLtgaDSM(pdDSM, iDSM_size);
		pc_linkage_to_share->vSetPopSize(iSize);
	}//else  if (iLinkLevel >= 0)
}//void  CLinkageAnalyzer::vSetLinkDataPackDSM(int  iLinkLevel, int  iSize, double **pdDSM, int iDSM_size)


void  CLinkageAnalyzer::vSetLTGA_DSM(int  iLinkLevel, int  iSize, double **pdDSM, int iDSM_size)
{
	CLinkageAnalyzerSingleDSM  *pc_new_dsm_set;



	if (iLinkLevel >= 0)
	{
		while (v_dsm_sets.size() <= iLinkLevel)
		{
			pc_new_dsm_set = new CLinkageAnalyzerSingleDSM(this);
			v_dsm_sets.push_back(pc_new_dsm_set);
		}//while (v_dsm_sets.size() <= iLinkLevel)

		v_dsm_sets.at(iLinkLevel)->vSetLtgaDSM(pdDSM, iDSM_size);
		v_dsm_sets.at(iLinkLevel)->vSetPopSize(iSize);
	}//if (iLinkLevel >= 0)
	else
	{
		if (pc_linkage_to_share == NULL)  pc_linkage_to_share = new CLinkageAnalyzerSingleDSM(this);

		pc_linkage_to_share->vSetLtgaDSM(pdDSM, iDSM_size);
		pc_linkage_to_share->vSetPopSize(iSize);
	}//else  if (iLinkLevel >= 0)
}//void  CLinkageAnalyzer::vSetLTGA_DSM(int  iLinkLevel, int  iSize, **pdDSM)


void  CLinkageAnalyzer::vSetP3DSM(int  iLinkLevel, int  iSize, unordered_map<int, unordered_map<int, double> > *pcDSM)
{
	CLinkageAnalyzerSingleDSM  *pc_new_dsm_set;



	if (iLinkLevel >= 0)
	{
		while (v_dsm_sets.size() <= iLinkLevel)
		{
			pc_new_dsm_set = new CLinkageAnalyzerSingleDSM(this);
			v_dsm_sets.push_back(pc_new_dsm_set);
		}//while (v_dsm_sets.size() <= iLinkLevel)

		v_dsm_sets.at(iLinkLevel)->vSetP3DSM(pcDSM);
		v_dsm_sets.at(iLinkLevel)->vSetPopSize(iSize);
	}//if (iLinkLevel >= 0)
	else
	{
		if (pc_linkage_to_share == NULL)  pc_linkage_to_share = new CLinkageAnalyzerSingleDSM(this);

		pc_linkage_to_share->vSetP3DSM(pcDSM);
		pc_linkage_to_share->vSetPopSize(iSize);
	}//else  if (iLinkLevel >= 0)


	/*if (pcDSM->size() + 1 != 40)
	{
		CString  s_buf;
		s_buf.Format("Entry size: %d / %d", pcDSM->size() + 1, pcDSM->at(0).size());
		::MessageBox(NULL, s_buf, s_buf, MB_OK);
	}//if (i_dsm_size != 40)*/

	


	/*if (pcDSM->size() + 1 != 40)
	{
		CString  s_buf;
		s_buf.Format("Out size: %d   DSM size: %d", pcDSM->size() + 1, v_dsm_sets.at(iLinkLevel)->iGetDSMsize());
		::MessageBox(NULL, s_buf, s_buf, MB_OK);
	}//if (i_dsm_size != 40)*/
	
}//void  CLinkageAnalyzer::vSetP3DSM(int  iLinkPart, unordered_map<int, unordered_map<int, double> > *pcDSM)



bool  CLinkageAnalyzer::bGetLinkageDiscoveryProbabilities(double  *pdAvr, double *pdMin, double *pdMax, double  *pdLinkageFill, int iProblemSize)
{
	if (pd_linkage_gathering_probabilities == NULL)  return(false);

	*pdLinkageFill = 0;
	*pdAvr = 0;
	*pdMin = pd_linkage_gathering_probabilities[0];
	*pdMax = pd_linkage_gathering_probabilities[0];
	for (int ii = 0; ii < iProblemSize; ii++)
	{
		*pdAvr += pd_linkage_gathering_probabilities[ii];

		if (*pdMin > pd_linkage_gathering_probabilities[ii])  *pdMin = pd_linkage_gathering_probabilities[ii];
		if (*pdMax < pd_linkage_gathering_probabilities[ii])  *pdMax = pd_linkage_gathering_probabilities[ii];

		if (pi_no_linkage_for_gene[ii] == 0)  (*pdLinkageFill)++;
	}//for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)


	*pdLinkageFill = *pdLinkageFill / iProblemSize;
	*pdAvr = *pdAvr / iProblemSize;

	return(true);
}//double  CLinkageInformationPack::dGetLinkageDiscoveryProbabilitiesAverage()


void  CLinkageAnalyzer::vResetProbabilities(int  iProblemSize)
{
	if (pd_linkage_gathering_probabilities != NULL)
	{
		for (int ii = 0; ii < iProblemSize; ii++)
		{
			pd_linkage_gathering_probabilities[ii] = 1;
			pi_no_linkage_for_gene[ii] = 1;
		}//for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
	}//if  (pd_linkage_gathering_probabilities == NULL)
}//void  CLinkageAnalyzer::vResetProbabilities()



bool  CLinkageAnalyzer::bIsOutsideModeLinkageGenerating()
{
	if (i_outside_linkage_mode == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_FAST_3LO)  return(true);
	if (i_outside_linkage_mode == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_RANDOM)  return(true);
	if (i_outside_linkage_mode == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_HLL)  return(true);
	if (i_outside_linkage_mode == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_MIX_DLED_SLL)  return(true);
	if (i_outside_linkage_mode == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_MIX_DLED_SLL_HLL)  return(true);
	if (i_outside_linkage_mode == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_SLL)  return(true);
	if (i_outside_linkage_mode == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_DIRECTIONAL_LINKAGE)  return(true);
	
	return(false);
}//bool  CLinkageAnalyzer::bIsOutsideModeLinkageGenerating()



bool  CLinkageAnalyzer::bLinkagePackCreate(CLinkageInformationPack **pcNewLinkagePack)
{
	if (pcNewLinkagePack == NULL)  return(false);

	*pcNewLinkagePack = new CLinkageInformationPack(this);
	(*pcNewLinkagePack)->i_linkage_type = this->i_outside_linkage_mode;
	
	return(true);
}//bool  CLinkageAnalyzer::bLinkagePackCreate(CLinkageInformationPack **pcNewLinkagePack)



void  CLinkageAnalyzer::vSetOutsideLinkage(int  iLinkLevel, int  iSize, int iDSM_size)
{
	//::Tools::vShow("CLinkageAnalyzer::vSetOutsideLinkage");
	if (v_true_linkage.size() == 0)  return;
	
	CLinkageAnalyzerSingleDSM  *pc_new_dsm_set;

	if (iLinkLevel >= 0)
	{
		bool  b_new_level = false;

		while (v_dsm_sets.size() <= iLinkLevel)
		{
			pc_new_dsm_set = new CLinkageAnalyzerSingleDSM(this);
			v_dsm_sets.push_back(pc_new_dsm_set);
			b_new_level = true;
		}//while (v_dsm_sets.size() <= iLinkLevel)

		v_dsm_sets.at(iLinkLevel)->vSetOutsideLinkage(iDSM_size);
		v_dsm_sets.at(iLinkLevel)->vSetPopSize(iSize);
	}//if (iLinkLevel >= 0)
	else
	{
		return;//we do not set anything if we already have it...
		if (pc_linkage_to_share == NULL)  pc_linkage_to_share = new CLinkageAnalyzerSingleDSM(this);

		v_dsm_sets.at(iLinkLevel)->vSetOutsideLinkage(iDSM_size);
		pc_linkage_to_share->vSetPopSize(iSize);
	}//else  if (iLinkLevel >= 0)
}//void  CLinkageAnalyzer::vSetOutsideLinkage(int  iLinkLevel, int  iSize, int iDSM_size)






void  CLinkageAnalyzer::vCheckSize()
{
	for (int i_dsm = 0; i_dsm < v_dsm_sets.size(); i_dsm++)
	{
		if (v_dsm_sets.at(i_dsm)->iGetDSMsize() != 400)  v_dsm_sets.at(0)->vShow(i_dsm);
	}//for (int i_dsm = 0; i_dsm < v_dsm_sets.size(); i_dsm++)
}//void  CLinkageAnalyzer::vCheckSize()



void  CLinkageAnalyzer::vUpdateSingleMemorySet()
{
	if (v_dsm_sets.size() > 0)
	{
		if  (v_memory_sets.size() == 0)  v_memory_sets.push_back(new CLinkageAnalyzerMemorySet());

		CLinkageAnalyzerMemorySet  *pc_current_memory_state;
		pc_current_memory_state = v_memory_sets.at(0);

		pc_current_memory_state->s_additional_name = v_dsm_sets.at(0)->s_additional_name;
		pc_current_memory_state->i_pop_size = v_dsm_sets.at(0)->i_pop_size;
		pc_current_memory_state->i_level = 0;


		v_dsm_sets.at(0)->vRecomputeDiscretizedDSM();

		//double  d_avr, d_median, d_min, d_max;
		v_dsm_sets.at(0)->vReportLinkQualityPerfectBlockLengthOverhead(&(pc_current_memory_state->d_overhead_avr), &(pc_current_memory_state->d_overhead_median), &(pc_current_memory_state->d_overhead_min), &(pc_current_memory_state->d_overhead_max));
		v_dsm_sets.at(0)->vReportLinkQualityPerfectBlockLengthFill(&(pc_current_memory_state->d_fill_avr), &(pc_current_memory_state->d_fill_median), &(pc_current_memory_state->d_fill_min), &(pc_current_memory_state->d_fill_max));


	}//if (v_dsm_sets.size() > 0)
}//void  CLinkageAnalyzer::vUpdateSingleMemorySet()



void  CLinkageAnalyzer::vCreatePairsReportAndFlushDependentPairs()
{
	CLinkageAnalyzerMemorySet  *pc_new_memory_state;


	for (int i_level = 0; i_level < v_dsm_sets.size(); i_level++)
	{
		pc_new_memory_state = new CLinkageAnalyzerMemorySet();


		v_memory_sets.push_back(pc_new_memory_state);

		pc_new_memory_state->s_additional_name = v_dsm_sets.at(i_level)->s_additional_name;
		pc_new_memory_state->i_pop_size = v_dsm_sets.at(i_level)->i_pop_size;
		pc_new_memory_state->i_level = i_level;


		v_dsm_sets.at(i_level)->vRecomputeDiscretizedDSM();

		//double  d_avr, d_median, d_min, d_max;
		v_dsm_sets.at(i_level)->vReportLinkQualityPerfectBlockLengthOverhead(&(pc_new_memory_state->d_overhead_avr), &(pc_new_memory_state->d_overhead_median), &(pc_new_memory_state->d_overhead_min), &(pc_new_memory_state->d_overhead_max));
		v_dsm_sets.at(i_level)->vReportLinkQualityPerfectBlockLengthFill(&(pc_new_memory_state->d_fill_avr), &(pc_new_memory_state->d_fill_median), &(pc_new_memory_state->d_fill_min), &(pc_new_memory_state->d_fill_max));


		v_dsm_sets.at(i_level)->vRecomputeDSM_PairingRankings();


		pc_new_memory_state->v_strict_dependent_set = v_dsm_sets.at(i_level)->v_strict_dependent_pairs;
		pc_new_memory_state->v_full_blocks_detection = v_dsm_sets.at(i_level)->v_full_blocks_detection;

		v_dsm_sets.at(i_level)->v_full_blocks_detection.clear();

		v_dsm_sets.at(i_level)->v_strict_dependent_pairs.clear();
	}//for  (int  i_level = 0; i_level < v_dsm_sets.size(); i_level++)
}//void  CLinkageAnalyzer::vCreatePairsReportAndFlushDependentPairs()



void  CLinkageAnalyzer::v_save_linkage_report_for_single_dsm(CString  sSingleDSM_LinkageReportFile, CString  sDSMname, CLinkageAnalyzerSingleDSM  *pcSingleDSManalyzer, FILE  *pfGeneralReport)
{
	CString  s_line, s_buf;
	double  d_avr, d_median, d_min, d_max;

	if (pfGeneralReport != NULL)
	{
		s_line.Format("DSM \t %s: \t Size: \t %d\t ", sDSMname, pcSingleDSManalyzer->iGetPopSize());
		pcSingleDSManalyzer->vRecomputeDiscretizedDSM();

		pcSingleDSManalyzer->vReportLinkQualityPerfectBlockLengthOverhead(&d_avr, &d_median, &d_min, &d_max);
		s_buf.Format("OVERHEAD: \t Med: \t %.8lf \t Avr: \t %.8lf \t Min: \t %.8lf \t Max: \t %.8lf \t", d_median, d_avr, d_min, d_max);
		s_line += s_buf;

		pcSingleDSManalyzer->vReportLinkQualityPerfectBlockLengthFill(&d_avr, &d_median, &d_min, &d_max);
		s_buf.Format("FILL: \t Med: \t %.8lf \t Avr: \t %.8lf \t Min: \t %.8lf \t Max: \t %.8lf \t", d_median, d_avr, d_min, d_max);
		s_line += s_buf;

		fprintf(pfGeneralReport, s_line + "\n");
	}//if  (pfGeneralReport  !=  NULL)


	if (sSingleDSM_LinkageReportFile != "")
	{
		pcSingleDSManalyzer->vSaveLinkageReport(sSingleDSM_LinkageReportFile);
	}//if (sSingleDSM_LinkageReportFile != "")



	pcSingleDSManalyzer->vRecomputeDSM_PairingRankings();
	//pcSingleDSManalyzer->vShow(-190901);
	pcSingleDSManalyzer->vRecomputeDiscretizedDSM();


	if (pfGeneralReport != NULL)
	{
		s_line.Format("DSMp \t %s: \t Size: \t %d\t ", sDSMname, pcSingleDSManalyzer->iGetPopSize());
		pcSingleDSManalyzer->vRecomputeDiscretizedDSM();

		pcSingleDSManalyzer->vReportLinkQualityPerfectBlockLengthOverhead(&d_avr, &d_median, &d_min, &d_max);
		s_buf.Format("OVERHEAD: \t Med: \t %.8lf \t Avr: \t %.8lf \t Min: \t %.8lf \t Max: \t %.8lf \t", d_median, d_avr, d_min, d_max);
		s_line += s_buf;

		pcSingleDSManalyzer->vReportLinkQualityPerfectBlockLengthFill(&d_avr, &d_median, &d_min, &d_max);
		s_buf.Format("FILL: \t Med: \t %.8lf \t Avr: \t %.8lf \t Min: \t %.8lf \t Max: \t %.8lf \t", d_median, d_avr, d_min, d_max);
		s_line += s_buf;

		fprintf(pfGeneralReport, s_line + "\n");
	}//if  (pfGeneralReport  !=  NULL)


	if (sSingleDSM_LinkageReportFile != "")
	{
		pcSingleDSManalyzer->vSaveLinkageReport(sSingleDSM_LinkageReportFile + "_PAIRING.txt");
	}//if (sSingleDSM_LinkageReportFile != "")


}//void  CLinkageAnalyzer::v_save_linkage_report_for_single_dsm(CString  sSingleDSM_LinkageReportFile, CString  sDSMname, CLinkageAnalyzerSingleDSM  *pcSingleDSManalyzer, FILE  *pfGeneralReport)



void  CLinkageAnalyzer::vSaveLinkageReportJOINT(CString  sLinkageReportFile)
{
	CString  s_file_name;
	s_file_name = sLinkageReportFile + s_name + LINKAGE_ANALYZER_JOINT_DSM +  LINKAGE_ANALYZER_POSTFIX;

	FILE  *pf_dest;
	pf_dest = fopen(s_file_name, "w+");


	/*if (pc_linkage_to_share == NULL)  pc_linkage_to_share = new CLinkageAnalyzerSingleDSM(this);
	pc_linkage_to_share->eCreteJOINED_DSM(&v_external_linkage_analyzers);
	pc_linkage_to_share->vSaveLinkageReport(s_file_name);*/



	CString  s_line, s_buf;
	double  d_avr, d_median, d_min, d_max;

	CString  s_file_name_single;

	if (pc_linkage_to_share != NULL)
	{
		s_file_name_single = sLinkageReportFile + s_name + LINKAGE_ANALYZER_SHARED_DSM_PREFIX + LINKAGE_ANALYZER_POSTFIX;
		v_save_linkage_report_for_single_dsm(s_file_name_single, LINKAGE_ANALYZER_SHARED_DSM_PREFIX, pc_linkage_to_share, pf_dest);
	}//if  (pc_linkage_to_share  !=  NULL)

	for (int i_dsm = 0; i_dsm < v_external_linkage_analyzers.size(); i_dsm++)
	{
		s_buf.Format("_%02d_", i_dsm);
		s_file_name_single = sLinkageReportFile + s_name + s_buf + LINKAGE_ANALYZER_JOINT_DSM + LINKAGE_ANALYZER_POSTFIX;

		v_save_linkage_report_for_single_dsm(s_file_name_single, s_buf, v_external_linkage_analyzers.at(i_dsm)->pcGetLinkageToShare(), pf_dest);
	}//for (int i_dsm = 0; i_dsm < v_dsm_sets.size(); i_dsm++)


	fclose(pf_dest);
}//CError  CLinkageAnalyzer::eSaveLinkageReportJOINT(CString  sLinkageReportFile)




void  CLinkageAnalyzerMemorySet::vComputeTrueFalseDependencies(double  dMaxDependencyRange, int *piTrue, int *piFalse, double  *pdPerc)
{
	int  i_pairs_good = 0;
	int  i_pairs_false = 0;

	for (int ii = 0; ii < v_strict_dependent_set.size(); ii++)
	{
		if (v_strict_dependent_set.at(ii).d_dependency <= dMaxDependencyRange)
		{
			if (v_strict_dependent_set.at(ii).bDependencyTrue == true)
				i_pairs_good++;
			else
				i_pairs_false++;
		}//if (v_strict_dependent_set.at(ii).d_dependency < dMaxDependencyRange)
	}//for (int ii = 0; ii < v_strict_dependent_set.size(); ii++)

	
	double  d_perc;

	d_perc = i_pairs_good;
	d_perc = d_perc / (i_pairs_good + i_pairs_false);


	if (piTrue != NULL)  *piTrue = i_pairs_good;
	if (piFalse != NULL)  *piFalse = i_pairs_false;
	if (pdPerc != NULL)  *pdPerc = d_perc;

}//void  CLinkageAnalyzerMemorySet::vComputeTrueFalseDependencies(double  dMaxDependencyRange, int *piTrue, int *piFalse, double  *pdPerc)



int  CSeparableBlockDetection::iDetectionLevel()
{
	if (i_part_detections == i_gene_last - i_gene_first + 1)  return(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_FULL);
	if (i_part_detections > 0)  return(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_PART);
	return(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_NONE);
}//int  CSeparableBlockDetection::iDetectionLevel()



int  CLinkageAnalyzerMemorySet::iGetPairsDetection(int  iDetectionType)
{
	int  i_res;

	i_res = 0;
	for (int ii = 0; ii < v_full_blocks_detection.size(); ii++)
	{
		if (v_full_blocks_detection.at(ii)->iDetectionLevel() == iDetectionType)  i_res++;
	}//for (int ii = 0; ii < v_full_blocks_detection.size(); ii++)
	
	return(i_res);
}//int  CLinkageAnalyzerMemorySet::iGetPairsDetection(int  iDetectionType)







CString  CLinkageAnalyzerMemorySet::sGeneralCurrentReport()
{
	CString  s_res;

	s_res.Format
	(
		"%s \t Pop: \t %d \t block: \t %d \t %d \t %d \t Over(AvMedMM): \t %.8lf \t %.8lf \t %.8lf \t %.8lf \t %s \t %.8lf \t  %s \t %.8lf \t  %s \t %.8lf \t  %s  \t %.8lf \t",
		s_additional_name,
		i_pop_size,
		
		iGetPairsDetection(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_FULL), iGetPairsDetection(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_PART), iGetPairsDetection(LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_NONE),
		d_overhead_avr, d_overhead_median, d_overhead_min, d_overhead_max,
		OPT_LINK_QUALITY_FILL_AVR, d_fill_avr, OPT_LINK_QUALITY_FILL_MEDIAN, d_fill_median, OPT_LINK_QUALITY_FILL_MIN, d_fill_min, OPT_LINK_QUALITY_FILL_MAX, d_fill_max
	);

	s_res.Format("\t %s \t %.2lf", OPT_LINK_QUALITY_FILL_AVR, d_fill_avr);
	
	return(s_res);
}//CString  sGeneralCurrentReport()



void  CLinkageAnalyzerMemorySet::vSave(FILE  *pfDest)
{
	CString  s_line, s_pairs, s_buf;

	
	/*s_line.Format
		(
			"Level: %d \t Pop: \t %d \t Over(AvMedMM): \t %.8lf \t %.8lf \t %.8lf \t %.8lf \t Fill: \t %.8lf \t %.8lf \t %.8lf \t %.8lf \t", 
			i_level, i_pop_size, 
			d_overhead_avr, d_overhead_median, d_overhead_min, d_overhead_max, 
			d_fill_avr, d_fill_median, d_fill_min, d_fill_max
		);*/

	s_buf.Format("%s \t Level: %d \t", s_additional_name, i_level);

	s_line = s_buf + sGeneralCurrentReport();


	s_pairs = "";

	int  i_pairs_good, i_pairs_false;
	double  d_perc;

	for (int i_dep_range = 1; i_dep_range < 20; i_dep_range++)
	{
		vComputeTrueFalseDependencies(i_dep_range, &i_pairs_good, &i_pairs_false, &d_perc);
		s_buf.Format(" (RangeGoodFalsePerc) \t %d \t %d \t %d \t %.4lf \t", i_dep_range, i_pairs_good, i_pairs_false, d_perc);

		s_pairs += s_buf;
	}//for (int i_dep_range = 1; i_dep_range < 20; i_dep_range++)
	

	s_line += s_pairs;
	fprintf(pfDest, s_line + "\n");
}//void  CLinkageAnalyzerMemorySet::vSave(FILE  *pfDest)




void  CDledDistanceStats::vConfigure(int  iHopNumber, int  iProblemLength)
{ 
	i_problem_length = iProblemLength; 
	i_hop_number = iHopNumber; 

	iCoverMin = -1;
	iCoverTotal = 0;
	iCoverMax = -1;
	iGenesNumber = 0;

	while (v_gene_hop_coverage.size() < i_problem_length)  v_gene_hop_coverage.push_back(0);
};//void  CDledDistanceStats::vConfigure(int  iHopNumber, int  iProblemLength)



void  CDledDistanceStats::vExtractData(int  **piDSM_DLED_Distances)
{
	int  i_genes_related_at_hop_number;

	for (int i_gene = 0; i_gene < i_problem_length; i_gene++)
	{
		i_genes_related_at_hop_number = 0;
		for (int i_gene_related = 0; i_gene_related < i_problem_length; i_gene_related++)
		{
			if (i_gene != i_gene_related)
			{
				if (piDSM_DLED_Distances[i_gene][i_gene_related] == i_hop_number) i_genes_related_at_hop_number++;
			}//if (i_gene != i_gene_related)
		}//for (int i_gene_related = 0; i_gene_related < i_problem_length; i_gene_related++)

		vInsertNewCoverForGene(i_gene, i_genes_related_at_hop_number);
	}//for (int i_gene = 0; i_gene < i_problem_length; i_gene++)
}//void  CDledDistanceStats::vExtractData(int  **piDSM_DLED_Distances)


double  CDledDistanceStats::dPerc()
{
	if (i_problem_length <= 0)  return(-1);

	double  d_res;
	d_res = iCoverTotal;
	d_res = d_res / i_problem_length;
	d_res = d_res / (i_problem_length - 1);

	return(d_res);
}//double  CDledDistanceStats::dPerc()


double  CDledDistanceStats::dAvrDependentGeneNumber()
{
	if (i_problem_length <= 0)  return(-1);

	double  d_res;
	d_res = iCoverTotal;
	d_res = d_res / i_problem_length;

	return(d_res);
}//double  CDledDistanceStats::dPerc()



CString  CDledDistanceStats::sGetAsString()
{
	CString  s_result;

	s_result.Format("hop: %d \t genes: %d \t coverage: %.4lf \t MinGenes: %d \t MaxGenes: %d", i_hop_number, iCoverTotal, dPerc(), iCoverMin, iCoverMax);

	return(s_result);
}//CString  CDledDistanceStats::sGetAsString()



CString  CDledDistanceStats::sGetAsStringShort()
{
	CString  s_result;

	s_result.Format(" {hop_%d_GeneNum_Avr} \t %.8lf \t {hop_%d_GenePerc_Avr} \t %.8lf", i_hop_number, dAvrDependentGeneNumber(), i_hop_number, dPerc());

	return(s_result);
}//CString  CDledDistanceStats::sGetAsStringShort()



void  CDledDistanceStats::vInsertNewCoverForGene(int  iGene, int  iCoveredGenes)
{
	iGenesNumber++;
	iCoverTotal += iCoveredGenes;

	if (iCoverMin == -1)  iCoverMin = iCoveredGenes;
	if (iCoverMax == -1)  iCoverMax = iCoveredGenes;

	if (iCoverMin > iCoveredGenes)  iCoverMin = iCoveredGenes;
	if (iCoverMax < iCoveredGenes)  iCoverMax = iCoveredGenes;

	if (iGene < v_gene_hop_coverage.size())
		v_gene_hop_coverage.at(iGene) = iCoveredGenes;
	else
		::MessageBox(NULL, "void  CDledDistanceStats::vInsertNewCoverForGene(int  iGene, int  iCoveredGenes)", "void  CDledDistanceStats::vInsertNewCoverForGene(int  iGene, int  iCoveredGenes)", MB_OK);

}//void  CDledDistanceStats::vInsertNewCoverForGene(int  iCoveredGenes)


	





CString  CLinkageAnalyzer::sSummaryReport()
{
	CString  s_res;
	int  i_pop_size_total = 0;
	int  i_pop_size_max = 0;

	if (v_memory_sets.size() > 0)
	{
		int  i_best_offset;
		
		i_best_offset = 0;
		for (int ii = 0; ii < v_memory_sets.size(); ii++)
		{
			i_pop_size_total += v_memory_sets.at(ii)->i_pop_size;
			if (i_pop_size_max < v_memory_sets.at(ii)->i_pop_size) i_pop_size_max = v_memory_sets.at(ii)->i_pop_size;

			if (
				(v_memory_sets.at(ii)->d_fill_avr > v_memory_sets.at(i_best_offset)->d_fill_avr)
				||
				( (v_memory_sets.at(ii)->d_fill_avr == v_memory_sets.at(i_best_offset)->d_fill_avr)&&(v_memory_sets.at(ii)->d_overhead_avr < v_memory_sets.at(i_best_offset)->d_overhead_avr) )
				)
			{
				i_best_offset = ii;
			}//if (v_memory_sets.at(ii)->d_fill_median > d_fill_median_best)
		}//for (int ii = 0; ii < v_memory_sets.size(); ii++)

		s_res = v_memory_sets.at(i_best_offset)->sGeneralCurrentReport();
		//::Tools::vShow(s_res);
	}//if (v_memory_sets.size() > 0)

	//if (s_res == "")  s_res = "\t <Missing:LinkInfo>";



	CString  s_linkage_general_info;
	//s_linkage_general_info.Format("\t %s \t %.2lf \t %s \t %.0lf \t Pop:(total/max): \t %d \t", OPT_LINK_COST_TIME, d_linkage_cost_time, OPT_LINK_COST_FFE, d_linkage_cost_ffe, i_pop_size_total, i_pop_size_max);
	s_linkage_general_info.Format("\t %s \t %.2lf \t %s \t %.0lf \t ", OPT_LINK_COST_TIME, d_linkage_cost_time, OPT_LINK_COST_FFE, d_linkage_cost_ffe, i_pop_size_total);
	s_linkage_general_info += s_res;
	
	//s_linkage_general_info += s_res;

	return(s_linkage_general_info);
}//CString  CLinkageAnalyzer::sSummaryReport()

CString  CLinkageAnalyzer::sGeneralCurrentReport()
{
	CString  s_res;

	if (v_memory_sets.size() > 0)
	{
		s_res = v_memory_sets.at(v_memory_sets.size() - 1)->sGeneralCurrentReport();
	}//if (v_memory_sets.size() > 0)

	return(s_res);
}//CString  CLinkageAnalyzer::sGeneralCurrentReport()


int  CLinkageAnalyzer::iGetPairsDetection(int  iDetectionType)
{
	if (v_memory_sets.size() > 0)
	{
		return(v_memory_sets.at(v_memory_sets.size() - 1)->iGetPairsDetection(iDetectionType));
	}//if (v_memory_sets.size() > 0)

	return(-1);
}//int  CLinkageAnalyzer::iGetPairsDetection(int  iDetectionType)


void  CLinkageAnalyzer::vSaveLinkageReport(CString  sLinkageReportFile, CString  sAdditionalPstfix)
{
	if (v_external_linkage_analyzers.size() > 0)
	{
		vSaveLinkageReportJOINT(sLinkageReportFile);
		return;
	}//if (v_external_linkage_analyzers.size() > 0)

	CString  s_file_name;
	//v_memory_sets.clear();
	if (v_memory_sets.size() > 0)
	{
		s_file_name = sLinkageReportFile + s_name + "_MEMORIZED_REPORT_" + sAdditionalPstfix + LINKAGE_ANALYZER_POSTFIX;



		FILE  *pf_dest;
		pf_dest = fopen(s_file_name, "w+");

		
		for (int ii = 0; ii < v_memory_sets.size(); ii++)
		{
			v_memory_sets.at(ii)->vSave(pf_dest);
		}//for (int ii = 0; ii < v_memory_sets.size(); ii++)


		fclose(pf_dest);

		if (i_linkage_force_full_report == 0)  return;
	}//if (v_memory_sets.size() > 0)*/
	
	s_file_name = sLinkageReportFile + s_name + sAdditionalPstfix + LINKAGE_ANALYZER_POSTFIX;

	FILE  *pf_dest;
	pf_dest = fopen(s_file_name, "w+");


	CString  s_line, s_buf;
	double  d_avr, d_median, d_min, d_max;

	CString  s_file_name_single;

	if (pc_linkage_to_share != NULL)
	{
		s_file_name_single = sLinkageReportFile + s_name + LINKAGE_ANALYZER_SHARED_DSM_PREFIX + sAdditionalPstfix + LINKAGE_ANALYZER_POSTFIX;
		v_save_linkage_report_for_single_dsm(s_file_name_single, LINKAGE_ANALYZER_SHARED_DSM_PREFIX, pc_linkage_to_share, pf_dest);
	}//if  (pc_linkage_to_share  !=  NULL)

	for (int i_dsm = 0; i_dsm < v_dsm_sets.size(); i_dsm++)
	{
		s_buf.Format("_%02d_", i_dsm);
		s_file_name_single = sLinkageReportFile + s_name + sAdditionalPstfix + s_buf + LINKAGE_ANALYZER_POSTFIX;

		v_save_linkage_report_for_single_dsm(s_file_name_single, s_buf, v_dsm_sets.at(i_dsm), pf_dest);
	}//for (int i_dsm = 0; i_dsm < v_dsm_sets.size(); i_dsm++)


	fclose(pf_dest);
}//void  CLinkageAnalyzer::vSaveLinkageReport(CString  sLinkageReportFile)





CLinkageInformationPack::CLinkageInformationPack(CLinkageAnalyzer  *pcParent)
{ 
	i_linkage_type = -1;
	pc_single_dsm_linkage = NULL;

	pc_evaluation = NULL;
	pc_log = NULL;
	pc_evaluation_individual = NULL;

	pi_dsm_dled = NULL;
	pi_dsm_dled_distances = NULL;
	pi_dsm_diversive = NULL;
	pd_dsm_sll = NULL;
	pppi_sll_genes_values_occurrences = NULL;
	//pd_linkage_gathering_probabilities = NULL;

	pc_directional_linkages = NULL;

	pc_parent = pcParent;

	pc_single_dsm_linkage = new CLinkageAnalyzerSingleDSM(pc_parent);
};//CLinkageInformationPack::CLinkageInformationPack()


CLinkageInformationPack::~CLinkageInformationPack()
{
	if (pi_dsm_dled != NULL)
	{
		for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
			delete  pi_dsm_dled[ii];
		delete  pi_dsm_dled;
	}//if (pi_dsm != NULL)



	if (pi_dsm_dled_distances != NULL)
	{
		for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
			delete  pi_dsm_dled_distances[ii];
		delete  pi_dsm_dled_distances;
	}//if (pi_dsm != NULL)



	if (pi_dsm_diversive != NULL)
	{
		for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
			delete  pi_dsm_diversive[ii];
		delete  pi_dsm_diversive;
	}//if (pi_dsm != NULL)


	if (pd_dsm_sll != NULL)
	{
		for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
			delete  pd_dsm_sll[ii];
		delete  pd_dsm_sll;
	}//if (pi_dsm != NULL)


	if (pppi_sll_genes_values_occurrences != NULL)
	{
		for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
		{
			for (int jj = 0; jj < pc_evaluation->iGetNumberOfElements(); jj++)
				delete pppi_sll_genes_values_occurrences[ii][jj];

			delete pppi_sll_genes_values_occurrences[ii];
		}//for (int ii = 0; ii < i_templ_length; ii++)

		delete pppi_sll_genes_values_occurrences;
	}//if (ppi_genes_values_occurrences != NULL)


	//if (pd_linkage_gathering_probabilities != NULL)  delete  pd_linkage_gathering_probabilities;


	if (pc_single_dsm_linkage != NULL)  delete  pc_single_dsm_linkage;

	for (int ii = 0; ii < v_directional_linkage_analyzed_inds.size(); ii++)
		delete  v_directional_linkage_analyzed_inds.at(ii);

	for (int ii = 0; ii < v_pop_to_analayze.size(); ii++)
		delete  v_pop_to_analayze.at(ii);
	
	for (int ii = 0; ii < v_gene_freqs.size(); ii++)
		delete  v_gene_freqs.at(ii);

	for (int ii = 0; ii < v_linkage_scraps.size(); ii++)
		delete  v_linkage_scraps.at(ii);


	if (pc_directional_linkages != NULL)  delete  pc_directional_linkages;


}//CLinkageInformationPack::~CLinkageInformationPack()


void  CLinkageInformationPack::vConfigure(CEvaluation<CBinaryCoding> *pcEvaluation, CLog *pcLog, CBinaryCoding *pcEvaluationIndividual)
{
	pc_evaluation = pcEvaluation;
	pc_log = pcLog;
	pc_evaluation_individual = pcEvaluationIndividual;

	int  i_problem_size;
	i_problem_size = pcEvaluation->iGetNumberOfElements();

	CLinkageInformationPackGeneFreq  *pc_gene_freq;
	for (int ii = 0; ii < i_problem_size; ii++)
	{
		pc_gene_freq = new CLinkageInformationPackGeneFreq(ii);
		pc_gene_freq->bAddNewValue(0);
		pc_gene_freq->bAddNewValue(1);

		v_gene_freqs.push_back(pc_gene_freq);
	}//for (int ii = 0; ii < i_problem_size; ii++)


	pi_dsm_dled = new int*[i_problem_size];
	for (int ii = 0; ii < i_problem_size; ii++)
		pi_dsm_dled[ii] = new int[i_problem_size];


	pi_dsm_dled_distances = new int*[i_problem_size];
	for (int ii = 0; ii < i_problem_size; ii++)
		pi_dsm_dled_distances[ii] = new int[i_problem_size];

	pi_dsm_diversive = new int*[i_problem_size];
	for (int ii = 0; ii < i_problem_size; ii++)
		pi_dsm_diversive[ii] = new int[i_problem_size];

	pd_dsm_sll = new double*[i_problem_size];
	for (int ii = 0; ii < i_problem_size; ii++)
		pd_dsm_sll[ii] = new double[i_problem_size];
	

	for (int ix = 0; ix < i_problem_size; ix++)
	{
		for (int iy = 0; iy < i_problem_size; iy++)
		{
			pi_dsm_dled[ix][iy] = 0;
			pi_dsm_diversive[ix][iy] = 0;
			pd_dsm_sll[ix][iy] = 0;
		}//for (int iy = 0; iy < i_problem_size; iy++)
	}//for (int ix = 0; ix < i_problem_size; ix++)


	for (int ii = 0; ii < pc_parent->v_global_linkage_scraps.size(); ii++)
	{
		pc_parent->v_global_linkage_scraps.at(ii)->vAddScrapToDSM(pi_dsm_dled, NULL, NULL);
	}//for (int ii = 0; ii < pc_parent->v_global_linkage_scraps.size(); ii++)
	
		

}//void  CLinkageInformationPack::vConfigure(CEvaluation<CBinaryCoding> *pcEvaluation, CLog *pcLog, CBinaryCoding *pcEvaluationIndividual)


CError  CLinkageInformationPack::eSaveDSM_DLED(CString  sDest, int  **piDSM)
{
	CError  c_err(iERROR_PARENT_CLinkageInformationPack);

	FILE  *pf_dest;
	pf_dest = fopen(sDest, "w+");

	if (pf_dest == NULL)
	{
		c_err.vSetError(iERROR_CLinkageInformationPack_SAVE_ERR, sDest);
		return(c_err);
	}//if  (pf_dest == NULL)

	vSaveDSM_DLED(pf_dest, piDSM);

	fclose(pf_dest);
	return(c_err);
}//CError  CLinkageInformationPack::eSaveDSM_DLED(CString  sDest)


void  CLinkageInformationPack::vSaveDSM_DLED(FILE  *pfDest, int  **piDSM)
{
	int  i_prob_len = pc_evaluation->iGetNumberOfElements();
	
	CString  s_line, s_buf;
	s_line = "\t";
	for (int i_gene_first = 0; i_gene_first < i_prob_len; i_gene_first++)
	{
		s_buf.Format("%.3d\t", i_gene_first);
		s_line += s_buf;
	}//for (int i_gene_first = 0; i_gene_first < i_prob_len; i_gene_first++)
	s_line += "\n";
	fprintf(pfDest, s_line);

	for (int i_gene_first = 0; i_gene_first < i_prob_len; i_gene_first++)
	{
		s_line.Format("%.3d\t", i_gene_first);
		for (int i_gene_second = 0; i_gene_second < i_prob_len; i_gene_second++)
		{
			s_buf.Format("%.3d\t", piDSM[i_gene_first][i_gene_second]);
			s_line += s_buf;
		}//for (int i_gene_second = 0; i_gene_second < i_prob_len; i_gene_second++)
		s_line += "\n";

		fprintf(pfDest, s_line);
	}//for (int i_gene_first = 0; i_gene_first < i_prob_len; i_gene_first++)

	
}//void  CLinkageInformationPack::vSaveDSM_DLED(FILE  *pfDest)



void  CLinkageInformationPack::vAddAnotherP3Individual(vector<bool> *pvNewSolution)
{
	CLinkageInformationPackIndividual  *pc_new_ind;

	pc_new_ind = new CLinkageInformationPackIndividual(pc_evaluation, pc_evaluation_individual);
	v_pop_to_analayze.push_back(pc_new_ind);

	pc_new_ind->vSetP3_Genotype(pvNewSolution);
}//void  CLinkageInformationPack::vAddAnotherP3Individual(vector<bool> *pvNewSolution)


void  CLinkageInformationPack::vSetIndividual3LOa(int  *piGenotype)
{
	for (int ii = 0; ii < v_pop_to_analayze.size(); ii++)
		delete  v_pop_to_analayze.at(ii);
	v_pop_to_analayze.clear();


	CLinkageInformationPackIndividual  *pc_new_ind;

	pc_new_ind = new CLinkageInformationPackIndividual(pc_evaluation, pc_evaluation_individual);
	v_pop_to_analayze.push_back(pc_new_ind);

	pc_new_ind->vSetInt_Genotype(piGenotype);
}//void  CLinkageInformationPack::vSetIndividual3LOa(int  *piGenotype, int  iSolSize)


void  CLinkageInformationPack::vSetPopulationLTGA(char  **Population, int iPopSize, int iSolSize)
{
	while (v_pop_to_analayze.size() > iPopSize)
	{
		delete  v_pop_to_analayze.at(v_pop_to_analayze.size()-1);
		v_pop_to_analayze.erase(v_pop_to_analayze.begin() + v_pop_to_analayze.size() - 1);
	}//while (v_pop_to_analayze.size() > iPopSize)


	CLinkageInformationPackIndividual  *pc_new_ind;
	while (v_pop_to_analayze.size() < iPopSize)
	{
		pc_new_ind = new CLinkageInformationPackIndividual(pc_evaluation, pc_evaluation_individual);
		v_pop_to_analayze.push_back(pc_new_ind);
	}//while (v_pop_to_analayze.size() < iPopSize)


	for (int i_ind = 0; i_ind < iPopSize; i_ind++)
	{
		v_pop_to_analayze.at(i_ind)->vSetLTGA_Genotype(Population[i_ind]);
	}//for (int i_ind = 0; i_ind < iPopSize; i_ind++)
}//void  CLinkageInformationPack::vSetPopulationLTGA(char  **Population, int iPopSize, int iSolSize)



void  CLinkageInformationPack::vAddAnotherIndividualGeneral(int *piIndividual)
{
	CLinkageInformationPackIndividual  *pc_new_ind;
	
	pc_new_ind = new CLinkageInformationPackIndividual(pc_evaluation, pc_evaluation_individual);
	pc_new_ind->vSetInt_Genotype(piIndividual);
	v_pop_to_analayze.push_back(pc_new_ind);
}//void  CLinkageInformationPack::vAddAnotherIndividualGeneral(int *piIndividual)



void  CLinkageInformationPack::vSetPopulationGeneral(vector<int*> *pvPopulation)
{
	while (v_pop_to_analayze.size() > pvPopulation->size())
	{
		delete  v_pop_to_analayze.at(v_pop_to_analayze.size() - 1);
		v_pop_to_analayze.erase(v_pop_to_analayze.begin() + v_pop_to_analayze.size() - 1);
	}//while (v_pop_to_analayze.size() > iPopSize)


	CLinkageInformationPackIndividual  *pc_new_ind;
	while (v_pop_to_analayze.size() < pvPopulation->size())
	{
		pc_new_ind = new CLinkageInformationPackIndividual(pc_evaluation, pc_evaluation_individual);
		v_pop_to_analayze.push_back(pc_new_ind);
	}//while (v_pop_to_analayze.size() < iPopSize)


	for (int i_ind = 0; i_ind < pvPopulation->size(); i_ind++)
	{
		v_pop_to_analayze.at(i_ind)->vSetInt_Genotype(pvPopulation->at(i_ind));
	}//for (int i_ind = 0; i_ind < iPopSize; i_ind++)


	/*CString  s_buf;
	FILE  *pf_dest;
	pf_dest = fopen("zzz_sll_pop.txt", "w+");
	for (int i_ind = 0; i_ind < v_pop_to_analayze.size(); i_ind++)
	{
		s_buf = v_pop_to_analayze.at(i_ind)->sToStr();
		fprintf(pf_dest, "%d: %s\n", i_ind, (LPCSTR) s_buf);
	}//for (int i_ind = 0; i_ind < pvPopulation->size(); i_ind++)
	fclose(pf_dest);*/
}//void  CLinkageInformationPack::vSetPopulationGeneral(vector<int*> *pvPopulation)



bool  CLinkageInformationPack::bGetLinkageDiscoveryProbabilities(double  *pdAvr, double *pdMin, double *pdMax, double  *pdLinkageFill)
{
	if (pc_parent == NULL)  return(false);
	return(pc_parent->bGetLinkageDiscoveryProbabilities(pdAvr, pdMin, pdMax, pdLinkageFill, pc_evaluation->iGetNumberOfElements()));
}//double  CLinkageInformationPack::dGetLinkageDiscoveryProbabilitiesAverage()



void  CLinkageInformationPack::vComputeDSM_Perfect()
{
	TimeCounters::CTimeCounter  c_timer;
	uint64_t i_start_ffe;
	i_start_ffe = pc_evaluation->iGetFFE();
	c_timer.vSetStartNow();


	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();


	vector<vector<int>>  v_true_dependencies;
	pc_evaluation->vGetTrueGeneDependencies(&v_true_dependencies);

	for (int ix = 0; ix < i_problem_size; ix++)
	{
		for (int iy = 0; iy < i_problem_size; iy++)
		{
			pi_dsm_dled[ix][iy] = 0;
			pi_dsm_diversive[ix][iy] = 0;
		}//for (int iy = 0; iy < i_problem_size; iy++)
	}//for (int ix = 0; ix < i_problem_size; ix++)


	for (int i_scrap = 0; i_scrap < v_true_dependencies.size(); i_scrap++)
	{
		for (int i_gene_scrap = 0; i_gene_scrap < v_true_dependencies.at(i_scrap).size(); i_gene_scrap++)
		{
			(pi_dsm_dled[i_scrap][v_true_dependencies.at(i_scrap).at(i_gene_scrap)])++;
			(pi_dsm_dled[v_true_dependencies.at(i_scrap).at(i_gene_scrap)][i_scrap])++;
		}//for (int i_gene_first = 0; i_gene_first < v_true_dependencies.at(i_scrap).size(); i_gene_first++)
	}//for (int i_scrap = 0; i_scrap < v_true_dependencies.size(); i_scrap++)


	

	/*FILE  *pf_report;
	pf_report = fopen("zzz_scrap_perf_test.txt", "w+");

	CString  s_line, s_buf;
	for (int i_scrap = 0; i_scrap < v_true_dependencies.size(); i_scrap++)
	{
		s_line.Format("%d\t= ", i_scrap);
		for (int ii = 0; ii < v_true_dependencies.at(i_scrap).size(); ii++)
		{
			s_buf.Format(" %d ", v_true_dependencies.at(i_scrap).at(ii));
			s_line += s_buf;
		}//for (int ii = 0; ii < v_true_dependencies.at(i_scrap).size(); ii++)
		
		fprintf(pf_report, "%s\n", s_line);
	}//for (int i_scrap = 0; i_scrap < v_true_dependencies.size(); i_scrap++)


	fprintf(pf_report, "\n\n\n\n");
	for (int ix = 0; ix < i_problem_size; ix++)
	{
		s_line = "";
		for (int iy = 0; iy < i_problem_size; iy++)
		{
			s_buf.Format(" %d ", pi_dsm_dled[ix][iy]);
			s_line += s_buf;
		}//for (int iy = 0; iy < i_problem_size; iy++)
		fprintf(pf_report, "%s\n", s_line);
	}//for (int ix = 0; ix < i_problem_size; ix++)

	fclose(pf_report);
	s_buf.Format("size = %d", v_true_dependencies.size());
	::MessageBox(NULL, "void  CLinkageInformationPack::vComputeDSM_Perfect()", s_buf, MB_OK);//*/
	

	
	if  (pc_parent->iGetLinkageRepresentation() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_LINKAGE_REPRESENTATION_LTREE)
		pc_single_dsm_linkage->vSetOutsideLinkage_DLED_LTree(pi_dsm_dled, pc_evaluation->iGetNumberOfElements(), false);

	if (pc_parent->iGetLinkageRepresentation() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_LINKAGE_REPRESENTATION_TIGHT_LINKAGE_BLOCKS)
		pc_single_dsm_linkage->vSetOutsideLinkage_DLED_TightLinkageBlocks(pi_dsm_dled, pc_evaluation, pc_log);




	uint64_t i_end_ffe;
	double  d_time_passed, d_ffe_passed;
	i_end_ffe = pc_evaluation->iGetFFE();
	c_timer.bGetTimePassed(&d_time_passed);

	d_ffe_passed = i_end_ffe - i_start_ffe;

	if (pc_parent != NULL)
	{
		pc_parent->d_linkage_cost_time += d_time_passed;
		pc_parent->d_linkage_cost_ffe += d_ffe_passed;
	}//if (pc_parent != NULL)
}//void  CLinkageInformationPack::vComputeDSM_Perfect()



void  CLinkageInformationPack::vComputeDSM_Random()
{
	TimeCounters::CTimeCounter  c_timer;
	uint64_t i_start_ffe;
	i_start_ffe = pc_evaluation->iGetFFE();
	c_timer.vSetStartNow();


	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();

	for (int ix = 0; ix < i_problem_size; ix++)
	{
		for (int iy = 0; iy < i_problem_size; iy++)
		{
			pi_dsm_dled[ix][iy] = 0;
			pi_dsm_diversive[ix][iy] = 0;
		}//for (int iy = 0; iy < i_problem_size; iy++)
	}//for (int ix = 0; ix < i_problem_size; ix++)


	pc_single_dsm_linkage->vSetOutsideLinkage_DLED_LTree(pi_dsm_dled, pc_evaluation->iGetNumberOfElements(), false);




	uint64_t i_end_ffe;
	double  d_time_passed, d_ffe_passed;
	i_end_ffe = pc_evaluation->iGetFFE();
	c_timer.bGetTimePassed(&d_time_passed);

	d_ffe_passed = i_end_ffe - i_start_ffe;

	if (pc_parent != NULL)
	{
		pc_parent->d_linkage_cost_time += d_time_passed;
		pc_parent->d_linkage_cost_ffe += d_ffe_passed;
	}//if (pc_parent != NULL)
}//void  CLinkageInformationPack::vComputeDSM_Random()



void  CLinkageInformationPack::vCountDifferentDLEDways
	(
	double  *pdDifferentWaysAvr, double  *pdDifferentWaysMinAvr, double  *pdDifferentWaysMaxAvr,
	double  *pdDifferentWaysMedAvr, double  *pdDifferentWaysMed3Avr, double  *pdDifferentWaysAvr3Avr
	)
{
	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();

	CString  s_line, s_buf;

	vCompute_DLED_Distances();


	/*FILE  *pf_test;
	pf_test = fopen("zzzz_dled_dist.txt", "w+");
	s_line = "";
	for (int ix = 0; ix < i_problem_size; ix++)
	{
		s_buf.Format(" %d", ix);
		s_line += s_buf;
	}//for (int ix = 0; ix < i_problem_size; ix++)
	fprintf(pf_test, s_line + "\n");


	for (int ix = 0; ix < i_problem_size; ix++)
	{
		s_line = "";
		for (int iy = 0; iy < i_problem_size; iy++)
		{
			s_buf.Format(" %d", pi_dsm_dled_distances[ix][iy]);
			s_line += s_buf;
		}//for (int iy = 0; iy < i_problem_size; iy++)
		fprintf(pf_test, s_line + "\n");
	}//for (int ix = 0; ix < i_problem_size; ix++)

	fclose(pf_test);//*/


	double  d_dep_genes_avr_cur;
	int  i_dep_genes_min_cur, i_dep_genes_max_cur;
	double  d_dep_genes_med_cur, d_dep_genes_med3_cur, d_dep_genes_avr3_cur;

	double  d_dep_genes_avr_avr, d_dep_genes_min_avr, d_dep_genes_max_avr;
	double  d_dep_genes_med_avr, d_dep_genes_med3_avr, d_dep_genes_avr3_avr;

	d_dep_genes_avr_avr = 0;
	d_dep_genes_min_avr = 0;
	d_dep_genes_max_avr = 0;
	d_dep_genes_med_avr = 0;
	d_dep_genes_med3_avr = 0;
	for (int i_source_gene = 0; i_source_gene < i_problem_size; i_source_gene++)
	{
		v_compute_different_dled_ways_for_source_gene(i_source_gene, &d_dep_genes_avr_cur, &i_dep_genes_min_cur, &i_dep_genes_max_cur, &d_dep_genes_med_cur, &d_dep_genes_med3_cur, &d_dep_genes_avr3_cur);

		d_dep_genes_avr_avr += d_dep_genes_avr_cur;
		d_dep_genes_min_avr += i_dep_genes_min_cur;
		d_dep_genes_max_avr += i_dep_genes_max_cur;
		if (d_dep_genes_med_cur >= 0)  d_dep_genes_med_avr += d_dep_genes_med_cur;
		if (d_dep_genes_med3_cur >= 0)  d_dep_genes_med3_avr += d_dep_genes_med3_cur;
		if (d_dep_genes_avr3_cur >= 0)  d_dep_genes_avr3_avr += d_dep_genes_avr3_cur;
	}//for (int i_source_gene = 0; i_source_gene < i_problem_size; i_source_gene++)

	d_dep_genes_avr_avr = d_dep_genes_avr_avr / i_problem_size;
	d_dep_genes_min_avr = d_dep_genes_min_avr / i_problem_size;
	d_dep_genes_max_avr = d_dep_genes_max_avr / i_problem_size;
	d_dep_genes_med_avr = d_dep_genes_med_avr / i_problem_size;
	d_dep_genes_med3_avr = d_dep_genes_med3_avr / i_problem_size;
	d_dep_genes_avr3_avr = d_dep_genes_avr3_avr / i_problem_size;
		

	*pdDifferentWaysAvr = d_dep_genes_avr_avr;
	*pdDifferentWaysMinAvr = d_dep_genes_min_avr;
	*pdDifferentWaysMaxAvr = d_dep_genes_max_avr;
	*pdDifferentWaysMedAvr = d_dep_genes_med_avr;
	*pdDifferentWaysMed3Avr = d_dep_genes_med3_avr;
	*pdDifferentWaysAvr3Avr = d_dep_genes_avr3_avr;
	//::Tools::vShow("aaaa");


	//return(d_summary);
}//double  CLinkageInformationPack::dCountDifferentDLEDways()


void  CLinkageInformationPack::v_compute_different_dled_ways_for_source_gene
	(
		int  iSourceGene, 
		double  *pdDifferentWaysAvr, int  *piDifferentWaysMinAvr, int  *piDifferentWaysMaxAvr,
		double  *pdDifferentWaysMed, double  *pdDifferentWaysMed3, double  *pdDifferentWaysAvr3
	)
{
	CString  s_buf;

	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();

	int  *pi_source_gene_dled_distances;
	pi_source_gene_dled_distances = pi_dsm_dled_distances[iSourceGene];


	//FILE  *pf_ways_details;
	//pf_ways_details = fopen("zzz_way_details.txt", "a");

	double d_different_ways_number_avr;
	int  i_counter;
	int  i_different_ways_number_cur, i_different_ways_number_min, i_different_ways_number_max;

	i_different_ways_number_min = -1;
	i_different_ways_number_max = -1;
	d_different_ways_number_avr = 0;
	i_counter = 0;
	
	vector<int>  v_lengths;
	for (int i_dest_gene = 0; i_dest_gene < i_problem_size; i_dest_gene++)
	{
		if (pi_source_gene_dled_distances[i_dest_gene] == 2)
		{
			i_different_ways_number_cur = i_count_different_dled_ways_for_pair(iSourceGene, i_dest_gene, pi_source_gene_dled_distances);
			d_different_ways_number_avr += i_different_ways_number_cur;
			if (i_different_ways_number_min < 0)  i_different_ways_number_min = i_different_ways_number_cur;
			if (i_different_ways_number_max < 0)  i_different_ways_number_max = i_different_ways_number_cur;


			if (i_different_ways_number_min > i_different_ways_number_cur)  i_different_ways_number_min = i_different_ways_number_cur;
			if (i_different_ways_number_max < i_different_ways_number_cur)  i_different_ways_number_max = i_different_ways_number_cur;

			v_lengths.push_back(i_different_ways_number_cur);

			i_counter++;

			//s_buf.Format("%d -> %d  [%d] ways  min:%d  max:%d\n", iSourceGene, i_dest_gene, i_different_ways_number_cur, i_different_ways_number_min, i_different_ways_number_max);
			//fprintf(pf_ways_details, s_buf);
		}//if (pi_source_gene_dled_distances[i_dest_gene] == 2)
	}//for (int i_dest_gene = 0; i_dest_gene < i_problem_size; i_dest_gene++)

	std::sort(v_lengths.begin(), v_lengths.end(), [](const int cVal0, const int cVal1) -> bool { return(cVal0 < cVal1); });

	/*FILE  *pf_ways;
	pf_ways = fopen("zzz__ways.txt", "a");
	CString  s_line;
	for (int ii = 0; ii < v_lengths.size(); ii++)
	{
		s_buf.Format("%d, ", v_lengths.at(ii));
		s_line += s_buf;
	}//for (int ii = 0; ii < v_lengths.size() ii++)
	s_line += "\n";
	fprintf(pf_ways, s_line);
	fclose(pf_ways);*/

	double  d_different_ways_med, d_different_ways_med3, d_different_ways_avr3;
	if (v_lengths.size() > 0)
	{
		if (v_lengths.size() == (v_lengths.size() / 2) * 2)
		{
			d_different_ways_med = v_lengths.at(v_lengths.size() / 2) + v_lengths.at(v_lengths.size() / 2 - 1);
			d_different_ways_med = d_different_ways_med / 2;
		}//if (v_lengths.size() == (v_lengths.size() / 2) * 2)
		else
			d_different_ways_med = v_lengths.at(v_lengths.size() / 2);
	}//if  (v_lengths.size() > 0)
	else
		d_different_ways_med = -1;

	if (v_lengths.size() >= 3)
	{
		d_different_ways_med3 = v_lengths.at(v_lengths.size() - 2);
		d_different_ways_avr3 = 0;
		for (int ii = v_lengths.size() - 3; ii < v_lengths.size(); ii++)
			d_different_ways_avr3 += v_lengths.at(ii);
		d_different_ways_avr3 = d_different_ways_avr3 / 3;
	}//if (v_lengths.size() >= 3)
	else
	{
		d_different_ways_med3 = -1;
		d_different_ways_avr3 = -1;
	}//else  if (v_lengths.size() >= 3)
	
	
	d_different_ways_number_avr = d_different_ways_number_avr / i_counter;

	*pdDifferentWaysAvr = d_different_ways_number_avr;
	*piDifferentWaysMinAvr = i_different_ways_number_min;
	*piDifferentWaysMaxAvr = i_different_ways_number_max;
	*pdDifferentWaysMed = d_different_ways_med;
	*pdDifferentWaysMed3 = d_different_ways_med3;
	*pdDifferentWaysAvr3 = d_different_ways_avr3;

	//s_buf.Format("%d AVERAGE: [%.2lf] ways  min:%d  max:%d  for %d genes\n", iSourceGene, d_different_ways_number_avr, i_different_ways_number_min, i_different_ways_number_max, i_counter);
	//fprintf(pf_ways_details, s_buf);
	//fclose(pf_ways_details);

	//::Tools::vShow(iSourceGene);

}//void  CLinkageInformationPack::v_compute_different_dled_ways_for_source_gene(int  iSourceGene)



int  CLinkageInformationPack::i_count_different_dled_ways_for_pair(int  iSourceGene, int  iDestGene, int  *piSourceGeneDledDistances)
{
	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();
	int  i_result;

	i_result = 0;
	for (int ix = 0; ix < i_problem_size; ix++)
	{
		if ((ix != iSourceGene) && (piSourceGeneDledDistances[ix] == 1))
		{
			if (pi_dsm_dled[ix][iDestGene] > 0)  i_result++;
		}//if ((ix != iSourceGene) && (piSourceGeneDledDistances[ix] == 1))
	}//for (int ix = 0; ix < i_problem_size; ix++)

	return(i_result);
}//int  CLinkageInformationPack::i_count_different_dled_ways_for_pair(int  iSourceGene, int  iDestGene, int  *piSourceGeneDledDistances)



void  CLinkageInformationPack::vCompute_DLED_Distances()
{
	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();

	for (int ix = 0; ix < i_problem_size; ix++)
	{
		for (int iy = 0; iy < i_problem_size; iy++)
		{
			if (pi_dsm_dled[ix][iy] > 0)
				pi_dsm_dled_distances[ix][iy] = 1;
			else
				pi_dsm_dled_distances[ix][iy] = 0;
		}//for (int iy = 0; iy < i_problem_size; iy++)
	}//for (int ix = 0; ix < i_problem_size; ix++)

	int  i_level = 2;
	while (i_populate_dled_distances(i_level, pi_dsm_dled_distances) >  0)
		i_level++;

	/*FILE  *pf_test = fopen("zzzzzzzzzzz_pi_dsm_dled_distances.txt", "w+");
	fprintf(pf_test, "x \t");
	for (int ix = 0; ix < i_problem_size; ix++)
		fprintf(pf_test, "%d \t", ix);
	fprintf(pf_test, "\n");

	for (int ix = 0; ix < i_problem_size; ix++)
	{
		fprintf(pf_test, "%d \t", ix);
		for (int iy = 0; iy < i_problem_size; iy++)
		{
			fprintf(pf_test, "%d \t", pi_dsm_dled_distances[ix][iy]);
		}//for (int iy = 0; iy < i_problem_size; iy++)
		fprintf(pf_test, "\n");
	}//for (int ix = 0; ix < i_problem_size; ix++)
	fprintf(pf_test, "\n");
	fclose(pf_test);
	//::Tools::vShow("CLinkageInformationPack::vCompute_DLED_Distances()");//*/

}//void  CLinkageInformationPack::vCompute_DLED_Distances()





void  CLinkageInformationPack::vGet_DLED_DistanceStats(vector<CDledDistanceStats>  *pvStats)
{
	bool  b_do_next_level;
	b_do_next_level = true;
	int  i_hop_number = 0;

	CDledDistanceStats  c_new_info;
	while (b_do_next_level == true)
	{
		c_new_info.vConfigure(i_hop_number, pc_evaluation->iGetNumberOfElements());
		c_new_info.vExtractData(pi_dsm_dled_distances);

		if ( (c_new_info.iCoverTotal == 0)&&(i_hop_number > 0) )  b_do_next_level = false;

		//MessageBox(NULL, c_new_info.sGetAsString(), c_new_info.sGetAsString(), MB_OK);
		

		pvStats->push_back(c_new_info);
		i_hop_number++;
	}//while (b_do_next_level == true)


}//void  CLinkageInformationPack::vGet_DLED_DistanceStats(vector<CDledDistanceStats>  *pcStats)



CLinkageInformationPackIndividual *CLinkageInformationPack::pc_get_best_individual(vector <CLinkageInformationPackIndividual *>  *pvPop)
{
	double  d_fit_cur_best;
	vector<CLinkageInformationPackIndividual *>  v_best_inds;

	if (pvPop->size() <= 0) return(NULL);

	//Prw: first find best fitness, then find all inds with such a fitness (should be faster than frequent vector clearing)
	d_fit_cur_best = pvPop->at(0)->dComputeFitness();

	for (int ii = 1; ii < pvPop->size(); ii++)
	{
		if (d_fit_cur_best < pvPop->at(ii)->dComputeFitness())  d_fit_cur_best = pvPop->at(ii)->dComputeFitness();
	}//for (int ii = 1; ii < pvPop->size(); ii++)


	for (int ii = 0; ii < pvPop->size(); ii++)
	{
		if (pvPop->at(ii)->dComputeFitness() == d_fit_cur_best)  v_best_inds.push_back(pvPop->at(ii));
	}//for (int ii = 0; ii < pvPop->size(); ii++)

	if (v_best_inds.size() == 0)  return(NULL);


	int  i_best_offset;
	i_best_offset = ::RandUtils::iRandNumber(0, v_best_inds.size() - 1);

	return(v_best_inds.at(i_best_offset));
}//CLinkageInformationPackIndividual *CLinkageInformationPack::pc_get_best_individual(vector <CLinkageInformationPackIndividual *>  *pvPop)



bool  CLinkageInformationPack::b_is_ind_included(CLinkageInformationPackIndividual *pcInd, vector <CLinkageInformationPackIndividual *>  *pvPop)
{
	for (int ii = 0; ii < pvPop->size(); ii++)
	{
		if (pcInd->dComputeFitness() == pvPop->at(ii)->dComputeFitness())
		{
			if  (pcInd->bGenotypesTheSame(pvPop->at(ii)) == true)  return(true);
		}//if (pcInd->dComputeFitness() == pvPop->at(ii)->dComputeFitness())
	}//for (int ii = 0; ii < pvPop->size(); ii++)

	return(false);
}//bool  CLinkageInformationPack::b_is_ind_included(CLinkageInformationPackIndividual *pcInd, vector <CLinkageInformationPackIndividual *>  *pvPop)



int  CLinkageInformationPack::i_populate_dled_distances(int  iNewLevel, int **piDSM_DLED_Distances)
{
	int  i_result = 0;

	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();

	for (int i_gene_main = 0; i_gene_main < i_problem_size; i_gene_main++)
	{
		for (int i_gene_related = 0; i_gene_related < i_problem_size; i_gene_related++)
		{
			if (piDSM_DLED_Distances[i_gene_main][i_gene_related] == iNewLevel - 1)
			{
				for (int i_gene_related_to_related = 0; i_gene_related_to_related < i_problem_size; i_gene_related_to_related++)
				{
					if (piDSM_DLED_Distances[i_gene_related][i_gene_related_to_related] == 1)
					{
						if (i_gene_main != i_gene_related_to_related)
						{
							if (piDSM_DLED_Distances[i_gene_main][i_gene_related_to_related] == 0)
							{
								piDSM_DLED_Distances[i_gene_main][i_gene_related_to_related] = iNewLevel;
								i_result++;
							}//if (piDSM_DLED_Distances[i_gene_main][i_gene_related_to_related] == 0)
						}//if  (i_gene_main != i_gene_related_to_related)
					}//if (piDSM_DLED_Distances[i_gene_related][i_gene_related_to_related] == 1)
				}//for (int i_gene_related_to_related = 0; i_gene_related_to_related < i_problem_size; i_gene_related_to_related++)
			}//if (piDSM_DLED_Distances[i_gene_main][i_gene_related] == iNewLevel - 1)
		}//for (int iy = 0; iy < i_problem_size; iy++)
	}//for (int ix = 0; ix < i_problem_size; ix++)

	return(i_result);
}//int  CLinkageInformationPack::i_populate_dled_distances(int  iNewLevel, int **piDSM_DLED_Distances)




void  CLinkageInformationPack::vComputeDSM_ProblemDEcomp_DLED(bool  bPerfectLinkage)
{
	TimeCounters::CTimeCounter  c_timer;
	uint64_t i_start_ffe;
	i_start_ffe = pc_evaluation->iGetFFE();
	c_timer.vSetStartNow();

	if (v_pop_to_analayze.size() < 1)  return;

	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();

	if (bPerfectLinkage == false)
	{
		int  i_rand_ind_offset;
		CLinkageInformationPackLinkageScrap  *pc_new_linkage_scrap;
		for (int i_gene = 0; i_gene < i_problem_size; i_gene++)
		{
			i_rand_ind_offset = ::RandUtils::iRandNumber(0, v_pop_to_analayze.size() - 1);
			pc_new_linkage_scrap = v_pop_to_analayze.at(i_rand_ind_offset)->pcGetLinkageScrap(i_gene, pi_dsm_dled);

			if (pc_new_linkage_scrap != NULL)
			{
				pc_new_linkage_scrap->vAddScrapToDSM(pi_dsm_dled, pc_parent->pd_linkage_gathering_probabilities, pc_parent->pi_no_linkage_for_gene);
				pc_parent->v_global_linkage_scraps.push_back(pc_new_linkage_scrap);
			}//if (pc_new_linkage_scrap != NULL)

		}//for (int i_gene_first = 0; i_gene_first < i_problem_size; i_gene_first++)
	}//if (bPerfectLinkage == false)
	else
	{
		vector<vector<int>>  v_true_dependencies;
		pc_evaluation->vGetTrueGeneDependencies(&v_true_dependencies);

		for (int ix = 0; ix < i_problem_size; ix++)
		{
			for (int iy = 0; iy < i_problem_size; iy++)
			{
				pi_dsm_dled[ix][iy] = 0;
			}//for (int iy = 0; iy < i_problem_size; iy++)
		}//for (int ix = 0; ix < i_problem_size; ix++)

		for (int i_scrap = 0; i_scrap < v_true_dependencies.size(); i_scrap++)
		{
			for (int i_gene_scrap = 0; i_gene_scrap < v_true_dependencies.at(i_scrap).size(); i_gene_scrap++)
			{
				(pi_dsm_dled[i_scrap][v_true_dependencies.at(i_scrap).at(i_gene_scrap)]) = 1;
				(pi_dsm_dled[v_true_dependencies.at(i_scrap).at(i_gene_scrap)][i_scrap]) = 1;
			}//for (int i_gene_first = 0; i_gene_first < v_true_dependencies.at(i_scrap).size(); i_gene_first++)
		}//for (int i_scrap = 0; i_scrap < v_true_dependencies.size(); i_scrap++)


		/*FILE  *pf_vig;
		pf_vig = fopen("zzz_vig.txt", "w+");
		CString  s_line, s_buf;
		s_line.Format("x \t");
		for (int ix = 0; ix < i_problem_size; ix++)
		{
			s_buf.Format("%d \t ", ix);
			s_line += s_buf;
		}//for (int ix = 0; ix < i_problem_size; ix++)
		fprintf(pf_vig, s_line + "\n");

		for (int ix = 0; ix < i_problem_size; ix++)
		{
			s_line.Format("%d \t ", ix);
			for (int iy = 0; iy < i_problem_size; iy++)
			{
				s_buf.Format("%d \t ", pi_dsm_dled[ix][iy]);
				s_line += s_buf;
			}//for (int iy = 0; iy < i_problem_size; iy++)
			fprintf(pf_vig, s_line + "\n");
		}//for (int ix = 0; ix < i_problem_size; ix++)
		fclose(pf_vig);//*/
	}//else  if (bPerfectLinkage == false)



	pc_single_dsm_linkage->vSetOutsideLinkage_DLED(pi_dsm_dled, pc_evaluation->iGetNumberOfElements(), false);



	uint64_t i_end_ffe;
	double  d_time_passed, d_ffe_passed;
	i_end_ffe = pc_evaluation->iGetFFE();
	c_timer.bGetTimePassed(&d_time_passed);

	d_ffe_passed = i_end_ffe - i_start_ffe;

	if (pc_parent != NULL)
	{
		pc_parent->d_linkage_cost_time += d_time_passed;
		pc_parent->d_linkage_cost_ffe += d_ffe_passed;
	}//if (pc_parent != NULL)

}//void  CLinkageInformationPack::vComputeDSM_ProblemDEcomp_DLED()



void  CLinkageInformationPack::vComputeDSM_DirectionalLinkage(bool bAccumulateClusters)
{
	TimeCounters::CTimeCounter  c_timer;
	uint64_t i_start_ffe;
	i_start_ffe = pc_evaluation->iGetFFE();
	c_timer.vSetStartNow();

	if (pc_directional_linkages == NULL)
	{
		pc_directional_linkages = new  CDirectional_DSM_Group();
		pc_directional_linkages->bSetSize(pc_evaluation->iGetNumberOfElements());
	}//if (pc_directional_linkages == NULL)


	if (v_pop_to_analayze.size() < 1)  return;

	CLinkageInformationPackIndividual *pc_best_ind, *pc_context;
	pc_best_ind = pc_get_best_individual(&v_pop_to_analayze);
	if (b_is_ind_included(pc_best_ind, &v_directional_linkage_analyzed_inds) == true)  return;

	pc_best_ind = pc_best_ind->pcGetClone();
	v_directional_linkage_analyzed_inds.push_back(pc_best_ind);

	bool  b_choose_from_pop = false;
	if (v_directional_linkage_analyzed_inds.size() > 1)
	{
		pc_context = v_directional_linkage_analyzed_inds.at(v_directional_linkage_analyzed_inds.size() - 2);
		if  (pc_context->bGenotypesTheSame(pc_best_ind) == true)  b_choose_from_pop = true;
	}//if (v_directional_linkage_analyzed_inds.size() > 0)
	else
		b_choose_from_pop = true;
	
	if (b_choose_from_pop == true)
	{
		pc_context = NULL;
		vector <CLinkageInformationPackIndividual *>  v_pop_for_context;

		for (int ii = 0; ii < v_pop_to_analayze.size(); ii++)
		{
			if (v_pop_to_analayze.at(ii)->bGenotypesTheSame(pc_best_ind) == false)  v_pop_for_context.push_back(v_pop_to_analayze.at(ii));
		}//for (int ii = 0; ii < v_pop_to_analayze.size(); ii++)
		
		if (v_pop_for_context.size() > 0)
		{
			int  i_context_offset;
			i_context_offset = ::RandUtils::iRandNumber(0, v_pop_for_context.size() - 1);
			pc_context = v_pop_for_context.at(i_context_offset);
		}//if (v_pop_for_context.size() > 0)		
	}//if (b_choose_from_pop == true)

	if (pc_context == NULL)  return;

	CLinkageInformationPackIndividual *pc_buffer;
	pc_buffer = pc_best_ind->pcGetClone();
	pc_best_ind->vGetDirectionalLinkage(pc_directional_linkages->pcGetDSM_ForLinkageDiscovery(false), 0, pc_context, pc_buffer);
	pc_directional_linkages->vMakeSummarizedLinkage();
	delete pc_buffer;


	//pc_directional_linkages->vSave("zzzzz_test_dirDSM.txt");
	//::Tools::vShow("zzzzz_test_dirDSM.txt");

	//generacja klastrow, zebranie linkage'u i inne bajery



	pc_directional_linkages->vCreateDirectional_BilateralGroups(NULL, NULL);
	//pc_directional_linkages->vSave("zzzzz_clusters.txt");
	//::Tools::vShow(6);


	pc_single_dsm_linkage->vSetOutsideLinkage_DirectionalNodes(pc_directional_linkages->pvGetDirectionalNodes(), pc_evaluation->iGetNumberOfElements(), bAccumulateClusters);




	uint64_t i_end_ffe;
	double  d_time_passed, d_ffe_passed;
	i_end_ffe = pc_evaluation->iGetFFE();
	c_timer.bGetTimePassed(&d_time_passed);

	d_ffe_passed = i_end_ffe - i_start_ffe;

	if (pc_parent != NULL)
	{
		pc_parent->d_linkage_cost_time += d_time_passed;
		pc_parent->d_linkage_cost_ffe += d_ffe_passed;
	}//if (pc_parent != NULL)
}//void  CLinkageInformationPack::vComputeDSM_DirectionalLinkage(bool bAccumulateClusters)


void  CLinkageInformationPack::vComputeDSM_DLED(bool bAccumulateClusters)
{
	TimeCounters::CTimeCounter  c_timer;
	uint64_t i_start_ffe;
	i_start_ffe = pc_evaluation->iGetFFE();
	c_timer.vSetStartNow();

	if (v_pop_to_analayze.size() < 1)  return;
	//compute gene freqs
	/*for (int ii = 0; ii < v_gene_freqs.size(); ii++)
	{
		v_gene_freqs.at(ii)->vResetCounters();
		v_gene_freqs.at(ii)->vCountGeneValueFreqs(&v_pop_to_analayze);
	}//for (int ii = 0; ii < v_gene_freqs.size(); ii++)*/

	if  (pc_parent->pd_linkage_gathering_probabilities == NULL)
	{ 
		pc_parent->pd_linkage_gathering_probabilities = new double[pc_evaluation->iGetNumberOfElements()];
		pc_parent->pi_no_linkage_for_gene = new int[pc_evaluation->iGetNumberOfElements()];
		for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
		{
			pc_parent->pd_linkage_gathering_probabilities[ii] = 1;
			pc_parent->pi_no_linkage_for_gene[ii] = 1;
		}//for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
	}//if  (pd_linkage_gathering_probabilities == NULL)
	
	//compute DSM
	vector<CLinkageInformationPackIndividual *>  v_inds_to_get_linkage;
	CLinkageInformationPackLinkageScrap  *pc_new_linkage_scrap;
	int  i_rand_ind_offset;
	for (int i_gene_off = 0; i_gene_off < v_gene_freqs.size(); i_gene_off++)
	{
		if ( (::RandUtils::dRandNumber(0, 1) < pc_parent->pd_linkage_gathering_probabilities[v_gene_freqs.at(i_gene_off)->iGetGeneOffset()])||(pc_parent->pi_no_linkage_for_gene[v_gene_freqs.at(i_gene_off)->iGetGeneOffset()] == 1) )
		{
			i_rand_ind_offset = ::RandUtils::iRandNumber(0, v_pop_to_analayze.size() - 1);
			pc_new_linkage_scrap = v_pop_to_analayze.at(i_rand_ind_offset)->pcGetLinkageScrap(v_gene_freqs.at(i_gene_off)->iGetGeneOffset());
			if (pc_new_linkage_scrap != NULL)  v_linkage_scraps.push_back(pc_new_linkage_scrap);
			
			//if there is a new linkage found, then the v_linkage_scraps.at(i_scrap)->vAddScrapToDSM(pi_dsm, pc_parent->pd_linkage_gathering_probabilities);
			//will reset the pc_parent->pd_linkage_gathering_probabilities[] value to 1
			pc_parent->pd_linkage_gathering_probabilities[v_gene_freqs.at(i_gene_off)->iGetGeneOffset()] = pc_parent->pd_linkage_gathering_probabilities[v_gene_freqs.at(i_gene_off)->iGetGeneOffset()] * 0.5;
		}//if  (::RandUtils::dRandNumber(0,1) <  pc_parent->pd_linkage_gathering_probabilities[v_gene_freqs.at(i_gene_off)->iGetGeneOffset()])

		/*v_inds_to_get_linkage.clear();
		v_gene_freqs.at(i_gene_off)->vGetIndsForLL(&v_inds_to_get_linkage, &v_pop_to_analayze);

		for (int i_ind_for_link = 0; i_ind_for_link < v_inds_to_get_linkage.size(); i_ind_for_link++)
		{
			pc_new_linkage_scrap = v_inds_to_get_linkage.at(i_ind_for_link)->pcGetLinkageScrap(v_gene_freqs.at(i_gene_off)->iGetGeneOffset());
			if  (pc_new_linkage_scrap  !=  NULL)  v_linkage_scraps.push_back(pc_new_linkage_scrap);
		}//for (int i_ind_for_link = 0; i_ind_for_link < v_inds_to_get_linkage.size(); i_ind_for_link++)*/
	}//for (int ii = 0; ii < v_gene_freqs.size(); ii++)



	for (int i_scrap = 0; i_scrap < v_linkage_scraps.size(); i_scrap++)
	{
		v_linkage_scraps.at(i_scrap)->vAddScrapToDSM(pi_dsm_dled, pc_parent->pd_linkage_gathering_probabilities, pc_parent->pi_no_linkage_for_gene);
		pc_parent->v_global_linkage_scraps.push_back(v_linkage_scraps.at(i_scrap));
		//delete  v_linkage_scraps.at(i_scrap);
	}//for (int i_scrap = 0; i_scrap < v_linkage_scraps.size(); i_scrap++)
	v_linkage_scraps.clear();



	pc_single_dsm_linkage->vSetOutsideLinkage_DLED(pi_dsm_dled, pc_evaluation->iGetNumberOfElements(), bAccumulateClusters);



	uint64_t i_end_ffe;
	double  d_time_passed, d_ffe_passed;
	i_end_ffe = pc_evaluation->iGetFFE();
	c_timer.bGetTimePassed(&d_time_passed);

	d_ffe_passed = i_end_ffe - i_start_ffe;

	if (pc_parent != NULL)
	{
		pc_parent->d_linkage_cost_time += d_time_passed;
		pc_parent->d_linkage_cost_ffe += d_ffe_passed;
	}//if (pc_parent != NULL)

}//void  CLinkageInformationPack::vComputeDSM_DLED()



void  CLinkageInformationPack::vComputeDSM_HLL_DLED_SLL(bool  bAccumulateClusters)
{
	TimeCounters::CTimeCounter  c_timer;
	uint64_t i_start_ffe;
	i_start_ffe = pc_evaluation->iGetFFE();
	c_timer.vSetStartNow();


	pc_single_dsm_linkage->vSetOutsideLinkage_HLL_DLED_SLL(pi_dsm_dled, pd_dsm_sll, pc_evaluation->iGetNumberOfElements(), bAccumulateClusters);



	uint64_t i_end_ffe;
	double  d_time_passed, d_ffe_passed;
	i_end_ffe = pc_evaluation->iGetFFE();
	c_timer.bGetTimePassed(&d_time_passed);

	d_ffe_passed = i_end_ffe - i_start_ffe;

	if (pc_parent != NULL)
	{
		pc_parent->d_linkage_cost_time += d_time_passed;
		pc_parent->d_linkage_cost_ffe += d_ffe_passed;
	}//if (pc_parent != NULL)
}//void  CLinkageInformationPack::vComputeDSM_HLL_DLED_SLL(bool  bAccumulateClusters)



void  CLinkageInformationPack::vSetDSM_DLED(bool bAccumulateClusters)
{
	pc_single_dsm_linkage->vSetOutsideLinkage_DLED(pi_dsm_dled, pc_evaluation->iGetNumberOfElements(), bAccumulateClusters);
}//void  CLinkageInformationPack::vSetDSM_DLED(bool bAccumulateClusters)



void  CLinkageInformationPack::vSetDSM_SLL(bool  bAccumulateClusters)
{
	pc_single_dsm_linkage->vSetOutsideLinkage_SLL(pd_dsm_sll, pc_evaluation->iGetNumberOfElements(), bAccumulateClusters);
}//void  CLinkageInformationPack::vSetDSM_SLL(bool  bAccumulateClusters)



void  CLinkageInformationPack::vSetDSM_HLL_DLED_SLL(bool  bAccumulateClusters)
{
	pc_single_dsm_linkage->vSetOutsideLinkage_HLL_DLED_SLL(pi_dsm_dled, pd_dsm_sll, pc_evaluation->iGetNumberOfElements(), bAccumulateClusters);
}//void  CLinkageInformationPack::vSetDSM_SLL(bool  bAccumulateClusters)





void  CLinkageInformationPack::vComputeDSM_SLL(bool bAccumulateClusters)
{
	TimeCounters::CTimeCounter  c_timer;
	uint64_t i_start_ffe;
	i_start_ffe = pc_evaluation->iGetFFE();
	c_timer.vSetStartNow();

	
	pc_single_dsm_linkage->vSetOutsideLinkage_SLL(pd_dsm_sll, pc_evaluation->iGetNumberOfElements(), bAccumulateClusters);



	uint64_t i_end_ffe;
	double  d_time_passed, d_ffe_passed;
	i_end_ffe = pc_evaluation->iGetFFE();
	c_timer.bGetTimePassed(&d_time_passed);

	d_ffe_passed = i_end_ffe - i_start_ffe;

	if (pc_parent != NULL)
	{
		pc_parent->d_linkage_cost_time += d_time_passed;
		pc_parent->d_linkage_cost_ffe += d_ffe_passed;
	}//if (pc_parent != NULL)

}//void  CLinkageInformationPack::vComputeDSM_SLL()




void  CLinkageInformationPack::vSetSLL_P3linkage(unordered_map<int, unordered_map<int, double> > *pcDSM)
{
	CString s_message;

	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();


	if (i_problem_size != pcDSM->size() + 1)//p3 dsm omits the diagonal. Thus, it is shorter by 1 than it should be
	{
		s_message.Format("void  CLinkageInformationPack::vSetSLL_P3linkage(unordered_map<int, unordered_map<int, double> > *pcDSM), (%d != %d)", i_problem_size, pcDSM->size());
		::MessageBox(NULL, s_message, s_message, MB_OK);
	}//if (i_problem_size != pcDSM->size() + 1)//p3 dsm omits the diagonal. Thus, it is shorter by 1 than it should be


	for (int ix = 0; ix < i_problem_size; ix++)
	{
		for (int iy = 0; iy < i_problem_size; iy++)
		{
			if (ix == iy)
				pd_dsm_sll[ix][iy] = 0;
			else
			{
				if (ix < iy)
					pd_dsm_sll[ix][iy] = (*pcDSM)[ix][iy];
				else
					pd_dsm_sll[ix][iy] = (*pcDSM)[iy][ix];
			}//else if (ix == iy)
		}//for (int iy = 0; iy < i_dsm_size; iy++)
	}//for (int ix = 0; ix < i_dsm_size; ix++)

}//void  CLinkageInformationPack::vSetSLL_P3linkage(unordered_map<int, unordered_map<int, double> > *pcDSM)



void  CLinkageInformationPack::vSetSLL_GenerateDSMfromPop()
{
	if (pppi_sll_genes_values_occurrences == NULL)
	{
		pppi_sll_genes_values_occurrences = new int**[pc_evaluation->iGetNumberOfElements()];

		for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
		{
			pppi_sll_genes_values_occurrences[ii] = new int*[pc_evaluation->iGetNumberOfElements()];

			for (int jj = 0; jj < pc_evaluation->iGetNumberOfElements(); jj++)
			{
				pppi_sll_genes_values_occurrences[ii][jj] = new int[4];

				for (int kk = 0; kk < 4; kk++)
				{
					pppi_sll_genes_values_occurrences[ii][jj][kk] = 0;
				}//for (int kk = 0; kk < 4; kk++)
			}//for (int jj = 0; jj < i_templ_length; jj++)
		}//for (int ii = 0; ii < i_templ_length; ii++)
	}//if (pppi_sll_genes_values_occurrences == NULL)
	
	v_sll_zero_genes_values_occurrences();

	for (int ii = 0; ii < v_pop_to_analayze.size(); ii++)
		v_sll_update_genes_values_occurrences(v_pop_to_analayze.at(ii));
	
	v_create_sll_dsm();
}//void  CLinkageInformationPack::vSetSLL_GenerateDSM()



void CLinkageInformationPack::v_sll_zero_genes_values_occurrences()
{
	if (pppi_sll_genes_values_occurrences == NULL)
	{
		for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements(); ii++)
		{
			for (int jj = 0; jj < pc_evaluation->iGetNumberOfElements(); jj++)
			{
				for (int kk = 0; kk < 4; kk++)
				{
					pppi_sll_genes_values_occurrences[ii][jj][kk] = 0;
				}//for (int kk = 0; kk < 4; kk++)
			}//for (int jj = 0; jj < i_templ_length; jj++)
		}//for (int ii = 0; ii < i_templ_length; ii++)
	}//if (pppi_sll_genes_values_occurrences == NULL)
}//void CLinkageInformationPack::v_sll_zero_genes_values_occurrences()



void CLinkageInformationPack::v_sll_update_genes_values_occurrences(CLinkageInformationPackIndividual *pcInd)
{
	int *pi_genotype = pcInd->piGetGenotype();

	for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements() - 1; ii++)
	{
		for (int jj = ii + 1; jj < pc_evaluation->iGetNumberOfElements(); jj++)
		{
			if (pi_genotype[ii] == 0 && pi_genotype[jj] == 0)
			{
				pppi_sll_genes_values_occurrences[ii][jj][0]++;
				pppi_sll_genes_values_occurrences[jj][ii][0]++;
			}//if (pi_genotype[ii] == 0 && pi_genotype[jj] == 0)
			else if (pi_genotype[ii] == 0 && pi_genotype[jj] == 1)
			{
				pppi_sll_genes_values_occurrences[ii][jj][1]++;
				pppi_sll_genes_values_occurrences[jj][ii][1]++;
			}//else if (pi_genotype[ii] == 0 && pi_genotype[jj] == 1)
			else if (pi_genotype[ii] == 1 && pi_genotype[jj] == 0)
			{
				pppi_sll_genes_values_occurrences[ii][jj][2]++;
				pppi_sll_genes_values_occurrences[jj][ii][2]++;
			}//else if (pi_genotype[ii] == 1 && pi_genotype[jj] == 0)
			else if (pi_genotype[ii] == 1 && pi_genotype[jj] == 1)
			{
				pppi_sll_genes_values_occurrences[ii][jj][3]++;
				pppi_sll_genes_values_occurrences[jj][ii][3]++;
			}//else if (pi_genotype[ii] == 1 && pi_genotype[jj] == 1)
		}//for (int jj = ii + 1; jj < i_templ_length; jj++)
	}//for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements() - 1; ii++)
}//void CLinkageInformationPack::v_sll_update_genes_values_occurrences(CLinkageInformationPackIndividual *pcInd)


void CLinkageInformationPack::v_create_sll_dsm()
{
	int pi_ones_or_zeros_occurrences[4];
	int i_total;

	double d_joint, d_sum_of_separated;

	for (int ii = 0; ii < pc_evaluation->iGetNumberOfElements() - 1; ii++)
	{
		pd_dsm_sll[ii][ii] = 0;

		for (int jj = ii + 1; jj < pc_evaluation->iGetNumberOfElements(); jj++)
		{
			pd_dsm_sll[ii][jj] = 0;

			pi_ones_or_zeros_occurrences[0] = pppi_sll_genes_values_occurrences[ii][jj][0] + pppi_sll_genes_values_occurrences[ii][jj][1];
			pi_ones_or_zeros_occurrences[1] = pppi_sll_genes_values_occurrences[ii][jj][2] + pppi_sll_genes_values_occurrences[ii][jj][3];
			pi_ones_or_zeros_occurrences[2] = pppi_sll_genes_values_occurrences[ii][jj][0] + pppi_sll_genes_values_occurrences[ii][jj][2];
			pi_ones_or_zeros_occurrences[3] = pppi_sll_genes_values_occurrences[ii][jj][1] + pppi_sll_genes_values_occurrences[ii][jj][3];

			i_total = pi_ones_or_zeros_occurrences[0] + pi_ones_or_zeros_occurrences[1];

			d_joint = MathUtils::dComputeEntropy((uint32_t*)pppi_sll_genes_values_occurrences[ii][jj], (uint32_t)4, (uint32_t)i_total);

			if (d_joint > 0)
			{
				d_sum_of_separated = MathUtils::dComputeEntropy((uint32_t*)pi_ones_or_zeros_occurrences, (uint32_t)4, (uint32_t)i_total);
				pd_dsm_sll[ii][jj] = 2 - d_sum_of_separated / d_joint;
			}//if (d_joint > 0)

			//pd_dsm_sll[ii][jj] = 1 - pd_dsm_sll[ii][jj];
			pd_dsm_sll[jj][ii] = pd_dsm_sll[ii][jj];
		}//for (int jj = ii + 1; jj < i_templ_length; jj++)
	}//for (int ii = 0; ii < i_templ_length - 1; ii++)


	/*CString  s_buf;
	FILE  *pf_dest;
	pf_dest = fopen("zzz_sll_dsm.txt", "w+");
	
	for (int ix = 0; ix < pc_evaluation->iGetNumberOfElements(); ix++)
	{
		for (int iy = 0; iy < pc_evaluation->iGetNumberOfElements(); iy++)
		{
			fprintf(pf_dest, "%.8lf\t", pd_dsm_sll[ix][iy]);
		}//for (int iy = 0; iy < pc_evaluation->iGetNumberOfElements(); iy++)
		fprintf(pf_dest, "\n");
	}//for (int ix = 0; ix < pc_evaluation->iGetNumberOfElements(); ix++)
	fclose(pf_dest);*/

}//void CLinkageInformationPack::v_create_sll_dsm()



void  CLinkageInformationPack::vSetSLL_LTGAlinkage(double  **pdDSM, int  iDSMsize)
{
	CString s_message;

	int  i_problem_size;
	i_problem_size = pc_evaluation->iGetNumberOfElements();

	
	if (i_problem_size != iDSMsize)
	{
		s_message.Format("void  CLinkageInformationPack::vSetSLL_LTGAlinkage(double  **pdDSM, int  iDSMsize)");
		::MessageBox(NULL, s_message, s_message, MB_OK);
	}



	for (int ix = 0; ix < i_problem_size; ix++)
	{
		for (int iy = 0; iy < i_problem_size; iy++)
		{
			if (ix == iy)
				pd_dsm_sll[ix][iy] = 0;
			else
			{
				if (ix < iy)
					pd_dsm_sll[ix][iy] = 1.0 - (pdDSM)[ix][iy];
				else
					pd_dsm_sll[ix][iy] = 1.0 - (pdDSM)[iy][ix];
			}//else if (ix == iy)
		}//for (int iy = 0; iy < i_dsm_size; iy++)
	}//for (int ix = 0; ix < i_dsm_size; ix++)


}//void  CLinkageInformationPack::vSetSLL_LTGAlinkage(double  **pdDSM, int  iDSMsize)



CLinkageInformationPackIndividual::CLinkageInformationPackIndividual(CEvaluation<CBinaryCoding> *pcEvaluation, CBinaryCoding *pcEvaluationIndividual)
{
	pc_evaluation = pcEvaluation;
	pc_evaluation_individual = pcEvaluationIndividual;

	i_problem_size = pc_evaluation->iGetNumberOfElements();
	pi_genotype = new int[i_problem_size];

	b_fit_actual = false;
}//CLinkageInformationPackIndividual(int  iProblemSize, CEvaluation<CBinaryCoding> *pcEvaluation, CBinaryCoding *pcEvaluationIndividual)

CLinkageInformationPackIndividual::~CLinkageInformationPackIndividual()
{
	delete  pi_genotype;
}//CLinkageInformationPackIndividual::~CLinkageInformationPackIndividual()


void  CLinkageInformationPackIndividual::vFIHC()
{
	int  i_gene_offset;
	double  d_best_fit, d_cur_fit;
	d_best_fit = d_compute_fitness(pi_genotype);

	bool  b_modified = true;

	while (b_modified == true)
	{
		b_modified = false;

		for (int ii = 0; ii < v_order.size(); ii++)
		{
			i_gene_offset = v_order.at(ii);
			pi_genotype[i_gene_offset] = i_get_other_value(pi_genotype[i_gene_offset]);

			d_cur_fit = d_compute_fitness(pi_genotype);

			if (d_best_fit < d_cur_fit)
			{
				b_modified = true;
				d_best_fit = d_cur_fit;
			}//if (d_cur_fit > d_best_fit)
			else
				pi_genotype[i_gene_offset] = i_get_other_value(pi_genotype[i_gene_offset]);
		}//for (int ii = 0; ii < v_order.size(); ii++)
	}//while (b_modified == true)

	b_fit_actual = false;
}//void  CLinkageInformationPackIndividual::vFIHC()


int  CLinkageInformationPackIndividual::i_get_other_value(int  iValue)
{
	if (iValue == 0)  return(1);
	return(0);
}//int  CLinkageInformationPackIndividual::i_get_other_value(int  iValue)


int  CLinkageInformationPackIndividual::i_get_better_value(int  *piGenoBuffer, int  *piGenotypeOrig, int  iGeneOff, double  dFitForOrig)
{
	piGenoBuffer[iGeneOff] = i_get_other_value(piGenotypeOrig[iGeneOff]);

	//no perturbation first
	int  i_better_gene_val;
	double  d_fit_for_mod;
	d_fit_for_mod = d_compute_fitness(piGenoBuffer);
	if (d_fit_for_mod > dFitForOrig)
		i_better_gene_val = piGenoBuffer[iGeneOff];
	else
		i_better_gene_val = piGenotypeOrig[iGeneOff];
		
	return(i_better_gene_val);
}//int  CLinkageInformationPackIndividual::i_get_better_value(int  *piGenoBuffer, int  *piGenotypeOrig, int  iGeneOff, double  dFitForOrig)





CLinkageInformationPackLinkageScrap  *CLinkageInformationPackIndividual::pcGetLinkageScrap(int iPerturbationOffset, int  **piDSM_CurrentlyLinkedToOmit /*= NULL*/)
{
	//vRandomizeOrder();
	//vFIHC();
	//for  (int  ii = 0; ii < 10; ii++)
		//pi_genotype[ii] = 1;

	CLinkageInformationPackLinkageScrap  *pc_new_linkage_scrap = new CLinkageInformationPackLinkageScrap();
	vector<int>  *pv_link_scrap;
	pv_link_scrap = pc_new_linkage_scrap->pvGetLinkageScrap();
	pv_link_scrap->push_back(iPerturbationOffset);


	int  *pi_geno_buffer, *pi_geno_buffer_perturbed;
	pi_geno_buffer = new int[i_problem_size];
	pi_geno_buffer_perturbed = new int[i_problem_size];

	double d_fit_for_orig, d_fit_for_perturbed, d_fit_for_mod;
	
	for (int ii = 0; ii < i_problem_size; ii++)
	{
		pi_geno_buffer[ii] = pi_genotype[ii];
		pi_geno_buffer_perturbed[ii] = pi_genotype[ii];
	}//for (int ii = 0; ii < i_problem_size; ii++)
	pi_geno_buffer_perturbed[iPerturbationOffset] = i_get_other_value(pi_genotype[iPerturbationOffset]);

	d_fit_for_orig = d_compute_fitness(pi_geno_buffer);
	d_fit_for_perturbed = d_compute_fitness(pi_geno_buffer_perturbed);
	

	int  i_better_gene_val, i_better_gene_val_for_perturbed;
	bool  b_perfrom_check;
	for (int i_gene_off = 0; i_gene_off < i_problem_size; i_gene_off++)
	{
		b_perfrom_check = true;
		if (i_gene_off != iPerturbationOffset)
		{
			b_perfrom_check = true;
			if (piDSM_CurrentlyLinkedToOmit != NULL)
			{
				if (piDSM_CurrentlyLinkedToOmit[iPerturbationOffset][i_gene_off] > 0)  b_perfrom_check = false;
			}//if (piDSM_CurrentlyLinkedToOmit != NULL)
		}//if (i_gene_off != iPerturbationOffset)
		else
		{
			b_perfrom_check = false;
		}//else  if (i_gene_off != iPerturbationOffset)

		if (b_perfrom_check == true)
		{
			i_better_gene_val = i_get_better_value(pi_geno_buffer, pi_genotype, i_gene_off, d_fit_for_orig);
			pi_geno_buffer[i_gene_off] = pi_genotype[i_gene_off];

			i_better_gene_val_for_perturbed = i_get_better_value(pi_geno_buffer_perturbed, pi_genotype, i_gene_off, d_fit_for_perturbed);
			pi_geno_buffer_perturbed[i_gene_off] = pi_genotype[i_gene_off];

			if  (i_better_gene_val != i_better_gene_val_for_perturbed)  pv_link_scrap->push_back(i_gene_off);
			
		}//if (i_gene_off != iGeneoOffset)
	}//for (int i_gene_off = 0; i_gene_off < i_problem_size; i_gene_off++)


	delete pi_geno_buffer;
	delete pi_geno_buffer_perturbed;

	if (pv_link_scrap->size() <= 1)
	{
		delete  pc_new_linkage_scrap;
		pc_new_linkage_scrap = NULL;
	}//if (pv_link_scrap->size() <= 1)
	

	return(pc_new_linkage_scrap);
}//CLinkageInformationPackLinkageScrap  *CLinkageInformationPackIndividual::pcGetLinkageScrap(int iGeneoOffset)


void  CLinkageInformationPackIndividual::vRandomizeOrder()
{
	vector<int>  v_buffer;

	for (int ii = 0; ii < i_problem_size; ii++)
		v_buffer.push_back(ii);

	int  i_rand_offset;
	while (v_buffer.size() > 0)
	{
		i_rand_offset = ::RandUtils::iRandNumber(0, v_buffer.size() - 1);
		v_order.push_back(v_buffer.at(i_rand_offset));
		v_buffer.erase(v_buffer.begin() + i_rand_offset);
	}//while (v_buffer.size() > 0)
}//void  CLinkageInformationPackIndividual::vRandomizeOrder()



void  CLinkageInformationPackIndividual::vSetP3_Genotype(vector<bool> *pvNewSolution)
{
	for (int ii = 0; ii < pvNewSolution->size(); ii++)
		pi_genotype[ii] = (pvNewSolution->at(ii) == TRUE) ? 1 : 0;

	b_fit_actual = false;
}//void  CLinkageInformationPackIndividual::vSetP3_Genotype(vector<bool> *pvNewSolution)


void  CLinkageInformationPackIndividual::vSetInt_Genotype(int  *piGenotype)
{
	for (int ii = 0; ii < i_problem_size; ii++)
		pi_genotype[ii] = piGenotype[ii];

	b_fit_actual = false;
}//void  CLinkageInformationPackIndividual::vSetInt_Genotype(int  *piGenotype, int  iSolSize)


void  CLinkageInformationPackIndividual::vSetLTGA_Genotype(char*  pcGenotype)
{
	for (int ii = 0; ii < i_problem_size; ii++)
		pi_genotype[ii] = (pcGenotype[ii] == TRUE) ? 1 : 0;

	b_fit_actual = false;
}//void  CLinkageInformationPackIndividual::vSetLTGA_Genotype(char*  pcGenotype)


bool  CLinkageInformationPackIndividual::bSetGene(int iGenePos, int iGeneVal)
{
	if (iGenePos < 0)  return(false);
	if (iGenePos >= i_problem_size)  return(false);

	pi_genotype[iGenePos] = iGeneVal;
	b_fit_actual = false;

	return(true);
}//bool  CLinkageInformationPackIndividual::bSetGene(int iGenePos, int iGeneVal)


double  CLinkageInformationPackIndividual::dComputeFitness()
{
	if (b_fit_actual == false)
	{
		d_fitness = d_compute_fitness(pi_genotype);
		b_fit_actual = true;
	}//if  (b_fit_actual ==  false)
	return(d_fitness);
}//double  CLinkageInformationPackIndividual::dComputeFitness()



double  CLinkageInformationPackIndividual::d_compute_fitness(int  *piGenotype)
{
	for (int ii = 0; ii < i_problem_size; ii++)
	{
		*(pc_evaluation_individual->piGetBits() + ii) = piGenotype[ii];
	}


	double  d_result;
	d_result = pc_evaluation->dEvaluate(pc_evaluation_individual);

	return(d_result);
}//double  CLinkageInformationPackIndividual::d_compute_fitness(int  *piGenotype)


bool  CLinkageInformationPackIndividual::bGenotypesTheSame(CLinkageInformationPackIndividual *pcOtherInd)
{
	return(bGenotypesTheSame(pcOtherInd->pi_genotype));
}//bool  CLinkageInformationPackIndividual::bGenotypesTheSame(CLinkageInformationPackIndividual *pcOtherInd)


bool  CLinkageInformationPackIndividual::bGenotypesTheSame(int  *piGenotype)
{
	for (int ii = 0; ii < i_problem_size; ii++)
	{
		if (pi_genotype[ii] != piGenotype[ii])  return(false);
	}//for (int ii = 0; ii < i_problem_size; ii++)

	return(true);
}//bool  CLinkageInformationPackIndividual::bGenotypesTheSame(int  *piGenotype)



CString  CLinkageInformationPackIndividual::sToStr()
{
	CString  s_res, s_buf;

	for (int ii = 0; ii < i_problem_size; ii++)
	{
		s_buf.Format("%d", pi_genotype[ii]);
		s_res += s_buf;
	}//for (int ii = 0; ii < i_problem_size; ii++)

	return(s_res);
}//CString  CLinkageInformationPackIndividual::sToStr()


CLinkageInformationPackIndividual*  CLinkageInformationPackIndividual::pcGetClone()
{
	CLinkageInformationPackIndividual  *pc_result;

	pc_result = new CLinkageInformationPackIndividual(pc_evaluation, pc_evaluation_individual);
	pc_result->vSetInt_Genotype(pi_genotype);

	return(pc_result);
}//CLinkageInformationPackIndividual*  CLinkageInformationPackIndividual::pcGetClone()







void  CLinkageInformationPackIndividual::vGetDirectionalLinkage(CDirectional_DSM  *pcDirectionalLinkage, int iBilateralLinkageOnly, CLinkageInformationPackIndividual  *pcContext, CLinkageInformationPackIndividual *pcBuffer)
{
	double  d_fitness_bo_oo, d_fitness_bo_oa, d_fitness_ba_oo, d_fitness_ba_oa;
	CString s_original_gen, s_fitness_bo_oo, s_fitness_bo_oa, s_fitness_ba_oo, s_fitness_ba_oa;
	int  i_base_orig_relation, i_base_alter_relation;
	int  i_other_orig_relation, i_other_alter_relation;

	pcBuffer->vSetInt_Genotype(pi_genotype);//store original state

	int  i_gene_base_orig, i_gene_base_alter;
	int  i_gene_other_orig, i_gene_other_alter;

	//s_original_gen = this->sToStr();

	int  i_checks = 0;
	for (int i_gene_base = 0; i_gene_base < i_problem_size; i_gene_base++)
	{
		if (pcContext->pi_genotype[i_gene_base] != pcBuffer->pi_genotype[i_gene_base])
		{
			for (int i_gene_other = i_gene_base + 1; i_gene_other < i_problem_size; i_gene_other++)
			{
				if (i_gene_base != i_gene_other)
				{
					if (pcContext->pi_genotype[i_gene_other] != pcBuffer->pi_genotype[i_gene_other])
					{
						{

							i_gene_base_orig = pcBuffer->pi_genotype[i_gene_base];
							i_gene_base_alter = pcContext->pi_genotype[i_gene_base];
							i_gene_other_orig = pcBuffer->pi_genotype[i_gene_other];
							i_gene_other_alter = pcContext->pi_genotype[i_gene_other];

							
							//d_fitness_bo_oa = pcBuffer->d_switch_virt_way(i_gene_other, pc_vw_other_alter, pcFOMcounter, plCapacities, lPenalty);
							pcBuffer->bSetGene(i_gene_other, i_gene_other_alter);
							d_fitness_bo_oa = pcBuffer->dComputeFitness();
							//s_fitness_bo_oa = pcBuffer->sToStr();
														
							//d_fitness_ba_oa = pcBuffer->d_switch_virt_way(i_gene_base, pc_vw_base_alter, pcFOMcounter, plCapacities, lPenalty);
							pcBuffer->bSetGene(i_gene_base, i_gene_base_alter);
							d_fitness_ba_oa = pcBuffer->dComputeFitness(); 
							//s_fitness_ba_oa = pcBuffer->sToStr();

							//d_fitness_ba_oo = pcBuffer->d_switch_virt_way(i_gene_other, pc_vw_other_orig, pcFOMcounter, plCapacities, lPenalty);
							pcBuffer->bSetGene(i_gene_other, i_gene_other_orig);
							d_fitness_ba_oo = pcBuffer->dComputeFitness();
							//s_fitness_ba_oo = pcBuffer->sToStr();
													

							//d_fitness_bo_oo = pcBuffer->d_switch_virt_way(i_gene_base, pc_vw_base_orig, pcFOMcounter, plCapacities, lPenalty);
							pcBuffer->bSetGene(i_gene_base, i_gene_base_orig);
							d_fitness_bo_oo = pcBuffer->dComputeFitness();
							//s_fitness_bo_oo = pcBuffer->sToStr();

							

							if (d_fitness_bo_oo < d_fitness_bo_oa)  i_base_orig_relation = -1;
							if (d_fitness_bo_oo == d_fitness_bo_oa)  i_base_orig_relation = 0;
							if (d_fitness_bo_oo > d_fitness_bo_oa)  i_base_orig_relation = 1;

							if (d_fitness_ba_oo < d_fitness_ba_oa)  i_base_alter_relation = -1;
							if (d_fitness_ba_oo == d_fitness_ba_oa)  i_base_alter_relation = 0;
							if (d_fitness_ba_oo > d_fitness_ba_oa)  i_base_alter_relation = 1;


							if (d_fitness_bo_oo < d_fitness_ba_oo)  i_other_orig_relation = -1;
							if (d_fitness_bo_oo == d_fitness_ba_oo)  i_other_orig_relation = 0;
							if (d_fitness_bo_oo > d_fitness_ba_oo)  i_other_orig_relation = 1;

							if (d_fitness_bo_oa < d_fitness_ba_oa)  i_other_alter_relation = -1;
							if (d_fitness_bo_oa == d_fitness_ba_oa)  i_other_alter_relation = 0;
							if (d_fitness_bo_oa > d_fitness_ba_oa)  i_other_alter_relation = 1;



							/*if ((i_gene_base == 0) && (i_gene_other == 12))
							{
								::Tools::vShow("if ((i_gene_base == 0) && (i_gene_other == 12))");

								CString  s_buf;
								s_buf.Format("i_base_orig_relation: %d  (%.4lf  %.4lf)  [%s] [%s]", i_base_orig_relation, d_fitness_bo_oo, d_fitness_bo_oa, s_fitness_bo_oo, s_fitness_bo_oa);
								::Tools::vReportInFile("zzzzz_test_dirDSM_additional.txt", s_buf);

								s_buf.Format("i_base_alter_relation: %d  (%.4lf  %.4lf)  [%s] [%s]", i_base_alter_relation, d_fitness_ba_oo, d_fitness_ba_oa, s_fitness_ba_oo, s_fitness_ba_oa);
								::Tools::vReportInFile("zzzzz_test_dirDSM_additional.txt", s_buf);

								s_buf.Format("i_other_orig_relation: %d  (%.4lf  %.4lf)  [%s] [%s]", i_other_orig_relation, d_fitness_bo_oo, d_fitness_ba_oo, s_fitness_bo_oo, s_fitness_ba_oo);
								::Tools::vReportInFile("zzzzz_test_dirDSM_additional.txt", s_buf);

								s_buf.Format("i_other_alter_relation: %d  (%.4lf  %.4lf)  [%s] [%s]", i_other_alter_relation, d_fitness_bo_oa, d_fitness_ba_oa, s_fitness_bo_oa, s_fitness_ba_oa);
								::Tools::vReportInFile("zzzzz_test_dirDSM_additional.txt", s_buf);

							}//if ((i_gene_base == 0) && (i_gene_other == 12))*/


							if (iBilateralLinkageOnly == 0)
							{
								if (i_base_orig_relation != i_base_alter_relation)  pcDirectionalLinkage->bSet(i_gene_base, i_gene_other, pcDirectionalLinkage->pdGetDSM()[i_gene_base][i_gene_other] + 1);
								if (i_other_orig_relation != i_other_alter_relation)  pcDirectionalLinkage->bSet(i_gene_other, i_gene_base, pcDirectionalLinkage->pdGetDSM()[i_gene_other][i_gene_base] + 1);
							}//if  (iBilateralLinkageOnly  == 0)
							else
							{
								if ((i_base_orig_relation != i_base_alter_relation) || (i_other_orig_relation != i_other_alter_relation))
								{
									pcDirectionalLinkage->bSet(i_gene_base, i_gene_other, pcDirectionalLinkage->pdGetDSM()[i_gene_base][i_gene_other] + 1);
									pcDirectionalLinkage->bSet(i_gene_other, i_gene_base, pcDirectionalLinkage->pdGetDSM()[i_gene_other][i_gene_base] + 1);
								}//if  ( (i_base_orig_relation != i_base_alter_relation)||(i_other_orig_relation != i_other_alter_relation) )							
							}//else  if  (iBilateralLinkageOnly  == 0)

							i_checks++;
						}//if  (

					}//if  (pcContext->pc_trajectories[i_gene_other]->iId  !=  pcBuffer->pc_trajectories[i_gene_other]->iId)
				}//if  (i_gene_base  !=  i_gene_other)
			}//for  (int  i_gene_other = 0; i_gene_other < iPairsNumber; i_gene_other++)
		}//if  (pcContext->pc_trajectories[i_opt_traj]->iId  !=  pc_trajectories[i_opt_traj]->iId)
	}//for  (int  i_base_traj = 0; i_base_traj < iPairsNumber; i_base_traj++)

}//void  CLinkageInformationPackIndividual::vGetDirectionalLinkage(CDirectional_DSM  *pcDirectionalLinkage, int iBilateralLinkageOnly, CLinkageInformationPackIndividual  *pcContext)






CLinkageInformationPackGeneFreq::~CLinkageInformationPackGeneFreq()
{
	for (int ii = 0; ii < v_gene_value_freqs.size(); ii++)
		delete  v_gene_value_freqs.at(ii);
}//CLinkageInformationPackGeneFreq::~CLinkageInformationPackGeneFreq()


void  CLinkageInformationPackGeneFreq::vResetCounters()
{
	for (int ii = 0; ii < v_gene_value_freqs.size(); ii++)
		v_gene_value_freqs.at(ii)->vResetCount();
}//void  CLinkageInformationPackGeneFreq::vResetCounters()


void  CLinkageInformationPackGeneFreq::vGetIndsForLL(vector <CLinkageInformationPackIndividual *>  *pvIndsToGetLinkage, vector <CLinkageInformationPackIndividual *>  *pvPopToAnalayze)
{
	CLinkageInformationPackIndividual  *pc_ind_for_linkage;
	for (int i_val_off = 0; i_val_off < v_gene_value_freqs.size(); i_val_off++)
	{
		pc_ind_for_linkage = v_gene_value_freqs.at(i_val_off)->pcGetIndForLL(pvIndsToGetLinkage, pvPopToAnalayze);

		if  (pc_ind_for_linkage != NULL)
			pvIndsToGetLinkage->push_back(pc_ind_for_linkage);
	}//for (int i_val_off = 0; i_val_off < v_gene_value_freqs.size(); i_val_off++)

}//void  CLinkageInformationPackGeneFreq::vGetIndsForLL(vector <CLinkageInformationPackIndividual *>  *pvIndsToGetLinkage, vector <CLinkageInformationPackIndividual *>  *pvPopToAnalayze)


void  CLinkageInformationPackGeneFreq::vCountGeneValueFreqs(vector <CLinkageInformationPackIndividual *>  *pvPopToAnalayze)
{
	for (int i_ind = 0; i_ind < pvPopToAnalayze->size(); i_ind++)
	{
		for (int i_val_off = 0; i_val_off < v_gene_value_freqs.size(); i_val_off++)
		{
			v_gene_value_freqs.at(i_val_off)->vCountForInd(pvPopToAnalayze->at(i_ind));
		}//for (int i_val_off = 0; i_val_off < v_gene_value_freqs.size(); i_val_off++)
	}//for (int ii = 0; ii < pvPopToAnalayze->size(); ii++)
}//void  CLinkageInformationPackGeneFreq::vCountGeneValueFreqs(vector <CLinkageInformationPackIndividual *>  *pvPopToAnalayze)


bool  CLinkageInformationPackGeneFreq::bAddNewValue(int  iNewValue)
{
	for (int ii = 0; ii < v_gene_value_freqs.size(); ii++)
	{
		if (v_gene_value_freqs.at(ii)->iGetValue() == iNewValue)  return(false);
	}//for (int ii = 0; ii < v_gene_freqs.size(); ii++)

	CLinkageInformationPackGeneFreqValue  *pc_new_value;
	pc_new_value = new CLinkageInformationPackGeneFreqValue(this, iNewValue);
	v_gene_value_freqs.push_back(pc_new_value);

	return(true);
};//bool  CLinkageInformationPackGeneFreq::bAddNewValue(int  iNewValue)



void  CLinkageInformationPackGeneFreqValue::vCountForInd(CLinkageInformationPackIndividual *pcInd)
{
	if (pcInd->piGetGenotype()[pc_parent->iGetGeneOffset()] == i_value)  i_count++;
};//void  CLinkageInformationPackGeneFreqValue::vCountForInd(CLinkageInformationPackIndividual *pcInd)



CLinkageInformationPackIndividual *  CLinkageInformationPackGeneFreqValue::pcGetIndForLL(vector <CLinkageInformationPackIndividual *>  *pvIndsToGetLinkage, vector <CLinkageInformationPackIndividual *>  *pvPopToAnalayze)
{
	vector<CLinkageInformationPackIndividual *>  v_filtered_inds;

	for (int ii = 0; ii < pvPopToAnalayze->size(); ii++)
	{
		if (pvPopToAnalayze->at(ii)->piGetGenotype()[pc_parent->iGetGeneOffset()] == i_value)  v_filtered_inds.push_back(pvPopToAnalayze->at(ii));
	}//for (int ii = 0; ii < pvPopToAnalayze->size(); ii++)

	if (v_filtered_inds.size() == 0)  return(NULL);
	int  i_rand_offset;
	i_rand_offset = ::RandUtils::iRandNumber(0, v_filtered_inds.size() - 1);

	return(v_filtered_inds.at(i_rand_offset));
}//void  CLinkageInformationPackGeneFreqValue::pcGetIndForLL(vector <CLinkageInformationPackIndividual *>  *pvIndsToGetLinkage, vector <CLinkageInformationPackIndividual *>  *pvPopToAnalayze)





void  CLinkageInformationPackLinkageScrap::vSaveTo(FILE  *pfDest)
{
	CString  s_line, s_buf;
	for (int ii = 0; ii < v_linkage_scrap.size(); ii++)
	{
		s_buf.Format("%d,", v_linkage_scrap.at(ii));
		s_line += s_buf;
	}//for (int ii = 0; ii < v_linkage_scrap.size(); ii++)

	fprintf(pfDest, s_line);
}//void  CLinkageInformationPackLinkageScrap::vSaveTo(FILE  *pfDest)



void  CLinkageInformationPackLinkageScrap::vAddScrapToDSM(int  **piDSM, double  *pdLinkageGatheringProbabilities, int *piNoLinkageForGene)
{
	if (v_linkage_scrap.size() < 2)  return;

	//we add only the realtions  for the FIRST gene
	int  i_leading_gene;
	i_leading_gene = v_linkage_scrap.at(0);

	int  i_other_gene_offset;
	for (int i_other_gene = 0; i_other_gene < v_linkage_scrap.size(); i_other_gene++)
	{
		i_other_gene_offset = v_linkage_scrap.at(i_other_gene);

		if (pdLinkageGatheringProbabilities != NULL)
		{
			//new dependency found
			if ((piDSM[i_leading_gene][i_other_gene_offset]) == 0)
			{
				pdLinkageGatheringProbabilities[i_leading_gene] = 1;
				pdLinkageGatheringProbabilities[i_other_gene_offset] = 1;

			}//if ((piDSM[i_leading_gene][i_other_gene_offset]) == 0)

			piNoLinkageForGene[i_leading_gene] = 0;
			piNoLinkageForGene[i_other_gene_offset] = 0;
		}//if  (pdLinkageGatheringProbabilities != NULL)

		
		(piDSM[i_leading_gene][i_other_gene_offset])++;
		(piDSM[i_other_gene_offset][i_leading_gene])++;
	}//for (int i_other_gene = 0; i_other_gene < v_linkage_scrap.size(); i_other_gene++)

}//void  CLinkageInformationPackLinkageScrap::vAddScrapToDSM(int  *piDSM)




//-------------------------------------------------------CLinkageAnalyzerSingleDSM-----------------------------------------------------------

CLinkageAnalyzerSingleDSM::CLinkageAnalyzerSingleDSM(CLinkageAnalyzer  *pcParent, CString  sAdditionalName)
{ 
	pi_dsm_discretized = NULL;
	pd_dsm = NULL; 
	i_dsm_size = 0;

	i_pop_size = 0;

	pc_parent = pcParent;

	s_additional_name = sAdditionalName;
}//CLinkageAnalyzerSingleDSM::CLinkageAnalyzerSingleDSM(CLinkageAnalyzer  *pcParent, CString  sAdditionalName)


CLinkageAnalyzerSingleDSM::~CLinkageAnalyzerSingleDSM()
{
	if (pd_dsm != NULL)
	{
		for (int ii = 0; ii < i_dsm_size; ii++)
			delete pd_dsm[ii];
		delete pd_dsm;
	}//if  (pd_dsm != NULL)


	if (pi_dsm_discretized != NULL)
	{
		for (int ii = 0; ii < i_dsm_size; ii++)
			delete pi_dsm_discretized[ii];
		delete pi_dsm_discretized;
	}//if  (pd_dsm != NULL)


	if (pi_dsm_discretized_ranking != NULL)
	{
		for (int ii = 0; ii < i_dsm_size; ii++)
			delete pi_dsm_discretized_ranking[ii];
		delete pi_dsm_discretized_ranking;
	}//if  (pd_dsm != NULL)


}//CLinkageAnalyzerSingleDSM::~CLinkageAnalyzerSingleDSM()



double  CLinkageAnalyzerSingleDSM::dGetDSMValue(int iX, int iY)
{
	return(pd_dsm[iX][iY]);
}//double  CLinkageAnalyzerSingleDSM::dGetDSMValue(int iX, int iY)



void  CLinkageAnalyzerSingleDSM::vCreateDSMofSize(int  iSize)
{
	i_dsm_size = iSize;

	pd_dsm = new double*[i_dsm_size];
	for (int ii = 0; ii < i_dsm_size; ii++)
		pd_dsm[ii] = new double[i_dsm_size];

	pi_dsm_discretized = new int*[i_dsm_size];
	for (int ii = 0; ii < i_dsm_size; ii++)
		pi_dsm_discretized[ii] = new int[i_dsm_size];

	pi_dsm_discretized_ranking = new int*[i_dsm_size];
	for (int ii = 0; ii < i_dsm_size; ii++)
		pi_dsm_discretized_ranking[ii] = new int[i_dsm_size];
}//void  CLinkageAnalyzerSingleDSM::vCreateDSMofSize(int  iSize)



CError  CLinkageAnalyzerSingleDSM::eCreteJOINED_DSM(vector<CLinkageAnalyzer  *>  *pvExternalLinkageAnalyzers)
{
	CError c_err(iERROR_PARENT_CLINKAGE_ANALYZER_SINGLE_DSM);
	CString  s_buf;

	if (pvExternalLinkageAnalyzers->size() < 1)
	{
		c_err.vSetError(CLinkageAnalyzerSingleDSM::iERROR_CODE_LINKAGE_ANALYZER_NO_EXTERNAL_DSMS);
		return(c_err);
	}//if (pvExternalLinkageAnalyzers->size() < 1)

	int  i_registered_dsm_size;
	i_registered_dsm_size = pvExternalLinkageAnalyzers->at(0)->v_true_linkage.size();
	for (int ii = 0; ii < pvExternalLinkageAnalyzers->size(); ii++)
	{
		if (i_registered_dsm_size != (int) (pvExternalLinkageAnalyzers->at(ii)->v_true_linkage.size()))
		{
			s_buf.Format("%d != %d", i_registered_dsm_size, pvExternalLinkageAnalyzers->at(ii)->v_true_linkage.size());
			c_err.vSetError(CLinkageAnalyzerSingleDSM::iERROR_CODE_LINKAGE_ANALYZER_NO_EXTERNAL_DSMS, s_buf);
			return(c_err);
		}//if (i_registered_dsm_size != pvExternalLinkageAnalyzers->at(ii)->v_true_linkage.size())
	}//for (int ii = 0; ii < pvExternalLinkageAnalyzers->size(); ii++)


	if (i_registered_dsm_size == 0)
	{
		c_err.vSetError(CLinkageAnalyzerSingleDSM::iERROR_CODE_LINKAGE_ANALYZER_DMS_ZERO_SIZE);
		return(c_err);
	}//if (pvExternalLinkageAnalyzers->size() < 1)


	vCreateDSMofSize(i_registered_dsm_size);


	SIntSort  s_sort;
	vector<int>  v_registered_values;
	double  d_median_ranking;

	for (int ix = 0; ix < i_registered_dsm_size; ix++)
	{
		for (int iy = 0; iy < i_registered_dsm_size; iy++)
		{
			v_registered_values.clear();
			for (int i_reg_dsm = 0; i_reg_dsm < pvExternalLinkageAnalyzers->size(); i_reg_dsm++)
			{
				v_registered_values.push_back((pvExternalLinkageAnalyzers->at(i_reg_dsm)->pcGetLinkageToShare()->pi_dsm_discretized)[ix][iy]);

				
				sort(v_registered_values.begin(), v_registered_values.end(), s_sort);

				if (v_registered_values.size() % 2 == 0)
				{
					d_median_ranking = v_registered_values.at(v_registered_values.size() / 2) + v_registered_values.at(v_registered_values.size() / 2 - 1);
					d_median_ranking = d_median_ranking / 2;
				}//if (v_registered_values.size() % 2 == 0)
				else
					d_median_ranking = v_registered_values.at(v_registered_values.size() / 2);


				pd_dsm[ix][iy] = d_median_ranking;
			}//for (int i_reg_dsm = 0; i_reg_dsm < pvExternalLinkageAnalyzers->size(); i_reg_dsm++)
		}//for (int iy = 0; iy < i_registered_dsm_size; iy++)
	}//for (int ix = 0; ix < i_registered_dsm_size; ix++)


	vRecomputeDiscretizedDSM();


	return(c_err);
}//int  CLinkageAnalyzerSingleDSM::iCreteJOINED_DSM(vector<CLinkageAnalyzer  *>  *pvExternalLinkageAnalyzers)





void  CLinkageAnalyzerSingleDSM::vSetP3Clusters(vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering)
{
	v_p3_clusters = *pvClusters;
	v_p3_cluster_ordering = *pvClusterOrdering;

	/*CString  s_buf;
	for (int ii = 0; ii < v_p3_cluster_ordering.size(); ii++)
	{
		s_buf.Format("%d\n", v_p3_clusters.at(v_p3_cluster_ordering.at(ii)).size());
		::Tools::vReportInFile("zzzzz_orig_clust.txt", s_buf);
	}//for (int ii = 0; ii < v_p3_clusters.size(); ii++)
	::Tools::vShow("vSetP3Clusters");*/


	//if (v_p3_clusters.size() > 0)  ::MessageBox(NULL, "ffff", "ffff", MB_OK);
}//void  CLinkageAnalyzerSingleDSM::vSetP3Clusters(vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering)



void  CLinkageAnalyzerSingleDSM::vSetClusters(vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering, bool  bAccumulateClusters, int iProblemSize, bool bRandomOrder)
{
	if (bAccumulateClusters == false)
	{
		v_p3_clusters = *pvClusters;
		v_p3_cluster_ordering = *pvClusterOrdering;
	}//if  (bAccumulateClusters == true)
	else
	{
		int  i_cluster_size;
		for (int i_cluster = 0; i_cluster < pvClusters->size(); i_cluster++)
		{
			i_cluster_size = pvClusters->at(i_cluster).size();
			if ((1 < i_cluster_size) && (i_cluster_size < iProblemSize))
				v_p3_clusters.push_back(pvClusters->at(i_cluster));
		}//for (int i_cluster = 0; i_cluster < clusters.size(); i_cluster++)
	}//else  if  (bAccumulateClusters == true)


	if (bRandomOrder == true)
	{
		//put all clusters in random order...
		vector<int>  v_ordering_buffer;
		for (int ii = 0; ii < v_p3_clusters.size(); ii++)
			v_ordering_buffer.push_back(ii);

		v_p3_cluster_ordering.clear();
		int  i_offset;
		while (v_ordering_buffer.size() > 0)
		{
			i_offset = RandUtils::iRandNumber(0, v_ordering_buffer.size() - 1);
			v_p3_cluster_ordering.push_back(v_ordering_buffer.at(i_offset));
			v_ordering_buffer.erase(v_ordering_buffer.begin() + i_offset);
		}//while (v_ordering_buffer.size() > 0)
	}//if  (bRandomOrder == true)
	else
	{
		for (int ii = 0; ii < v_p3_clusters.size(); ii++)
			v_p3_cluster_ordering.push_back(ii);
	}//else  if  (bRandomOrder == true)



	//if (v_p3_clusters.size() > 0)  ::MessageBox(NULL, "ffff", "ffff", MB_OK);
}//void  CLinkageAnalyzerSingleDSM::vSetP3Clusters(vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering)



void  CLinkageAnalyzerSingleDSM::vSetDSMGA2_DSM(TriMatrix<double> *pvDSM, int iDSM_size)
{
	if (pd_dsm == NULL)
	{
		vCreateDSMofSize(iDSM_size);
	}//if (pd_dsm == NULL)

	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			if (ix == iy)
				pd_dsm[ix][iy] = 0;
			else
			{
				if (ix < iy)
					pd_dsm[ix][iy] = 1.0 - (*pvDSM)(ix,iy);
				else
					pd_dsm[ix][iy] = 1.0 - (*pvDSM)(iy,ix);
			}//else if (ix == iy)
		}//for (int iy = 0; iy < i_dsm_size; iy++)
	}//for (int ix = 0; ix < i_dsm_size; ix++)
}//void  CLinkageAnalyzerSingleDSM::vSetDSMGA2_DSM(TriMatrix<double> *pvDSM, int iDSM_size)


void  CLinkageAnalyzerSingleDSM::vSetPerfectDSM(int  **piDSM, int iDSM_size)
{
	//for statistics...
	unordered_map<int, unordered_map<int, double> > uo_p3_dsm;

	CString  s_buf;
	bool  b_true_dependency_found;
	int  i_correct_genes;

	double  d_value;
	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		for (int i_second = 0; i_second < iDSM_size; i_second++)
		{
			if (i_first < i_second)
			{
				if (piDSM[i_first][i_second] > 0)
				{
					d_value = piDSM[i_first][i_second] + 1;
					//f_value = 2;
					d_value = d_value + RandUtils::dRandNumber(0, 0.5);
					d_value = 1.0 / d_value;
				}//if (piScrapDSM[i_first][i_second] > 0)
				else
					d_value = 0.6 + RandUtils::dRandNumber(0, 0.39);

				uo_p3_dsm[i_first][i_second] = d_value;
				//uo_p3_dsm[i_second][i_first] = f_value;
			}//if  (i_first > i_second)
		}//for (int i_second = 0; i_second < iDSM_size; i_second++)
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)



	//s_buf.Format("%d", uo_p3_dsm.size());
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);


	vSetP3DSM(&uo_p3_dsm);
}//void  CLinkageAnalyzerSingleDSM::vSetPerfectDSM(int  **piDSM, int iDSM_size)




void  CLinkageAnalyzerSingleDSM::vSetLtgaDSM(double  **pdDSM, int  iDSM_size)
{
	if (pd_dsm == NULL)
	{
		vCreateDSMofSize(iDSM_size);
	}//if (pd_dsm == NULL)

	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			if (ix == iy)
				pd_dsm[ix][iy] = 0;
			else
			{
				if (ix < iy)
					pd_dsm[ix][iy] = 1.0 - (pdDSM)[ix][iy];
				else
					pd_dsm[ix][iy] = 1.0 - (pdDSM)[iy][ix];
			}//else if (ix == iy)
		}//for (int iy = 0; iy < i_dsm_size; iy++)
	}//for (int ix = 0; ix < i_dsm_size; ix++)
}//void  CLinkageAnalyzerSingleDSM::vSetLtgaDSM(double  **pdDSM, int  iDSM_size)


void  CLinkageAnalyzerSingleDSM::vSetLinkDataPackDSM(double  **pdDSM, int  iDSM_size)
{
	if (pd_dsm == NULL)
	{
		vCreateDSMofSize(iDSM_size);
	}//if (pd_dsm == NULL)

	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			if (ix == iy)
				pd_dsm[ix][iy] = 0;
			else
			{
				if (ix < iy)
					pd_dsm[ix][iy] = (pdDSM)[ix][iy];
				else
					pd_dsm[ix][iy] = (pdDSM)[iy][ix];
			}//else if (ix == iy)
		}//for (int iy = 0; iy < i_dsm_size; iy++)
	}//for (int ix = 0; ix < i_dsm_size; ix++)
}//void  CLinkageAnalyzerSingleDSM::vSetLtgaDSM(double  **pdDSM, int  iDSM_size)



void  CLinkageAnalyzerSingleDSM::vComputeP3MapDSM(int  **piScrapDSM, int  iDSM_size, unordered_map<int, unordered_map<int, double> > *pc_uo_p3_dsm)
{
	CString  s_buf;
	bool  b_true_dependency_found;
	int  i_correct_genes;

	double  f_value;
	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		for (int i_second = 0; i_second < iDSM_size; i_second++)
		{
			if (i_first < i_second)
			{
				if (piScrapDSM[i_first][i_second] > 0)
				{
					f_value = piScrapDSM[i_first][i_second] + 1;
					f_value = f_value + RandUtils::dRandNumber(0, 0.5);
					f_value = 1.0 / f_value;
				}//if (piScrapDSM[i_first][i_second] > 0)
				else
					f_value = 0.6 + RandUtils::dRandNumber(0, 0.39);

				if (i_first / 10 == i_second / 10)
					f_value = 0.1 + RandUtils::dRandNumber(0, 0.2);
				else
					f_value = 0.6 + RandUtils::dRandNumber(0, 0.2);


				(*pc_uo_p3_dsm)[i_first][i_second] = f_value;
				(*pc_uo_p3_dsm)[i_second][i_first] = f_value;
			}//if  (i_first > i_second)
		}//for (int i_second = 0; i_second < iDSM_size; i_second++)
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)
}//void  CLinkageAnalyzerSingleDSM::vComputeP3MapDSM(int  **piScrapDSM, int  iDSM_size, unordered_map<int, unordered_map<int, double> > *pc_uo_p3_dsm)




void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_SLL_LTree(double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters)
{
	unordered_map<int, unordered_map<int, double> > uo_p3_dsm;

	CString  s_buf;
	bool  b_true_dependency_found;
	int  i_correct_genes;

	double  d_value;
	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		for (int i_second = 0; i_second < iDSM_size; i_second++)
		{
			if (i_first < i_second)
			{
				d_value = pdScrapDSM[i_first][i_second];
				uo_p3_dsm[i_first][i_second] = d_value;
				//uo_p3_dsm[i_second][i_first] = f_value;
			}//if  (i_first > i_second)
		}//for (int i_second = 0; i_second < iDSM_size; i_second++)
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)



	//s_buf.Format("%d", uo_p3_dsm.size());
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);


	vSetP3DSM(&uo_p3_dsm);

	vector<vector<int> > clusters;
	vector<int> cluster_ordering;


	vCreateP3Clusters(uo_p3_dsm, clusters, cluster_ordering);


	vSetClusters(&clusters, &cluster_ordering, bAccumulateClusters, iDSM_size);
}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_SLL(double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters)



void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_HLL_DLED_SLL_LTree(int  **piScrapDSM, double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters)
{
	unordered_map<int, unordered_map<int, double> > uo_p3_dsm;

	CString  s_buf;
	bool  b_true_dependency_found;
	int  i_correct_genes;

	double  f_value;
	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		for (int i_second = 0; i_second < iDSM_size; i_second++)
		{
			if (i_first < i_second)
			{
				if (piScrapDSM[i_first][i_second] > 0)
				{
					//f_value = piScrapDSM[i_first][i_second] + 1;
					f_value = 2;
					f_value = f_value + (1.0 - pdScrapDSM[i_first][i_second]);
					f_value = 1.0 / f_value;
				}//if (piScrapDSM[i_first][i_second] > 0)
				else
					f_value = 0.6 + (pdScrapDSM[i_first][i_second]) * 0.4;

				/*if (i_first / 10 == i_second / 10)
					f_value = 0.1 + RandUtils::dRandNumber(0, 0.2);
				else
					f_value = 0.6 + RandUtils::dRandNumber(0, 0.2);*/


				uo_p3_dsm[i_first][i_second] = f_value;
				//uo_p3_dsm[i_second][i_first] = f_value;
			}//if  (i_first > i_second)
		}//for (int i_second = 0; i_second < iDSM_size; i_second++)
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)



	//s_buf.Format("%d", uo_p3_dsm.size());
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);


	vSetP3DSM(&uo_p3_dsm);

	vector<vector<int> > clusters;
	vector<int> cluster_ordering;


	vCreateP3Clusters(uo_p3_dsm, clusters, cluster_ordering);


	vSetClusters(&clusters, &cluster_ordering, bAccumulateClusters, iDSM_size);
}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_HLL_DLED_SLL(int  **piScrapDSM, double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters)




void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DLED_LTree(int  **piScrapDSM, int  iDSM_size, bool bAccumulateClusters)
{
	unordered_map<int, unordered_map<int, double> > uo_p3_dsm;

	CString  s_buf;
	bool  b_true_dependency_found;
	int  i_correct_genes;

	double  f_value;
	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		for (int i_second = 0; i_second < iDSM_size; i_second++)
		{
			if (i_first < i_second)
			{
				if (piScrapDSM[i_first][i_second] > 0)
				{
					f_value = piScrapDSM[i_first][i_second] + 1;
					//f_value = 2;
					f_value = f_value + RandUtils::dRandNumber(0, 0.5);
					f_value = 1.0 / f_value;
				}//if (piScrapDSM[i_first][i_second] > 0)
				else
					f_value = 0.6 + RandUtils::dRandNumber(0, 0.39);

				uo_p3_dsm[i_first][i_second] = f_value;
				//uo_p3_dsm[i_second][i_first] = f_value;
			}//if  (i_first > i_second)
		}//for (int i_second = 0; i_second < iDSM_size; i_second++)
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)



	//s_buf.Format("%d", uo_p3_dsm.size());
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);


	vSetP3DSM(&uo_p3_dsm);

	vector<vector<int> > clusters;
	vector<int> cluster_ordering;


	vCreateP3Clusters(uo_p3_dsm, clusters, cluster_ordering);


	vSetClusters(&clusters, &cluster_ordering, bAccumulateClusters, iDSM_size);

}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage(int  **piScrapDSM, int  iDSM_size)



void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DLED_TightLinkageBlocks(int  **piScrapDSM, CEvaluation<CBinaryCoding> *pcEvaluation, CLog *pcLog)
{
	if (pc_tlb_superv == NULL)  pc_tlb_superv = new CTightLinkageBlockSupervisor(pcEvaluation, pcLog);


	vSetPerfectDSM(piScrapDSM, pcEvaluation->iGetNumberOfElements());//only for stats

	pc_tlb_superv->vBuildTLBs(piScrapDSM);

	vSetOutsideLinkage_DLED_RefreshTLB_Clusters(pcEvaluation);
}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DLED_TightLinkageBlocks(int  **piScrapDSM)


int   CLinkageAnalyzerSingleDSM::iGetDonorByTLB(vector<int>   *pvCluster, char *pcSourceInd, char	**pcLTGApopulation, int  iPopSize)
{
	if (pc_tlb_superv == NULL)  return(-1);
	return(pc_tlb_superv->iGetDonorByTLB(pvCluster, pcSourceInd, pcLTGApopulation, iPopSize));
}//int   CLinkageAnalyzerSingleDSM::iGetDonorByTLB(vector<int>   *pvCluster, char	**pcLTGApopulation, int  iPopSize)


void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DLED_RefreshTLB_Clusters(CEvaluation<CBinaryCoding> *pcEvaluation)
{
	if (pc_tlb_superv == NULL)  return;

	vector<vector<int> > clusters;
	vector<int> cluster_ordering;

	pc_tlb_superv->vCreateTLB_Clusters(&clusters, &cluster_ordering);
	//pc_tlb_superv->vSaveTLBs("zzzz_tlb.txt", &clusters);
	//::MessageBox(NULL, "void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DLED_TightLinkageBlocks", "void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DLED_TightLinkageBlocks", MB_OK);

	vSetClusters(&clusters, &cluster_ordering, false, pcEvaluation->iGetNumberOfElements(), false);
}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DLED_RefreshTLB_Clusters()



void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_SLL(double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters)
{
	unordered_map<int, unordered_map<int, double> > uo_p3_dsm;

	CString  s_buf;
	bool  b_true_dependency_found;
	int  i_correct_genes;

	double  f_value;
	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		for (int i_second = 0; i_second < iDSM_size; i_second++)
		{
			if (i_first < i_second)
			{
				f_value = pdScrapDSM[i_first][i_second];
				uo_p3_dsm[i_first][i_second] = f_value;
				//uo_p3_dsm[i_second][i_first] = f_value;
			}//if  (i_first > i_second)
		}//for (int i_second = 0; i_second < iDSM_size; i_second++)
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)



	//s_buf.Format("%d", uo_p3_dsm.size());
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);


	vSetP3DSM(&uo_p3_dsm);

	vector<vector<int> > clusters;
	vector<int> cluster_ordering;


	vCreateP3Clusters(uo_p3_dsm, clusters, cluster_ordering);


	vSetClusters(&clusters, &cluster_ordering, bAccumulateClusters, iDSM_size);
}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_SLL(double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters)



void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_HLL_DLED_SLL(int  **piScrapDSM, double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters)
{
	unordered_map<int, unordered_map<int, double> > uo_p3_dsm;

	CString  s_buf;
	bool  b_true_dependency_found;
	int  i_correct_genes;

	double  f_value;
	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		for (int i_second = 0; i_second < iDSM_size; i_second++)
		{
			if (i_first < i_second)
			{
				if (piScrapDSM[i_first][i_second] > 0)
				{
					//f_value = piScrapDSM[i_first][i_second] + 1;
					f_value = 2;
					f_value = f_value + (1.0 - pdScrapDSM[i_first][i_second]);
					f_value = 1.0 / f_value;
				}//if (piScrapDSM[i_first][i_second] > 0)
				else
					f_value = 0.6 + (pdScrapDSM[i_first][i_second]) * 0.4;

				/*if (i_first / 10 == i_second / 10)
					f_value = 0.1 + RandUtils::dRandNumber(0, 0.2);
				else
					f_value = 0.6 + RandUtils::dRandNumber(0, 0.2);*/


				uo_p3_dsm[i_first][i_second] = f_value;
				//uo_p3_dsm[i_second][i_first] = f_value;
			}//if  (i_first > i_second)
		}//for (int i_second = 0; i_second < iDSM_size; i_second++)
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)



	//s_buf.Format("%d", uo_p3_dsm.size());
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);


	vSetP3DSM(&uo_p3_dsm);

	vector<vector<int> > clusters;
	vector<int> cluster_ordering;


	vCreateP3Clusters(uo_p3_dsm, clusters, cluster_ordering);


	vSetClusters(&clusters, &cluster_ordering, bAccumulateClusters, iDSM_size);
}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_HLL_DLED_SLL(int  **piScrapDSM, double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters)




void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DLED(int  **piScrapDSM, int  iDSM_size, bool bAccumulateClusters)
{
	unordered_map<int, unordered_map<int, double> > uo_p3_dsm;

	CString  s_buf;
	bool  b_true_dependency_found;
	int  i_correct_genes;

	double  f_value;
	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		for (int i_second = 0; i_second < iDSM_size; i_second++)
		{
			if (i_first < i_second)
			{
				if (piScrapDSM[i_first][i_second] > 0)
				{
					f_value = piScrapDSM[i_first][i_second] + 1;
					//f_value = 2;
					f_value = f_value + RandUtils::dRandNumber(0, 0.5);
					f_value = 1.0 / f_value;
				}//if (piScrapDSM[i_first][i_second] > 0)
				else
					f_value = 0.6 + RandUtils::dRandNumber(0, 0.39);

				/*if (i_first / 10 == i_second / 10)
					f_value = 0.1 + RandUtils::dRandNumber(0, 0.2);
				else
					f_value = 0.6 + RandUtils::dRandNumber(0, 0.2);*/

				
				uo_p3_dsm[i_first][i_second] = f_value;
				//uo_p3_dsm[i_second][i_first] = f_value;
			}//if  (i_first > i_second)
		}//for (int i_second = 0; i_second < iDSM_size; i_second++)
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)


	
	//s_buf.Format("%d", uo_p3_dsm.size());
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);


	vSetP3DSM(&uo_p3_dsm);

	vector<vector<int> > clusters;
	vector<int> cluster_ordering;


	vCreateP3Clusters(uo_p3_dsm, clusters, cluster_ordering);
	

	vSetClusters(&clusters, &cluster_ordering, bAccumulateClusters, iDSM_size);
	
}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage(int  **piScrapDSM, int  iDSM_size)




void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DirectionalNodes(vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, int  iDSM_size, bool bAccumulateClusters)
{
	vector <int> v_cluster_current;
	vector<vector<int> > v_clusters;
	vector<int> v_cluster_ordering;

	int  i_cluster_order = 0;
	for (int i_node = 0; i_node < pvDirectionalNodes->size(); i_node++)
	{
		v_cluster_current = *(pvDirectionalNodes->at(i_node)->pvGetGenes());
		v_clusters.push_back(v_cluster_current);
		v_cluster_ordering.push_back(i_cluster_order);
		i_cluster_order++;

		if (pvDirectionalNodes->at(i_node)->pvGetGenesExtended()->size() > 0)
		{
			for (int ii = 0; ii < pvDirectionalNodes->at(i_node)->pvGetGenesExtended()->size(); ii++)
				v_cluster_current.push_back(pvDirectionalNodes->at(i_node)->pvGetGenesExtended()->at(ii));

			v_clusters.push_back(v_cluster_current);
			v_cluster_ordering.push_back(i_cluster_order);
			i_cluster_order++;
		}//if (pvDirectionalNodes->at(i_node)->pvGetGenesExtended()->size() > 0)
		
	}//for (int ii = 0; ii < pvDirectionalNodes->size(); ii++)

	vSetClusters(&v_clusters, &v_cluster_ordering, bAccumulateClusters, iDSM_size);

}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage_DirectionalNodes(vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, int  iDSM_size, bool bAccumulateClusters)





void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage(int  iDSM_size)
{
	unordered_map<int, unordered_map<int, double> > uo_p3_dsm;

	CString  s_buf;
	bool  b_true_dependency_found;
	int  i_correct_genes;

	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		for (int i_second = 0; i_second < iDSM_size; i_second++)
		{
			if (i_first < i_second)
			{
				uo_p3_dsm[i_first][i_second] = 0.6 + RandUtils::dRandNumber(0, 0.4);
			}//if  (i_first > i_second)
		}//for (int i_second = 0; i_second < iDSM_size; i_second++)
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)


	
	int  i_truly_dependent;
	for (int i_first = 0; i_first < iDSM_size; i_first++)
	{
		i_correct_genes = 0;
		for (int i_dsm_dependent_gene_offset = 0; i_dsm_dependent_gene_offset < pc_parent->v_true_linkage.at(i_first).size(); i_dsm_dependent_gene_offset++)
		{
			i_truly_dependent = pc_parent->v_true_linkage.at(i_first).at(i_dsm_dependent_gene_offset);

			if (i_first < i_truly_dependent)
			{
				if  (RandUtils::dRandNumber(0, 1) < this->pc_parent->d_outside_linkage_quality)
					uo_p3_dsm[i_first][i_truly_dependent] = RandUtils::dRandNumber(0, 0.4);
				else
					uo_p3_dsm[i_first][i_truly_dependent] = 0.6 + RandUtils::dRandNumber(0, 0.4);
			}//if (i_first < i_truly_dependent)
		}//for (int i_dsm_dependent_gene_offset = 0; i_dsm_dependent_gene_offset < pc_parent->v_true_linkage.at(i_first).size(); i_dsm_dependent_gene_offset++)

		//s_buf.Format("%.2lf", this->pc_parent->d_outside_linkage_quality);
		//::MessageBox(NULL, s_buf, s_buf, MB_OK);
	}//for (int i_first = 0; i_first < iDSM_size; i_first++)


	//s_buf.Format("%d", uo_p3_dsm.size());
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);

	
	vSetP3DSM(&uo_p3_dsm);

	vector<vector<int> > clusters;
	vector<int> cluster_ordering;


	vCreateP3Clusters(uo_p3_dsm, clusters, cluster_ordering);



	vSetP3Clusters(&clusters, &cluster_ordering);
}//void  CLinkageAnalyzerSingleDSM::vSetOutsideLinkage(int  iDSM_size)





double CLinkageAnalyzerSingleDSM::get_distance_p3(int x, int y, unordered_map<int, unordered_map<int, double> > &uoP3Dsm)
{
	if (x > y) {
		std::swap(x, y);
	}
	return uoP3Dsm[x][y];
}//double CLinkageAnalyzerSingleDSM::get_distance_p3(int x, int y, unordered_map<int, unordered_map<int, double> > &uoP3Dsm)


double CLinkageAnalyzerSingleDSM::round_double_p3(double value, int precision)
{
	return round(value * precision) / precision;
}//double CLinkageAnalyzerSingleDSM::round_double_p3(double value, int precision) {



void CLinkageAnalyzerSingleDSM::ordering_p3_smallest_first
	(const vector<vector<int>>& clusters,	vector<int>& cluster_ordering) 
{
	// NOTE: My previous work did not shuffle here
	//std::shuffle(cluster_ordering.begin(), cluster_ordering.end(), rand);
	std::stable_sort(
		cluster_ordering.begin(),
		cluster_ordering.end(),
		[clusters](int x, int y) {return clusters[x].size() < clusters[y].size(); });
}//void CLinkageAnalyzerSingleDSM::ordering_p3_smallest_first



void CLinkageAnalyzerSingleDSM::vCreateP3Clusters(unordered_map<int, unordered_map<int, double> > &uoP3Dsm, vector<vector<int> > &clusters, vector<int> &cluster_ordering)
{
	int  length = uoP3Dsm.size() + 1;
	int  precision = 65535;
	bool keep_zeros = false;
	bool no_singles = false;

	//initialize
	clusters.resize(2 * length - 1);
	cluster_ordering.resize(clusters.size());
	// first "length" clusters just contain a single gene
	for (size_t i = 0; i < length; i++) {
		clusters[i].push_back(i);
	}
	// initially the ordering is just to use the clusters in numeric order
	for (size_t i = 0; i < cluster_ordering.size(); i++) {
		cluster_ordering[i] = i;
	}

	
	// usable keeps track of which clusters can still be merged
	vector<size_t> usable(length);
	// initialize it to just the clusters of size 1
	std::iota(usable.begin(), usable.end(), 0);
	// useful keeps track of clusters that should be used by crossover
	vector<bool> useful(clusters.size(), true);
	// Shuffle the single variable clusters
	//shuffle(clusters.begin(), clusters.begin() + length, rand);
	std::random_shuffle(clusters.begin(), clusters.begin() + length);

	// keeps track of the distances between clusters
	vector<vector<double> > distances(clusters.size(),
		vector<double>(clusters.size(), -1));

	// Find the initial distances between the clusters
	for (size_t i = 0; i < length - 1; i++) {
		for (size_t j = i + 1; j < length; j++) {
			distances[i][j] = get_distance_p3(clusters[i][0], clusters[j][0], uoP3Dsm);
			// make it symmetric
			distances[j][i] = distances[i][j];
		}
	}

	size_t first, second;
	size_t final, best_index;
	// Each iteration we add some amount to the path, and remove the last
	// two elements.  This keeps track of how much of usable is in the path.
	size_t end_of_path = 0;
	
	// rebuild all clusters after the single variable clusters
	for (size_t index = length; index < clusters.size(); index++) {
		// Shuffle everything not yet in the path
		//std::shuffle(usable.begin() + end_of_path, usable.end(), rand);
		std::random_shuffle(usable.begin() + end_of_path, usable.end());

		// if nothing in the path, just add a random usable node
		if (end_of_path == 0) {
			end_of_path++;
		}

		while (end_of_path < usable.size()) {
			// last node in the path
			final = usable[end_of_path - 1];

			// best_index stores the location of the best thing in usable
			best_index = end_of_path;
			double min_dist = distances[final][usable[best_index]];
			// check all options which might be closer to "final" than "usable[best_index]"
			for (size_t option = end_of_path + 1; option < usable.size(); option++) {
				if (distances[final][usable[option]] < min_dist) {
					min_dist = distances[final][usable[option]];
					best_index = option;
				}
			}

			// If the current last two in the path are minimally distant
			if (end_of_path > 1
				&& min_dist >= distances[final][usable[end_of_path - 2]]) {
				break;
			}

			// move the best to the end of the path
			swap(usable[end_of_path], usable[best_index]);
			end_of_path++;
		}
		
		// Last two elements in the path are the clusters to join
		first = usable[end_of_path - 2];
		second = usable[end_of_path - 1];

		// If the distance between the joining clusters is zero, only keep them
		// if configured to do so
		if (round_double_p3(distances[first][second], precision) == 0) {
			useful[first] = keep_zeros;
			useful[second] = keep_zeros;
		}
		
		// Remove things from the path
		end_of_path -= 2;

		// create new cluster
		clusters[index] = clusters[first];
		// merge the two clusters
		clusters[index].insert(clusters[index].end(), clusters[second].begin(),
			clusters[second].end());

		// Calculate distances from all clusters to the newly created cluster
		int i = 0;
		int end = usable.size() - 1;
		while (i <= end) {
			auto x = usable[i];
			// Removes 'first' and 'second' from usable
			if (x == first || x == second) {
				swap(usable[i], usable[end]);
				end--;
				continue;
			}
			// Use the previous distances to calculate the joined distance
			double first_distance = distances[first][x];
			first_distance *= clusters[first].size();
			double second_distance = distances[second][x];
			second_distance *= clusters[second].size();
			distances[x][index] = ((first_distance + second_distance)
				/ (clusters[first].size() + clusters[second].size()));
			// make it symmetric
			distances[index][x] = distances[x][index];
			i++;
		}
		// Shorten usable by 1, insert the new cluster
		usable.pop_back();
		usable.back() = index;
	}
	
	// Now that we know what clusters exist, determine their ordering
	cluster_ordering.resize(clusters.size());
	std::iota(cluster_ordering.begin(), cluster_ordering.end(), 0);
	if (no_singles) {
		// marks all clusters of size 1 as not useful
		for (size_t i = 0; i < length; i++) {
			useful[i] = false;
		}
	}

	// The last cluster contains all variables and is always useless
	useful.back() = false;

	// remove not useful clusters
	size_t kept = 0;
	for (size_t i = 0; i < cluster_ordering.size(); i++) {
		if (useful[cluster_ordering[i]]) {
			swap(cluster_ordering[i], cluster_ordering[kept]);
			kept++;
		}
	}
	cluster_ordering.resize(kept);

	// Applies the desired ordering to the clusters
	ordering_p3_smallest_first(clusters, cluster_ordering);
}//void CLinkageAnalyzerSingleDSM::vCreateP3Clusters(unordered_map<int, unordered_map<int, double> > &uoP3Dsm, vector<vector<int> > &clusters, vector<int> &cluster_ordering, Random *pcRand)




void  CLinkageAnalyzerSingleDSM::vSetP3DSM(unordered_map<int, unordered_map<int, double> > *pcDSM)
{
	//pairwise_distance[i][j] = ratio;
	CString  s_buf;

	if (pd_dsm == NULL)
	{
		vCreateDSMofSize(pcDSM->size() + 1);
		
		/*pd_dsm = new double*[i_dsm_size];
		for (int ii = 0; ii < i_dsm_size; ii++)
			pd_dsm[ii] = new double[i_dsm_size];

		pi_dsm_discretized = new int*[i_dsm_size];
		for (int ii = 0; ii < i_dsm_size; ii++)
			pi_dsm_discretized[ii] = new int[i_dsm_size];

		pi_dsm_discretized_ranking = new int*[i_dsm_size];
		for (int ii = 0; ii < i_dsm_size; ii++)
			pi_dsm_discretized_ranking[ii] = new int[i_dsm_size];*/
	}//if (pd_dsm == NULL)



	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			if (ix == iy)
				pd_dsm[ix][iy] = 0;
			else
			{
				if (ix < iy)
					pd_dsm[ix][iy] = (*pcDSM)[ix][iy];
				else
					pd_dsm[ix][iy] = (*pcDSM)[iy][ix];
			}//else if (ix == iy)
		}//for (int iy = 0; iy < i_dsm_size; iy++)
	}//for (int ix = 0; ix < i_dsm_size; ix++)
}//void  CLinkageAnalyzerSingleDSM::vGetP3DSM(unordered_map<int, unordered_map<int, double> > *pcDSM)




void  CLinkageAnalyzerSingleDSM::vRecomputeDSM_PairingRankings()
{
	CString  s_buf;
	//we ignore the first most dependent ranking, because each index points to itself...


	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			if  (ix == iy)
				pd_dsm[ix][iy] = 0;
			else
				pd_dsm[ix][iy] = i_dsm_size + 2;
		}//for (int iy = 0; iy < i_dsm_size; iy++)
	}//for (int ix = 0; ix < i_dsm_size; ix++)

	int  i_check_up_with_gene;
	bool  b_found;


	v_strict_dependent_pairs.clear();
	CLinkageAnalyzerDependentPair  c_dependent_pair;

	for (int i_range = 0; i_range < i_dsm_size-1; i_range++)
	//for (int i_range = 0; i_range < 2; i_range++)
	{
		for (int ix = 0; ix < i_dsm_size; ix++)		
		{
			i_check_up_with_gene = pi_dsm_discretized_ranking[ix][1 + i_range];
			b_found = false;

			for (int i_ranking_offset = 1; (i_ranking_offset < 1 + i_range + 1)&&(b_found == false); i_ranking_offset++)
			{
				if (pi_dsm_discretized_ranking[i_check_up_with_gene][i_ranking_offset] == ix)
				{
					b_found = true;
					pd_dsm[ix][i_check_up_with_gene] = i_range + 1;
					pd_dsm[i_check_up_with_gene][ix] = i_range + 1;

					c_dependent_pair.iFirstGene = ix;
					c_dependent_pair.iSecondGene = i_check_up_with_gene;
					c_dependent_pair.d_dependency = i_range + 1;
					
					c_dependent_pair.bDependencyTrue = b_check_if_dependency_is_true(ix, i_check_up_with_gene);

					v_strict_dependent_pairs.push_back(c_dependent_pair);

					//s_buf.Format("%d + %d\n", ix, i_check_up_with_gene);
					//vDebugLog(s_buf);
				}//if (pi_dsm_discretized_ranking[i_check_up_with_gene][i_ranking_offset] == i_check_up_with_gene)
			}//for (int i_ranking_offset = 1; (i_ranking_offset < 1 + i_range + 1)&&(b_found == false); i_ranking_offset++)

		}//for (int i_range = 0; i_range < i_dsm_size - 1; i_range++)
		
	}//for (int ix = 0; ix < i_dsm_size; ix++)

}//void  CLinkageAnalyzerSingleDSM::vRecomputeDSM_PairingRankings()



void  CLinkageAnalyzerSingleDSM::vGetReproducedDSM_P3(unordered_map<int, unordered_map<int, double> > *pcDestination)
{
	int i_first, i_second;

	for (int ii = 0; ii < v_strict_dependent_pairs.size(); ii++)
	{
		if (v_strict_dependent_pairs.at(ii).iFirstGene < v_strict_dependent_pairs.at(ii).iSecondGene)
		{
			i_first = v_strict_dependent_pairs.at(ii).iFirstGene;
			i_second = v_strict_dependent_pairs.at(ii).iSecondGene;
		}//if (v_strict_dependent_pairs.at(ii).iFirstGene < v_strict_dependent_pairs.at(ii).iSecondGene)
		else
		{
			i_first = v_strict_dependent_pairs.at(ii).iSecondGene;
			i_second = v_strict_dependent_pairs.at(ii).iFirstGene;
		}//else  if (v_strict_dependent_pairs.at(ii).iFirstGene < v_strict_dependent_pairs.at(ii).iSecondGene)

		(*pcDestination)[i_first][i_second] = 0;
	}//for (int ii = 0; ii < v_strict_dependent_pairs.size(); ii++)

	
}//void  CLinkageAnalyzerSingleDSM::vGetReproducedDSM_P3(unordered_map<int, unordered_map<int, double> > *pcDestination)



void  CLinkageAnalyzerSingleDSM::vRecomputeDiscretizedDSM()
{
	vector<int>  v_indexes;

	for (int ii = 0; ii < i_dsm_size; ii++)
		v_indexes.push_back(ii);


	/*FILE  *pf_dest;
	CString  s_line, s_buf;
	pf_dest = fopen("___test.txt", "w+");
	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		s_line = "";

		s_buf.Format("%08d", ix);
		s_line += s_buf + "\t";

		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			s_buf.Format("%.8lf", pd_dsm[ix][iy]);
			s_line += s_buf + "\t";
		}//for (int iy = 0; iy < i_dsm_size; iy++)

		fprintf(pf_dest, s_line + "\n");
	}//for (int ix = 0; ix < i_dsm_size; ix++)
	fclose(pf_dest);
	::MessageBox(NULL, "a", "a", MB_OK);//*/

	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		
		SDSMSort  s_sort;
		s_sort.pd_dsm = pd_dsm;
		s_sort.ix = ix;
		sort(v_indexes.begin(), v_indexes.end(), s_sort);


		for (int ii = 0; ii < i_dsm_size; ii++)
			pi_dsm_discretized[ix][v_indexes.at(ii)] = ii;

		for (int ii = 0; ii < i_dsm_size; ii++)
			pi_dsm_discretized_ranking[ix][ii] = v_indexes.at(ii);

		
	}//for (int ix = 0; ix < i_dsm_size; ix++)

}//void  CLinkageAnalyzerSingleDSM::v_recompute_discretized_dsm()



void  CLinkageAnalyzerSingleDSM::v_get_base_stats(vector<double> *pvData, double  *pdAvr, double  *pdMedian, double *pdMin, double *pdMax)
{
	*pdAvr = -1;
	*pdMedian = -1;
	*pdMin = -1;
	*pdMax = -1;

	if (pvData->size() < 1)  return;

	SDoubleSort  s_sort;
	sort(pvData->begin(), pvData->end(), s_sort);


	*pdAvr = 0;
	*pdMin = pvData->at(0);
	*pdMax = pvData->at(0);

	for (int ii = 0; ii < pvData->size(); ii++)
	{
		*pdAvr += pvData->at(ii);
		if (*pdMin > pvData->at(ii))  *pdMin = pvData->at(ii);
		if (*pdMax < pvData->at(ii))  *pdMax = pvData->at(ii);
	}//for (int ii = 0; ii < pvData->size(); ii++)

	*pdAvr = *pdAvr / pvData->size();

	if (pvData->size() % 2 == 0)
	{
		*pdMedian = pvData->at(pvData->size() / 2) + pvData->at(pvData->size() / 2 - 1);
		*pdMedian = *pdMedian / 2;
	}//if (pvData->size() % 2 == 0)
	else
		*pdMedian = pvData->at(pvData->size() / 2);


	if (LINKAGE_ANALYZER_DEBUG)
	{
		CString  s_buf;
		s_buf.Format("Med: %.8lf  Avr: %.8lf Min: %.8lf Max: %.8lf \n", *pdMedian, *pdAvr, *pdMin, *pdMax);
		vDebugLog(s_buf);

		CString  s_line;

		for (int ii = 0; ii < pvData->size(); ii++)
		{
			s_buf.Format("%.4lf, ", pvData->at(ii));
			s_line += s_buf;
		}//for (int ii = 0; ii < pvData->size(); ii++)
		
		vDebugLog(s_line);
		vShow(0);
	}//if (LINKAGE_ANALYZER_DEBUG)

	return;
}//void  CLinkageAnalyzerSingleDSM::v_get_base_stats(vector<double> *pvdata, double  *pdAvr, double  *pdMedian, double *pdMin, double *pdMax)



void  CLinkageAnalyzerSingleDSM::vReportLinkQualityPerfectBlockLengthOverhead(double  *pdAvr, double  *pdMedian, double *pdMin, double *pdMax)
{
	vector<double>  v_detailed_results;

	for (int ii = 0; ii < i_dsm_size; ii++)
		v_detailed_results.push_back(dLinkQuality_PerfectBlockLengthOverhead(ii));


	double  d_avr, d_median, d_min, d_max;
	v_get_base_stats(&v_detailed_results, &d_avr, &d_median, &d_min, &d_max);

	/*if (d_min < 0)
	{
		CString  s_buf;

		for (int ii = 0; ii < v_detailed_results.size(); ii++)
		{
			s_buf.Format("%lf", v_detailed_results.at(ii));
			vDebugLog(s_buf);
		}//for (int ii = 0; ii < v_detailed_results.size(); ii++)
		
		vShow(i_dsm_size);
	}//if (d_min < 0)*/


	*pdAvr = d_avr;
	*pdMedian = d_median;
	*pdMin = d_min;
	*pdMax = d_max;
}//void  CLinkageAnalyzerSingleDSM::vReportLinkQualityPerfectBlockLengthOverhead(double  *pdAvr, double  *pdMedian, double *pdMin, double *pdMax)



void  CLinkageAnalyzerSingleDSM::vReportLinkQualityPerfectBlocksFound(vector<double>  *pvFillReport, vector<CSeparableBlockDetection *>  *pvFullBlocksDetected)
{
	CString  s_buf;

	//first get the full blocks
	pvFullBlocksDetected->clear();


	int  i_block_gene_first, i_block_gene_last;
	bool  b_at_least_one_full_detection;
	double  d_block_detection;
	int  i_full_detections;

	for (int i_gene = 0; i_gene < pc_parent->v_true_linkage.size(); i_gene++)
	{
		i_block_gene_first = i_gene;
		i_block_gene_last = i_gene;
		for (int i_true_link_gene_offset = 0; i_true_link_gene_offset < pc_parent->v_true_linkage.at(i_gene).size(); i_true_link_gene_offset++)
		{
			if (i_block_gene_last < pc_parent->v_true_linkage.at(i_gene).at(i_true_link_gene_offset))
				i_block_gene_last = pc_parent->v_true_linkage.at(i_gene).at(i_true_link_gene_offset);

			if (i_block_gene_first > pc_parent->v_true_linkage.at(i_gene).at(i_true_link_gene_offset))
				i_block_gene_first = pc_parent->v_true_linkage.at(i_gene).at(i_true_link_gene_offset);
		}//for (int i_true_link_gene_offset = 0; i_true_link_gene_offset < pc_parent->v_true_linkage.at(i_block_gene_first).size(); i_true_link_gene_offset++)


		d_block_detection = 0;
		i_full_detections = 0;

		for (int ii = i_block_gene_first; ii < i_block_gene_last + 1; ii++)
		{
			d_block_detection += pvFillReport->at(ii);
			if (pvFillReport->at(ii) == 1)  i_full_detections++;
		}//for (int ii = i_block_gene_first; ii < i_block_gene_last + 1; ii++)

		d_block_detection = d_block_detection / (i_block_gene_last - i_block_gene_first + 1);
		
		CSeparableBlockDetection  *pc_block_detection_report;
		pc_block_detection_report = new CSeparableBlockDetection();

		pc_block_detection_report->i_gene_first = i_block_gene_first;
		pc_block_detection_report->i_gene_last = i_block_gene_last;
		pc_block_detection_report->d_detection_fill_avr = d_block_detection;
		pc_block_detection_report->i_part_detections = i_full_detections;


		pvFullBlocksDetected->push_back(pc_block_detection_report);

		//s_buf.Format("Start: %d  End: %d  Detection: %.2lf  FullDetections: %d", i_block_gene_first, i_block_gene_last, d_block_detection, i_full_detections);
		//vDebugLog(s_buf);

		i_gene = i_block_gene_last;
	}//for (int i_gene = 0; i_gene < pc_parent->v_true_linkage.size(); i_gene++)


	//::MessageBox(NULL, "aa", "aa", MB_OK);
}//void  CLinkageAnalyzerSingleDSM::vReportLinkQualityPerfectBlocksFound(int *piFull, int *piPartially, int  *piNone)


void  CLinkageAnalyzerSingleDSM::vReportLinkQualityPerfectBlockLengthFill(double  *pdAvr, double  *pdMedian, double *pdMin, double *pdMax)
{
	vector<double>  v_detailed_results;

	for (int ii = 0; ii < i_dsm_size; ii++)
		v_detailed_results.push_back(dLinkQuality_PerfectBlockLengthFill(ii));


	vReportLinkQualityPerfectBlocksFound(&v_detailed_results, &v_full_blocks_detection);//must be done BEFORE v_get_base_stats, because it sorts v_detailed_results to get median...

	double  d_avr, d_median, d_min, d_max;
	v_get_base_stats(&v_detailed_results, &d_avr, &d_median, &d_min, &d_max);

	*pdAvr = d_avr;
	*pdMedian = d_median;
	*pdMin = d_min;
	*pdMax = d_max;


	

}//void  CLinkageAnalyzerSingleDSM::vReportLinkQualityPerfectBlockLengthFill(double  *pdAvr, double  *pdMedian, double *pdMin, double *pdMax)



double  CLinkageAnalyzerSingleDSM::dLinkQuality_PerfectBlockLengthOverhead(int iGeneIndex, int *piFurthestGene)
{
	CString  s_buf;
	int  i_perfect_block_length;

	if (iGeneIndex >= pc_parent->v_true_linkage.size())  return(-1);


	int  i_furtherst_true_linkage_element;
	int  i_true_link_dependent_gene;
	bool  b_distance_found;	

	s_buf.Format("LINKAGE FOR GENE INDEX: %d", iGeneIndex);
	if  (LINKAGE_ANALYZER_DEBUG)  vDebugLog(s_buf);

	i_furtherst_true_linkage_element = 0;
	for (int i_true_link_gene_offset = 0; i_true_link_gene_offset < pc_parent->v_true_linkage.at(iGeneIndex).size(); i_true_link_gene_offset++)
	{
		i_true_link_dependent_gene = pc_parent->v_true_linkage.at(iGeneIndex).at(i_true_link_gene_offset);
		s_buf.Format("TRUE DEPENDENT GENE: %d", i_true_link_dependent_gene);
		if (LINKAGE_ANALYZER_DEBUG)  vDebugLog(s_buf);

		b_distance_found = false;
		for (int i_disc_dsm_offset = 0; (i_disc_dsm_offset < i_dsm_size)&&(b_distance_found == false); i_disc_dsm_offset++)
		{
			if (pi_dsm_discretized_ranking[iGeneIndex][i_disc_dsm_offset] == i_true_link_dependent_gene)
			{
				b_distance_found = true;

				//s_buf.Format("found at offset: %d", i_disc_dsm_offset);
				//vDebugLog(s_buf);

				if (i_furtherst_true_linkage_element < i_disc_dsm_offset)
				{
					i_furtherst_true_linkage_element = i_disc_dsm_offset;
					if (piFurthestGene != NULL)  *piFurthestGene = i_true_link_dependent_gene;
				}//if (i_furtherst_true_linkage_element < i_disc_dsm_offset)
			}//if (pi_dsm_discretized_ranking[iGeneIndex][i_disc_dsm_offset] == i_true_link_dependent_gene)
		}//for (int i_disc_dsm_offset = 0; (i_disc_dsm_offset < i_dsm_size)&&(b_distance_found == false); i_disc_dsm_offset++)

		if (b_distance_found == false)
		{
			s_buf.Format("NOT FOUND");
			if (LINKAGE_ANALYZER_DEBUG)  vDebugLog(s_buf);

			if  (piFurthestGene != NULL)  *piFurthestGene = i_true_link_dependent_gene;
			return(-2);
		}//if (b_distance_found == false)
		
	}//for (int i_true_link_gene_offset = 0; i_true_link_gene_offset < v_true_linkage.at(iGeneIndex).size(); i_true_link_gene_offset++)


	s_buf.Format("LinkSize: %d", pc_parent->v_true_linkage.at(iGeneIndex).size());
	if (LINKAGE_ANALYZER_DEBUG)  vDebugLog(s_buf);
	s_buf.Format("FurhtestElement: %d", i_furtherst_true_linkage_element);
	if (LINKAGE_ANALYZER_DEBUG)  vDebugLog(s_buf);
	
	double  d_result;
	d_result = i_furtherst_true_linkage_element - pc_parent->v_true_linkage.at(iGeneIndex).size() + 1;
	s_buf.Format("RESULT: %lf\n\n", d_result);
	if (LINKAGE_ANALYZER_DEBUG)  vDebugLog(s_buf);

	return(d_result);
}//double  CLinkageAnalyzerSingleDSM::dLinkQuality_PerfectBlockLengthOverhead(int iGeneIndex)



double  CLinkageAnalyzerSingleDSM::dLinkQuality_PerfectBlockLengthFill(int iGeneIndex)
{
	CString  s_buf;
	int  i_perfect_block_length;

	if (iGeneIndex >= pc_parent->v_true_linkage.size())  return(-1);


	int  i_correct_genes;
	int  i_dsm_dependent_gene;
	bool  b_true_dependency_found;

	//s_buf.Format("LINKAGE FOR GENE INDEX: %d", iGeneIndex);
	//vDebugLog(s_buf);

	i_correct_genes = 0;
	for (int i_dsm_dependent_gene_offset = 0; i_dsm_dependent_gene_offset < pc_parent->v_true_linkage.at(iGeneIndex).size(); i_dsm_dependent_gene_offset++)
	{
		i_dsm_dependent_gene = pi_dsm_discretized_ranking[iGeneIndex][i_dsm_dependent_gene_offset];

		if (i_dsm_dependent_gene != iGeneIndex)
		{
			//s_buf.Format("TRUE DEPENDENT GENE: %d", i_true_link_dependent_gene);
			//vDebugLog(s_buf);

			b_true_dependency_found = false;
			for (int i_true_link_gene_offset = 0; (i_true_link_gene_offset < pc_parent->v_true_linkage.at(iGeneIndex).size()) && (b_true_dependency_found == false); i_true_link_gene_offset++)
			{
				if (i_dsm_dependent_gene == pc_parent->v_true_linkage.at(iGeneIndex).at(i_true_link_gene_offset))
				{
					b_true_dependency_found = true;
					i_correct_genes++;
				}//if (pi_dsm_discretized_ranking[iGeneIndex][i_disc_dsm_offset] == i_true_link_dependent_gene)
			}//for (int i_disc_dsm_offset = 0; (i_disc_dsm_offset < i_dsm_size)&&(b_distance_found == false); i_disc_dsm_offset++)
		}//if  (i_dsm_dependent_gene  != iGeneIndex)

	}//for (int i_true_link_gene_offset = 0; i_true_link_gene_offset < v_true_linkage.at(iGeneIndex).size(); i_true_link_gene_offset++)


	double  d_perf_block_fill_up;

	if (pc_parent->v_true_linkage.at(iGeneIndex).size() > 0)
	{
		d_perf_block_fill_up = i_correct_genes;
		d_perf_block_fill_up = d_perf_block_fill_up / (pc_parent->v_true_linkage.at(iGeneIndex).size() - 1);
	}//if (v_true_linkage.at(iGeneIndex).size() > 0)
	else
		d_perf_block_fill_up = 0;

	return(d_perf_block_fill_up);
}//double  CLinkageAnalyzerSingleDSM::dLinkQuality_PerfectBlockLengthFill(int iGeneIndex)



void  CLinkageAnalyzerSingleDSM::vReportClusters(FILE  *pfDest)
{
	CString  s_line, s_buf;

	for (int i_cluster = 0; i_cluster < v_p3_clusters.size(); i_cluster++)
	{
		s_line.Format("[%d]:", v_p3_clusters.at(i_cluster).size());
		for (int i_cluster_node = 0; i_cluster_node < v_p3_clusters.at(i_cluster).size(); i_cluster_node++)
		{
			s_buf.Format("%d", v_p3_clusters.at(i_cluster).at(i_cluster_node));
			s_line += " " + s_buf;
		}//for (int i_cluster_node = 0; i_cluster_node < v_p3_clusters.at(i_cluster).size(); i_cluster_node++)

		fprintf(pfDest, s_line + "\n");
	}//for (int i_cluster = 0; i_cluster < v_p3_clusters.size(); i_cluster++)
}//void  CLinkageAnalyzerSingleDSM::vReportClusters(FILE  *pfDest)



void  CLinkageAnalyzerSingleDSM::vShow(double  dValue)
{
	CString  s_buf;
	s_buf.Format("%lf", dValue);
	::MessageBox(NULL, s_buf, s_buf, MB_OK);
}//void  CLinkageAnalyzer::vShow(double  dValue)


void  CLinkageAnalyzerSingleDSM::vDebugLog(CString  sLog)
{
	FILE  *pf_dest;

	pf_dest = fopen("____DEBUG_log.txt", "a");
	fprintf(pf_dest, sLog + "\n");
	fclose(pf_dest);
}//void  CLinkageAnalyzer::vShow(double  dValue)




void  CLinkageAnalyzerSingleDSM::vSaveLinkageReport(CString  sLinkageReportFile)
{
	CString  s_file_name;
	s_file_name = sLinkageReportFile + LINKAGE_ANALYZER_POSTFIX;

	FILE  *pf_dest;
	pf_dest = fopen(s_file_name, "w+");

	CString  s_line, s_buf;

	vRecomputeDiscretizedDSM();



	double  d_link_quality_block_overhead, d_link_quality_perf_block_fill;
	int  i_furthest_gene;

	fprintf(pf_dest, "\n\n\n\n\n\n\n\n  TRUE LINKAGE: \n\n\n\n");
	for (int i_gene = 0; i_gene < pc_parent->v_true_linkage.size(); i_gene++)
	{
		s_line = "";
		s_buf.Format("%04d \t", i_gene);
		s_line += s_buf;

		d_link_quality_block_overhead = dLinkQuality_PerfectBlockLengthOverhead(i_gene, &i_furthest_gene);
		s_buf.Format("BlockLengthOverhead: \t %lf \t %d \t", d_link_quality_block_overhead, i_furthest_gene);
		s_line += s_buf + " \t ";

		d_link_quality_perf_block_fill = dLinkQuality_PerfectBlockLengthFill(i_gene);
		s_buf.Format("PerfectBlockLengthFill: \t %lf \t", d_link_quality_perf_block_fill);
		s_line += s_buf + " dependent: \t ";

		

		for (int i_dependent = 0; i_dependent < pc_parent->v_true_linkage.at(i_gene).size(); i_dependent++)
		{
			s_buf.Format("%04d", pc_parent->v_true_linkage.at(i_gene).at(i_dependent));
			s_line += s_buf + "\t ";
		}//for (int i_dependent = 0; i_dependent < pvDependentGenes->at(i_gene).size(); i_dependent++)

		fprintf(pf_dest, s_line + "\n");

	}//for (int i_gene = 0; i_gene < pvDependentGenes->size(); i_gene++)
	



	

	fprintf(pf_dest, "\n\n\n\n\n\n\n\n  DISCRETIZED RANKING: \n\n\n\n");

	s_line = "";
	s_buf.Format("xxxx");
	s_line += s_buf + "\t";

	for (int iy = 0; iy < i_dsm_size; iy++)
	{
		s_buf.Format("%04d", iy);
		s_line += s_buf + "\t";
	}//for (int iy = 0; iy < i_dsm_size; iy++)
	fprintf(pf_dest, s_line + "\n\n");

	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		s_line = "";

		s_buf.Format("%04d", ix);
		s_line += s_buf + "\t";

		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			s_buf.Format("%04d", pi_dsm_discretized_ranking[ix][iy]);
			s_line += s_buf + "\t";
		}//for (int iy = 0; iy < i_dsm_size; iy++)

		fprintf(pf_dest, s_line + "\n");
	}//for (int ix = 0; ix < i_dsm_size; ix++)






	fprintf(pf_dest, "\n\n\n\n\n\n\n\n  DISCRETIZED: \n\n\n\n");

	s_line = "";
	s_buf.Format("xxxx");
	s_line += s_buf + "\t";

	for (int iy = 0; iy < i_dsm_size; iy++)
	{
		s_buf.Format("%04d", iy);
		s_line += s_buf + "\t";
	}//for (int iy = 0; iy < i_dsm_size; iy++)
	fprintf(pf_dest, s_line + "\n\n");

	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		s_line = "";

		s_buf.Format("%04d", ix);
		s_line += s_buf + "\t";

		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			s_buf.Format("%04d", pi_dsm_discretized[ix][iy]);
			s_line += s_buf + "\t";
		}//for (int iy = 0; iy < i_dsm_size; iy++)

		fprintf(pf_dest, s_line + "\n");
	}//for (int ix = 0; ix < i_dsm_size; ix++)


	fprintf(pf_dest, "\n\n\n\n\n\n\n\n  RAW: \n\n\n\n");


	s_line = "";
	s_buf.Format("xxxxxxxx");
	s_line += s_buf + "\t";


	for (int iy = 0; iy < i_dsm_size; iy++)
	{
		s_buf.Format("%08d", iy);
		s_line += s_buf + "\t";
	}//for (int iy = 0; iy < i_dsm_size; iy++)
	fprintf(pf_dest, s_line + "\n\n");

	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		s_line = "";

		s_buf.Format("%08d", ix);
		s_line += s_buf + "\t";

		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			s_buf.Format("%.8lf", pd_dsm[ix][iy]);
			s_line += s_buf + "\t";			
		}//for (int iy = 0; iy < i_dsm_size; iy++)

		fprintf(pf_dest, s_line + "\n");
	}//for (int ix = 0; ix < i_dsm_size; ix++)


	fprintf(pf_dest, "\n\n\n\n\n\n\n\n  HEAVILY TIED PAIRS: \n\n\n\n");
	int  i_deps_true, i_deps_false;
	i_deps_true = 0;
	i_deps_false = 0;
	for (int ix = 0; ix < i_dsm_size; ix++)
	{
		for (int iy = 0; iy < i_dsm_size; iy++)
		{
			if (ix != iy)
			{
				if (pd_dsm[ix][iy] < 2)
				{
					s_line.Format("%d + %d = %.8lf", ix, iy, pd_dsm[ix][iy]);
					if (b_check_if_dependency_is_true(ix, iy) == true)
					{
						i_deps_true++;
						s_buf = "";
					}//if (b_check_if_dependency_is_true(ix, iy) == true)
					else
					{
						i_deps_false++;
						s_buf = "   FALSE";
					}//else  if (b_check_if_dependency_is_true(ix, iy) == true)*/

					s_line += s_buf;
					fprintf(pf_dest, s_line + "\n");
				}//if (pd_dsm[ix][iy] < 9)
			}//if (ix != iy)
		}//for (int iy = 0; iy < i_dsm_size; iy++)
	}//for (int ix = 0; ix < i_dsm_size; ix++)


	double  d_deps_perc;
	d_deps_perc = i_deps_true;

	if (i_deps_true + i_deps_false > 0)
		d_deps_perc = d_deps_perc / (i_deps_true + i_deps_false);
	else
		d_deps_perc = 0;

	s_line.Format("\n\n\n SUMMARY:\n true: %d\n FALSE: %d\n %.4lf ", i_deps_true, i_deps_false, d_deps_perc);
	//s_line = "";
	fprintf(pf_dest, s_line + "\n");


	/*fprintf(pf_dest, "\n\n\n SVED DEP PAIRS: \n\n");
	for (int ii = 0; ii < v_strict_dependent_pairs.size(); ii++)
	{
		s_line.Format("%d + %d = %.8lf", v_strict_dependent_pairs.at(ii).iFirstGene, v_strict_dependent_pairs.at(ii).iSecondGene, v_strict_dependent_pairs.at(ii).d_dependency);
		fprintf(pf_dest, s_line + "\n");
	}//for (int ii = 0; ii < v_strict_dependent_pairs.size(); ii++)*/


	
	fclose(pf_dest);
}//void  CLinkageAnalyzerSingleDSM::vSaveLinkageReport(CString  sLinkageReportFile)


bool  CLinkageAnalyzerSingleDSM::b_check_if_dependency_is_true(int iX, int iY)
{
	if (pc_parent == NULL)  return(false);
	if (iX >= pc_parent->v_true_linkage.size())  return(false);

	for (int ii = 0; ii < pc_parent->v_true_linkage.at(iX).size(); ii++)
	{
		if (pc_parent->v_true_linkage.at(iX).at(ii) == iY)  return(true);
	}//for (int ii = 0; ii < pc_parent->v_true_linkage.size(); ii++)
	
	return(false);
};//bool  CLinkageAnalyzerSingleDSM::b_check_if_dependency_is_true(int iX, int iY)


























CDirectional_DSM::CDirectional_DSM()
{
	pd_dsm = NULL;
	pi_coverage_comp_tool = NULL;
	pi_included_nodes = NULL;
	pc_coverage = NULL;
	i_size = 0;

	i_pairs_total = 0;
	i_pairs_bilateral = 0;
	i_pairs_directional = 0;
	i_pairs_unconnected = 0;
}//CDirectional_DSM::CDirectional_DSM()


CDirectional_DSM::~CDirectional_DSM()
{
	vFlushNodes();

	if (pd_dsm != NULL)
	{
		for (int ii = 0; ii < i_size; ii++)
			delete  pd_dsm[ii];
	}//if  (pd_dsm != NULL)
	delete  pd_dsm;

	if (pi_coverage_comp_tool != NULL)  delete  pi_coverage_comp_tool;
	if (pi_included_nodes != NULL)  delete  pi_included_nodes;

	if (pc_coverage != NULL)  delete[] pc_coverage;
}//CDirectional_DSM::~CDirectional_DSM()



bool  CDirectional_DSM::bSetSize(int  iSize)
{
	if (i_size > 0)  return(false);

	i_size = iSize;
	pd_dsm = new double*[i_size];
	for (int ii = 0; ii < i_size; ii++)
		pd_dsm[ii] = new double[i_size];

	pi_included_nodes = new int[i_size];
	pi_coverage_comp_tool = new int[i_size];
	pc_coverage = new CDirectional_DSM_CoverageStats[i_size];
	for (int ii = 0; ii < i_size; ii++)
		pc_coverage[ii].vSetConfig(i_size, ii);

	bZeroDSM();
	return(true);
}//bool  CDirectional_DSM::bSetSize(int  iSize)


void  CDirectional_DSM::vComputeCoverage()
{
	for (int ii = 0; ii < i_size; ii++)
		pc_coverage[ii].vZeroStats();

	for (int ii = 0; ii < i_size; ii++)
		v_compute_coverage(ii);

	i_pairs_total = 0;
	i_pairs_bilateral = 0;
	i_pairs_directional = 0;
	i_pairs_unconnected = 0;

	for (int ix = 0; ix < i_size; ix++)
	{
		for (int iy = 0; iy < i_size; iy++)
		{
			if (ix > iy)
			{
				i_pairs_total++;
				if ((pd_dsm[ix][iy] > 0) && (pd_dsm[iy][ix] > 0))  i_pairs_bilateral++;
				if (
					((pd_dsm[ix][iy] > 0) && (pd_dsm[iy][ix] == 0))
					||
					((pd_dsm[ix][iy] == 0) && (pd_dsm[iy][ix] > 0))
					)  i_pairs_directional++;

				if ((pd_dsm[ix][iy] == 0) && (pd_dsm[iy][ix] == 0))  i_pairs_unconnected++;
			}//if  (ix > iy)
		}//for  (int iy = 0; iy < i_size; iy++)
	}//for  (int ix = 0; ix < i_size; ix++)
}//void  CDirectional_DSM::vComputeCoverage()




CString  CDirectional_DSM::sGetCoverageStats()
{
	int  i_genes_disconnected, i_genes_connected, i_coverage_min, i_coverage_max, i_hop_min, i_hop_max;
	double  d_coverage_avr, d_hop_avr;
	int  i_linkage_origin_genes, i_linkage_leaf_genes;

	i_coverage_min = -1;
	i_coverage_max = -1;
	i_hop_min = -1;
	i_hop_max = -1;
	d_coverage_avr = 0;
	d_hop_avr = 0;
	i_genes_disconnected = 0;
	i_linkage_origin_genes = 0;
	for (int ii = 0; ii < i_size; ii++)
	{
		if (pc_coverage[ii].iCoverage > 1)
		{
			i_genes_connected++;

			if (i_coverage_min == -1)  i_coverage_min = pc_coverage[ii].iCoverage;
			if (i_coverage_min > pc_coverage[ii].iCoverage)  i_coverage_min = pc_coverage[ii].iCoverage;
			if (i_coverage_max < pc_coverage[ii].iCoverage)  i_coverage_max = pc_coverage[ii].iCoverage;

			if (i_hop_min == -1)  i_hop_min = pc_coverage[ii].iMaxHopNumber();
			if (i_hop_min > pc_coverage[ii].iMaxHopNumber())  i_hop_min = pc_coverage[ii].iMaxHopNumber();
			if (i_hop_max < pc_coverage[ii].iMaxHopNumber())  i_hop_max = pc_coverage[ii].iMaxHopNumber();

			if (pc_coverage[ii].bLinkageOrigin == true)  i_linkage_origin_genes++;
			if (pc_coverage[ii].bLinkageLeaf == true)  i_linkage_leaf_genes++;

			d_coverage_avr += pc_coverage[ii].iCoverage;
			d_hop_avr += pc_coverage[ii].iMaxHopNumber();
		}//if  (pc_coverage[ii].iCoverage > 1)  
		else
		{
			if (pc_coverage[ii].bLinkageLeaf == true)
				i_genes_connected++;
			else
				i_genes_disconnected++;
		}//if  (pc_coverage[ii].iCoverage > 1)  

	}//for  (int  ii = 0; ii < i_size; ii++)



	if (i_genes_connected > 0)
	{
		d_coverage_avr = d_coverage_avr / i_genes_connected;
		d_hop_avr = d_hop_avr / i_genes_connected;
	}//if  (i_genes_connected > 0)


	double  d_pairs_bilateral, d_pairs_directional, d_pairs_unconnected;
	d_pairs_bilateral = i_pairs_bilateral;
	d_pairs_bilateral = d_pairs_bilateral / i_pairs_total;
	d_pairs_directional = i_pairs_directional;
	d_pairs_directional = d_pairs_directional / i_pairs_total;
	d_pairs_unconnected = i_pairs_unconnected;
	d_pairs_unconnected = d_pairs_unconnected / i_pairs_total;

	CString  s_line;
	s_line.Format
	(
		"GENES(connected/disconnected/origin/leaf) \t %d \t %d \t %d \t %d \t PAIRS(all/bilateral/directional/unconnected): \t %d \t %d \t %.8lf \t %d \t %.8lf \t %d \t %.8lf \t COVERAGE(min/max/avr) \t %d \t %d \t %.8lf \t HOP(min/max/avr) \t %d \t %d \t %.8lf \t",
		i_genes_connected, i_genes_disconnected, i_linkage_origin_genes, i_linkage_leaf_genes,
		i_pairs_total, i_pairs_bilateral, d_pairs_bilateral, i_pairs_directional, d_pairs_directional, i_pairs_unconnected, d_pairs_unconnected,
		i_coverage_min, i_coverage_max, d_coverage_avr, i_hop_min, i_hop_max, d_hop_avr
	);

	return(s_line);
}//CString  CDirectional_DSM::sGetCoverageStats()




void  CDirectional_DSM_CoverageStats::vGetStats(int  *piCoverageCompTool)
{
	int  i_max_level;
	i_max_level = -1;

	for (int ii = 0; ii < i_size; ii++)
	{
		if (i_max_level < piCoverageCompTool[ii])  i_max_level = piCoverageCompTool[ii];
	}//for (int  ii = 0; ii < i_size; ii++)

	iCoverage = 0;
	int  i_coverage_at_level;
	for (int i_level = 0; i_level < i_max_level; i_level++)
	{
		i_coverage_at_level = 0;

		for (int ii = 0; ii < i_size; ii++)
		{
			if (piCoverageCompTool[ii] == i_level)  i_coverage_at_level++;
		}//for (int ii = 0; ii < i_size; ii++)

		iCoverage += i_coverage_at_level;
		v_coverage_per_hop.push_back(i_coverage_at_level);
	}//for  (int  i_level = 0; i_level < i_max_level; i_level++)

}//void  CDirectional_DSM_CoverageStats::vGetStats(int  *piCoverageCompTool)


double  CDirectional_DSM_CoverageStats::dCoveragePerc()
{
	double  d_res;
	d_res = iCoverage;
	d_res = d_res / i_size;
	return(d_res);
}//double  CDirectional_DSM_CoverageStats::dCoveragePerc()



void  CDirectional_DSM_CoverageStats::vSave(FILE  *pfDest)
{
	CString  s_line, s_hop_coverage, s_buf;

	for (int ii = 0; ii < v_coverage_per_hop.size(); ii++)
	{
		s_buf.Format("%d", v_coverage_per_hop.at(ii));
		if (ii < v_coverage_per_hop.size()) s_buf += ",";
		s_hop_coverage += s_buf;
	}//for  (int  ii = 0; ii < v_coverage_per_hop.size(); ii++)

	CString  s_origin;
	if (bLinkageOrigin == true)  s_origin = "*";
	s_line.Format("Gene%s %.4d: %d(%.4lf) maxHop: %d %s\n", (LPCSTR)s_origin, i_gene_offset, iCoverage, dCoveragePerc(), v_coverage_per_hop.size() - 1, (LPCSTR)s_hop_coverage);
	fprintf(pfDest, s_line);
}//void  CDirectional_DSM_CoverageStats::vSave(FILE  *pfDest)





void  CDirectional_DSM_CoverageStats::vCreateDirectional_BilateralGroup(CDirectional_DSM_CoverageStats  *pcGenesCoverage, double **pdDSM, int  *piAllIncludedNodes, CDirectional_LTreeNode  **pcLTnode, CLinkageInformationPackIndividual  *pcInd0, CLinkageInformationPackIndividual  *pcInd1)
{
	CString  s_buf;
	*pcLTnode = NULL;

	int  *pi_this_ils_nodes;

	pi_this_ils_nodes = new int[i_size];
	for (int ii = 0; ii < i_size; ii++)
		pi_this_ils_nodes[ii] = 0;


	pi_this_ils_nodes[i_gene_offset] = 1;


	vector<int>  v_nodes_included;

	v_nodes_included.push_back(i_gene_offset);
	//we can not set all nodes here -> we set it only if there is at least one gene connected
	//piAllIncludedNodes[i_gene_offset] = 1;

	int  i_offset_bilateral;
	i_offset_bilateral = 0;


	while (i_offset_bilateral < v_nodes_included.size())
	{
		pcGenesCoverage[v_nodes_included.at(i_offset_bilateral)].vExtendDirectionalILS(pcGenesCoverage, NULL, pdDSM, piAllIncludedNodes, pi_this_ils_nodes, &v_nodes_included, true, pcInd0, pcInd1, false, false);
		i_offset_bilateral++;
	}//while  (i_offset_bilateral < pvNodeCluster->size())


	if (v_nodes_included.size() > 1)
	{
		*pcLTnode = new CDirectional_LTreeNode();
		*((*pcLTnode)->pvGetGenes()) = v_nodes_included;
	}//if  (v_nodes_included.size() >= 2)


	int  i_size_before_directional, i_size_after_directional;

	int  i_offset_directional = 0;
	i_size_before_directional = v_nodes_included.size();
	while (i_offset_directional < v_nodes_included.size())
	{
		pcGenesCoverage[v_nodes_included.at(i_offset_directional)].vExtendDirectionalILS(pcGenesCoverage, NULL, pdDSM, piAllIncludedNodes, pi_this_ils_nodes, &v_nodes_included, false, pcInd0, pcInd1, false, false);
		pcGenesCoverage[v_nodes_included.at(i_offset_directional)].vExtendDirectionalILS(pcGenesCoverage, NULL, pdDSM, piAllIncludedNodes, pi_this_ils_nodes, &v_nodes_included, false, pcInd0, pcInd1, false, true);
		i_offset_directional++;
	}//while  (i_offset_directional  < v_nodes_included.size())
	i_size_after_directional = v_nodes_included.size();


	if (i_size_after_directional > 1)
	{
		if (*pcLTnode == NULL)
		{
			*pcLTnode = new CDirectional_LTreeNode();
			*((*pcLTnode)->pvGetGenesExtended()) = v_nodes_included;
		}//if  (*pcLTnode == NULL)
		else
		{
			for (int ii = i_size_before_directional; ii < v_nodes_included.size(); ii++)
				(*pcLTnode)->pvGetGenesExtended()->push_back(v_nodes_included.at(ii));

		}//else  if  (*pcLTnode == NULL)

		(*pcLTnode)->vGeneMapGenerate(i_size);
	}//if  (i_size_after_directional > 1)


	delete  pi_this_ils_nodes;
}//void  CDirectional_DSM_CoverageStats::vCreateDirectional_BilateralGroup(CDirectional_DSM_CoverageStats  *pcGenesCoverage, double **pdDSM, int  *piAllIncludedNodes, CDirectional_LTreeNode  **pcLTnode)






void  CDirectional_DSM_CoverageStats::vExtendDirectionalILS(CDirectional_DSM_CoverageStats  *pcGenesCoverage, vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, double **pdDSM, int  *piAllIncludedNodes, int  *piThisTreeNodes, vector<int>  *pvIncrementalLinkageSet, bool  bOnlyBilateralNodes, CLinkageInformationPackIndividual  *pcInd0, CLinkageInformationPackIndividual  *pcInd1, bool  bAddOnlyOneGene, bool bAddPointingNotPointed)
{
	CString  s_buf;
	vector<int>  v_linked_genes;

	for (int i_gene = 0; i_gene < i_size; i_gene++)
	{
		if ((pcInd0 != NULL) && (pcInd1 != NULL))
		{
			if (pcInd0->piGetGenotype()[i_gene] != pcInd1->piGetGenotype()[i_gene])
			{
				if (bOnlyBilateralNodes == true)
				{
					if ((pdDSM[i_gene_offset][i_gene] > 0) && (pdDSM[i_gene][i_gene_offset] > 0) && (piThisTreeNodes[i_gene] == 0))
					{
						/*if  (pcGenesCoverage[i_gene_offset].iCoverage != pcGenesCoverage[i_gene].iCoverage)
						{
							CString  s_buf;
							s_buf.Format("%d != %d", pcGenesCoverage[i_gene_offset].iCoverage, pcGenesCoverage[i_gene].iCoverage);
							::Tools::vShow(s_buf);
						}//if  (pcGenesCoverage[i_gene_offset].iCoverage != pcGenesCoverage[i_gene].iCoverage)*/
						v_linked_genes.push_back(i_gene);
						//piThisTreeNodes[i_gene] = 1;
						//piAllIncludedNodes[i_gene] = 1;
					}//if  ( (pdDSM[i_gene_offset][i_gene] > 0)&&(pi_this_tree_nodes[i_gene] == 0) )
				}//if  (bOnlyBilateralNodes == true)
				else
				{
					if (bAddPointingNotPointed == false)
					{
						if ((pdDSM[i_gene_offset][i_gene] > 0) && (pdDSM[i_gene][i_gene_offset] == 0) && (piThisTreeNodes[i_gene] == 0))
						{
							v_linked_genes.push_back(i_gene);
							//piThisTreeNodes[i_gene] = 1;
							//piAllIncludedNodes[i_gene] = 1;
						}//if  ( (pdDSM[i_gene_offset][i_gene] > 0)&&(pi_this_tree_nodes[i_gene] == 0) )
					}//if  (bAddPointingNotPointed == false)
					else
					{
						if ((pdDSM[i_gene][i_gene_offset] > 0) && (pdDSM[i_gene_offset][i_gene] == 0) && (piThisTreeNodes[i_gene] == 0))
						{
							v_linked_genes.push_back(i_gene);
							//piThisTreeNodes[i_gene] = 1;
							//piAllIncludedNodes[i_gene] = 1;
						}//if  ( (pdDSM[i_gene_offset][i_gene] > 0)&&(pi_this_tree_nodes[i_gene] == 0) )
					}//else  if  (bAddPointingNotPointed == false)
				}//else  if  (bOnlyBilateralNodes == true)
			}//if  (pcInd0->pc_trajectories[i_gene]->iId  !=  pcInd1->pc_trajectories[i_gene]->iId)*/
		}//if  ( (pcInd0 != NULL)&&(pcInd1 != NULL) )
		else
		{
			if (bOnlyBilateralNodes == true)
			{
				if ((pdDSM[i_gene_offset][i_gene] > 0) && (pdDSM[i_gene][i_gene_offset] > 0) && (piThisTreeNodes[i_gene] == 0))
				{
					v_linked_genes.push_back(i_gene);
					//piThisTreeNodes[i_gene] = 1;
					//piAllIncludedNodes[i_gene] = 1;
				}//if  ( (pdDSM[i_gene_offset][i_gene] > 0)&&(pi_this_tree_nodes[i_gene] == 0) )
			}//if  (bOnlyBilateralNodes == true)
			else
			{
				if (bAddPointingNotPointed == false)
				{
					if ((pdDSM[i_gene_offset][i_gene] > 0) && (pdDSM[i_gene][i_gene_offset] == 0) && (piThisTreeNodes[i_gene] == 0))
					{
						v_linked_genes.push_back(i_gene);
						//piThisTreeNodes[i_gene] = 1;
						//piAllIncludedNodes[i_gene] = 1;
					}//if  ( (pdDSM[i_gene_offset][i_gene] > 0)&&(pi_this_tree_nodes[i_gene] == 0) )
				}//if  (bAddPointingNotPointed == false)
				else
				{
					if ((pdDSM[i_gene][i_gene_offset] > 0) && (pdDSM[i_gene_offset][i_gene] == 0) && (piThisTreeNodes[i_gene] == 0))
					{
						v_linked_genes.push_back(i_gene);
						//piThisTreeNodes[i_gene] = 1;
						//piAllIncludedNodes[i_gene] = 1;
					}//if  ( (pdDSM[i_gene_offset][i_gene] > 0)&&(pi_this_tree_nodes[i_gene] == 0) )
				}//else  if  (bAddPointingNotPointed == false)
			}//else  if  (bOnlyBilateralNodes == true)
		}//else  if  ( (pcInd0 != NULL)&&(pcInd1 != NULL) )
	}//for  (int  i_gene = 0; i_gene < i_size; i_gene++)


	//::Tools::vShow(v_linked_genes.size());


	if (bAddOnlyOneGene == true)
	{
		//s_buf.Format("Directional nodes: %d", v_linked_genes.size());
		//::Tools::vShow(s_buf);

		if (v_linked_genes.size() > 0)
		{
			int  i_pos;
			i_pos = RandUtils::iRandNumber(0, v_linked_genes.size() - 1); //lRand(v_linked_genes.size());
			pvIncrementalLinkageSet->push_back(v_linked_genes.at(i_pos));

			piThisTreeNodes[v_linked_genes.at(i_pos)] = 1;
			piAllIncludedNodes[v_linked_genes.at(i_pos)] = 1;
		}//if  (v_linked_genes.size() >= 1)
	}//if  (bAddOnlyOneGene == true)
	else
	{
		if (v_linked_genes.size() > 0)
		{
			vector<int>  v_linked_genes_tmp;

			v_linked_genes_tmp = v_linked_genes;
			v_linked_genes.clear();

			int  i_pos;
			while (v_linked_genes_tmp.size() > 0)
			{
				i_pos = RandUtils::iRandNumber(0, v_linked_genes_tmp.size() - 1);// lRand(v_linked_genes_tmp.size());
				v_linked_genes.push_back(v_linked_genes_tmp.at(i_pos));
				v_linked_genes_tmp.erase(v_linked_genes_tmp.begin() + i_pos);
			}//while  (v_nodes_tmp.size()  >  0)

			/*int  i_marked_genes = 0;
			for  (int ii = 0; ii < i_size; ii++)
			{
				if  (piThisTreeNodes[ii] == 1)  i_marked_genes++;
			}//for  (int ii = 0; ii < i_size; ii++)
			int  i_marked_genes_start = i_marked_genes;*/

			for (int ii = 0; ii < v_linked_genes.size(); ii++)
			{
				pvIncrementalLinkageSet->push_back(v_linked_genes.at(ii));

				piThisTreeNodes[v_linked_genes.at(ii)] = 1;
				piAllIncludedNodes[v_linked_genes.at(ii)] = 1;
			}//for  (int ii = 0; ii < v_directly_linked_genes_bilateral.size(); ii++)

			piThisTreeNodes[i_gene_offset] = 1;
			piAllIncludedNodes[i_gene_offset] = 1;

			/*i_marked_genes = 0;
			for  (int ii = 0; ii < i_size; ii++)
			{
				if  (piThisTreeNodes[ii] == 1)  i_marked_genes++;
			}//for  (int ii = 0; ii < i_size; ii++)
			int  i_marked_genes_end = i_marked_genes;asdasdasd

			s_buf.Format("Marked genes: START:%d  END:%d LINKEDsize:%d", i_marked_genes_start, i_marked_genes_end,  v_linked_genes.size());
			::Tools::vShow(s_buf);*/
		}//if  (v_linked_genes.size() >= 1)
	}//else  if  (bAddOnlyOneGene == true)



}//void  CDSM_CoverageStats::vExtendDirectionalILS(CDSM_CoverageStats  *pcGenesCoverage, vector<CLTreeNode *>  *pvDirectionalNodes, double **pdDSM, int  *piAllIncludedNodes, int  *piThisTreeNodes, vector<int>  *pvIncrementalLinkageSet, bool  bOnlyBilateralNodes)






bool  CDirectional_DSM::bZeroDSM()
{
	if (i_size <= 0)  return(false);

	for (int ix = 0; ix < i_size; ix++)
	{
		for (int iy = 0; iy < i_size; iy++)
			pd_dsm[ix][iy] = 0;
	}//for  (int ix = 0; ix < i_size; ix++)

}//bool  CDirectional_DSM::bZeroDSM()



bool  CDirectional_DSM::bSet(int iX, int iY, double dVal)
{
	if ((iX < 0) || (i_size <= iX))  return(false);
	if ((iY < 0) || (i_size <= iY))  return(false);
	pd_dsm[iX][iY] = dVal;
	return(true);
}//bool  CDirectional_DSM::bSet(int iX, int iY, double dVal)


bool  CDirectional_DSM::vFillRandomly()
{
	if (i_size <= 0)  return(false);

	double d_val;
	for (int ix = 0; ix < i_size; ix++)
	{
		for (int iy = 0; iy < i_size; iy++)
		{
			d_val = RandUtils::dRandNumber(0, 1); //dRand();

			pd_dsm[ix][iy] = d_val;
			pd_dsm[iy][ix] = d_val;
		}//for  (int iy = 0; iy < i_size; iy++)
	}//for  (int ix = 0; ix < i_size; ix++)

}//bool  CDirectional_DSM::vFillRandomly()



bool bLtreeNodeGreater(CDirectional_LTreeNode *elem1, CDirectional_LTreeNode *elem2)
{
	return(elem1->pvGetGenes()->size() < elem2->pvGetGenes()->size());
}//bool bLtreeNodeGreater(CLTreeNode *elem1, CLTreeNode *elem2)


void  CDirectional_DSM::vShuffleNodes(bool  bConsiderLength)
{
	vector<CDirectional_LTreeNode *>  v_nodes_tmp;

	v_nodes_tmp = v_directional_nodes;
	v_directional_nodes.clear();

	int  i_pos;
	while (v_nodes_tmp.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_nodes_tmp.size() - 1); //lRand(v_nodes_tmp.size());
		v_directional_nodes.push_back(v_nodes_tmp.at(i_pos));
		v_nodes_tmp.erase(v_nodes_tmp.begin() + i_pos);
	}//while  (v_nodes_tmp.size()  >  0)

	if (bConsiderLength == true)
	{
		std::sort(v_directional_nodes.begin(), v_directional_nodes.end(), bLtreeNodeGreater);
	}//if  (bConsiderLength == true)

	//for  (int ii = 0; ii < v_directional_nodes.size(); ii+=50)
	//	::Tools::vShow(v_directional_nodes.at(ii)->pvGetGenes()->size());

};//void  CDirectional_DSM::vShuffleNodes(bool  bConsiderLength)





void  CDirectional_DSM::v_compute_coverage(int  iGene)
{
	for (int ii = 0; ii < i_size; ii++)
		pi_coverage_comp_tool[ii] = -1;

	pi_coverage_comp_tool[iGene] = 0;
	v_compute_coverage_extend_level(0);


	pc_coverage[iGene].vGetStats(pi_coverage_comp_tool);

	pc_coverage[iGene].bLinkageOrigin = false;
	pc_coverage[iGene].bLinkageLeaf = false;
	if (pc_coverage[iGene].iCoverage > 1)
	{
		pc_coverage[iGene].bLinkageOrigin = true;

		for (int i_other_gene = 0; (i_other_gene < i_size) && (pc_coverage[iGene].bLinkageOrigin == true); i_other_gene++)
		{
			if (i_other_gene != iGene)
			{
				if (pd_dsm[i_other_gene][iGene] > 0)  pc_coverage[iGene].bLinkageOrigin = false;
			}//if  (i_other_gene != iGene)
		}//for  (int  i_other_gene = 0; i_other_gene < i_size; i_other_gene++)
	}//if  (pc_coverage[iGene].iCoverage > 1)
	else
	{
		for (int i_other_gene = 0; (i_other_gene < i_size) && (pc_coverage[iGene].bLinkageLeaf == false); i_other_gene++)
		{
			if (i_other_gene != iGene)
			{
				if (pd_dsm[i_other_gene][iGene] > 0)  pc_coverage[iGene].bLinkageLeaf = true;
			}//if  (i_other_gene != iGene)
		}//for  (int  i_other_gene = 0; i_other_gene < i_size; i_other_gene++)
	}//else  if  (pc_coverage[iGene].iCoverage > 1)



}//void  CDirectional_DSM::v_compute_coverage(int  iGene)




void  CDirectional_DSM::v_compute_coverage_extend_level(int  iLevel)
{
	bool  b_at_least_one_gene_marked;

	b_at_least_one_gene_marked = false;
	for (int i_gene = 0; i_gene < i_size; i_gene++)
	{
		if (pi_coverage_comp_tool[i_gene] == iLevel)
		{
			if (b_compute_coverage_for_gene(i_gene, pi_coverage_comp_tool, iLevel + 1) == true)  b_at_least_one_gene_marked = true;
		}//if  (pi_coverage_comp_tool[i_gene] == iLevel)
	}//for  (int  i_gene = 0; i _gene < i_size; i_gene++)

	if (b_at_least_one_gene_marked == true)  v_compute_coverage_extend_level(iLevel + 1);
}//void  CDirectional_DSM::v_compute_coverage_extend_level(int  iLevel)


bool  CDirectional_DSM::b_compute_coverage_for_gene(int  iGene, int  *piCoverageCompTool, int iLevelToMark)
{
	bool  b_result;

	b_result = false;
	for (int ii = 0; ii < i_size; ii++)
	{
		if (piCoverageCompTool[ii] < 0)
		{
			if (pd_dsm[iGene][ii] > 0)
			{
				piCoverageCompTool[ii] = iLevelToMark;
				b_result = true;
			}//if  (pd_dsm[iGene][ii] > 0)
		}//if  (piCoverageCompTool[ii] < 0)
	}//for  (int  ii = 0; ii < i_size; ii++)

	return(b_result);
}//bool  CDirectional_DSM::b_compute_coverage_for_gene(int  iGene, int  *piCoverageCompTool)






void  CDirectional_DSM::vSave(CString  sDest)
{
	FILE  *pf_dest;

	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;

	vSave(pf_dest);

	fclose(pf_dest);
}//void  CDSM::vSave(CString  sDest)





void  CDirectional_DSM::v_get_directional_linkage_info(FILE  *pfDest)
{
	CString  s_line, s_buf;


	s_line.Format("Total pairs: %d\n", i_pairs_total);
	fprintf(pfDest, s_line);
	s_line.Format("Pairs bilateral: %d\n", i_pairs_bilateral);
	fprintf(pfDest, s_line);
	s_line.Format("Pairs directional: %d\n", i_pairs_directional);
	fprintf(pfDest, s_line);
	s_line.Format("Links unconnected: %d (%d)\n", i_pairs_total - i_pairs_directional - i_pairs_bilateral, i_pairs_unconnected);
	fprintf(pfDest, s_line);

	//CString  s_cover_stats;
	//s_cover_stats = sGetCoverageStats();

	//fprintf(pfDest, "\n\nCOVERAGE STATS:\n");
	//fprintf(pfDest, s_cover_stats);

	fprintf(pfDest, "\n\nDIRECTED PAIRS:\n");

	s_line = "";
	for (int ix = 0; ix < i_size; ix++)
	{
		for (int iy = 0; iy < i_size; iy++)
		{
			if (ix > iy)
			{
				if (
					((pd_dsm[ix][iy] > 0) && (pd_dsm[iy][ix] == 0))
					||
					((pd_dsm[ix][iy] == 0) && (pd_dsm[iy][ix] > 0))
					)
				{
					s_buf.Format("(%d;%d),", ix, iy);
					s_line += s_buf;
				}//if  (
			}//if  (ix > iy)
		}//for  (int iy = 0; iy < i_size; iy++)
	}//for  (int ix = 0; ix < i_size; ix++)

	fprintf(pfDest, s_line);

	//fprintf(pfDest, "\n\nCOVERAGE:\n");
	//for (int ii = 0; ii < i_size; ii++)
		//pc_coverage[ii].vSave(pfDest);

}//void  CDirectional_DSM::v_get_directional_linkage_info(FILE  *pfDest)




void  CDirectional_DSM::vSave(FILE  *pfDest)
{
	CString  s_line, s_buf;


	s_line.Format("Size: %d\n\n", i_size);
	fprintf(pfDest, s_line);

	v_get_directional_linkage_info(pfDest);


	s_line = "xxxx \t";
	for (int ii = 0; ii < i_size; ii++)
	{
		s_buf.Format("%.4d \t", ii);
		s_line += s_buf;
	}//for  (int ii = 0; ii < i_size; ii++)
	s_line += "\n";

	fprintf(pfDest, s_line);


	int  i_buf;
	for (int ix = 0; ix < i_size; ix++)
	{
		s_line.Format("%.4d \t", ix);

		for (int iy = 0; iy < i_size; iy++)
		{
			i_buf = (int)pd_dsm[ix][iy];
			s_buf.Format("%.4d \t", i_buf);

			s_line += s_buf;
		}//for  (int iy = 0; iy < i_size; iy++)
		s_line += "\n";

		fprintf(pfDest, s_line);
	}//for  (int ix = 0; ix < i_size; ix++)


	fprintf(pfDest, "\nCLUSTERS:\n");
	for (int i_node = 0; i_node < v_directional_nodes.size(); i_node++)
	{
		s_line.Format("%s\n", v_directional_nodes.at(i_node)->sGetAsString());
		fprintf(pfDest, s_line);
	}//for (int i_node = 0; i_node < v_directional_nodes.size(); i_node++)

	fprintf(pfDest, "\nEND OF DSM:\n\n\n");
}//void  CDirectional_DSM::vSave(FILE  *pfDest);



void  CDirectional_DSM::vFlushNodes()
{
	for (int ii = 0; ii < v_directional_nodes.size(); ii++)
	{
		//if  (v_directional_nodes.at(ii)->iGetSuccCross() == 0)
		{
			delete  v_directional_nodes.at(ii);
			v_directional_nodes.erase(v_directional_nodes.begin() + ii);
			ii--;
		}//if  (v_directional_nodes.at(ii)->iGetSuccCross() == 0)
	}//for  (int ii = 0; ii < v_directional_nodes.size(); ii++)
	//v_directional_nodes.clear();
}//void  CDirectional_DSM::vFlushNodes()




void  CDirectional_DSM::vCreateDirectional_BilateralGroups(CLinkageInformationPackIndividual  *pcInd0, CLinkageInformationPackIndividual  *pcInd1)
{
	vFlushNodes();

	for (int ii = 0; ii < i_size; ii++)
		pi_included_nodes[ii] = 0;


	bool  b_nodes_to_cover_exist;
	b_nodes_to_cover_exist = true;
	int  i_node_to_start;



	CDirectional_LTreeNode  *pc_lt_node;
	for (int ii = 0; ii < i_size; ii++)
	{
		if (pi_included_nodes[ii] == 0)
		{
			pc_lt_node = NULL;

			//bilateral -> regular nodes;    directional -> extended nodes
			pc_coverage[ii].vCreateDirectional_BilateralGroup(pc_coverage, pd_dsm, pi_included_nodes, &pc_lt_node, pcInd0, pcInd1);

			if (pc_lt_node != NULL)  v_directional_nodes.push_back(pc_lt_node);
		}//if  (pi_included_nodes[ii] == 0)
	}//for  (int  ii = 0; ii < i_size; ii++)	


	//now nodes with no coverage
	/*vector<int>  v_nodes_not_included;
	for  (int  ii = 0; ii < i_size; ii++)
	{
		if  (pi_included_nodes[ii] == 0)
		{
			if  ( (pcInd0 != NULL)&&(pcInd1 != NULL) )
			{
				if  (pcInd0->pc_trajectories[ii]->iId  !=  pcInd1->pc_trajectories[ii]->iId)  v_nodes_not_included.push_back(ii);
			}//if  ( (pcInd0 != NULL)&&(pcInd1 != NULL) )
			else
				v_nodes_not_included.push_back(ii);
		}//if  (pi_included_nodes[ii] == 0)
	}//for  (int  ii = 0; ii < i_size; ii++)


	if  (v_nodes_not_included.size() > 0)
	{
		pc_lt_node = new CLTreeNode();
		*(pc_lt_node->pvGetGenes()) = v_nodes_not_included;
		pc_lt_node->vSetUnconnectedGenesNode(true);
		pc_lt_node->vGeneMapGenerate(i_size);
		v_directional_nodes.push_back(pc_lt_node);
	}//if  (v_nodes_not_included.size() > 0)*/
	//else
	//	::Tools::vShow("allNodesIncluded");

	//vComputeCoverage();
}//void  CDirectional_DSM::vCreateDirectional_BilateralGroups()



//--------------------------implementation of class CDirectional_DSM_Group--------------------------
CDirectional_DSM_Group::CDirectional_DSM_Group()
{
	pc_directional_linkage_summarized = NULL;
}//CDirectional_DSM_Group::CDirectional_DSM_Group()


CDirectional_DSM_Group::~CDirectional_DSM_Group()
{
	delete  pc_directional_linkage_summarized;
	for (int ii = 0; ii < v_directional_linkages.size(); ii++)
		delete  v_directional_linkages.at(ii);
}//CDirectional_DSM_Group::~CDirectional_DSM_Group()


CString  CDirectional_DSM_Group::sGetCoverageStats()
{
	CString  s_result, s_single;

	for (int ii = 0; ii < v_directional_linkages.size(); ii++)
	{
		s_single.Format("DSM_%d: %s\n", ii, v_directional_linkages.at(ii)->sGetCoverageStats());
		s_result += s_single;
	}//for  (int ii = 0; ii < v_directional_linkages.size();  ii++)


	return(s_result);
}//CString  CDirectional_DSM_Group::sGetCoverageStats()




void  CDirectional_DSM_Group::vShuffleNodes(bool  bConsiderLength)
{
	vector<CDirectional_LTreeNode *>  v_nodes_tmp;

	v_nodes_tmp = v_directional_nodes;
	v_directional_nodes.clear();

	int  i_pos;
	while (v_nodes_tmp.size() > 0)
	{
		i_pos = ::RandUtils::iRandNumber(0, v_nodes_tmp.size() - 1); //lRand(v_nodes_tmp.size());
		v_directional_nodes.push_back(v_nodes_tmp.at(i_pos));
		v_nodes_tmp.erase(v_nodes_tmp.begin() + i_pos);
	}//while  (v_nodes_tmp.size()  >  0)

	if (bConsiderLength == true)
	{
		std::sort(v_directional_nodes.begin(), v_directional_nodes.end(), bLtreeNodeGreater);
	}//if  (bConsiderLength == true)

	//for  (int ii = 0; ii < v_directional_nodes.size(); ii+=50)
	//	::Tools::vShow(v_directional_nodes.at(ii)->pvGetGenes()->size());

}//void  CDSM_Group::vShuffleNodes(bool  bConsiderLength)



CDirectional_DSM  *CDirectional_DSM_Group::pcGetDSM_ForLinkageDiscovery(bool  bAccumulateLinkage)
{
	if (bAccumulateLinkage == true)
	{
		if (v_directional_linkages.size() > 0)  return(v_directional_linkages.at(0));
	}//if  (bAccumulateLinkage == true)

	CDirectional_DSM  *pc_dsm_for_linage;

	pc_dsm_for_linage = new CDirectional_DSM();
	pc_dsm_for_linage->bSetSize(i_size);

	v_directional_linkages.push_back(pc_dsm_for_linage);

	return(pc_dsm_for_linage);
}//CDSM  *CDirectional_DSM_Group::pcGetDSM_ForLinkageDiscovery()





void  CDirectional_DSM_Group::vMakeSummarizedLinkage()
{
	if (v_directional_linkages.size() < 2)  return;

	if (pc_directional_linkage_summarized == NULL)
	{
		pc_directional_linkage_summarized = new CDirectional_DSM();
		pc_directional_linkage_summarized->bSetSize(i_size);
	}//if  (pc_directional_linkage_summarized == NULL)

	//pc_directional_linkage_summarized->bZeroDSM();

	pc_directional_linkage_summarized->vFlushNodes();

	double  d_sum;
	for (int ix = 0; ix < i_size; ix++)
	{
		for (int iy = 0; iy < i_size; iy++)
		{
			d_sum = 0;

			for (int i_dir_link = 0; i_dir_link < v_directional_linkages.size(); i_dir_link++)
			{
				d_sum += v_directional_linkages.at(i_dir_link)->pdGetDSM()[ix][iy];
			}//for  (int  i_dir_link = 0; i_dir_link < v_directional_linkages.size(); i_dir_link++)

			pc_directional_linkage_summarized->pdGetDSM()[ix][iy] = d_sum;
		}//for  (int iy = 0; iy < i_size; iy++)
	}//for  (int ix = 0; ix < i_size; ix++)

	//pc_directional_linkage_summarized->vComputeCoverage();

}//void  CDirectional_DSM_Group::vMakeSummarizedLinkage()






void  CDirectional_DSM_Group::vCreateDirectional_BilateralGroups(CLinkageInformationPackIndividual  *pcInd0, CLinkageInformationPackIndividual  *pcInd1)
{
	//CString  s_rep, s_buf;

	//::Tools::vReportInFile("zzz_joining_nodes.txt", "START\n");
	//1. create bilateral clusters
	v_directional_nodes.clear();
	//::Tools::vReportInFile("zzz_joining_nodes.txt", "\n\n del before\n");
	for (int ii = 0; ii < v_nodes_created.size(); ii++)
		delete  v_nodes_created.at(ii);
	v_nodes_created.clear();
	//::Tools::vReportInFile("zzz_joining_nodes.txt", " del after \n\n");


	//::Tools::vReportInFile("zzz_joining_nodes.txt", "1\n");

	for (int i_dsm = 0; i_dsm < v_directional_linkages.size(); i_dsm++)
	{
		if (v_directional_linkages.at(i_dsm)->pvGetDirectionalNodes()->size() == 0)  v_directional_linkages.at(i_dsm)->vCreateDirectional_BilateralGroups(pcInd0, pcInd1);

		for (int i_node = 0; i_node < v_directional_linkages.at(i_dsm)->pvGetDirectionalNodes()->size(); i_node++)
			v_directional_nodes.push_back(v_directional_linkages.at(i_dsm)->pvGetDirectionalNodes()->at(i_node));
	}//for  (int i_dsm = 0; i_dsm < v_directional_linkages.size();  i_dsm++)


	vector<int>  v_nodes_not_included;
	if (pc_directional_linkage_summarized != NULL)
	{
		if (pc_directional_linkage_summarized->pvGetDirectionalNodes()->size() == 0)  pc_directional_linkage_summarized->vCreateDirectional_BilateralGroups(pcInd0, pcInd1);

		for (int i_node = 0; i_node < pc_directional_linkage_summarized->pvGetDirectionalNodes()->size(); i_node++)
			v_directional_nodes.push_back(pc_directional_linkage_summarized->pvGetDirectionalNodes()->at(i_node));


		//not included nodes detection
		for (int ii = 0; ii < i_size; ii++)
		{
			if (pc_directional_linkage_summarized->piGetIncludedNodes()[ii] == 0)
			{
				v_nodes_not_included.push_back(ii);
			}//if  (pi_included_nodes[ii] == 0)  */
		}//for  (int  ii = 0; ii < i_size; ii++)	
	}//if  (pc_directional_linkage_summarized != NULL)
	else
	{
		//not included nodes detection
		for (int ii = 0; ii < i_size; ii++)
		{
			if (v_directional_linkages.at(0)->piGetIncludedNodes()[ii] == 0)
			{
				v_nodes_not_included.push_back(ii);
			}//if  (pi_included_nodes[ii] == 0)  */
		}//for  (int  ii = 0; ii < i_size; ii++)	
	}//else  if  (pc_directional_linkage_summarized != NULL)


	//s_rep.Format("GenotypeLength: %d\n", i_size);
	//::Tools::vReportInFile("zzz_joining_nodes.txt", s_rep);
	//s_rep.Format("NODES initial [%d]: ", v_directional_nodes.size());
	/*for  (int  ii = 0;  ii < v_directional_nodes.size(); ii++)
	{
		if  (v_directional_nodes.at(ii)->bUnconnectedGenesNode() == true)
			s_buf.Format(" (%d|%d,true) ", v_directional_nodes.at(ii)->pvGetGenes()->size(), v_directional_nodes.at(ii)->pvGetGenesExtended()->size());
		else
			s_buf.Format(" (%d|%d,FALSE) ", v_directional_nodes.at(ii)->pvGetGenes()->size(), v_directional_nodes.at(ii)->pvGetGenesExtended()->size());
		s_rep += s_buf;
	}//for  (int  ii = 0;  ii < v_directional_nodes.size(); ii++)
	::Tools::vReportInFile("zzz_joining_nodes.txt", s_rep);//*/


	//first eliminate the same nodes
	for (int i_node_0 = 0; i_node_0 < v_directional_nodes.size(); i_node_0++)
	{
		for (int i_node_1 = i_node_0 + 1; i_node_1 < v_directional_nodes.size(); i_node_1++)
		{
			if (v_directional_nodes.at(i_node_0)->bTheSame(v_directional_nodes.at(i_node_1)) == true)
			{
				//delete  v_directional_nodes.at(i_node_1); we can not delete here, the owner is a particular dsm
				v_directional_nodes.erase(v_directional_nodes.begin() + i_node_1);
				i_node_1--;
			}//if  (v_directional_nodes.at(i_node_0)->bTheSame(v_directional_nodes.at(i_node_1)) == true)
		}//for  (int  i_node_1 = i_node_0 + 1; i_node_1 < v_directional_nodes.size(); i_node_1++)
	}//for  (int  i_node_0 = 0; i_node_0 < v_directional_nodes.size(); i_node_0++)


	/*s_rep.Format("\n\n\AFTER ELIMINATING NODES: [%d]: ", v_directional_nodes.size());
	for  (int  ii = 0;  ii < v_directional_nodes.size(); ii++)
	{
		s_buf.Format(" (%d|%d,%s) ", v_directional_nodes.at(ii)->pvGetGenes()->size(), v_directional_nodes.at(ii)->pvGetGenesExtended()->size(), ::Tools::sFormatBool(v_directional_nodes.at(ii)->bUnconnectedGenesNode()));
		s_rep += s_buf;
	}//for  (int  ii = 0;  ii < v_directional_nodes.size(); ii++)
	::Tools::vReportInFile("zzz_joining_nodes.txt", s_rep);//*/



	vector<CDirectional_LTreeNode *>  v_nodes_to_join;
	for (int ii = 0; ii < v_directional_nodes.size(); ii++)
	{
		if (v_directional_nodes.at(ii)->bUnconnectedGenesNode() == false)
		{
			v_nodes_to_join.push_back(v_directional_nodes.at(ii));
		}//if  (v_directional_nodes.at(ii)->bUnconnectedGenesNode() == false)		
	}//for  (int  ii = 0; ii < v_directional_nodes.size(); ii++)

	vector<CDirectional_LTreeNode *>  v_nodes_to_cross;
	v_nodes_to_cross = v_nodes_to_join;


	/*s_rep.Format("\n\n\NODES to join: [%d]: ", v_nodes_to_join.size());
	for  (int  ii = 0;  ii < v_nodes_to_join.size(); ii++)
	{
		s_buf.Format(" (%d|%d,%s) ", v_nodes_to_join.at(ii)->pvGetGenes()->size(), v_nodes_to_join.at(ii)->pvGetGenesExtended()->size(), ::Tools::sFormatBool(v_nodes_to_join.at(ii)->bUnconnectedGenesNode()));
		s_rep += s_buf;
	}//for  (int  ii = 0;  ii < v_directional_nodes.size(); ii++)
	::Tools::vReportInFile("zzz_joining_nodes.txt", s_rep);//*/


	int  i_pos, i_joined_pos, i_overlapping_node_offset;
	vector<int>  v_overlapping_nodes_offets;
	CDirectional_LTreeNode *pc_considered_node, *pc_new_node;
	while (v_nodes_to_join.size() > 1)
	{
		i_pos = ::RandUtils::iRandNumber(0, v_nodes_to_join.size() - 1); //lRand(v_nodes_to_join.size());
		pc_considered_node = v_nodes_to_join.at(i_pos);
		v_nodes_to_join.erase(v_nodes_to_join.begin() + i_pos);

		v_overlapping_nodes_offets.clear();
		pc_considered_node->vGetOverlappingButDifferentNodes(&v_nodes_to_join, &v_overlapping_nodes_offets);

		if (v_overlapping_nodes_offets.size() > 0)
		{
			i_joined_pos = ::RandUtils::iRandNumber(0, v_overlapping_nodes_offets.size() - 1); //lRand(v_overlapping_nodes_offets.size());
			i_overlapping_node_offset = v_overlapping_nodes_offets.at(i_joined_pos);
			pc_new_node = pc_considered_node->pcByMapJoinNodes(v_nodes_to_join.at(i_overlapping_node_offset));

			/*s_rep = "JOINING: ";
			s_buf.Format(" (%d|%d,%s)  +  ", pc_considered_node->pvGetGenes()->size(), pc_considered_node->pvGetGenesExtended()->size(), ::Tools::sFormatBool(pc_considered_node->bUnconnectedGenesNode()));
			s_rep += s_buf;
			s_buf.Format(" (%d|%d,%s)  =  ", v_nodes_to_join.at(i_overlapping_node_offset)->pvGetGenes()->size(), v_nodes_to_join.at(i_overlapping_node_offset)->pvGetGenesExtended()->size(), ::Tools::sFormatBool(pc_considered_node->bUnconnectedGenesNode()));
			s_rep += s_buf;
			s_buf.Format(" (%d|%d,%s)  ", pc_new_node->pvGetGenes()->size(), pc_new_node->pvGetGenesExtended()->size(), ::Tools::sFormatBool(pc_new_node->bUnconnectedGenesNode()));
			s_rep += s_buf;
			::Tools::vReportInFile("zzz_joining_nodes.txt", s_rep);//*/


			v_nodes_to_join.erase(v_nodes_to_join.begin() + i_overlapping_node_offset);
			v_nodes_to_join.push_back(pc_new_node);
			v_directional_nodes.push_back(pc_new_node);
			v_nodes_created.push_back(pc_new_node);
		}//if  (v_overlapping_nodes_offets.size() > 0)
	}//while  (v_nodes_to_join.size() > 1)


	/*s_rep.Format("\n\n\AFTER JOINING NODES: [%d]: ", v_directional_nodes.size());
	for  (int  ii = 0;  ii < v_directional_nodes.size(); ii++)
	{
		s_buf.Format(" (%d|%d,%s) ", v_directional_nodes.at(ii)->pvGetGenes()->size(), v_directional_nodes.at(ii)->pvGetGenesExtended()->size(), ::Tools::sFormatBool(v_directional_nodes.at(ii)->bUnconnectedGenesNode()));
		s_rep += s_buf;
	}//for  (int  ii = 0;  ii < v_directional_nodes.size(); ii++)
	::Tools::vReportInFile("zzz_joining_nodes.txt", s_rep);//*/




	//crossing
	vector<CDirectional_LTreeNode *>  v_new_nodes;
	while (v_nodes_to_cross.size() > 1)
	{
		i_pos = ::RandUtils::iRandNumber(0, v_nodes_to_cross.size() - 1); //lRand(v_nodes_to_cross.size());
		pc_considered_node = v_nodes_to_cross.at(i_pos);
		v_nodes_to_cross.erase(v_nodes_to_cross.begin() + i_pos);

		v_overlapping_nodes_offets.clear();
		pc_considered_node->vGetOverlappingNodes(&v_nodes_to_cross, &v_overlapping_nodes_offets);

		if (v_overlapping_nodes_offets.size() > 0)
		{
			i_joined_pos = ::RandUtils::iRandNumber(0, v_overlapping_nodes_offets.size() - 1);// lRand(v_overlapping_nodes_offets.size());
			i_overlapping_node_offset = v_overlapping_nodes_offets.at(i_joined_pos);
			v_new_nodes.clear();
			pc_considered_node->vByMapCrossNodes(v_nodes_to_cross.at(i_overlapping_node_offset), &v_new_nodes);

			/*s_rep = "CROSSING: ";
			s_buf.Format(" (%d|%d,%s)  *  ", pc_considered_node->pvGetGenes()->size(), pc_considered_node->pvGetGenesExtended()->size(), ::Tools::sFormatBool(pc_considered_node->bUnconnectedGenesNode()));
			s_rep += s_buf;
			s_buf.Format(" (%d|%d,%s)  =  [%d]:  ", v_nodes_to_cross.at(i_overlapping_node_offset)->pvGetGenes()->size(), v_nodes_to_cross.at(i_overlapping_node_offset)->pvGetGenesExtended()->size(), ::Tools::sFormatBool(pc_considered_node->bUnconnectedGenesNode()), v_new_nodes.size());
			s_rep += s_buf;

			for  (int  ii = 0; ii < v_new_nodes.size(); ii++)
			{
				s_buf.Format(" (%d|%d,%s)  ", v_new_nodes.at(ii)->pvGetGenes()->size(), v_new_nodes.at(ii)->pvGetGenesExtended()->size(), ::Tools::sFormatBool(pc_new_node->bUnconnectedGenesNode()));
				s_rep += s_buf;
			}//for  (int  ii = 0; ii < v_new_nodes.size(); ii++)
			::Tools::vReportInFile("zzz_joining_nodes.txt", s_rep);//*/


			v_nodes_to_cross.erase(v_nodes_to_cross.begin() + i_overlapping_node_offset);

			for (int ii = 0; ii < v_new_nodes.size(); ii++)
			{
				v_nodes_to_cross.push_back(v_new_nodes.at(ii));
				v_directional_nodes.push_back(v_new_nodes.at(ii));
				v_nodes_created.push_back(v_new_nodes.at(ii));
			}//for  (int  ii = 0; ii < v_new_nodes.size(); ii++)

		}//if  (v_overlapping_nodes_offets.size() > 0)
	}//while  (v_nodes_to_cross.size() > 1)




	//now nodes with no coverage
	int  i_nodes_not_included;
	CDirectional_LTreeNode *pc_lt_node_new;
	vector<CDirectional_LTreeNode *>  v_unconnected_nodes;
	i_nodes_not_included = v_nodes_not_included.size();
	if (v_nodes_not_included.size() > 0)
	{
		vector<CDirectional_LTreeNode *>  v_unconnected_nodes;

		int  i_gene_offset;
		while (v_nodes_not_included.size() > 0)
		{
			pc_lt_node_new = new CDirectional_LTreeNode();
			v_directional_nodes.push_back(pc_lt_node_new);
			v_unconnected_nodes.push_back(pc_lt_node_new);
			v_nodes_created.push_back(pc_lt_node_new);

			i_gene_offset = ::RandUtils::iRandNumber(0, v_nodes_not_included.size() - 1); //::lRand(v_nodes_not_included.size());
			pc_lt_node_new->pvGetGenes()->push_back(v_nodes_not_included.at(i_gene_offset));
			v_nodes_not_included.erase(v_nodes_not_included.begin() + i_gene_offset);

			if (v_nodes_not_included.size() > 0)
			{
				i_gene_offset = ::RandUtils::iRandNumber(0, v_nodes_not_included.size() - 1); // ::lRand(v_nodes_not_included.size());
				pc_lt_node_new->pvGetGenes()->push_back(v_nodes_not_included.at(i_gene_offset));
				v_nodes_not_included.erase(v_nodes_not_included.begin() + i_gene_offset);
			}//if  (v_nodes_not_included.size() > 0)

			pc_lt_node_new->vGeneMapGenerate(i_size);
			pc_lt_node_new->vSetUnconnectedGenesNode(true);
		}//while  (v_nodes_not_included.size() > 0)


		int  i_node_offset_0, i_node_offset_1;
		CDirectional_LTreeNode *pc_lt_node_0, *pc_lt_node_1;
		while (v_unconnected_nodes.size() > 1)
		{
			i_node_offset_0 = ::RandUtils::iRandNumber(0, v_unconnected_nodes.size() - 1); //::lRand(v_unconnected_nodes.size());
			pc_lt_node_0 = v_unconnected_nodes.at(i_node_offset_0);
			v_unconnected_nodes.erase(v_unconnected_nodes.begin() + i_node_offset_0);

			if (v_unconnected_nodes.size() > 0)
			{
				i_node_offset_1 = ::RandUtils::iRandNumber(0, v_unconnected_nodes.size() - 1); //::lRand(v_unconnected_nodes.size());
				pc_lt_node_1 = v_unconnected_nodes.at(i_node_offset_1);
				v_unconnected_nodes.erase(v_unconnected_nodes.begin() + i_node_offset_1);
			}//if  (v_unconnected_nodes.size() > 0)

			pc_lt_node_new = new CDirectional_LTreeNode();
			v_directional_nodes.push_back(pc_lt_node_new);
			v_unconnected_nodes.push_back(pc_lt_node_new);
			v_nodes_created.push_back(pc_lt_node_new);


			for (int ii = 0; ii < pc_lt_node_0->pvGetGenes()->size(); ii++)
				pc_lt_node_new->pvGetGenes()->push_back(pc_lt_node_0->pvGetGenes()->at(ii));
			for (int ii = 0; ii < pc_lt_node_1->pvGetGenes()->size(); ii++)
				pc_lt_node_new->pvGetGenes()->push_back(pc_lt_node_1->pvGetGenes()->at(ii));

			pc_lt_node_new->vGeneMapGenerate(i_size);
			pc_lt_node_new->vSetUnconnectedGenesNode(true);
		}//while  (v_unconnected_nodes.size() > 1)


	}//if  (v_nodes_not_included.size() > 0)*/






	//s_rep.Format("Unconnected nodes: %d", i_nodes_not_included);
	//::Tools::vReportInFile("zzz_joining_nodes.txt", s_rep);


	//::Tools::vReportInFile("zzz_joining_nodes.txt", "\n");

	//::Tools::vReportInFile("zzz_joining_nodes.txt", "END\n\n\n\n\n");


	vShuffleNodes(false);

	//if one bilateral cluster points on the other -> join them
	//eliminate the same clusters
	//shuffle gene order in nodes

	//create all nodes only once
	//if node has a succValue > 0 -> do not shuffle?

}//void  CDSM_Group::vCreateDirectional_BilateralGroups(CSingleTrajectorySet  *pcInd0, CSingleTrajectorySet  *pcInd1)







void  CDirectional_DSM_Group::vSave(CString  sDest)
{
	FILE  *pf_dest;

	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;

	vSave(pf_dest);

	fclose(pf_dest);
}//void  CDirectional_DSM_Group::vSave(CString  sDest)



void  CDirectional_DSM_Group::vSave(FILE  *pfDest)
{
	CString  s_buf;

	s_buf.Format("DSMs: %d\n", v_directional_linkages.size());
	fprintf(pfDest, s_buf);


	for (int ii = 0; ii < v_directional_linkages.size(); ii++)
	{
		s_buf.Format("\n\n\nDSM: %d\n\n", ii);
		v_directional_linkages.at(ii)->vSave(pfDest);
	}//for  (int ii = 0; ii < v_directional_linkages.size();  ii++)


	s_buf.Format("\n\n\n\n\nALL CLUSTERS [%d]:\n\n", v_directional_nodes.size());
	fprintf(pfDest, s_buf);
	for (int i_node = 0; i_node < v_directional_nodes.size(); i_node++)
	{
		s_buf.Format("%s\n", v_directional_nodes.at(i_node)->sGetAsString());
		fprintf(pfDest, s_buf);
	}//for (int i_node = 0; i_node < v_directional_nodes.size(); i_node++)

	fprintf(pfDest, "\n\nEND OF GROUPS:\n\n\n");


}//void  CDirectional_DSM_Group::vSave(FILE  *pfDest)












//--------------------------implementation of class CDirectional_LTreeNode--------------------------

CString  CDirectional_LTreeNode::sGetAsString()
{
	CString  s_result, s_buf;
	s_result.Format("[Size:%d]: ", v_genes.size());
	for (int ii = 0; ii < v_genes.size(); ii++)
	{
		s_buf.Format(" %d;", v_genes.at(ii));
		s_result += s_buf;
	}//for  (int  ii = 0; ii < v_genes.size(); ii++)


	s_buf.Format("EXT[Size:%d]: ", v_genes_extended.size());
	s_result += s_buf;
	for (int ii = 0; ii < v_genes_extended.size(); ii++)
	{
		s_buf.Format(" %d;", v_genes_extended.at(ii));
		s_result += s_buf;
	}//for  (int  ii = 0; ii < v_genes.size(); ii++)

	return(s_result);
}//CString  CDirectional_LTreeNode::sGetAsString()



void  CDirectional_LTreeNode::vGeneMapGenerate(int  iGenotypeSize)
{
	if (iGenotypeSize <= 0)  return;

	if (pi_gene_map != NULL)
	{
		if (i_genotype_size != iGenotypeSize)
		{
			delete  pi_gene_map;
			pi_gene_map = new int[iGenotypeSize];
			i_genotype_size = iGenotypeSize;
		}//if  (i_genotype_size != iGenotypeSize)
	}//if  (pi_gene_map != NULL)
	else
	{
		pi_gene_map = new int[iGenotypeSize];
		i_genotype_size = iGenotypeSize;
	}//else  if  (pi_gene_map != NULL)


	for (int ii = 0; ii < i_genotype_size; ii++)
		pi_gene_map[ii] = 0;

	for (int ii = 0; ii < v_genes_extended.size(); ii++)
		pi_gene_map[v_genes_extended.at(ii)] = 2;

	for (int ii = 0; ii < v_genes.size(); ii++)
		pi_gene_map[v_genes.at(ii)] = 1;

}//void  CDirectional_LTreeNode::vGeneMapGenerate(int  iGenotypeSize)



bool  CDirectional_LTreeNode::bTheSame(CDirectional_LTreeNode  *pcOther)
{
	if ((pi_gene_map == NULL) || (pcOther->pi_gene_map == NULL))  ::Tools::vShow("bool  CLTreeNode::bTheSame(CLTreeNode  *pcOther)  ->  if  ( (pi_gene_map == NULL)||(pcOther->pi_gene_map == NULL) )");

	bool  b_one_gene_common, b_one_gene_different;

	b_one_gene_common = false;
	b_one_gene_different = false;
	for (int ii = 0; ii < i_genotype_size; ii++)
	{
		if (pi_gene_map[ii] != pcOther->pi_gene_map[ii])  return(false);
	}//for  (int  ii = 0; ii < i_genotype_size; ii++)

	return(true);
}//bool  CDirectional_LTreeNode::bTheSame(CLTreeNode  *pcOther)





void  CDirectional_LTreeNode::vCheckOverlappingAndSepation(CDirectional_LTreeNode  *pcOther, bool *pbOverlapping, bool  *pbThisHasSeparatePart, bool  *pbOtherHasSeparatePart)
{
	if ((pi_gene_map == NULL) || (pcOther->pi_gene_map == NULL))  ::Tools::vShow("bool  CLTreeNode::bTheSame(CLTreeNode  *pcOther)  ->  if  ( (pi_gene_map == NULL)||(pcOther->pi_gene_map == NULL) )");

	*pbOverlapping = false;
	*pbThisHasSeparatePart = false;
	*pbOtherHasSeparatePart = false;

	for (int ii = 0; ii < i_genotype_size; ii++)
	{
		if ((pi_gene_map[ii] > 0) && (pcOther->pi_gene_map[ii] > 0))  *pbOverlapping = true;
		if ((pi_gene_map[ii] > 0) && (pcOther->pi_gene_map[ii] == 0))  *pbThisHasSeparatePart = true;
		if ((pi_gene_map[ii] == 0) && (pcOther->pi_gene_map[ii] > 0))  *pbOtherHasSeparatePart = true;

		if (
			(*pbOverlapping == true) &&
			(*pbThisHasSeparatePart == true) &&
			(*pbOtherHasSeparatePart == true)
			)
			return;
	}//for  (int  ii = 0; ii < i_genotype_size; ii++)

}//bool  CDirectional_LTreeNode::bOverlappingButDifferent(CDirectional_LTreeNode  *pcOther)



void  CDirectional_LTreeNode::vGetOverlappingButDifferentNodes(vector<CDirectional_LTreeNode *>  *pvNodesToCheck, vector<int>  *pvNodesOverlappingOffests)
{
	bool b_overlapping, b_this_has_separate_part, b_other_has_separate_part;

	for (int i_node = 0; i_node < pvNodesToCheck->size(); i_node++)
	{
		if (this != pvNodesToCheck->at(i_node))
		{
			vCheckOverlappingAndSepation(pvNodesToCheck->at(i_node), &b_overlapping, &b_this_has_separate_part, &b_other_has_separate_part);

			if ((b_overlapping == true) && (b_this_has_separate_part == true) && (b_other_has_separate_part == true))
				pvNodesOverlappingOffests->push_back(i_node);
		}//if  (this  !=  pvNodesToCheck->at(i_node))
	}//for  (int  i_node = 0; i_node < pvNodesToCheck->size(); i_node++)

}//void  CDirectional_LTreeNode::vGetOverlappingButDifferentNodes(vector<CLTreeNode *>  *pvNodesToCheck, vector<int>  *pvNodesOverlappingOffests)


void  CDirectional_LTreeNode::vGetOverlappingNodes(vector<CDirectional_LTreeNode *>  *pvNodesToCheck, vector<int>  *pvNodesOverlappingOffests)
{
	bool b_overlapping, b_this_has_separate_part, b_other_has_separate_part;

	for (int i_node = 0; i_node < pvNodesToCheck->size(); i_node++)
	{
		if (this != pvNodesToCheck->at(i_node))
		{
			vCheckOverlappingAndSepation(pvNodesToCheck->at(i_node), &b_overlapping, &b_this_has_separate_part, &b_other_has_separate_part);

			if (
				(b_overlapping == true) &&
				((b_this_has_separate_part == true) || (b_other_has_separate_part == true))
				)
				pvNodesOverlappingOffests->push_back(i_node);
		}//if  (this  !=  pvNodesToCheck->at(i_node))
	}//for  (int  i_node = 0; i_node < pvNodesToCheck->size(); i_node++)

}//void  CDirectional_LTreeNode::vGetOverlappingNodes(vector<CLTreeNode *>  *pvNodesToCheck, vector<int>  *pvNodesOverlappingOffests)




void  CDirectional_LTreeNode::v_shuffle_list(vector<int>  *pvBase, vector<int>  *pvShuffled)
{
	vector<int>  v_buf;

	v_buf = *pvBase;

	pvShuffled->clear();

	int  i_pos;
	while (v_buf.size() > 0)
	{
		i_pos = ::RandUtils::iRandNumber(0, v_buf.size() - 1); //::lRand(v_buf.size());
		pvShuffled->push_back(v_buf.at(i_pos));
		v_buf.erase(v_buf.begin() + i_pos);
	}//while  (v_buf.size() > 0)

}//void  CDirectional_LTreeNode::v_shuffle_list(vector<int>  *pvBase, vector<int>  *pvShuffled)



CDirectional_LTreeNode*  CDirectional_LTreeNode::pcByMapJoinNodes(CDirectional_LTreeNode  *pcOther)
{
	CDirectional_LTreeNode  *pc_result;
	pc_result = new CDirectional_LTreeNode();

	vector<int>  v_bilateral, v_directional;

	for (int ii = 0; ii < i_genotype_size; ii++)
	{
		if ((pi_gene_map[ii] == 1) || (pcOther->pi_gene_map[ii] == 1))
			v_bilateral.push_back(ii);
		else
		{
			if ((pi_gene_map[ii] == 2) || (pcOther->pi_gene_map[ii] == 2))  v_directional.push_back(ii);
		}//else  if  ( (pi_gene_map[ii] == 1)||(pcOther->pi_gene_map[ii] == 1) )  
	}//for  (int  ii = 0; ii < i_genotype_size; ii++)

	v_shuffle_list(&v_bilateral, &v_bilateral);
	v_shuffle_list(&v_directional, &v_directional);


	*(pc_result->pvGetGenes()) = v_bilateral;
	*(pc_result->pvGetGenesExtended()) = v_directional;


	pc_result->vGeneMapGenerate(i_genotype_size);

	return(pc_result);
}//CDirectional_LTreeNode*  CLTreeNode::pcJoinNodesByMap(CLTreeNode  *pcOther)



void  CDirectional_LTreeNode::vByMapCrossNodes(CDirectional_LTreeNode  *pcOther, vector<CDirectional_LTreeNode*> *pvNewNodes)
{
	vector<int>  v_common_bilateral, v_common_directional;
	vector<int>  v_this_bilateral, v_this_directional;
	vector<int>  v_other_bilateral, v_other_directional;

	for (int ii = 0; ii < i_genotype_size; ii++)
	{
		if ((pi_gene_map[ii] == 1) && (pcOther->pi_gene_map[ii] == 1))  v_common_bilateral.push_back(ii);
		if (
			((pi_gene_map[ii] == 1) && (pcOther->pi_gene_map[ii] == 2)) ||
			((pi_gene_map[ii] == 2) && (pcOther->pi_gene_map[ii] == 1)) ||
			((pi_gene_map[ii] == 2) && (pcOther->pi_gene_map[ii] == 2))
			)
			v_common_directional.push_back(ii);

		if ((pi_gene_map[ii] == 1) && (pcOther->pi_gene_map[ii] == 0))  v_this_bilateral.push_back(ii);
		if ((pi_gene_map[ii] == 2) && (pcOther->pi_gene_map[ii] == 0))  v_this_directional.push_back(ii);

		if ((pi_gene_map[ii] == 0) && (pcOther->pi_gene_map[ii] == 1))  v_other_bilateral.push_back(ii);
		if ((pi_gene_map[ii] == 0) && (pcOther->pi_gene_map[ii] == 2))  v_other_directional.push_back(ii);


	}//for  (int  ii = 0; ii < i_genotype_size; ii++)

	v_shuffle_list(&v_common_bilateral, &v_common_bilateral);
	v_shuffle_list(&v_common_directional, &v_common_directional);

	v_shuffle_list(&v_this_bilateral, &v_this_bilateral);
	v_shuffle_list(&v_this_directional, &v_this_directional);

	v_shuffle_list(&v_other_bilateral, &v_other_bilateral);
	v_shuffle_list(&v_other_directional, &v_other_directional);


	//PREPARE RESULTS...
	CDirectional_LTreeNode  *pc_result;

	//if the nodes are like: thisSeparatePart(common)otherSeparatePart
	if (
		(v_common_bilateral.size() + v_common_directional.size() > 0) &&
		(v_this_bilateral.size() + v_this_directional.size() > 0) &&
		(v_other_bilateral.size() + v_other_directional.size() > 0)
		)
	{
		pc_result = new CDirectional_LTreeNode();
		*(pc_result->pvGetGenes()) = v_common_bilateral;
		*(pc_result->pvGetGenesExtended()) = v_common_directional;
		pc_result->vGeneMapGenerate(i_genotype_size);
		pvNewNodes->push_back(pc_result);

		pc_result = new CDirectional_LTreeNode();
		*(pc_result->pvGetGenes()) = v_this_bilateral;
		*(pc_result->pvGetGenesExtended()) = v_this_directional;
		pc_result->vGeneMapGenerate(i_genotype_size);
		pvNewNodes->push_back(pc_result);

		pc_result = new CDirectional_LTreeNode();
		*(pc_result->pvGetGenes()) = v_other_bilateral;
		*(pc_result->pvGetGenesExtended()) = v_other_directional;
		pc_result->vGeneMapGenerate(i_genotype_size);
		pvNewNodes->push_back(pc_result);
	}//if  (


	//if one node is inside the other...
	if (
		(v_common_bilateral.size() + v_common_directional.size() > 0) &&
		(
		(v_this_bilateral.size() + v_this_directional.size() == 0) ||
			(v_other_bilateral.size() + v_other_directional.size() == 0)
			)
		)
	{
		if (v_this_bilateral.size() + v_this_directional.size() > 0)
		{
			pc_result = new CDirectional_LTreeNode();
			*(pc_result->pvGetGenes()) = v_this_bilateral;
			*(pc_result->pvGetGenesExtended()) = v_this_directional;
			pc_result->vGeneMapGenerate(i_genotype_size);
			pvNewNodes->push_back(pc_result);
		}//if  (v_this_bilateral.size() + v_this_directional.size() > 0)

		if (v_other_bilateral.size() + v_other_directional.size() > 0)
		{
			pc_result = new CDirectional_LTreeNode();
			*(pc_result->pvGetGenes()) = v_other_bilateral;
			*(pc_result->pvGetGenesExtended()) = v_other_directional;
			pc_result->vGeneMapGenerate(i_genotype_size);
			pvNewNodes->push_back(pc_result);
		}//if  (v_other_bilateral.size() + v_other_directional.size() > 0)
	}//if  (

}//void  CLTreeNode::vByMapCrossNodes(CLTreeNode  *pcOther, vector<CLTreeNode*> *pvNewNodes)



















CTightLinkageBlockSupervisor::CTightLinkageBlockSupervisor(CEvaluation<CBinaryCoding> *pcEvaluation, CLog *pcLog)
{
	pc_evaluation = pcEvaluation;
	pc_log = pcLog;
}//CTightLinkageBlockSupervisor::CTightLinkageBlockSupervisor(CEvaluation<CBinaryCoding> *pcEvaluation, CLog *pcLog)


CTightLinkageBlockSupervisor::~CTightLinkageBlockSupervisor()
{

};//CTightLinkageBlockSupervisor::~CTightLinkageBlockSupervisor()


void  CTightLinkageBlockSupervisor::vSaveTLBs(CString  sDest, vector<vector<int> > *pvClusters)
{
	FILE   *pf_dest;
	pf_dest = fopen(sDest, "w+");

	for (int ii = 0; ii < v_tlbs.size(); ii++)
	{
		fprintf(pf_dest, "%d: \t", ii);
		v_tlbs.at(ii)->vSave(pf_dest);
	}//for (int ii = 0; ii < v_tlbs.size(); ii++)


	if (pvClusters != NULL)
	{
		fprintf(pf_dest, "\n\n\n\nCLUSTERS:\n\n");

		CString  s_line, s_buf;

		for (int i_clust = 0; i_clust < pvClusters->size(); i_clust++)
		{
			s_line.Format("%d [%d]:\t", i_clust, pvClusters->at(i_clust).size());

			for (int ii = 0; ii < pvClusters->at(i_clust).size(); ii++)
			{
				s_buf.Format(" %d ", pvClusters->at(i_clust).at(ii));
				s_line += s_buf;
			}//for (int ii = 0; ii < pvClusters->at(i_clust).size(); ii++)

			fprintf(pf_dest, "%s\n", s_line);
		}//for (int i_clust = 0; i_clust < pvClusters->size(); i_clust++)
	}//if (pvClusters != NULL)

	fclose(pf_dest);
}//void  CTightLinkageBlockSupervisor::vSaveTLBs(CString  sDest, vector<vector<int> > *pvClusters)


void  CTightLinkageBlockSupervisor::vBuildTLBs(int  **piScrapDSM)
{
	//first - flush current LTBs
	for (int ii = 0; ii < v_tlbs.size(); ii++)
		delete v_tlbs.at(ii);
	v_tlbs.clear();

	CTightLinkageBlock  *pc_tlb;

	//create TLBs for every gene 
	int  i_this_tlb_offset;
	for (int i_gene_source = 0; i_gene_source < pc_evaluation->iGetNumberOfElements(); i_gene_source++)
	{
		pc_tlb = new CTightLinkageBlock();
		v_tlbs.push_back(pc_tlb);
		i_this_tlb_offset = v_tlbs.size() - 1;
		if (pc_tlb->bReadInAndAddToList(i_gene_source, &v_tlbs, piScrapDSM, pc_evaluation->iGetNumberOfElements(), 0) == false)
		{
			v_tlbs.erase(v_tlbs.begin() + i_this_tlb_offset);
			delete  pc_tlb;
		}//if (pc_tlb->bReadInAndAddToList(i_gene_source, &v_tlbs, piScrapDSM, pc_evaluation->iGetNumberOfElements(), 0) == false)
		else
			i_this_tlb_offset++;

		while (i_this_tlb_offset < v_tlbs.size())
		{
			pc_tlb = v_tlbs.at(i_this_tlb_offset);

			if (pc_tlb->bReadInAndAddToList(-1, &v_tlbs, piScrapDSM, pc_evaluation->iGetNumberOfElements(), 0) == false)
			{
				v_tlbs.erase(v_tlbs.begin() + i_this_tlb_offset);
				delete  pc_tlb;
			}//if (pc_tlb->bReadInAndAddToList(i_gene_source, &v_tlbs, piScrapDSM, pc_evaluation->iGetNumberOfElements(), 0) == false)
			else
				i_this_tlb_offset++;
		}//while (i_this_tlb_offset < v_tlbs.size())
	}//for (int i_gene_source = 0; i_gene_source < pc_evaluation->iGetNumberOfElements(); i_gene_source++)


	//CString  s_buf;
	//s_buf.Format("%d", v_tlbs.size());
	//::MessageBox(NULL, s_buf, s_buf, MB_OK);
};//void  CTightLinkageBlockSupervisor::vBuildTLBs(int  **piScrapDSM)



void  CTightLinkageBlockSupervisor::vCreateTLB_Clusters(vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering)
{
	vector<CTightLinkageBlock *>  v_temporary_tlbs;
	vector<CTightLinkageBlock *>  v_current_tlbs;
	vector<int>  v_base_tlb_offsets;
	int  i_base_tlb_offset;

	for (int ii = 0; ii < v_tlbs.size(); ii++)
		v_base_tlb_offsets.push_back(ii);

	while (v_base_tlb_offsets.size() > 0)
	{
		i_base_tlb_offset = RandUtils::iRandNumber(0, v_base_tlb_offsets.size() - 1);
		//i_base_tlb_offset = 0;
		pvClusters->push_back(v_tlbs.at(v_base_tlb_offsets.at(i_base_tlb_offset))->v_tight_linkage_block);
		v_base_tlb_offsets.erase(v_base_tlb_offsets.begin() + i_base_tlb_offset);
	}//while (v_contained_tlb_offsets.size() > 0)*/

	return;

	//1st level tlbs
	for (int ii = 0; ii < v_tlbs.size(); ii++)
		v_base_tlb_offsets.push_back(ii);

	while (v_base_tlb_offsets.size() > 0)
	{
		i_base_tlb_offset = RandUtils::iRandNumber(0, v_base_tlb_offsets.size() - 1);
		//i_base_tlb_offset = 0;
		v_tlbs.at(v_base_tlb_offsets.at(i_base_tlb_offset))->vGetTLBclusterOnLevel(1, &v_tlbs, pvClusters);
		v_base_tlb_offsets.erase(v_base_tlb_offsets.begin() + i_base_tlb_offset);
	}//while (v_contained_tlb_offsets.size() > 0)

	return;

	/*for (int ii = 0; ii < v_tlbs.size(); ii++)
	{
		pvClusters->push_back(v_tlbs.at(ii)->v_tight_linkage_block);
		//v_tlbs.at(ii)->vCreateRandomSubclusters(pvClusters);//it creates the full single TLB cluster as well
	}//for (int ii = 0; ii < v_tlbs.size(); ii++)*/

	v_current_tlbs = v_tlbs;

	CTightLinkageBlock  *pc_tlb_current, *pc_tlb_current_overlap;
	CTightLinkageBlock  *pc_tlb_new;
	int  i_tlb_current_offset, i_tlb_current_overlap_offset;
	while (v_current_tlbs.size() > 1)
	{
		i_tlb_current_offset = RandUtils::iRandNumber(0, v_current_tlbs.size() - 1);
		pc_tlb_current = v_current_tlbs.at(i_tlb_current_offset);

		i_tlb_current_overlap_offset = pc_tlb_current->iGetOverlappingTLB_Offset(&v_current_tlbs);

		if (i_tlb_current_overlap_offset >= 0)
		{
			pc_tlb_current_overlap = v_current_tlbs.at(i_tlb_current_overlap_offset);
			pc_tlb_new = pc_tlb_current->pcJoinTLBs(pc_tlb_current_overlap);

			if (i_tlb_current_offset > i_tlb_current_overlap_offset)
			{
				v_current_tlbs.erase(v_current_tlbs.begin() + i_tlb_current_offset);
				v_current_tlbs.erase(v_current_tlbs.begin() + i_tlb_current_overlap_offset);
			}//if (i_tlb_current_offset > i_tlb_current_overlap_offset)
			else
			{
				v_current_tlbs.erase(v_current_tlbs.begin() + i_tlb_current_overlap_offset);
				v_current_tlbs.erase(v_current_tlbs.begin() + i_tlb_current_offset);
			}//else  if (i_tlb_current_offset > i_tlb_current_overlap_offset)

			v_temporary_tlbs.push_back(pc_tlb_new);
			v_current_tlbs.push_back(pc_tlb_new);

			if  (pc_tlb_new->v_tight_linkage_block.size() < pc_evaluation->iGetNumberOfElements())
				pvClusters->push_back(pc_tlb_new->v_tight_linkage_block);
		}//if (i_tlb_current_overlap_offset >= 0)
		else
		{
			v_current_tlbs.erase(v_current_tlbs.begin() + i_tlb_current_offset);
		}//else  if (i_tlb_current_overlap_offset >= 0)

		//we do not want to do it...
		//pc_tlb_current->vGetContainedTLBsOffsets(&v_contained_tlb_offsets);
	}//while (v_current_tlbs.size() > 1)

	for (int ii = 0; ii < pvClusters->size(); ii++)
		pvClusterOrdering->push_back(ii);

	for (int ii = 0; ii < v_temporary_tlbs.size(); ii++)
		delete  v_temporary_tlbs.at(ii);

}//void  CTightLinkageBlockSupervisor::vCreateTLB_Clusters(vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering)


int   CTightLinkageBlockSupervisor::iGetDonorByTLB(vector<int>   *pvCluster, char *pcSourceInd, char	**pcLTGApopulation, int  iPopSize)
{
	vector<CTightLinkageBlock *>  v_overlapping_tlbs;

	for (int ii = 0; ii < v_tlbs.size(); ii++)
	{
		if (v_tlbs.at(ii)->bAtLeastOneGeneInCommon(pvCluster) == true)
		{
			if (v_tlbs.at(ii)->bAtLeastOneGeneDifferent(pvCluster) == true)
				v_overlapping_tlbs.push_back(v_tlbs.at(ii));
		}//if (v_tlbs.at(ii)->bAtLeastOneGeneInCommon(pvCluster) == true)
	}//for (int ii = 0; ii < v_tlbs.size(); ii++)


	if (v_overlapping_tlbs.size() > 0)
	{
		int  i_chosen_overlapping_tlb;
		i_chosen_overlapping_tlb = RandUtils::iRandNumber(0, v_overlapping_tlbs.size() - 1);

		vector<int>  v_genes_in_common;
		v_overlapping_tlbs.at(i_chosen_overlapping_tlb)->vGetGenesInCommon(pvCluster, &v_genes_in_common);

		if (v_overlapping_tlbs.size() == 0)  ::MessageBox(NULL, "if (v_overlapping_tlbs.size() == 0)", "if (v_overlapping_tlbs.size() == 0)", MB_OK);
		if (v_overlapping_tlbs.size() == pvCluster->size())  ::MessageBox(NULL, "v_overlapping_tlbs.size() == pvCluster->size()", "v_overlapping_tlbs.size() == pvCluster->size()", MB_OK);

		vector<int>  v_fitting_donors;
		for (int i_ind = 0; i_ind < iPopSize; i_ind++)
		{
			if (b_can_i_be_donnor(pcSourceInd, pcLTGApopulation[i_ind], &v_genes_in_common, pvCluster) == true)
				v_fitting_donors.push_back(i_ind);
		}//for (int i_ind = 0; i_ind < iPopSize; i_ind++)

		if (v_fitting_donors.size() > 0)
		{
			int  i_donor_offset;
			i_donor_offset = RandUtils::iRandNumber(0, v_fitting_donors.size() - 1);
			return(v_fitting_donors.at(i_donor_offset));
		}//if (v_fitting_donors.size() > 0)
	}//if (v_overlapping_tlbs.size() > 0)

	return(RandUtils::iRandNumber(0, iPopSize - 1));	
}//int   CTightLinkageBlockSupervisor::iGetDonorByTLB(vector<int>   *pvCluster, char *pcSourceInd, char	**pcLTGApopulation, int  iPopSize)


bool  CTightLinkageBlockSupervisor::b_can_i_be_donnor(char *pcSourceInd, char  *pcDonorCandidate, vector<int> *pvGenesInCommon, vector<int> *pvCluster)
{
	for (int ii = 0; ii < pvGenesInCommon->size(); ii++)
	{
		if (pcSourceInd[pvGenesInCommon->at(ii)] != pcDonorCandidate[pvGenesInCommon->at(ii)])  return(false);
	}//for (int ii = 0; ii < pvGenesInCommon->size(); ii++)


	for (int ii = 0; ii < pvCluster->size(); ii++)
	{
		if (pcSourceInd[pvCluster->at(ii)] != pcDonorCandidate[pvCluster->at(ii)])  return(true);
	}//for (int ii = 0; ii < pvGenesInCommon->size(); ii++)

	return(false);
}//bool  CTightLinkageBlockSupervisor::b_can_i_be_donnor(char *pcSourceInd, char  *pcDonorCandidate, vector<int> *pvGenesInCommon, vector<int> *pvCluster)



void  CTightLinkageBlock::vAddTLB(CTightLinkageBlock  *pcTLB_ToAdd)
{
	vector<int>  v_new_tlb;

	v_new_tlb = v_tight_linkage_block;

	for (int ii = 0; ii < pcTLB_ToAdd->v_tight_linkage_block.size(); ii++)
		v_new_tlb.push_back(pcTLB_ToAdd->v_tight_linkage_block.at(ii));

	vSetTLB(&v_new_tlb);

}//void  CTightLinkageBlock::vAddTLB(CTightLinkageBlock  *pcTLB_ToAdd)



CTightLinkageBlock  *CTightLinkageBlock::pcJoinTLBs(CTightLinkageBlock  *pcTLB_CurrentOverlap)
{
	CTightLinkageBlock  *pc_new_tlb;
	vector<int>  v_new_tlb;


	pc_new_tlb = new CTightLinkageBlock();
	pc_new_tlb->vSetTLB(&v_tight_linkage_block);
	pc_new_tlb->vAddTLB(pcTLB_CurrentOverlap);



	return(pc_new_tlb);
}//CTightLinkageBlock  *CTightLinkageBlock::pcJoinTLBs(CTightLinkageBlock  *pcTLB_CurrentOverlap)



void  CTightLinkageBlock::vGetContainedTLBsOffsets(vector<int>  *pvContainedTLB_Offsets)
{
	::MessageBox(NULL, "void  CTightLinkageBlock::vGetContainedTLBsOffsets(vector<int>  *pvContainedTLB_Offsets)", "void  CTightLinkageBlock::vGetContainedTLBsOffsets(vector<int>  *pvContainedTLB_Offsets)", MB_OK);
}//void  CTightLinkageBlock::vGetContainedTLBsOffsets(vector<int>  *pvContainedTLB_Offsets)



void  CTightLinkageBlock::vGetTLBclusterOnLevel(int iLevel, vector<CTightLinkageBlock *>  *pvTLBs, vector<vector<int> > *pvClusters)
{
	CTightLinkageBlock  c_tlb_cluster;
	vector<int>  v_candidate_tlb_offsets;
	int  i_candidate_tlb_offset_offset;

	c_tlb_cluster.vSetTLB(&v_tight_linkage_block);
	pvClusters->push_back(c_tlb_cluster.v_tight_linkage_block);


	while (iLevel > 0)
	{
		iLevel--;
		v_candidate_tlb_offsets.clear();

		for (int i_tlb_offset = 0; i_tlb_offset < pvTLBs->size(); i_tlb_offset++)
		{
			if (this->bTheSame(pvTLBs->at(i_tlb_offset)) == false)
			{
				if (this->bAtLeastOneGeneInCommon(pvTLBs->at(i_tlb_offset)) == true)
				{
					if (
						(c_tlb_cluster.bDoIContain(pvTLBs->at(i_tlb_offset)) == false) &&
						(pvTLBs->at(i_tlb_offset)->bDoIContain(&c_tlb_cluster) == false)
						)
					{
						v_candidate_tlb_offsets.push_back(i_tlb_offset);
					}//if (
				}//if (bAtLeastOneGeneInCommon(pvTLBs->at(i_tlb_offset)) == true)
			}//if  (this  != pvTLBs->at(i_tlb_offset))
		}//for (int i_tlb_offset = 0; i_tlb_offset < pvTLBs->size(); i_tlb_offset++)

		/*for (int ii = 0; ii < v_candidate_tlb_offsets.size(); ii++)
		{
			c_tlb_cluster.vAddTLB(pvTLBs->at(v_candidate_tlb_offsets.at(ii)));
		}//for (int ii = 0; ii < v_candidate_tlb_offsets.size(); ii++)*/

		while (v_candidate_tlb_offsets.size() > 0)
		{
			i_candidate_tlb_offset_offset = RandUtils::iRandNumber(0, v_candidate_tlb_offsets.size() - 1);
			//i_candidate_tlb_offset_offset = 0;
			c_tlb_cluster.vAddTLB(pvTLBs->at(v_candidate_tlb_offsets.at(i_candidate_tlb_offset_offset)));
			//pvClusters->push_back(c_tlb_cluster.v_tight_linkage_block);

			v_candidate_tlb_offsets.erase(v_candidate_tlb_offsets.begin() + i_candidate_tlb_offset_offset);
		}//while (v_contained_tlb_offsets.size() > 0)

		pvClusters->push_back(c_tlb_cluster.v_tight_linkage_block);
	}//while (iLevel > 0)


	//pvClusters->push_back(c_tlb_cluster.v_tight_linkage_block);

}//void  CTightLinkageBlock::vGetTLBclusterOnLevel(int iLevel, vector<CTightLinkageBlock *>  *pvTLBs, vector<vector<int> > *pvClusters)



void  CTightLinkageBlock::vGetOverlappingTLB_Offsets(vector<CTightLinkageBlock *>  *pvTLBs, vector<int> *pvTLBsOverlappingOffsets)
{
	pvTLBsOverlappingOffsets->clear();

	for (int i_tlb_offset = 0; i_tlb_offset < pvTLBs->size(); i_tlb_offset++)
	{
		if (this != pvTLBs->at(i_tlb_offset))
		{
			if (bAtLeastOneGeneInCommon(pvTLBs->at(i_tlb_offset)) == true)
			{
				if (
					(this->bDoIContain(pvTLBs->at(i_tlb_offset)) == false) &&
					(pvTLBs->at(i_tlb_offset)->bDoIContain(this) == false)
					)
				{
					pvTLBsOverlappingOffsets->push_back(i_tlb_offset);
				}//if (
			}//if (bAtLeastOneGeneInCommon(pvTLBs->at(i_tlb_offset)) == true)
		}//if  (this  != pvTLBs->at(i_tlb_offset))
	}//for (int i_tlb_offset = 0; i_tlb_offset < pvTLBs->size(); i_tlb_offset++)
}//void  CTightLinkageBlock::vGetOverlappingTLB_Offsets(vector<CTightLinkageBlock *>  *pvTLBs, vector<int> *pvTLBsOverlappingOffsets)



void  CTightLinkageBlock::vGetOverlappingTLBs(vector<CTightLinkageBlock *>  *pvTLBs, vector<CTightLinkageBlock *> *pvTLBsOverlapping)
{
	pvTLBsOverlapping->clear();

	vector<int>  v_candidate_tlb_offsets;
	vGetOverlappingTLB_Offsets(pvTLBs, &v_candidate_tlb_offsets);

	for (int ii = 0; ii < v_candidate_tlb_offsets.size(); ii++)
		pvTLBsOverlapping->push_back(pvTLBs->at(v_candidate_tlb_offsets.at(ii)));
}//void  CTightLinkageBlock::vGetOverlappingTLB_Offsets(vector<CTightLinkageBlock *>  *pvTLBs, vector<int> *pvTLBsOverlappingOffsets)




int  CTightLinkageBlock::iGetOverlappingTLB_Offset(vector<CTightLinkageBlock *>  *pvTLBs)
{
	vector<int>  v_candidate_tlb_offsets;

	vGetOverlappingTLB_Offsets(pvTLBs, &v_candidate_tlb_offsets);

	if (v_candidate_tlb_offsets.size() == 0)  return(-1);

	int  i_chosen_tlb;
	i_chosen_tlb = RandUtils::iRandNumber(0, v_candidate_tlb_offsets.size() - 1);

	return(v_candidate_tlb_offsets.at(i_chosen_tlb));


	/*vector<int>  v_candidate_tlb_offsets;

	for (int i_tlb_offset = 0; i_tlb_offset < pvTLBs->size(); i_tlb_offset++)
	{
		if (this != pvTLBs->at(i_tlb_offset))
		{
			if (bAtLeastOneGeneInCommon(pvTLBs->at(i_tlb_offset)) == true)
			{
				if (
					(this->bDoIContain(pvTLBs->at(i_tlb_offset)) == false) &&
					(pvTLBs->at(i_tlb_offset)->bDoIContain(this) == false)
					)
				{
					v_candidate_tlb_offsets.push_back(i_tlb_offset);
				}//if (
			}//if (bAtLeastOneGeneInCommon(pvTLBs->at(i_tlb_offset)) == true)
		}//if  (this  != pvTLBs->at(i_tlb_offset))
	}//for (int i_tlb_offset = 0; i_tlb_offset < pvTLBs->size(); i_tlb_offset++)

	if (v_candidate_tlb_offsets.size() == 0)  return(-1);

	int  i_chosen_tlb;
	i_chosen_tlb = RandUtils::iRandNumber(0, v_candidate_tlb_offsets.size() - 1);

	return(v_candidate_tlb_offsets.at(i_chosen_tlb));*/
}//int  CTightLinkageBlock::iGetOverlappingTLB_Offset(vector<CTightLinkageBlock *>  *pvTLBs)



void  CTightLinkageBlock::vCreateRandomSubclusters(vector<vector<int> > *pvClusters)
{
	vector<vector<int>>  v_clusters_current_buf;
	vector<int>  v_cluster_buf;

	for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)
	{
		v_cluster_buf.clear();
		v_cluster_buf.push_back(v_tight_linkage_block.at(ii));

		v_clusters_current_buf.push_back(v_cluster_buf);
		pvClusters->push_back(v_cluster_buf);
	}//for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)


	int  i_cluster_to_join_first, i_cluster_to_join_second;
	while (v_clusters_current_buf.size() > 1)
	{
		i_cluster_to_join_first = RandUtils::iRandNumber(0, v_clusters_current_buf.size() - 1);
		i_cluster_to_join_second = RandUtils::iRandNumber(0, v_clusters_current_buf.size() - 2);

		if (i_cluster_to_join_second >= i_cluster_to_join_first)  i_cluster_to_join_second++;

		v_cluster_buf.clear();
		v_cluster_buf = v_clusters_current_buf.at(i_cluster_to_join_first);

		for (int ii = 0; ii < v_clusters_current_buf.at(i_cluster_to_join_second).size(); ii++)
			v_cluster_buf.push_back(v_clusters_current_buf.at(i_cluster_to_join_second).at(ii));

		v_clusters_current_buf.push_back(v_cluster_buf);
		pvClusters->push_back(v_cluster_buf);

		if (i_cluster_to_join_first > i_cluster_to_join_second)
		{
			v_clusters_current_buf.erase(v_clusters_current_buf.begin() + i_cluster_to_join_first);
			v_clusters_current_buf.erase(v_clusters_current_buf.begin() + i_cluster_to_join_second);			
		}//if (i_cluster_to_join_first > i_cluster_to_join_second)
		else
		{
			v_clusters_current_buf.erase(v_clusters_current_buf.begin() + i_cluster_to_join_second);
			v_clusters_current_buf.erase(v_clusters_current_buf.begin() + i_cluster_to_join_first);
		}//else  if (i_cluster_to_join_first > i_cluster_to_join_second)

	}//while (v_clusters_current_buf.size() > 1)
}//void  CTightLinkageBlock::vCreateRandomSubclusters(vector<vector<int> > *pvClusters)



void  CTightLinkageBlock::vSave(FILE  *pfDest)
{
	CString  s_res, s_buf;

	for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)
	{
		s_buf.Format(" %d ", v_tight_linkage_block.at(ii));
		s_res += s_buf;
	}//for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)

	fprintf(pfDest, "%s\n", s_res);
}//void  CTightLinkageBlock::vSave(FILE  *pfDest)


void  CTightLinkageBlock::vSetTLB(vector<int>  *pvTLB)
{
	v_tight_linkage_block = *pvTLB;
	std::sort(v_tight_linkage_block.begin(), v_tight_linkage_block.end(), [](const int cVal0, const int cVal1) -> bool { return(cVal0 < cVal1); });

	//remove repeatations
	bool  b_check_next;
	for (int ii = 0; ii < v_tight_linkage_block.size() - 1; ii++)
	{
		b_check_next = true;
		while (b_check_next == true)
		{
			if (v_tight_linkage_block.at(ii) == v_tight_linkage_block.at(ii + 1))
			{
				v_tight_linkage_block.erase(v_tight_linkage_block.begin() + ii + 1);
				if (ii + 1 >= v_tight_linkage_block.size())  b_check_next = false;
			}//if (v_new_tlb.at(ii) == v_new_tlb.at(ii + 1))
			else
				b_check_next = false;
		}//while (b_check_next == true)
	}//for (int ii = 0; ii < v_new_tlb.size() - 1; ii++)
}//void  CTightLinkageBlock::vSetTLB(vector<int>  *pvTLB)



bool  CTightLinkageBlock::bReadInAndAddToList(int  iSeedGene, vector<CTightLinkageBlock *>  *pvTLBs, int  **piScrapDSM, int iDSMsize, int iStartOffset)
{
	if (iSeedGene >= 0)
	{
		v_tight_linkage_block.clear();
		v_tight_linkage_block.push_back(iSeedGene);
	}//if (iSeedGene >= 0)


	CTightLinkageBlock  *pc_new_tlb;
	vector<int>  v_connected_genes;
	
	int  i_gene_fit_to_tlb;
	for (int i_current_offset = iStartOffset; i_current_offset < iDSMsize; i_current_offset++)
	{
		i_gene_fit_to_tlb = i_check_gene(i_current_offset, piScrapDSM, pvTLBs, &v_connected_genes);
		if (i_gene_fit_to_tlb == 1)
		{
			v_add_gene_to_tlb(i_current_offset);
		}//if (i_gene_fit_to_tlb == 1)

		if (i_gene_fit_to_tlb == 2)
		{
			pc_new_tlb = new CTightLinkageBlock();
			pc_new_tlb->vSetTLB(&v_connected_genes);
			pvTLBs->push_back(pc_new_tlb);
		}//if (i_gene_fit_to_tlb == 2)
	}//for (int i_current_offset = iStartOffset; i_current_offset < iDSMsize; i_current_offset++)


	for (int ii = 0; ii < pvTLBs->size(); ii++)
	{
		if (pvTLBs->at(ii) != this)
		{
			if (pvTLBs->at(ii)->bDoIContain(&v_tight_linkage_block) == true)  return(false);
		}//if  (pvTLBs->at(ii) != this)
	}//for (int ii = 0; ii < pvTLBs->size(); ii++)


	return(true);
}//bool  CTightLinkageBlock::bReadInAndAddToList(int  iSeedGene, vector<CTightLinkageBlock *>  *pvTLBs, int  **piScrapDSM, int iDSMsize, int iStartOffset)



void  CTightLinkageBlock::v_add_gene_to_tlb(int  iNewGeneOffset)
{
	v_tight_linkage_block.push_back(iNewGeneOffset);
	std::sort(v_tight_linkage_block.begin(), v_tight_linkage_block.end(), [](const int cVal0, const int cVal1) -> bool { return(cVal0 < cVal1); });
}//void  CTightLinkageBlock::v_add_gene_to_tlb(int  iNewGeneOffset)



int  CTightLinkageBlock::i_check_gene(int  iGeneToCheck, int  **piScrapDSM, vector<CTightLinkageBlock *>  *pvTLBs, vector<int>  *pvConnectedGenes)
{
	pvConnectedGenes->clear();

	for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)
	{
		if (v_tight_linkage_block.at(ii) == iGeneToCheck)  return(0);
	}//for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)

	
	for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)
	{
		if (piScrapDSM[v_tight_linkage_block.at(ii)][iGeneToCheck] > 0)  pvConnectedGenes->push_back(v_tight_linkage_block.at(ii));
	}//for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)

	if (pvConnectedGenes->size() == 0)  return(0);
	if (pvConnectedGenes->size() == v_tight_linkage_block.size())
	{
		for (int ii = 0; ii < pvTLBs->size(); ii++)
		{
			if (pvTLBs->at(ii) != this)
			{
				if (pvTLBs->at(ii)->bDoIContain(pvConnectedGenes) == true)  return(0);
			}//if (pvTLBs->at(ii) != this)
		}//for (int ii = 0; ii < pvTLBs->size(); ii++)

		return(1);
	}//if (pvConnectedGenes->size() == v_tight_linkage_block.size())

	pvConnectedGenes->push_back(iGeneToCheck);
	std::sort(pvConnectedGenes->begin(), pvConnectedGenes->end(), [](const int cVal0, const int cVal1) -> bool { return(cVal0 < cVal1); });

	for (int ii = 0; ii < pvTLBs->size(); ii++)
	{
		if (pvTLBs->at(ii) != this)
		{
			if (pvTLBs->at(ii)->bDoIContain(pvConnectedGenes) == true) return(0);
		}//if (pvTLBs->at(ii) != this)
	}//for (int ii = 0; ii < pvTLBs->size(); ii++)
	
	return(2);
}//int  CTightLinkageBlock::i_check_gene(int  iGeneToCheck, int  **piScrapDSM, vector<CTightLinkageBlock *>  *pvTLBs)




bool  CTightLinkageBlock::bAtLeastOneGeneDifferent(CTightLinkageBlock  *pcOtherBlock)
{
	return(bAtLeastOneGeneDifferent(&(pcOtherBlock->v_tight_linkage_block)));
}//bool  CTightLinkageBlock::bAtLeastOneGeneDifferent(CTightLinkageBlock  *pcOtherBlock)


bool  CTightLinkageBlock::bAtLeastOneGeneDifferent(vector<int>  *pvConnectedGenes)
{
	if (v_tight_linkage_block.size() == 0) return(false);

	int  i_this_offset, i_other_offset;

	i_this_offset = 0;
	i_other_offset = 0;

	while
		(
		(i_this_offset < v_tight_linkage_block.size()) &&
			(i_other_offset < pvConnectedGenes->size())
			)
	{
		if (v_tight_linkage_block.at(i_this_offset) == pvConnectedGenes->at(i_other_offset))
		{
			i_this_offset++;
			i_other_offset++;
			if (i_this_offset >= v_tight_linkage_block.size())  return(false);
		}//if (v_tight_linkage_block.at(i_this_offset) == pvConnectedGenes->at(i_other_offset))
		else
		{
			if (v_tight_linkage_block.at(i_this_offset) < pvConnectedGenes->at(i_other_offset))
				return(true);
			else
				i_other_offset++;
		}//else  if (v_tight_linkage_block.at(i_this_offset) == pvConnectedGenes->at(i_other_offset))
	}//while


	return(true);
}//bool  bAtLeastOneGeneInCommon(vector<int>  *pvConnectedGenes)


void  CTightLinkageBlock::vGetGenesInCommon(vector<int>  *pvCluster, vector<int>  *pvGenesInCommon)
{
	pvGenesInCommon->clear();
	if (v_tight_linkage_block.size() == 0) return;
	if (pvCluster->size() == 0) return;

	int  i_this_offset, i_other_offset;
	i_this_offset = 0;
	i_other_offset = 0;

	while
		(
		(i_this_offset < v_tight_linkage_block.size()) &&
			(i_other_offset < pvCluster->size())
			)
	{
		if (v_tight_linkage_block.at(i_this_offset) == pvCluster->at(i_other_offset))
		{
			pvGenesInCommon->push_back(v_tight_linkage_block.at(i_this_offset));
		}//if (v_tight_linkage_block.at(i_this_offset) == pvCluster->at(i_other_offset))

		if (v_tight_linkage_block.at(i_this_offset) < pvCluster->at(i_other_offset))
			i_this_offset++;
		else
			i_other_offset++;
	}//while


}//void  CTightLinkageBlock::vGetGenesInCommon(vector<int>  *pvCluster, vector<int>  *pvGenesInCommon)


bool  CTightLinkageBlock::bAtLeastOneGeneInCommon(vector<int>  *pvConnectedGenes)
{
	if (v_tight_linkage_block.size() == 0) return(false);

	int  i_this_offset, i_other_offset;

	i_this_offset = 0;
	i_other_offset = 0;

	while
		(
		(i_this_offset < v_tight_linkage_block.size()) &&
		(i_other_offset < pvConnectedGenes->size())
		)
	{
		if (v_tight_linkage_block.at(i_this_offset) == pvConnectedGenes->at(i_other_offset))  return(true);

		if (v_tight_linkage_block.at(i_this_offset) < pvConnectedGenes->at(i_other_offset))
			i_this_offset++;
		else
			i_other_offset++;
	}//while
	

	return(false);
}//bool  bAtLeastOneGeneInCommon(vector<int>  *pvConnectedGenes)

bool  CTightLinkageBlock::bAtLeastOneGeneInCommon(CTightLinkageBlock  *pcOtherBlock)
{
	return(bAtLeastOneGeneInCommon(&(pcOtherBlock->v_tight_linkage_block)));
}//bool  CTightLinkageBlock::bAtLeastOneGeneInCommon(CTightLinkageBlock  *pcOtherBlock)


bool  CTightLinkageBlock::bDoIContain(vector<int>  *pvConnectedGenes)
{
	if (v_tight_linkage_block.size() == 0) return(false);

	int  i_this_offset;

	i_this_offset = 0;
	for (int ii = 0; ii < pvConnectedGenes->size(); ii++)
	{
		while (
			(i_this_offset < v_tight_linkage_block.size()) &&
			(pvConnectedGenes->at(ii) != v_tight_linkage_block.at(i_this_offset))
			)
		{
			i_this_offset++;
			if (i_this_offset >= v_tight_linkage_block.size())  return(false);
		}//while (
	}//for (int ii = 0; ii < pvConnectedGenes->size(); ii++)


	return(true);
}//bool  CTightLinkageBlock::bDoIContain(vector<int>  *pvConnectedGenes)


bool  CTightLinkageBlock::bDoIContain(CTightLinkageBlock  *pcOtherBlock)
{
	return(bDoIContain(&(pcOtherBlock->v_tight_linkage_block)));
}//bool  CTightLinkageBlock::bDoIContain(CTightLinkageBlock  *pcOtherBlock)


bool  CTightLinkageBlock::bTheSame(vector<int>  *pvConnectedGenes)
{
	if (v_tight_linkage_block.size() != pvConnectedGenes->size())  return(false);
	
	for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)
	{
		if (v_tight_linkage_block.at(ii) != pvConnectedGenes->at(ii))  return(false);
	}//for (int ii = 0; ii < v_tight_linkage_block.size(); ii++)

	return(true);
}//bool  CTightLinkageBlock::bTheSame(vector<int>  *pvConnectedGenes)



bool  CTightLinkageBlock::bTheSame(CTightLinkageBlock  *pcOtherBlock)
{
	return(bTheSame(&(pcOtherBlock->v_tight_linkage_block)));
}//bool  CTightLinkageBlock::bTheSame(vector<int>  *pvConnectedGenes)



bool  CTightLinkageBlock::bTheSameInTheList(vector<CTightLinkageBlock *>  *pvTLBs)
{
	for (int ii = 0; ii < pvTLBs->size(); ii++)
	{
		if (bTheSame(pvTLBs->at(ii)) == true)  return(true);
	}//for (int ii = 0; ii < pvTLBs->size(); ii++)

	return(false);
}//bool  CTightLinkageBlock::bTheSameInTheList(vector<CTightLinkageBlock *>  *pvTLBs)






uint32_t CLinkageAnalyzer::iERROR_PARENT_CLINKAGE_ANALYZER = CError::iADD_ERROR_PARENT("CLinkageAnalyzer");

uint32_t CLinkageAnalyzerSingleDSM::iERROR_PARENT_CLINKAGE_ANALYZER_SINGLE_DSM = CError::iADD_ERROR_PARENT("CLinkageAnalyzerSingleDSM");
uint32_t CLinkageAnalyzerSingleDSM::iERROR_CODE_LINKAGE_ANALYZER_DIFFERENT_REGISTERED_DSM_LENGTHS = CError::iADD_ERROR("iERROR_CODE_LINKAGE_ANALYZER_DIFFERENT_REGISTERED_DSM_LENGTHS");
uint32_t CLinkageAnalyzerSingleDSM::iERROR_CODE_LINKAGE_ANALYZER_NO_EXTERNAL_DSMS = CError::iADD_ERROR("iERROR_CODE_LINKAGE_ANALYZER_NO_EXTERNAL_DSMS");
uint32_t CLinkageAnalyzerSingleDSM::iERROR_CODE_LINKAGE_ANALYZER_DMS_ZERO_SIZE = CError::iADD_ERROR("iERROR_CODE_LINKAGE_ANALYZER_DMS_ZERO_SIZE");


