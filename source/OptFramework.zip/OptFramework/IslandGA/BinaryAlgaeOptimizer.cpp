#include "BinaryAlgaeOptimizer.h"

uint32_t CBinaryAlgaeOptimizer::iERROR_PARENT_CBinaryAlgaeOptimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_CBinaryAlgaeOptimizer");
const uint32_t CBinaryAlgaeOptimizer::I_DEFAULT_POPULATION_SIZE = 20;
const float CBinaryAlgaeOptimizer::F_DEFAULT_NR = 0.33;
const float CBinaryAlgaeOptimizer::F_DEFAULT_ENERGY_LOSS = 0.3;
const float CBinaryAlgaeOptimizer::F_DEFAULT_ADAPTATION = 0.5;


CBinaryAlgaeOptimizer::CBinaryAlgaeOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed) :
	CPopulationSizingSingleOptimizer(pcProblem, pcLog, iRandomSeed),
	c_uniform_distribution(0, 1),
	v_population(I_DEFAULT_POPULATION_SIZE, nullptr)
{
	c_random_engine.seed(iRandomSeed);

	i_genotype_length = pcProblem->pcGetEvaluation()->iGetNumberOfElements();
	i_population_size = I_DEFAULT_POPULATION_SIZE;

	d_nr = static_cast<double>(F_DEFAULT_NR);
	d_energy_loss = static_cast<double>(F_DEFAULT_ENERGY_LOSS);
	d_adaptation = static_cast<double>(F_DEFAULT_ADAPTATION);

	pc_best = nullptr;
	
}//CBinaryAlgaeOptimizer::CBinaryAlgaeOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)

CBinaryAlgaeOptimizer::CBinaryAlgaeOptimizer(CBinaryAlgaeOptimizer * pcOther) :
	CPopulationSizingSingleOptimizer(pcOther),
	v_population(pcOther->v_population.size(), nullptr),
	c_uniform_distribution(pcOther->c_uniform_distribution),
	c_random_engine(pcOther->c_random_engine)
{
	i_genotype_length = pcOther->i_genotype_length;
	i_population_size = pcOther->i_population_size;
	d_nr = pcOther->d_nr;
	d_energy_loss = pcOther->d_energy_loss;
	d_adaptation = pcOther->d_adaptation;
	pc_best = pcOther->pc_best != nullptr ? new CBinaryAlgaeIndividual(pcOther->pc_best) : nullptr;
	d_best_fitness = pcOther->d_best_fitness;
	b_use_stale_detection - pcOther->b_use_stale_detection;

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		if (pcOther->v_population[ii] != nullptr)
		{
			v_population[ii] = new CBinaryAlgaeIndividual(pcOther->v_population[ii]);
		}//if (pcOther->v_population[ii] != nullptr)
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//CBinaryAlgaeOptimizer::CBinaryAlgaeOptimizer(CBinaryAlgaeOptimizer * pcOther)

CBinaryAlgaeOptimizer::~CBinaryAlgaeOptimizer()
{
	v_delete_population();
}//CBinaryAlgaeOptimizer::~CBinaryAlgaeOptimizer()

COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryAlgaeOptimizer::pcCopy()
{
	return new CBinaryAlgaeOptimizer(this);
}//COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryAlgaeOptimizer::pcCopy()

CError CBinaryAlgaeOptimizer::eConfigure(istream * psSettings)
{
	CError c_error(iERROR_PARENT_CBinaryAlgaeOptimizer);
	c_error = COptimizer::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_population_size(BINARY_ALGAE_OPTIMIZER_ARGUMENT_POPULATION_SIZE, 2, UINT32_MAX, I_DEFAULT_POPULATION_SIZE);
		i_population_size = p_population_size.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_nr(BINARY_ALGAE_OPTIMIZER_ARGUMENT_NR, F_DEFAULT_NR);
		d_nr = static_cast<double>(p_nr.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_energy_loss(BINARY_ALGAE_OPTIMIZER_ARGUMENT_ENERGY_LOSS, F_DEFAULT_ENERGY_LOSS);
		d_energy_loss = static_cast<double>(p_energy_loss.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_adaptation(BINARY_ALGAE_OPTIMIZER_ARGUMENT_ADAPTATION, F_DEFAULT_ADAPTATION);
		d_adaptation = static_cast<double>(p_adaptation.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CBoolCommandParam p_stale_detection(BINARY_ALGAE_OPTIMIZER_ARGUMENT_STALE_DETECTION, true, false);
		b_use_stale_detection = p_stale_detection.bGetValue(psSettings, &c_error);
	}//if (!c_error)

	return c_error;
}//CError CBinaryAlgaeOptimizer::eConfigure(istream * psSettings)

bool CBinaryAlgaeOptimizer::bRunIteration(uint32_t iIterationNumber)
{
	v_helical_movement_phase();

	v_calculate_size();
	v_calculate_energy();

	v_evaluation_phase();
	v_adaptation_phase();

	vEvaluate();

	v_update_best();

	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->d_fitness, [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->v_genotype[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});

	v_calculate_size();
	v_calculate_energy();

	CString s_log_message;
	s_log_message.Format(
		"Best fitness: %f; ffe: %llu; time: %.2lf; population size: %u",
		pc_best_individual->dGetFitnessValue(),
		pc_problem->pcGetEvaluation()->iGetFFE(),
		c_optimizer_timer.dGetTimePassed(),
		i_population_size);
	pc_log->vPrintLine(s_log_message, true);

	return b_updated;
}//bool CBinaryAlgaeOptimizer::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

void CBinaryAlgaeOptimizer::vInitialize()
{
	vResetBestIndividual();
	v_delete_population();
	v_initialize_population();
	v_update_best();
	v_calculate_size();
	v_calculate_energy();
}//void CBinaryAlgaeOptimizer::vInitialize(time_t tStartTime)

void CBinaryAlgaeOptimizer::vEvaluate()
{
	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		d_evaluate(v_population[ii]);
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void CBinaryAlgaeOptimizer::vEvaluate()

bool CBinaryAlgaeOptimizer::bIsSteadyState()
{
	if (!b_use_stale_detection)
	{
		return false;
	}//if (!b_stale_detection)

	bool b_different_found = false;

	for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)
	{
		bool b_all_same = true;

		for (size_t j = 0; b_all_same && j < i_genotype_length; j++)
		{
			if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
			{
				b_all_same = false;
			}//if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
		}//for (size_t j = 0; b_all_same && j < i_genotype_length; j++)

		if (!b_all_same)
		{
			b_different_found = true;
		}//if (!b_all_same)
	}//for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)

	return !b_different_found;
}//bool CBinaryAlgaeOptimizer::bIsSteadyState()

double CBinaryAlgaeOptimizer::dComputeAverageFitnessValue()
{
	double d_fitness_sum = 0;

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		d_fitness_sum += v_population[ii]->d_fitness;
	}//for (size_t ii = 0; ii < v_population.size(); ii++)

	return d_fitness_sum / static_cast<double>(v_population.size());
}//double DBinaryPSOOptimizer::dComputeAverageFitnessValue()

void CBinaryAlgaeOptimizer::v_delete_population()
{
	delete pc_best;
	pc_best = nullptr;

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		delete v_population[ii];
		v_population[ii] = nullptr;
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void CBinaryAlgaeOptimizer::v_delete_population()

void CBinaryAlgaeOptimizer::v_initialize_population()
{
	v_population.clear();

	for (uint32_t ii = 0; ii < i_population_size; ii++)
	{
		v_population.push_back(
			CBinaryAlgaeIndividual::pcGetRandomIndividual(
				i_genotype_length,
				c_uniform_distribution,
				c_random_engine
			)
		);
	}//for (uint32_t ii = 0; ii < i_population_size; ii++)

	vEvaluate();
}//void CBinaryAlgaeOptimizer::v_initialize_population()

double CBinaryAlgaeOptimizer::d_evaluate(CBinaryAlgaeIndividual * pc_individual)
{
	CBinaryCoding c_coding(i_genotype_length, pc_individual->v_genotype.data());
	double d_fitness_value = pcGetProblem()->pcGetEvaluation()->dEvaluate(&c_coding);
	pc_individual->d_fitness = d_fitness_value;

	return d_fitness_value;
}//double CBinaryAlgaeOptimizer::d_evaluate(CBinaryAlgaeIndividual * pc_individual)

void CBinaryAlgaeOptimizer::v_update_best()
{
	uint32_t i_best_id = 0;

	for (uint32_t ii = 1; ii < i_population_size; ii++)
	{
		if (pc_problem->bIsBetterFitnessValue(v_population[ii]->d_fitness, v_population[i_best_id]->d_fitness))
		{
			i_best_id = ii;
		}//if (pc_problem->bIsBetterFitnessValue(v_population[ii]->d_fitness, v_population[i_best_id]->d_fitness))
	}//for (uint32_t ii = 1; ii < i_population_size; ii++)

	delete pc_best;
	pc_best = new CBinaryAlgaeIndividual(v_population[i_best_id]);
	d_best_fitness = pc_best->d_fitness;
}//void CBinaryAlgaeOptimizer::v_update_best()

void CBinaryAlgaeOptimizer::v_helical_movement_phase()
{
	uniform_int_distribution<uint32_t> c_neighbours_distribution(0, i_population_size - 1);
	uniform_int_distribution<uint16_t> c_gene_distribution(0, i_genotype_length - 1);

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		bool b_found_anything = false;
		while (v_population[ii]->d_energy > 0)
		{
			uint32_t i_neighbour = c_neighbours_distribution(c_random_engine);
			while (i_neighbour == ii)
			{
				i_neighbour = c_neighbours_distribution(c_random_engine);
			}//while (i_neighbour == ii)

			vector<uint16_t> v_genes;

			while (v_genes.size() < 3)
			{
				uint16_t i_gene = c_gene_distribution(c_random_engine);

				if (find(v_genes.begin(), v_genes.end(), i_gene) == v_genes.end())
				{
					v_genes.push_back(i_gene);
				}//if (find(v_genes.begin(), v_genes.end(), i_gene) == v_genes.end())
			}//while (v_genes.size() < 3)

			vector<int32_t> v_new_genotype = v_population[ii]->v_genotype;

			for (size_t ig = 0; ig < v_genes.size(); ig++)
			{
				if (c_uniform_distribution(c_random_engine) > d_nr)
				{
					v_new_genotype[v_genes[ig]] = v_population[i_neighbour]->v_genotype[v_genes[ig]];
				}//if (pc_uniform_distribution(pc_random_engine) > d_nr)
				else
				{
					v_new_genotype[v_genes[ig]] = 1 - v_population[i_neighbour]->v_genotype[v_genes[ig]];
				}//else if (pc_uniform_distribution(pc_random_engine) > d_nr)
			}//for (size_t ig = 0; ig < v_genes.size(); ig++)

			v_population[ii]->d_energy -= d_energy_loss / 2;

			CBinaryCoding c_coding(i_genotype_length, v_new_genotype.data());
			double d_new_fitness = pcGetProblem()->pcGetEvaluation()->dEvaluate(&c_coding);

			if (pc_problem->bIsBetterFitnessValue(d_new_fitness, v_population[ii]->d_fitness))
			{
				v_population[ii]->v_genotype = v_new_genotype;
				v_population[ii]->d_fitness = d_new_fitness;
				b_found_anything = true;
			}//if (pc_problem->bIsBetterFitnessValue(d_new_fitness, d_evaluate(v_population[ii])))
			else
			{
				v_population[ii]->d_energy -= d_energy_loss / 2;
			}//else if (pc_problem->bIsBetterFitnessValue(d_new_fitness, d_evaluate(v_population[ii])))
		}//while (v_population[ii]->d_energy > 0)

		if (!b_found_anything)
		{
			v_population[ii]->i_starvation++;
		}//if (!b_found_anything)

	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void CBinaryAlgaeOptimizer::v_helical_movement_phase()

void CBinaryAlgaeOptimizer::v_evaluation_phase()
{
	uniform_int_distribution<uint16_t> c_gene_distribution(0, i_genotype_length - 1);

	uint32_t i_biggest = 0;
	uint32_t i_smallest = 0;

	for (size_t ii = 1; ii < v_population.size(); ii++)
	{
		if (v_population[ii]->d_size < v_population[i_smallest]->d_size)
		{
			i_smallest = ii;
		}//if (v_population[ii]->d_size < v_population[i_smallest]->d_size)

		if (v_population[ii]->d_size > v_population[i_biggest]->d_size)
		{
			i_biggest = ii;
		}//if (v_population[ii]->d_size > v_population[i_biggest]->d_size)
	}//for (size_t ii = 1; ii < v_population.size(); ii++)

	uint16_t i_gene = c_gene_distribution(c_random_engine);

	v_population[i_smallest]->v_genotype[i_gene] = v_population[i_biggest]->v_genotype[i_gene];
}//void CBinaryAlgaeOptimizer::v_evaluation_phase()

void CBinaryAlgaeOptimizer::v_adaptation_phase()
{
	uint32_t i_starved = 0;
	uint32_t i_biggest = 0;

	for (size_t ii = 1; ii < v_population.size(); ii++)
	{
		if (v_population[ii]->i_starvation > v_population[i_starved]->i_starvation)
		{
			i_starved = ii;
		}//if (v_population[ii]->i_starvation > v_population[i_starved]->i_starvation)

		if (v_population[ii]->d_size > v_population[i_biggest]->d_size)
		{
			i_biggest = ii;
		}//if (v_population[ii]->d_size > v_population[i_biggest]->d_size)
	}//for (size_t ii = 1; ii < v_population.size(); ii++)

	for (uint16_t ii = 0; ii < i_genotype_length; ii++)
	{
		if (c_uniform_distribution(c_random_engine) < d_adaptation)
		{
			v_population[i_starved]->v_genotype[ii] = v_population[i_biggest]->v_genotype[ii];
		}//if (pc_uniform_distribution(pc_random_engine) < d_adaptation)
	}//for (uint16_t ii = 0; ii < i_genotype_length; ii++)
}//void CBinaryAlgaeOptimizer::v_adaptation_phase()

void CBinaryAlgaeOptimizer::v_calculate_energy()
{
	vector<uint32_t> v_order(v_population.size());
	iota(v_order.begin(), v_order.end(), 0);

	double max_value = v_population.size() * v_population.size();
	double min_value = 1.;

	for (size_t i = 0; i < v_order.size() - 1; i++)
	{
		for (size_t j = i + 1; j < v_order.size(); j++)
		{
			if (v_population[v_order[i]]->d_size > v_population[v_order[j]]->d_size)
			{
				swap(v_order[i], v_order[j]);
			}//if (v_population[order[i]]->d_size > v_population[order[j]]->d_size)
		}//for (size_t j = i + 1; j < order.size(); j++)

		v_population[v_order[i]]->d_energy = ((i + 1.) * (i + 1.) - min_value) / (max_value - min_value);
	}//for (size_t i = 0; i < order.size() - 1; i++)

	v_population[v_order.back()]->d_energy = 1.;
}//void CBinaryAlgaeOptimizer::v_calculate_energy()

void CBinaryAlgaeOptimizer::v_calculate_size()
{
	double d_max_fitness = v_population[0]->d_fitness;
	double d_min_fitness = v_population[0]->d_fitness;

	for (size_t ii = 1; ii < v_population.size(); ii++)
	{
		if (v_population[ii]->d_fitness < d_min_fitness)
		{
			d_min_fitness = v_population[ii]->d_fitness;
		}//if (v_population[ii]->d_fitness < d_min_fitness)
		if (v_population[ii]->d_fitness > d_max_fitness)
		{
			d_max_fitness = v_population[ii]->d_fitness;
		}//if (v_population[ii]->d_fitness > d_max_fitness)
	}//for (size_t ii = 1; ii < v_population.size(); ii++)

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		v_population[ii]->vUpdateRelativeFitness(d_max_fitness, d_min_fitness);
		v_population[ii]->vUpdateSize();
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void CBinaryAlgaeOptimizer::v_calculate_size()

//////////////////////////////////////////////////////////////////////////

CBinaryAlgaeIndividual::CBinaryAlgaeIndividual(uint16_t iGenotypeLength) :
	v_genotype(iGenotypeLength, static_cast<uint16_t>(0))
{
	this->d_size = 1;
	this->i_starvation = 0;
}//CBinaryAlgaeIndividual::CBinaryAlgaeIndividual(uint16_t iGenotypeLength)

CBinaryAlgaeIndividual::CBinaryAlgaeIndividual(CBinaryAlgaeIndividual * pcOther)
{
	this->d_fitness = pcOther->d_fitness;
	this->d_size = pcOther->d_size;
	this->i_starvation = pcOther->i_starvation;
	this->d_energy = pcOther->d_energy;
	this->d_relative_fitness = pcOther->d_relative_fitness;
	
	this->v_genotype = pcOther->v_genotype;
}//CBinaryAlgaeIndividual::CBinaryAlgaeIndividual(CBinaryAlgaeIndividual * pcOther)

CBinaryAlgaeIndividual * CBinaryAlgaeIndividual::pcGetRandomIndividual(uint16_t iGenotypeLength, uniform_real_distribution<double>& cUniformDistribution, default_random_engine & cRandomEngine)
{
	CBinaryAlgaeIndividual* pc_individual = new CBinaryAlgaeIndividual(iGenotypeLength);

	for (uint16_t ii = 0; ii < iGenotypeLength; ii++)
	{
		pc_individual->v_genotype[ii] = cUniformDistribution(cRandomEngine) > 0.5 ? 1 : 0;
	}//for (uint16_t ii = 0; ii < iGenotypeLength; ii++)

	return pc_individual;
}//CBinaryAlgaeIndividual * CBinaryAlgaeIndividual::pcGetRandomIndividual(uint16_t iGenotypeLength, uniform_real_distribution<double>& pcUniformDistribution, default_random_engine & pcRandomEngine)

void CBinaryAlgaeIndividual::vUpdateRelativeFitness(double dBestFitness, double dWorstFitness)
{
	d_relative_fitness = 1 - (d_fitness - dWorstFitness) / (dBestFitness - dWorstFitness);
}//void CBinaryAlgaeIndividual::vUpdateRelativeFitness(double dBestFitness, double dWorstFitness)

void CBinaryAlgaeIndividual::vUpdateSize()
{
	double d_mu = d_relative_fitness / (d_size / 2 - d_relative_fitness);
	d_size = d_size + d_mu * d_size;
}//void CBinaryAlgaeIndividual::vUpdateSize()
