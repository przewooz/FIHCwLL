#ifndef LINKAGE_ANALYZER_H
#define LINKAGE_ANALYZER_H

#define LINKAGE_ANALYZER_POSTFIX "_LinkageAnalyzer.txt"
#define LINKAGE_ANALYZER_JOINT_DSM "_JOINED_"
#define LINKAGE_ANALYZER_SHARED_DSM_PREFIX "_sh_"

#define LINKAGE_ANALYZER_DEBUG false

#include "Error.h"

#include <atlstr.h>
#include <cstdint>
#include <ostream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <array>
#include <cmath>
#include <numeric>

#include  <functional>
#include  <algorithm>

#include "UIntCommandParam.h"
#include "FloatCommandParam.h"

#include "RandUtils.h"
#include "MathUtils.h"

#include  "util\tools.h"


#include "..\DSMGA2\trimatrix.h"
#include "..\DSMGA2\trimatrixpair.h"



#include "../IslandGA/BinaryCoding.h"
#include "../IslandGA/Evaluation.h"
#include "../IslandGA/Log.h"
#include "../IslandGA/LinkageAnalyzer.h"

using namespace std;



class  CLinkageAnalyzerMemorySet;
class  CSeparableBlockDetection;


#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_FREQUENCY "linkageAnalyzerFrequency"
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_LINKAGE_MODE "linkageAnalyzerOutsideLinkageMode (0-DLED; 1-FixedLinkageQuality; 2-Measure; 3-Random; 4-Hybrid=SLL+DLED; 5-Mix=DLED+SLL; 6-Mix=DLED+SLL+HLL; 7-SLL; 8-DirectionalLinkage; 9-TLB)"
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_LINKAGE_REPRESENTATION "linkageAnalyzerLinkageRepresentation (0-LTree; 1-TightLinkageBlocks)"
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_FORCE_FULL_REPORT "forceFullLinkReport"
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY "linkageAnalyzerOutsideFillQuality"
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_DIVERSE "linkageAnalyzerOutsideDiverse (-2-single -1-at every population iteration; >0 probability at crossover)"

#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_FAST_3LO 0
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_FIXED_LINKAGE 1
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_MEASURE 2
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_RANDOM 3
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_HLL 4
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_MIX_DLED_SLL 5
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_MIX_DLED_SLL_HLL 6
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_SLL 7
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_DIRECTIONAL_LINKAGE 8
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_PERFECT_TIGHT_LINKAGE_BLOCKS 9

#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_LINKAGE_REPRESENTATION_LTREE 0
#define OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_LINKAGE_REPRESENTATION_TIGHT_LINKAGE_BLOCKS 1


#define OPT_LINK_QUALITY_FILL_MIN "{LinkQualityFill_Min}"
#define OPT_LINK_QUALITY_FILL_MAX "{LinkQualityFill_Max}"
#define OPT_LINK_QUALITY_FILL_AVR "{LinkQualityFill_Avr}"
#define OPT_LINK_QUALITY_FILL_MEDIAN "{LinkQualityFill_Median}"
#define OPT_LINK_QUALITY_MAX_HOP "{maxHop}"
#define OPT_LINK_QUALITY_AVR_HOP "{avrHop}"
#define OPT_LINK_QUALITY_AVR_DIFFERENT_WAYS "{DifferentWaysHop2avrAvr}"
#define OPT_LINK_QUALITY_AVR_DIFFERENT_WAYS_MIN "{DifferentWaysHop2minAvr}"
#define OPT_LINK_QUALITY_AVR_DIFFERENT_WAYS_MAX "{DifferentWaysHop2maxAvr}"
#define OPT_LINK_QUALITY_AVR_DIFFERENT_WAYS_MED "{DifferentWaysHop2medAvr}"
#define OPT_LINK_QUALITY_AVR_DIFFERENT_WAYS_MED3 "{DifferentWaysHop2med3Avr}"
#define OPT_LINK_QUALITY_AVR_DIFFERENT_WAYS_AVR3 "{DifferentWaysHop2avr3Avr}"



#define OPT_LINK_COST_TIME "{LinkCost_Time}"
#define OPT_LINK_COST_FFE "{LinkCost_FFE}"

#define OPT_LINK_COST_TIME_LSWLL_ADDITIONAL "{LinkCost_Time_LSwLL_Additional}"
#define OPT_LINK_COST_FFE_LSWLL_ADDITIONAL "{LinkCost_FFE_LSwLL_Additional}"


class  CLinkageInformationPack;
class  CLinkageInformationPackIndividual;
class  CLinkageInformationPackGeneFreq;
class  CLinkageInformationPackGeneFreqValue;
class  CLinkageInformationPackLinkageScrap;
class  CTightLinkageBlockSupervisor;
class  CTightLinkageBlock;

class  CDirectional_DSM_Group;
class  CDirectional_DSM;
class  CDirectional_LTreeNode;


class CLinkageAnalyzer
{
	friend class CLinkageAnalyzerSingleDSM;
	friend class CLinkageInformationPack;
public:
	static uint32_t iERROR_PARENT_CLinkageAnalyzer;
	//static uint32_t iERROR_CODE_CMO_EmPfDec_UNKNOWN_DECOMPOSITION_TYPE;

	CLinkageAnalyzer();
	~CLinkageAnalyzer();

	void vTest();
	void  vCheckSize();

	CLinkageAnalyzerSingleDSM  *pcGetLinkageToShare() { return(pc_linkage_to_share); }

	vector<CLinkageAnalyzerSingleDSM  *>  *pvGetDSM_Sets() { return(&v_dsm_sets); }

	CError eConfigure(istream *psSettings);

	void  vRegisterExternalLinkage(CLinkageAnalyzer  *pcExternalLinkage) { v_external_linkage_analyzers.push_back(pcExternalLinkage); }

	void  vRecomputeDiscretizedDSM(int  iLinkLevel);
	void  vRecomputeDSM_PairingRankings(int  iLinkLevel);
	void  vGetReproducedDSM_P3(int  iLinkLevel, unordered_map<int, unordered_map<int, double> > *pcDestination);

	void  vSetP3DSM(int  iLinkLevel, int  iSize, unordered_map<int, unordered_map<int, double> > *pcDSM);
	void  vSetP3Clusters(int  iLinkLevel, vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering);
	vector<vector<int> > *pvGetP3Clusters(int  iLinkLevel);
	vector<int> *pvGetP3ClusterOrdering(int  iLinkLevel);
	void  vSetTrueLinkage(vector<vector <int>>  *pvDependentGenes);

	void  vSetLinkDataPackDSM(int  iLinkLevel, int  iSize, double **pdDSM, int iDSM_size, CString  sAdditionalName = "");
	void  vSetLTGA_DSM(int  iLinkLevel, int  iSize, double **pdDSM, int iDSM_size);
	void  vSetDSMGA2_DSM(int  iLinkLevel, int  iSize, TriMatrix<double> *pvDSM, int iDSM_size);

	void  vSetOutsideLinkage(int  iLinkLevel, int  iSize, int iDSM_size);
	bool  bGetLinkageDiscoveryProbabilities(double  *pdAvr, double *pdMin, double *pdMax, double  *pdLinkageFill, int iProblemSize);
		

	void  vSetName(CString  sNewName) { s_name = sNewName; };
	void  vSaveLinkageReport(CString  sLinkageReportFile, CString  sAdditionalPstfix);
	void  vSaveLinkageReportJOINT(CString  sLinkageReportFile);

	void  vCreatePairsReportAndFlushDependentPairs();
	void  vUpdateSingleMemorySet();


	CString  sSummaryReport();
	CString  sGeneralCurrentReport();
	int  iGetPairsDetection(int  iDetectionType);

	int  iGetLinkageAnalyzerFrequency() { return(i_analyzer_iterations_frequency); };


	double  dGetOutsideLinkageQuality() { return(d_outside_linkage_quality); }
	double  dGetOutsideLinkageDiverse() { return(d_outside_linkage_diverse); }

	vector<CLinkageAnalyzerMemorySet  *>  *pvGetMemorySets() { return(&v_memory_sets); };

	void  vResetProbabilities(int  iProblemSize);
	int  iGetOutsideLinkageMode() { return(i_outside_linkage_mode); };
	int  iGetLinkageRepresentation() { return(i_outside_linkage_representation); };
	bool  bIsOutsideModeLinkageGenerating();

	bool  bLinkagePackCreate(CLinkageInformationPack **pcNewLinkagePack);
	void  vRegisterPackForP3(CLinkageInformationPack *pcP3LinkagePack) { pc_p3_linkage_pack = pcP3LinkagePack; };
	CLinkageInformationPack *pcGetLinkagePackForP3() { return(pc_p3_linkage_pack); };

private:

	static uint32_t iERROR_PARENT_CLINKAGE_ANALYZER;

	void  v_save_linkage_report_for_single_dsm(CString  sSingleDSM_LinkageReportFile, CString  sDSMname, CLinkageAnalyzerSingleDSM  *pcSingleDSManalyzer, FILE  *pfGeneralReport);

	
	CLinkageAnalyzerSingleDSM  *pc_linkage_to_share;
	vector<CLinkageAnalyzerSingleDSM  *>  v_dsm_sets;
	vector<vector <int>>  v_true_linkage;

	vector<CLinkageAnalyzer  *>  v_external_linkage_analyzers;


	vector<CLinkageAnalyzerMemorySet  *>  v_memory_sets;


	double  d_outside_linkage_quality;
	double  d_outside_linkage_diverse;
	int  i_outside_linkage_mode;
	int  i_outside_linkage_representation;
	int  i_linkage_force_full_report;

	CString  s_name;

	int  i_analyzer_iterations_frequency;
	int  i_registered_iterations;


	//for fast 3lo
	double  *pd_linkage_gathering_probabilities;
	int     *pi_no_linkage_for_gene;
	vector <CLinkageInformationPackLinkageScrap *> v_global_linkage_scraps;
	CLinkageInformationPack *pc_p3_linkage_pack;

	double  d_linkage_cost_ffe;
	double  d_linkage_cost_time;


};//class CLinkageAnalyzer





class  CLinkageAnalyzerDependentPair
{
public:
	int  iFirstGene;
	int  iSecondGene;

	bool  bDependencyTrue;

	double  d_dependency;
};//class  CLinkageAnalyzerDependentPair



class  CLinkageAnalyzerMemorySet
{
public:
	CLinkageAnalyzerMemorySet() {};

	CString  sGeneralCurrentReport();
	void  vSave(FILE  *pfDest);
	void  vComputeTrueFalseDependencies(double  dMaxDependencyRange, int *piTrue, int *piFalse, double  *pdPerc);

	int  iGetPairsDetection(int  iDetectionType);


	int  i_level;
	int  i_pop_size;
	CString  s_additional_name;

	double  d_overhead_avr, d_overhead_median, d_overhead_min, d_overhead_max;
	double  d_fill_avr, d_fill_median, d_fill_min, d_fill_max;


	vector<CSeparableBlockDetection *>  v_full_blocks_detection;
	vector<CLinkageAnalyzerDependentPair>  v_strict_dependent_set;
};//class  CLinkageAnalyzerMemorySet


#define  LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_FULL  2
#define  LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_PART  1
#define  LINKAGE_ANALYZER_SEPRABLE_BLOCK_DETECTION_NONE  0
class  CSeparableBlockDetection
{
public:
	int  iDetectionLevel();//2-FULL  1-Partial  0-none

	int  i_gene_first;
	int  i_gene_last;
	double  d_detection_fill_avr;
	int  i_part_detections;
	
};//class  CSeparableBlockDetection





class CLinkageAnalyzerSingleDSM
{
	friend class CLinkageAnalyzer;
	public:
		CLinkageAnalyzerSingleDSM(CLinkageAnalyzer  *pcParent, CString  sAdditionalName = "");
		~CLinkageAnalyzerSingleDSM();

		void  vSetPopSize(int  iNewPopSize) { i_pop_size = iNewPopSize; };
		void  vCreateDSMofSize(int  iSize);

		CError  eCreteJOINED_DSM(vector<CLinkageAnalyzer  *>  *pvExternalLinkageAnalyzers);
		void  vSetPerfectDSM(int  **piDSM, int iDSM_size);
		void  vSetP3DSM(unordered_map<int, unordered_map<int, double> > *pcDSM);
		void  vSetP3Clusters(vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering);
		void  vSetClusters(vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering, bool  bAccumulateClusters, int iProblemSize, bool bRandomOrder = true);
		void  vSetLtgaDSM(double  **pdDSM, int iDSM_size);
		void  vSetLinkDataPackDSM(double  **pdDSM, int  iDSM_size);
		void  vSetDSMGA2_DSM(TriMatrix<double> *pvDSM, int iDSM_size);

		vector<vector<int> > *pvGetP3Clusters() { return(&v_p3_clusters); };
		vector<int> *pvGetP3ClusterOrdering() { return(&v_p3_cluster_ordering); };




		void  vSetOutsideLinkage_DLED_TightLinkageBlocks(int  **piScrapDSM, CEvaluation<CBinaryCoding> *pcEvaluation, CLog *pcLog);
		void  vSetOutsideLinkage_DLED_RefreshTLB_Clusters(CEvaluation<CBinaryCoding> *pcEvaluation);
		int   iGetDonorByTLB(vector<int>   *pvCluster, char *pcSourceInd, char	**pcLTGApopulation, int  iPopSize);

		void  vSetOutsideLinkage(int  iDSM_size);
		void  vSetOutsideLinkage_DLED(int  **piScrapDSM, int  iDSM_size, bool bAccumulateClusters);
		void  vSetOutsideLinkage_DirectionalNodes(vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, int  iDSM_size, bool bAccumulateClusters);
		void  vSetOutsideLinkage_SLL(double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters);
		void  vSetOutsideLinkage_HLL_DLED_SLL(int  **piScrapDSM, double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters);
		void  vSetOutsideLinkage_DLED_LTree(int  **piScrapDSM, int  iDSM_size, bool bAccumulateClusters);
		void  vSetOutsideLinkage_SLL_LTree(double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters);
		void  vSetOutsideLinkage_HLL_DLED_SLL_LTree(int  **piScrapDSM, double  **pdScrapDSM, int  iDSM_size, bool bAccumulateClusters);
		void  vComputeP3MapDSM(int  **piScrapDSM, int  iDSM_size, unordered_map<int, unordered_map<int, double> > *pc_uo_p3_dsm);
		void  vCreateP3Clusters(unordered_map<int, unordered_map<int, double> > &uoP3Dsm, vector<vector<int> > &clusters, vector<int> &cluster_ordering);


		void  vSaveLinkageReport(CString  sLinkageReportFile);


		void  vRecomputeDiscretizedDSM();
		void  vRecomputeDSM_PairingRankings();
		void  vGetReproducedDSM_P3(unordered_map<int, unordered_map<int, double> > *pcDestination);
		void  vReportLinkQualityPerfectBlockLengthOverhead(double  *pdAvr, double  *pdMedian, double *pdMin, double *pdMax);
		void  vReportLinkQualityPerfectBlockLengthFill(double  *pdAvr, double  *pdMedian, double *pdMin, double *pdMax);
		void  vReportLinkQualityPerfectBlocksFound(vector<double>  *pvFillReport, vector<CSeparableBlockDetection *>  *pvFullBlocksDetected);

		void  vReportClusters(FILE  *pfDest);



		int  iGetDSMsize() { return(i_dsm_size); }
		int  iGetPopSize() { return(i_pop_size); };
		double  dGetDSMValue(int  iX, int iY);

		double  dLinkQuality_PerfectBlockLengthOverhead(int iGeneIndex, int *piFurthestGene = NULL);
		double  dLinkQuality_PerfectBlockLengthFill(int iGeneIndex);

		void  vShow(double  dValue);
		void  vDebugLog(CString  sLog);


		double  **pdGetDSM() { return(pd_dsm); };

private:
	static uint32_t iERROR_PARENT_CLINKAGE_ANALYZER_SINGLE_DSM;
	static uint32_t iERROR_CODE_LINKAGE_ANALYZER_NO_EXTERNAL_DSMS;
	static uint32_t iERROR_CODE_LINKAGE_ANALYZER_DIFFERENT_REGISTERED_DSM_LENGTHS;
	static uint32_t iERROR_CODE_LINKAGE_ANALYZER_DMS_ZERO_SIZE;

	void  v_get_base_stats(vector<double> *pvData, double  *pdAvr, double  *pdMedian, double *pdMin, double *pdMax);
	bool  b_check_if_dependency_is_true(int iX, int iY);

	double get_distance_p3(int x, int y, unordered_map<int, unordered_map<int, double> > &uoP3Dsm);
	double round_double_p3(double value, int precision);
	void ordering_p3_smallest_first(const vector<vector<int>>& clusters, vector<int>& cluster_ordering);

	CString  s_additional_name;
	
	int  i_pop_size;

	int  i_dsm_size;
	double  **pd_dsm;
	int  **pi_dsm_discretized;
	int  **pi_dsm_discretized_ranking;

	vector<vector<int> > v_p3_clusters;
	vector<int> v_p3_cluster_ordering;

	CLinkageAnalyzer  *pc_parent;

	CTightLinkageBlockSupervisor  *pc_tlb_superv;

	vector<CSeparableBlockDetection *>  v_full_blocks_detection;
	vector<CLinkageAnalyzerDependentPair>  v_strict_dependent_pairs;
};//class CLinkageAnalyzerSingleDSM



struct SDoubleSort
{
	bool operator()(const double const& p1, const double const& p2)
	{
		return p1 < p2;
	}
};//struct SDoubleSort


struct SIntSort
{
	bool operator()(const int const& p1, const int const& p2)
	{
		return p1 < p2;
	}
};//struct SDoubleSort



struct SDSMSort
{
	bool operator()(const int const& p1, const int const& p2)
	{
		return pd_dsm[ix][p1] < pd_dsm[ix][p2];
	}

	int  ix;
	double  **pd_dsm;
};//struct SReportGridSort




class CDledDistanceStats
{
public:
	CDledDistanceStats() {};
	~CDledDistanceStats() {};

	void  vConfigure(int  iHopNumber, int  iProblemLength);
	void  vInsertNewCoverForGene(int  iGene, int  iCoveredGenes);
	void  vExtractData(int  **piDSM_DLED_Distances);
	CString  sGetAsString();
	CString  sGetAsStringShort();

	double  dPerc();
	double  dAvrDependentGeneNumber();
	int  iHopNumber() { return(i_hop_number); };

	int  iGetProblemLength() { return(i_problem_length); };

	vector<int>  *pvGetGeneHopCoverage() { return(&v_gene_hop_coverage); };


	int  iCoverMin;
	int  iCoverTotal;
	int  iCoverMax;
	int  iGenesNumber;

private:
	int  i_problem_length;
	int  i_hop_number;

	vector<int>  v_gene_hop_coverage;
};//class CDledDistanceStats



class  CLinkageInformationPack
{
	friend class CLinkageAnalyzer;
public:
	static uint32_t iERROR_PARENT_CLinkageInformationPack;
	static uint32_t iERROR_CLinkageInformationPack_SAVE_ERR;

	CLinkageInformationPack(CLinkageAnalyzer  *pcParent);
	~CLinkageInformationPack();

	void  vConfigure(CEvaluation<CBinaryCoding> *pcEvaluation, CLog *pcLog, CBinaryCoding *pcEvaluationIndividual);

	CLinkageAnalyzerSingleDSM  *pcGetSingleLinkage() { return(pc_single_dsm_linkage); };


	void  vSetSLL_LTGAlinkage(double  **pdDSM, int  iDSMsize);
	void  vSetSLL_P3linkage(unordered_map<int, unordered_map<int, double> > *pcDSM);
	void  vSetSLL_GenerateDSMfromPop();

	void  vSetPopulationLTGA(char  **Population, int iPopSize, int iSolSize);
	void  vSetPopulationGeneral(vector<int*> *pvPopulation);
	void  vAddAnotherIndividualGeneral(int *piIndividual);
	void  vAddAnotherP3Individual(vector<bool> *pvNewSolution);
	void  vSetIndividual3LOa(int  *piGenotype);
	void  vComputeDSM_DLED(bool bAccumulateClusters);
	void  vComputeDSM_SLL(bool  bAccumulateClusters);
	void  vComputeDSM_HLL_DLED_SLL(bool  bAccumulateClusters);
	void  vComputeDSM_DirectionalLinkage(bool bAccumulateClusters);
	void  vComputeDSM_Random();
	void  vComputeDSM_Perfect();

	void  vComputeDSM_ProblemDEcomp_DLED(bool  bPerfectLinkage);
	void  vCompute_DLED_Distances();
	void  vGet_DLED_DistanceStats(vector<CDledDistanceStats>  *pvStats);
	void  vCountDifferentDLEDways
		(
			double  *pdDifferentWaysAvr, double  *pdDifferentWaysMinAvr, double  *pdDifferentWaysMaxAvr,
			double  *pdDifferentWaysMedAvr, double  *pdDifferentWaysMed3Avr, double  *pdDifferentWaysAvr3Avr
		);

	void  vSetDSM_DLED(bool bAccumulateClusters);
	void  vSetDSM_SLL(bool  bAccumulateClusters);
	void  vSetDSM_HLL_DLED_SLL(bool  bAccumulateClusters);

	CError  eSaveDSM_DLED(CString  sDest, int  **piDSM);
	void  vSaveDSM_DLED(FILE  *pfDest, int  **piDSM);


	int  **piGet_DSM_DLED() { return(pi_dsm_dled); }
	int  **piGet_DSM_DLED_Distances() { return(pi_dsm_dled_distances); }



	bool  bGetLinkageDiscoveryProbabilities(double  *pdAvr, double *pdMin, double *pdMax, double  *pdLinkageFill);

	vector <CLinkageInformationPackIndividual *>  *pvGetPopToAnayze() { return(&v_pop_to_analayze); };
	
private:
	void v_sll_update_genes_values_occurrences(CLinkageInformationPackIndividual *pcInd);
	void v_sll_zero_genes_values_occurrences();
	void v_create_sll_dsm();
	int  i_populate_dled_distances(int  iNewLevel, int **piDSM_DLED_Distances);
	CLinkageInformationPackIndividual *pc_get_best_individual(vector <CLinkageInformationPackIndividual *>  *pvPop);
	bool  b_is_ind_included(CLinkageInformationPackIndividual *pcInd, vector <CLinkageInformationPackIndividual *>  *pvPop);

	void  v_compute_different_dled_ways_for_source_gene
		(
			int  iSourceGene, 
			double  *pdDifferentWaysAvr, int  *piDifferentWaysMinAvr, int  *piDifferentWaysMaxAvr,
			double  *pdDifferentWaysMed, double  *pdDifferentWaysMed3, double  *pdDifferentWaysAvr3
		);
	int  i_count_different_dled_ways_for_pair(int  iSourceGene, int  iDestGene, int  *piSourceGeneDledDistances);


	CLinkageAnalyzer  *pc_parent;

	int  i_linkage_type;
	

	vector <CLinkageInformationPackIndividual *>  v_pop_to_analayze;
	vector <CLinkageInformationPackGeneFreq *> v_gene_freqs;
	vector <CLinkageInformationPackLinkageScrap *> v_linkage_scraps;

	vector <CLinkageInformationPackIndividual *>  v_directional_linkage_analyzed_inds;

	CDirectional_DSM_Group  *pc_directional_linkages;

	CLinkageAnalyzerSingleDSM  *pc_single_dsm_linkage;
	int  **pi_dsm_dled;
	int  **pi_dsm_dled_distances;
	int  **pi_dsm_diversive;
	double  **pd_dsm_sll;


	int  ***pppi_sll_genes_values_occurrences;
	
	

	CEvaluation<CBinaryCoding> *pc_evaluation;
	CLog *pc_log;
	CBinaryCoding *pc_evaluation_individual;
};//class  CLinkageInformationPack


class  CLinkageInformationPackIndividual
{
public:

	CLinkageInformationPackIndividual(CEvaluation<CBinaryCoding> *pcEvaluation, CBinaryCoding *pcEvaluationIndividual);
	~CLinkageInformationPackIndividual();

	CLinkageInformationPackLinkageScrap  *pcGetLinkageScrap(int iPerturbationOffset, int  **piDSM_CurrentlyLinkedToOmit = NULL);
	CLinkageInformationPackIndividual*  pcGetClone();

	void  vGetDirectionalLinkage(CDirectional_DSM  *pcDirectionalLinkage, int iBilateralLinkageOnly, CLinkageInformationPackIndividual  *pcContext, CLinkageInformationPackIndividual *pcBuffer);

	int  *piGetGenotype() { return(pi_genotype); };
	void  vRandomizeOrder();
	void  vFIHC();
	void  vSetLTGA_Genotype(char*  pcGenotype);
	void  vSetP3_Genotype(vector<bool> *pvNewSolution);
	void  vSetInt_Genotype(int  *piGenotype);
	bool  bSetGene(int iGenePos, int iGeneVal);


	double  dComputeFitness();
	bool  bGenotypesTheSame(CLinkageInformationPackIndividual *pcOtherInd);
	bool  bGenotypesTheSame(int  *piGenotype);

	CString  sToStr();

private:
	double  d_compute_fitness(int  *piGenotype);
	int  i_get_other_value(int  iValue);
	int  i_get_better_value(int  *piGenoBuffer, int  *piGenotypeOrig, int  iGeneOff, double  dFitForOrig);

	int  *pi_genotype;
	int  i_problem_size;
	bool  b_fit_actual;
	double  d_fitness;
	vector<int>  v_order;

	CEvaluation<CBinaryCoding> *pc_evaluation;
	CBinaryCoding *pc_evaluation_individual;
};//class  CLinkageInformationPackIndividual


class  CLinkageInformationPackGeneFreq
{
public:
	CLinkageInformationPackGeneFreq(int  iGeneOffset) { i_gene_offset = iGeneOffset; };
	~CLinkageInformationPackGeneFreq();

	void  vGetIndsForLL(vector <CLinkageInformationPackIndividual *>  *pvIndsToGetLinkage, vector <CLinkageInformationPackIndividual *>  *pvPopToAnalayze);
	int  iGetGeneOffset() { return(i_gene_offset); };

	bool  bAddNewValue(int  iNewValue);
	void  vResetCounters();
	void  vCountGeneValueFreqs(vector <CLinkageInformationPackIndividual *>  *pvPopToAnalayze);

private:
	int  i_gene_offset;
	vector<CLinkageInformationPackGeneFreqValue *>  v_gene_value_freqs;
};//class  CLinkageInformationPackGeneFreq


class  CLinkageInformationPackGeneFreqValue
{
public:
	CLinkageInformationPackGeneFreqValue(CLinkageInformationPackGeneFreq  *pcParent, int  iValue) { pc_parent = pcParent;  i_value = iValue; i_count = 0; };
	~CLinkageInformationPackGeneFreqValue() {};

	int  iGetValue() { return(i_value); }
	int  iGetCount() { return(i_count); }

	void  vResetCount() { i_count = 0; };
	void  vCountForInd(CLinkageInformationPackIndividual *pcInd);
	CLinkageInformationPackIndividual  *pcGetIndForLL(vector <CLinkageInformationPackIndividual *>  *pvIndsToGetLinkage, vector <CLinkageInformationPackIndividual *>  *pvPopToAnalayze);

private:
	CLinkageInformationPackGeneFreq  *pc_parent;
	int  i_value;
	int  i_count;

};//class  CLinkageInformationPackGeneFreqValue


class  CLinkageInformationPackLinkageScrap
{
public:
	CLinkageInformationPackLinkageScrap() {};
	~CLinkageInformationPackLinkageScrap() {};

	void  vSetScrap(vector<int>  *pvLinkageScrap) { v_linkage_scrap = *pvLinkageScrap; };
	vector<int>  *pvGetLinkageScrap() { return(&v_linkage_scrap); };


	void  vSaveTo(FILE  *pfDest);
	void  vAddScrapToDSM(int  **piDSM, double  *pdLinkageGatheringProbabilities, int *piNoLinkageForGene);

private:
	vector<int>  v_linkage_scrap;

};//class  CLinkageInformationPackLinkageScrap



class  CTightLinkageBlockSupervisor
{
public:
	CTightLinkageBlockSupervisor(CEvaluation<CBinaryCoding> *pcEvaluation, CLog *pcLog);
	~CTightLinkageBlockSupervisor();
	
	void  vBuildTLBs(int  **piScrapDSM);
	void  vCreateTLB_Clusters(vector<vector<int> > *pvClusters, vector<int> *pvClusterOrdering);
	void  vSaveTLBs(CString  sDest, vector<vector<int> > *pvClusters = NULL);

	int   iGetDonorByTLB(vector<int>   *pvCluster, char *pcSourceInd, char	**pcLTGApopulation, int  iPopSize);

private:
	bool  b_can_i_be_donnor(char *pcSourceInd, char  *pcDonorCandidate, vector<int> *pvGenesInCommon, vector<int> *pvCluster);

	CEvaluation<CBinaryCoding> *pc_evaluation;
	CLog *pc_log;

	vector<CTightLinkageBlock *>  v_tlbs;
};//class  CTightLinkageBlockSupervisor



class  CTightLinkageBlock
{
	friend class CTightLinkageBlockSupervisor;
public:
	CTightLinkageBlock() {};
	~CTightLinkageBlock() {};

	//cluster joining
	void  vGetTLBclusterOnLevel(int iLevel, vector<CTightLinkageBlock *>  *pvTLBs, vector<vector<int> > *pvClusters);

	//cluster creation
	void  vGetContainedTLBsOffsets(vector<int>  *pvContainedTLB_Offsets);
	void  vGetOverlappingTLBs(vector<CTightLinkageBlock *>  *pvTLBs, vector<CTightLinkageBlock *> *pvTLBsOverlapping);
	void  vGetOverlappingTLB_Offsets(vector<CTightLinkageBlock *>  *pvTLBs, vector<int> *pvTLBsOverlappingOffsets);
	int   iGetOverlappingTLB_Offset(vector<CTightLinkageBlock *>  *pvTLBs);
	void  vCreateRandomSubclusters(vector<vector<int> > *pvClusters);

	void  vAddTLB(CTightLinkageBlock  *pcTLB_ToAdd);
	CTightLinkageBlock  *pcJoinTLBs(CTightLinkageBlock  *pcTLB_CurrentOverlap);

	void  vSave(FILE  *pfDest);

	void  vGetGenesInCommon(vector<int>  *pvCluster, vector<int>  *pvGenesInCommon);

	bool  bAtLeastOneGeneDifferent(vector<int>  *pvConnectedGenes);
	bool  bAtLeastOneGeneDifferent(CTightLinkageBlock  *pcOtherBlock);

	bool  bAtLeastOneGeneInCommon(vector<int>  *pvConnectedGenes);
	bool  bAtLeastOneGeneInCommon(CTightLinkageBlock  *pcOtherBlock);

	bool  bDoIContain(vector<int>  *pvConnectedGenes);
	bool  bDoIContain(CTightLinkageBlock  *pcOtherBlock);

	bool  bTheSame(vector<int>  *pvConnectedGenes);
	bool  bTheSame(CTightLinkageBlock  *pcOtherBlock);
	bool  bTheSameInTheList(vector<CTightLinkageBlock *>  *pvTLBs);

	//TLB creation
	void  vSetTLB(vector<int>  *pvTLB);
	bool  bReadInAndAddToList(int  iStartGene, vector<CTightLinkageBlock *>  *pvTLBs, int  **piScrapDSM, int iDSMsize, int iStartOffset);

private:
	int  i_check_gene(int  iGeneToCheck, int  **piScrapDSM, vector<CTightLinkageBlock *>  *pvTLBs, vector<int>  *pvConnectedGenes);
	void  v_add_gene_to_tlb(int  iNewGeneOffset);
	bool  b_any_contact(int  iGeneToCheck, int  **piScrapDSM);


	vector<int>  v_tight_linkage_block;

};//class  CTightLinkageBlock






//-------------------------------directional linkage-----------------------------------------------------------------

class  CDirectional_LTreeNode
{
public:
	CDirectional_LTreeNode() { i_succ_crossings = 0; pi_gene_map = NULL; i_genotype_size = -1; b_unconnected_genes_node = false; };
	~CDirectional_LTreeNode() { if (pi_gene_map != NULL)  delete  pi_gene_map; };

	void  vGeneMapGenerate(int  iGenotypeSize);
	//void  vGeneMapInclude(int  *piNewGeneMap, int  iGenotypeSize);

	CString  sGetAsString();
	/*double  dGetDist(CDirectional_LTreeNode  *pcOtherNode, CDirectional_DSM *pdDsm);
	bool  bAnyCommonGenes(CDirectional_LTreeNode  *pcOther);
	bool  bDoIContain(int iOffset);

	CDirectional_LTreeNode  *pcJoinNodes(CDirectional_LTreeNode  *pcOther);

	int  iGetSuccCross() { return(i_succ_crossings); };
	void  vIncrSuccCross() { i_succ_crossings++; };*/
	vector<int>  *pvGetGenes() { return(&v_genes); };
	vector<int>  *pvGetGenesExtended() { return(&v_genes_extended); };

	void  vSetUnconnectedGenesNode(bool  bNewUnconnectedGenesNode) { b_unconnected_genes_node = bNewUnconnectedGenesNode; }
	bool  bUnconnectedGenesNode() { return(b_unconnected_genes_node); }

	void  vGetOverlappingButDifferentNodes(vector<CDirectional_LTreeNode *>  *pvNodesToCheck, vector<int>  *pvNodesOverlappingOffests);
	void  vGetOverlappingNodes(vector<CDirectional_LTreeNode *>  *pvNodesToCheck, vector<int>  *pvNodesOverlappingOffests);
	bool  bTheSame(CDirectional_LTreeNode  *pcOther);
	void  vCheckOverlappingAndSepation(CDirectional_LTreeNode  *pcOther, bool *pbOverlapping, bool  *pbThisHasSeparatePart, bool  *pbOtherHasSeparatePart);

	CDirectional_LTreeNode  *pcByMapJoinNodes(CDirectional_LTreeNode  *pcOther);
	void  vByMapCrossNodes(CDirectional_LTreeNode  *pcOther, vector<CDirectional_LTreeNode*> *pvNewNodes);
private:
	void  v_shuffle_list(vector<int>  *pvBase, vector<int>  *pvShuffled);

	vector<int>  v_genes;
	vector<int>  v_genes_extended;
	int  i_succ_crossings;

	int  *pi_gene_map;
	int  i_genotype_size;

	bool  b_unconnected_genes_node;
};//class  CDirectional_LTreeNode




class  CDirectional_DSM_CoverageStats
{
public:
	CDirectional_DSM_CoverageStats() {}
	~CDirectional_DSM_CoverageStats() {}

	void  vSetConfig(int  iSize, int iGeneOffset) { i_size = iSize; i_gene_offset = iGeneOffset; };
	void  vZeroStats() { iCoverage = 0; v_coverage_per_hop.clear(); };
	void  vGetStats(int  *piCoverageCompTool);
	void  vSave(FILE  *pfDest);

	bool  bLinkageOrigin; //gene that is NOT pointed by any other gene
	bool  bLinkageLeaf; //gene that does not point any other gene BUT is pointed by at least one gene
	int  iCoverage;
	double  dCoveragePerc();
	int  iMaxHopNumber() { return(v_coverage_per_hop.size() - 1); };
	void  vAddGenesCovered(int  iHopNum, int iGenesCovered);

	//void  vCreateDirectionalNodes(CDirectional_DSM_CoverageStats  *pcGenesCoverage, vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, double **pdDSM, int  *piAllIncludedNodes);
	//void  vExtendDirectionalTree(CDirectional_DSM_CoverageStats  *pcGenesCoverage, vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, double **pdDSM, int  *piAllIncludedNodes, int  *piThisTreeNodes, vector<int>  *pvIncrementalLinkageSet);

	void  vCreateDirectional_BilateralGroup(CDirectional_DSM_CoverageStats  *pcGenesCoverage, double **pdDSM, int  *piAllIncludedNodes, CDirectional_LTreeNode  **pcLTnode, CLinkageInformationPackIndividual  *pcInd0, CLinkageInformationPackIndividual  *pcInd1);
	//void  vCreateDirectional_ILS_Inverted(CDirectional_DSM_CoverageStats  *pcGenesCoverage, vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, double **pdDSM, int  *piAllIncludedNodes);
	//void  vCreateDirectional_ILS(CDirectional_DSM_CoverageStats  *pcGenesCoverage, vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, double **pdDSM, int  *piAllIncludedNodes);
	void  vExtendDirectionalILS(CDirectional_DSM_CoverageStats  *pcGenesCoverage, vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, double **pdDSM, int  *piAllIncludedNodes, int  *piThisTreeNodes, vector<int>  *pvIncrementalLinkageSet, bool  bOnlyBilateralNodes, CLinkageInformationPackIndividual  *pcInd0, CLinkageInformationPackIndividual  *pcInd1, bool  bAddOnlyOneGene, bool bAddPointingNotPointed);

	void  vCreateDirectional_OnlyBilateralBlock(CDirectional_DSM_CoverageStats  *pcGenesCoverage, vector<CDirectional_LTreeNode *>  *pvDirectionalNodes, double **pdDSM, int  *piAllIncludedNodes);

private:
	int  i_size;
	int  i_gene_offset;
	vector<int>  v_coverage_per_hop;

private:

};//class  CDirectional_DSM_CoverageStats






class  CDirectional_DSM
{
	friend class CDirectional_LTreeNode;
public:
	CDirectional_DSM();
	~CDirectional_DSM();

	bool  bSetSize(int  iSize);

	int  iGetSize() { return(i_size); };

	bool  bZeroDSM();
	bool  vFillRandomly();
	void  vShuffleNodes();
	void  vShuffleNodes(bool  bConsiderLength);
	void  vShuffleNodesByLength();

	void  vSave(CString  sDest);
	void  vSave(FILE  *pfDest);

	bool  bSet(int iX, int iY, double dVal);
	double  **pdGetDSM() { return(pd_dsm); }

	void  vFlushNodes();
	void  vCreateDirectional_BilateralGroups(CLinkageInformationPackIndividual  *pcInd0, CLinkageInformationPackIndividual  *pcInd1);
	vector<CDirectional_LTreeNode *>  *pvGetDirectionalNodes() { return(&v_directional_nodes); };

	/*vector<CLTreeNode *>  *pvGetDirectionalNodes() { return(&v_directional_nodes); };

	void  vCreateDirectional_ILS_Inverted(CSingleTrajectorySet  *pcInd0, CSingleTrajectorySet  *pcInd1, int iCreateInterNodes, bool  bFlushNodes);

	void  vCreateDirectional_BilateralGroups(CSingleTrajectorySet  *pcInd0, CSingleTrajectorySet  *pcInd1);
	void  vCreateDirectional_ILS(CSingleTrajectorySet  *pcInd0, CSingleTrajectorySet  *pcInd1, int iCreateInterNodes);
	void  vCreateDirectional_TreeLike_ILS(CSingleTrajectorySet  *pcInd0, CSingleTrajectorySet  *pcInd1);
	void  vCreateDirectional_BilateralBlocksFirst(CSingleTrajectorySet  *pcInd0, CSingleTrajectorySet  *pcInd1);*/

	int  *piGetIncludedNodes() { return(pi_included_nodes); }

	void  vComputeCoverage();
	CString  sGetCoverageStats();


private:
	void  v_get_directional_linkage_info(FILE  *pfDest);
	void  v_compute_coverage(int  iGene);
	void  v_compute_coverage_extend_level(int  iLevel);
	bool  b_compute_coverage_for_gene(int  iGene, int  *piCoverageCompTool, int iLevelToMark);

	int  *pi_included_nodes;
	int  *pi_coverage_comp_tool;
	CDirectional_DSM_CoverageStats  *pc_coverage;
	double  **pd_dsm;
	int  i_size;
	vector<CDirectional_LTreeNode *>  v_directional_nodes;

	int  i_pairs_total, i_pairs_bilateral, i_pairs_directional, i_pairs_unconnected;//for stats only*/
};//class  CDirectional_DSM



class  CDirectional_DSM_Group
{
public:
	CDirectional_DSM_Group();
	~CDirectional_DSM_Group();

	bool  bSetSize(int  iSize) { i_size = iSize; return(true); };
	int  iGetSize() { return(i_size); };

	void  vCreateDirectional_BilateralGroups(CLinkageInformationPackIndividual  *pcInd0, CLinkageInformationPackIndividual  *pcInd1);
	CDirectional_DSM  *pcGetDSM_ForLinkageDiscovery(bool  bAccumulateLinkage);
	void  vMakeSummarizedLinkage();
	vector<CDirectional_LTreeNode *>  *pvGetDirectionalNodes() { return(&v_directional_nodes); };

	CString  sGetCoverageStats();
	void  vShuffleNodes(bool  bConsiderLength);

	void  vSave(CString  sDest);
	void  vSave(FILE  *pfDest);

private:
	CDirectional_DSM  *pc_directional_linkage_summarized;
	vector<CDirectional_DSM  *>  v_directional_linkages;
	vector<CDirectional_LTreeNode *>  v_directional_nodes;
	vector<CDirectional_LTreeNode *>  v_nodes_created;

	int  i_size;
};//class  CDSM_Group














#endif//LINKAGE_ANALYZER_H
