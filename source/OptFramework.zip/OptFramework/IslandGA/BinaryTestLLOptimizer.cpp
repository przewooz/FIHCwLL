#include "BinaryTestLLOptimizer.h"

#include "HierarchicalClustering.h"
#include "PointerUtils.h"
#include "RandUtils.h"
#include "VectorUtils.h"

#include <algorithm>
#include <unordered_map>
#include <utility>

using namespace Clustering;

CBinaryTestLLOptimizer::CBinaryTestLLOptimizer(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: CPopulationOptimizer<CBinaryCoding, CBinaryCoding>(pcProblem, pcLog, iRandomSeed)
{

}//CBinaryTestLLOptimizer::CBinaryTestLLOptimizer(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

CBinaryTestLLOptimizer::CBinaryTestLLOptimizer(CBinaryTestLLOptimizer *pcOther)
	: CPopulationOptimizer<CBinaryCoding, CBinaryCoding>(pcOther)
{

}//CBinaryTestLLOptimizer::CBinaryTestLLOptimizer(CBinaryTestLLOptimizer *pcOther)

bool CBinaryTestLLOptimizer::bRunIteration(uint32_t iIterationNumber)
{
	random_shuffle(ppc_population + 0, ppc_population + i_population_size);

	vector<CGenePatternTree*> *pv_individual_trees = pv_get_individual_trees(ppc_population, i_population_size);

	uint16_t i_number_of_elements = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	unordered_map<uint16_t, vector<CGenePattern*>*> m_patterns;
	m_patterns.reserve((size_t)i_number_of_elements);

	uint16_t i_random_element_index;
	vector<CGenePattern*> *pv_patterns;

	for (uint32_t i = 0; i < i_population_size; i++)
	{
		i_random_element_index = RandUtils::iRandIndex((uint32_t)i_number_of_elements);

		if (m_patterns.count(i_random_element_index) == 0)
		{
			pv_patterns = pv_get_patterns(pv_individual_trees, ppc_population, i_population_size, i_random_element_index);
			m_patterns.insert(pair<const uint16_t, vector<CGenePattern*>*>(i_random_element_index, pv_patterns));
		}//if (m_patterns.count(i_random_element_index) == 0)
		else
		{
			pv_patterns = m_patterns.at(i_random_element_index);
		}//else if (m_patterns.count(i_random_element_index) == 0)

		v_optimal_mixing(ppc_population + i, pv_patterns);
	}//for (uint32_t i = 0; i < i_population_size; i++)


	unordered_map<uint16_t, vector<CGenePattern*>*>::iterator i_it;

	for (i_it = m_patterns.begin(); i_it != m_patterns.end(); i_it++)
	{
		VectorUtils::vDeleteElementsAndClear(i_it->second);
		delete i_it->second;
	}//for (i_it = m_patterns.begin(); i_it != m_patterns.end(); i_it++)

	VectorUtils::vDeleteElementsAndClear(pv_individual_trees);


	bool b_updated = b_update_best_individual(iIterationNumber);


	CString s_log_message;

	s_log_message.Format("best fitness: %f; best unitation: %f; ffe: %u; %.2lf; population size: %u",
		pc_best_individual->dGetFitnessValue(), pc_best_individual->pcGetGenotype()->dGetUnitation(), pc_problem->pcGetEvaluation()->iGetFFE(),
		c_optimizer_timer.dGetTimePassed(), iGetPopulationSize());

	pc_log->vPrintLine(s_log_message, true);


	return b_updated;
}//bool CBinaryTestLLOptimizer::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

double ** CBinaryTestLLOptimizer::ppd_get_distances(CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iPopulationSize, uint16_t iElementIndex)
{
	double **ppd_distances = new double*[iPopulationSize];

	for (uint32_t i = 0; i < iPopulationSize; i++)
	{
		*(ppd_distances + i) = new double[iPopulationSize];
	}//for (uint32_t i = 0; i < iPopulationSize; i++)

	double d_distance;

	CBinaryCoding *pc_genotype_0, *pc_genotype_1;

	for (uint32_t i = 0; i < iPopulationSize; i++)
	{
		*(*(ppd_distances + i) + i) = 0;

		pc_genotype_0 = (*(ppcPopulation + i))->pcGetGenotype();

		for (uint32_t j = i + 1; j < iPopulationSize; j++)
		{
			pc_genotype_1 = (*(ppcPopulation + j))->pcGetGenotype();

			d_distance = abs(*(pc_genotype_0->piGetBits() + iElementIndex) - *(pc_genotype_1->piGetBits() + iElementIndex));

			*(*(ppd_distances + i) + j) = d_distance;
			*(*(ppd_distances + j) + i) = d_distance;
		}//for (uint32_t j = i + 1; j < iPopulationSize; j++)
	}//for (uint32_t i = 0; i < iPopulationSize; i++)

	return ppd_distances;
}//double ** CBinaryTestLLOptimizer::ppd_get_distances(CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iPopulationSize, uint16_t iElementIndex)

vector<CGenePatternTree*> * CBinaryTestLLOptimizer::pv_get_individual_trees(CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iPopulationSize)
{
	uint16_t i_number_of_elements = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	vector<CGenePatternTree*> *pv_individual_trees = new vector<CGenePatternTree*>();

	double **ppd_distances;

	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		ppd_distances = ppd_get_distances(ppcPopulation, iPopulationSize, i);

		CHierarchicalClustering c_clustering(iPopulationSize, ppd_distances, pc_log);
		c_clustering.vRun();

		pv_individual_trees->push_back(new CGenePatternTree(c_clustering.pvGetClusterIndexes()));
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)

	PointerUtils::vDelete(ppd_distances, iPopulationSize);

	return pv_individual_trees;
}//vector<CGenePatternTree*> * CBinaryTestLLOptimizer::pv_get_individual_trees(CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iPopulationSize)

vector<CGenePattern*> * CBinaryTestLLOptimizer::pv_get_patterns(vector<CGenePatternTree*> *pvIndividualTrees, CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iPopulationSize, uint16_t iElementIndex)
{
	CGenePatternTree *pc_individual_tree = pvIndividualTrees->at((size_t)iElementIndex);

	vector<CGenePattern*>* pv_patterns = new vector<CGenePattern*>();
	pv_patterns->reserve(pc_individual_tree->pvGetAllGenePatterns()->size() - (size_t)iPopulationSize - 1);

	CGenePattern *pc_individual_pattern, *pc_closest_individual_pattern, *pc_pattern;

	for (uint16_t i = (uint16_t)iPopulationSize; i < (uint16_t)pc_individual_tree->pvGetAllGenePatterns()->size() - 1; i++)
	{
		pc_individual_pattern = pc_individual_tree->pvGetAllGenePatterns()->at((size_t)i);

		if (b_all_the_same_bits(pc_individual_pattern, ppcPopulation, iElementIndex))
		{
			pc_pattern = new CGenePattern();
			pc_pattern->vAdd(iElementIndex, i_get_first_bit(pc_individual_pattern, ppcPopulation, iElementIndex));

			for (uint16_t j = 0; j < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); j++)
			{
				if (j != iElementIndex)
				{
					pc_closest_individual_pattern = pvIndividualTrees->at(j)->pcGetClosestGenePattern(pc_individual_pattern);

					if (pc_closest_individual_pattern != nullptr)
					{
						if (b_all_the_same_bits(pc_closest_individual_pattern, ppcPopulation, j))
						{
							pc_pattern->vAdd(j, i_get_first_bit(pc_closest_individual_pattern, ppcPopulation, j));
						}//if (b_all_the_same_bits(pc_closest_individual_pattern, ppcPopulation, j))
					}//if (pc_closest_individual_pattern != nullptr)
				}//if (j != iElementIndex)
			}//for (uint16_t j = 0; j < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); j++)

			pv_patterns->push_back(pc_pattern);
		}//if (b_all_the_same_bits(pc_individual_pattern, ppcPopulation, iElementIndex))
	}//for (uint16_t i = (uint16_t)iPopulationSize; i < (uint16_t)pc_individual_tree->pvGetAllGenePatterns()->size() - 1; i++)

	return pv_patterns;
}//vector<CGenePattern*> * CBinaryTestLLOptimizer::pv_get_patterns(vector<CGenePatternTree*> *pvIndividualTrees, CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iPopulationSize, uint16_t iElementIndex)

int32_t CBinaryTestLLOptimizer::i_get_bit(CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iIndividualIndex, uint16_t iElementIndex)
{
	CIndividual<CBinaryCoding, CBinaryCoding> *pc_individual = *(ppcPopulation + iIndividualIndex);
	return *(pc_individual->pcGetGenotype()->piGetBits() + iElementIndex);
}//int32_t CBinaryTestLLOptimizer::i_get_bit(CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iIndividualIndex, uint16_t iElementIndex)

int32_t CBinaryTestLLOptimizer::i_get_first_bit(CGenePattern *pcIndividualPattern, CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint16_t iElementIndex)
{
	return i_get_bit(ppcPopulation, (uint32_t)*pcIndividualPattern->piGetPattern(), iElementIndex);
}//int32_t CBinaryTestLLOptimizer::i_get_first_bit(CGenePattern *pcIndividualPattern, CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint16_t iElementIndex)

bool CBinaryTestLLOptimizer::b_all_the_same_bits(CGenePattern *pcIndividualPattern, CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint16_t iElementIndex)
{
	bool b_all_the_same = true;

	int32_t i_first_bit = i_get_first_bit(pcIndividualPattern, ppcPopulation, iElementIndex);

	for (uint16_t i = 1; i < pcIndividualPattern->iGetSize() && b_all_the_same; i++)
	{
		b_all_the_same = i_first_bit == i_get_bit(ppcPopulation, (uint32_t)*(pcIndividualPattern->piGetPattern() + i), iElementIndex);
	}//for (uint16_t i = 1; i < pcIndividualPattern->iGetSize() && b_all_the_same; i++)

	return b_all_the_same;
}//bool CBinaryTestLLOptimizer::b_all_the_same_bits(CGenePattern *pcIndividualPattern, CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint16_t iElementIndex)

void CBinaryTestLLOptimizer::v_optimal_mixing(CIndividual<CBinaryCoding, CBinaryCoding> **ppcIndividual, vector<CGenePattern*> *pvPatterns)
{
	for (size_t i = 0; i < pvPatterns->size(); i++)
	{
		v_optimal_mixing(ppcIndividual, pvPatterns->at(i));
	}//for (size_t i = 0; i < pvPatterns->size(); i++)
}//void CBinaryTestLLOptimizer::v_optimal_mixing(CIndividual<CBinaryCoding, CBinaryCoding> **ppcIndividual, vector<CGenePattern*> *pvPatterns)

void CBinaryTestLLOptimizer::v_optimal_mixing(CIndividual<CBinaryCoding, CBinaryCoding> **ppcIndividual, CGenePattern *pcPattern)
{
	CIndividual<CBinaryCoding, CBinaryCoding> *pc_clone = new CIndividual<CBinaryCoding, CBinaryCoding>(*ppcIndividual);

	bool b_at_least_one_different = false;

	int32_t *pi_old_bit;
	int32_t i_new_bit;

	for (uint16_t i = 0; i < pcPattern->iGetSize(); i++)
	{
		pi_old_bit = (*ppcIndividual)->pcGetGenotype()->piGetBits() + *(pcPattern->piGetPattern() + i);
		i_new_bit = *(pcPattern->piGetBits() + i);

		if (*pi_old_bit != i_new_bit)
		{
			*pi_old_bit = i_new_bit;
			b_at_least_one_different = true;
		}//if (*pi_old_bit != i_new_bit)
	}//for (uint16_t i = 0; i < pcPattern->iGetSize(); i++)

	if (b_at_least_one_different)
	{
		pc_clone->vIsEvaluated(false);
		pc_clone->vEvaluate();

		if (!pc_problem->bIsBetterIndividual(*ppcIndividual, pc_clone))
		{
			delete *ppcIndividual;
			*ppcIndividual = pc_clone;
		}//if (!pc_problem->bIsBetterIndividual(*ppcIndividual, pc_clone))
		else
		{
			delete pc_clone;
		}//else if (!pc_problem->bIsBetterIndividual(*ppcIndividual, pc_clone))
	}//if (b_at_least_one_different)
	else
	{
		delete pc_clone;
	}//else if (b_at_least_one_different)
}//void CBinaryTestLLOptimizer::v_optimal_mixing(CIndividual<CBinaryCoding, CBinaryCoding> **ppcIndividual, CGenePattern *pcPattern)