#ifndef CDARK_GRAY_GA_OPTIMIZER_H
#define CDARK_GRAY_GA_OPTIMIZER_H


#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "CommandParam.h"
#include "Error.h"
#include "Log.h"
#include "MathUtils.h"
#include "Optimizer.h"
#include "Problem.h"
#include "Individual.h"
#include  "util\timer.h"
#include  "util\tools.h"
#include "PopulationSizingOptimizer.h"



//#include <istream>
//#include <algorithm>





namespace nDarkGrayGA
{
	class  CDarkGrayGASinglePop;
	class  CDarkGrayGAIndividual;
	class  CDarkGA_DSM;
	class  CDarkGrayGAPxMaskManager;
	class  CDarkGrayGAPxMask;

	#define  s_OPTIMIZER_DARK_GA_POP_SCHEME			"popScheme(0-P3like; 1-GA-like)"
	#define  s_OPTIMIZER_DARK_GA_DONOR_IMPROVEMENT  "DonorImprovement"
	#define  s_OPTIMIZER_DARK_GA_PERFECT_LINKAGE	"PerfectLinkage"
	#define  s_OPTIMIZER_DARK_GA_GLOBAL_BEST_IMPROVEMENT	"GlobalBestImprovement"
	#define  s_OPTIMIZER_DARK_GA_GLOBAL_BEST_LIMIT	"GlobalBestLimit (0=unlimited bestPop size)"
	#define  s_OPTIMIZER_DARK_GA_GLOBAL_BEST_POP_RUN	"GlobalBestPopRun"
	#define  s_OPTIMIZER_DARK_GA_UNIFORM_CROSSOVER_FOR_SLIDE	"UniformCrossoverForSlide"


	class CDarkGrayGA : public CBinaryOptimizer
	{
		friend class CDarkGrayGAIndividual;
		friend class CDarkGA_DSM;
	public:
		static uint32_t iERROR_PARENT_CDarkGrayGA;
		static uint32_t iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0;


		CDarkGrayGA(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
		CDarkGrayGA(CDarkGrayGA *pcOther);
		~CDarkGrayGA();

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CDarkGrayGA(this); };
		virtual bool bRunIteration(uint32_t iIterationNumber) override;
		virtual bool bRunIteration_P3(uint32_t iIterationNumber);
		virtual bool bRunIteration_sGA(uint32_t iIterationNumber);

		virtual CError eConfigure(istream *psSettings) override;
		virtual void vInitialize() override;


		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo();
		CString  sLinkageSummaryReport();

		double dComputeFitness(int32_t *piBits);


		CDarkGrayGAIndividual  *pcGetBest();
		void  vInsertToBestPop(CDarkGrayGAIndividual  *pcNewInd);
		void  vInsertToBestPop(CDarkGrayGASinglePop  *pcSinglePop);

		CDarkGA_DSM  *pcGetDSM() { return(pc_dsm); };


		int  iP3GetPyramidIndNumber();
		int  iGetPopLevel(CDarkGrayGASinglePop  *pcPopToCheck);

	private:
		bool  b_p3_add_to_level(int iLevel, CDarkGrayGAIndividual*pcIndToAdd);
		bool b_p3_the_same_exists(CDarkGrayGAIndividual  *pcIndToAdd);
		void  v_global_best_improvement();
		void  v_global_best_pop_run();

		CTimeCounter  c_time_counter;
		double  d_time_last_time;

		int  i_sett_pop_scheme;
		int  i_sett_donor_improvement;
		int  i_sett_perfect_linkage;
		int  i_sett_global_best_improvement;
		int  i_sett_global_number_limit;
		int  i_sett_global_best_pop_run;
		int  i_sett_uniform_crossover_for_slide;

		int  i_next_pop_size;
		vector<CDarkGrayGASinglePop *> v_pyramid;
		vector<CDarkGrayGASinglePop *> v_pop_running, v_pops_obsolete;

		CDarkGrayGASinglePop  *pc_base_pop;
		CDarkGrayGASinglePop  *pc_best_pop;
		//CDarkGrayGAIndividual  *pc_best;

		CDarkGA_DSM  *pc_dsm;
		int  i_pop_size;
		int  i_templ_length;
	};//class CDarkGrayGA : public CBinaryOptimizer	*/



	class CDarkGrayGASinglePop : public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>
	{
		friend class CDarkGrayGA;
		friend class CDarkGrayGAIndividual;
	public:
		static uint32_t iERROR_PARENT_CDarkGrayGASinglePop;
		static uint32_t iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0;


		CDarkGrayGASinglePop(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed, CDarkGrayGA  *pcParent);
		CDarkGrayGASinglePop(CDarkGrayGASinglePop *pcOther);
		~CDarkGrayGASinglePop();

		void  vCopyFrom(CDarkGrayGASinglePop *pcOther);

		COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() override;
		virtual bool bRunIteration(uint32_t iIterationNumber) override;
		bool bRunIterationForceCross(uint32_t iIterationNumber);
		bool bRunIterationMaskLen(uint32_t iIterationNumber);
		bool bRunIteration_sGA(uint32_t iIterationNumber);

		bool  bDonateToIndividual(CDarkGrayGAIndividual  *pcReceiver);
		int  iDonateToIndividual_PxByLen(CDarkGrayGAIndividual  *pcReceiver, bool bPrint = true);

		virtual CError eConfigure(istream *psSettings) override;
		virtual void vInitialize() override;

		bool bIsSteadyState() override;
		double dComputeAverageFitnessValue() override;

		uint32_t iGetPopulationSize() override { return i_pop_size; }
		void vSetPopulationSize(uint32_t iPopulationSize) override { i_pop_size = iPopulationSize; };

		void  vGetGenotypeBufferTools(int  **piTool_0, int  **piTool_1);


		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo();

		double dComputeFitness(int32_t *piBits);
		double dComputeFitnessDouble(int32_t *piBits);


		CDarkGrayGAIndividual  *pcGetBest() { return(pc_best); };

		CDarkGA_DSM  *pcGetDSM() { return(pc_dsm); };

		CDarkGrayGAPxMaskManager  *pcGetPxMasksManager() { return(pc_px_masks_manager); }

		void  vSavePopTest();


	private:
		
		double d_evaluate(int32_t *piBits);
		double d_evaluate_double(int32_t *piBits);
		CDarkGrayGAIndividual* pc_get_random_individual();

		CDarkGrayGA  *pc_parent;

		bool  b_steady_state;
		CTimeCounter  c_time_counter;
		double  d_time_last_time;
		CIndividual<CBinaryCoding, CBinaryCoding> *pc_evaluation_individual;
		CDarkGrayGAIndividual *pc_individual_buffer;
		int  *pi_genotope_buffer_tool_0, *pi_genotope_buffer_tool_1;

		int  i_slide_number;
		int  i_uniform_donations;

		vector<CDarkGrayGAIndividual *> v_pop, v_pop_copy;

		CDarkGrayGAPxMaskManager  *pc_px_masks_manager;
		
		CDarkGrayGAIndividual  *pc_best;

		CDarkGA_DSM  *pc_dsm;
		int  i_pop_size;
		int  i_templ_length;
	};//class CDarkGrayGASinglePop : public CBinaryOptimizer	


	class  CDarkGA_DSM
	{
	public:
		CDarkGA_DSM(CDarkGrayGA  *pcParent);
		~CDarkGA_DSM();


		bool  bSetSize(int  iProbSize);

		CString  sLinkageSummaryReport();
		bool  bGetTrueLinkage(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem);
		void  vDarkGrayMapDependentGenes(int  iGeneOffset, int  *piMask);

		void  vUpdateDSM(CDarkGrayGAPxMask  *pcMask);

		int  **piGetDSM() { return(pi_dsm); }

		bool  bSave(CString  sDest);
		bool  bSave(FILE  *pfDest);

	private:
		void  v_extract_dled_for_gene_pair(int  iGeneContext, int iGeneBlock, int  *piDledExtractionMask, CDarkGrayGAIndividual  *pcExtractionIndividual, int *piNewPairsDetected);
		bool  b_check_if_true_linkage(int iGeneBlock, int  iGeneContext);

		int  **pi_dsm;
		int  i_prob_size;
		CDarkGrayGAIndividual  *pc_individual_tool;

		int  i_cost_ffe;
		double  d_cost_time;

		CDarkGrayGA  *pc_parent;
	
	};//class  CDargGA_DSM


	class  CDarkGrayGAPxMaskManager
	{
	public:
		CDarkGrayGAPxMaskManager();
		~CDarkGrayGAPxMaskManager();

		void  vClear();

		void  vReport(CString  sDest);
		void  vReport(FILE  *pfDest);
		CDarkGrayGAPxMask  *pcGetNewPxMask();

		void  vShuffle();
		void  vSortByLength();

		int  iGetSize() { return(v_masks.size()); };
		CDarkGrayGAPxMask  *pcGetAt(int iOffset);

	private:
		vector<CDarkGrayGAPxMask *>  v_masks;
		vector<CDarkGrayGAPxMask *>  v_masks_buffered;
		
	};//class  CDarkGrayGAPxMaskManager


	class CDarkGrayGAPxMask
	{
	public:
		CDarkGrayGAPxMask() { };

		void  vClear() { v_mask.clear();  pc_parent_0 = NULL; pc_parent_1 = NULL; }
		void  vReport(CString  sDest);
		void  vReport(FILE  *pfDest);

		CString  sToStr();

		CDarkGrayGAIndividual  *pcGetOtherInd(CDarkGrayGAIndividual  *pcOtherThanThisOne);
		bool  bDoICContain(CDarkGrayGAIndividual  *pcOtherThanThisOne);

		vector<int> v_mask;
		CDarkGrayGAIndividual  *pc_parent_0;
		CDarkGrayGAIndividual  *pc_parent_1;
	};//class CDarkGrayGAPxMask



	class  CDarkGrayGAIndividual
	{
		friend class CDarkGrayGA;
		friend class CDarkGrayGASinglePop;
		friend class CDarkGrayGAPxMask;
		friend class CDarkGA_DSM;
	public:
		CDarkGrayGAIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CDarkGrayGASinglePop *pcParent);
		CDarkGrayGAIndividual(CDarkGrayGAIndividual &pcOther);
		~CDarkGrayGAIndividual();

		bool  bIsTheSame(CDarkGrayGAIndividual  *pcOther);
		double  dGetSimilarity(CDarkGrayGAIndividual  *pcOther, int  *piGenesTheSame);
		void  vRandomizeGenotype();
		int*  piGetGenotype() { return(pi_genotype); }

		int  iGetPopLevel();


		int   iMixing_ePX(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult);
		int   iMixing_ePX_Brutal(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult);

		void  vGetPxMasks(CDarkGrayGAIndividual  *pcOther, CDarkGrayGAPxMaskManager  *pcMasksManager);
		int   iMixing_ePX_ByMaskLen(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult);
		int   iMixing_PX_ByMask(CDarkGrayGAPxMask *pcMask, CDarkGrayGAIndividual  *pcResult);
		int   iUniformCrossoverByMask(CDarkGrayGAPxMask *pcMask, CDarkGrayGAIndividual  *pcResult);

		int   iMixing_ePX_ByDonor(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult);
		int   iMixing_ePX_ByDonor(CDarkGrayGAIndividual *pcDonor, CDarkGrayGAIndividual  *pcResult);
		int   iMixing_ePX_Pair(CDarkGrayGAIndividual *pcOther, CDarkGrayGAIndividual  *pcResult);
		void  vEpxMaskCompute(int  iGeneToCross, CDarkGrayGAIndividual *pcReceiver);
		bool  bEpxMaskCanICross();
		int   iEpxMaskPositionsExchanged() { return(i_epx_mask_positions_exchanged); };
		int   iEpxMaskPositionsRemainDiffering() { return(i_epx_mask_positions_remain_differing); };
		int   iEpxDonateByMask(CDarkGrayGAIndividual *pcReceiver, CDarkGrayGAIndividual *pcResult);

		void  vCopyFrom(CDarkGrayGAIndividual  *pcNewInd);

		double  dComputeFitness();
		double  dComputeFitnessDouble();
		double  dComputeFitnessOptimize(vector<int>  *pvOrder = NULL, bool  bDarkGray = false, int  *piDarkGrayModifiedGenes = NULL);


		void  vClearOptOrder() { v_opt_order.clear(); }

		CString  sToStr();
		CString  sEpxToStr();

	private:
		void  v_epx_mask_extend_at_level(int  iLevelToExplode, CDarkGrayGAIndividual *pcReceiver);

		void  v_create_opt_order(vector<int>  *pvOrder);
		double  d_optimize_single_gene(int  iOptGene);

		bool  b_get_all_epx_masks(int  *piMasksManager, int  *piMasksNum, CDarkGrayGAIndividual  *pcDonor);



		CDarkGrayGASinglePop  *pc_parent;
		int  i_templ_length;
		int  *pi_genotype;
		vector<int>  v_opt_order;

		int  *pi_epx_mask;
		bool  b_epx_mask_can_cross;
		int   i_epx_mask_positions_exchanged;
		int   i_epx_mask_positions_remain_differing;

		double  d_fitnes_buf;
		bool  b_fitness_actual;

		CProblem<CBinaryCoding, CBinaryCoding > *pc_problem;
	};//class  CDarkGrayGAIndividual

}//namespace nDarkGrayGA

#endif//CDARK_GRAY_GA_OPTIMIZER_H
