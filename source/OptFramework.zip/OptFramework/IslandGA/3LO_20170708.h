#ifndef C3LO_OPTIMIZER_H
#define C3LO_OPTIMIZER_H


#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "Error.h"
#include "Log.h"
#include "Optimizer.h"
#include "Problem.h"
#include  "util\timer.h"


#include <istream>
#include <algorithm>



namespace ThreeLO
{
	#define  _3LO_TRIBE_MAX_ROUNDS_NUM								5


	class  C3LOIndividual;
	class  C3LOPattern;
	class  CMessyGene;
	class  C3LOPatternPair;
	class  C3LOHighLvlGeneFreq;
	class  CGenotypeInfoNode;


	class C3LO : public CBinaryOptimizer
	{
		friend class C3LOIndividual;
	public:
		static uint32_t iERROR_PARENT_C3LOOptimizer;
		static uint32_t iERROR_CODE_3LO_GENOTYPE_LEN_BELOW_0;



		C3LO(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog);
		C3LO(C3LO *pcOther);
		~C3LO();

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new C3LO(this); };

		virtual CError eConfigure(istream *psSettings);

		virtual void vInitialize(time_t tStartTime);
		virtual bool bRunIteration(uint32_t iIterationNumber, time_t tStartTime);


		vector<vector<C3LOPattern *>>  *pvGetHigherLevelTreesGenes() { return(&v_higher_level_trees_genes); }

		//for individuals
		double dComputeFitness(int32_t *piBits);
		bool  bCanIndBeAddedAtAnyLevel(C3LOIndividual *pcInd, bool  bComparePhenotypes = true, bool  bCompareGenotypes = false);


	private:
		void  v_initialize_orders();
		void  v_add_order_by_genotype(bool  bReversed);
		void  v_add_order_random(bool  bWithOpposite);

		void  v_insert_gene_pattern_part_level(int  iPatternPartLevel);
		void  v_add_gene_pattern_tree(C3LOPattern  *pcTree, int  iPatternLevel);
		double  d_get_most_similar_pattern_pair_offset(int  *piMostSimlarPairOffset, vector<C3LOPatternPair>  *pvPatternPairs);

		void  v_remove_pattern_from_buffer(vector<C3LOPattern  *>  *pvPartsBuffer, C3LOPattern  *pcPatternToRemove);
		void  v_remove_pattern_from_pairs_buffer(vector<C3LOPatternPair>  *pvPatternPairsBuffer, C3LOPattern  *pcPatternToRemove);


		bool  b_add_higher_level_gene(C3LOPattern  *pcHigherLevelGene, int  iGeneLevel);
		bool  b_ind_on_lvl(C3LOIndividual *pcInd, int  iEvolutionLvl);
		bool  b_run_flat_pop_for_ind(C3LOIndividual  *pcIndMain, int iPatternLevel, vector<C3LOIndividual  *>  *pvLevelsOffspringsDifferentToParent);
		void  v_tiny_restricted_evolution(C3LOIndividual  *pcParentMain, C3LOIndividual  *pcParentDonator, C3LOIndividual  **pcOffspring, C3LOIndividual  **pcReversedOffspring, int  iPatternLevel, int  iPopDestLvl, int iRepeatation = -1);

		void  v_update_high_lvl_genes_and_trees();
		void  v_create_trees_from_ind(C3LOIndividual  *pcIndiv, vector<C3LOPattern *>  *pvTreesDest, int iPatternLevel);
		void  v_build_pattern_tree(vector<C3LOPattern  *>  *pvGenePatternsParts, vector<C3LOPattern  *>  *pvGenePatternsTrees, int  iLevel);
		bool  b_cross_individuals_by_tree_branch(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOIndividual  **pcOffspring, C3LOIndividual  **pcReversedOffspring, C3LOPattern *pcCrossingTree, int  iPatternLevel);
		bool  b_cross_individuals_by_tree_branch_or_part(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOIndividual  **pcOffspring, C3LOIndividual  **pcReversedOffspring, C3LOPattern *pcCrossingTree, int  iPatternLevel);
		bool  b_cross_individuals_by_tree_branch_longest_reasonable_branch(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOIndividual  **pcOffspring, C3LOIndividual  **pcReversedOffspring, C3LOPattern *pcCrossingTree, int  iPatternLevel);
		bool  b_cross_individuals_by_tree(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOIndividual  **pcOffspring, C3LOPattern *pcCrossingTree, int iPatternLevel);
		bool  b_cross_infect_individual_by_tree(C3LOIndividual  *pcInd, C3LOIndividual  *pcDonator, C3LOIndividual  **pcOffspring, C3LOPattern *pcCrossingTree, int iPatternLevel);


		void  v_remove_from_levels(C3LOIndividual *pcInd);
		double  d_get_covering_at_level(int  iLevel);
		void  v_add_linkage_covering_at_level(int  iLevel);

		int  i_get_ind_number();

		void  v_count_higher_genes_freq();


		C3LOIndividual* pc_get_random_individual();
		C3LOIndividual *pc_get_individual_with_lvl_tournament(C3LOIndividual *pcDifferentToIndiv = NULL);
		C3LOIndividual *pc_get_individual_from_lvl(int  iEvolutionLvl, C3LOIndividual *pcDifferentToIndiv = NULL);
		bool  b_add_at_level(C3LOIndividual *pcInd, int  iLevel, bool  bComparePhenotypes = true, bool  bCompareGenotypes = false);
		C3LOIndividual* pc_insert_into_pop(vector  <C3LOIndividual  *>  *pvPopDest, C3LOIndividual  *pcIndToInsert, bool bCheckPhenotype = true, bool  bCheckGenotype = false);
		bool  b_can_ind_be_added_at_any_level(C3LOIndividual *pcInd, bool  bComparePhenotypes = true, bool  bCompareGenotypes = false);
		bool  b_produce_new_linkage(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, int  iPatternLevel);

		void  v_save_trees_and_patterns(CString  sPatternFile);


	private:
		int  i_templ_length;
		vector<vector<int>> v_optimization_orders;
		vector  <C3LOIndividual  *>  *pv_population;
		vector<C3LOIndividual  *>  v_new_individuals;

		vector<vector<C3LOPattern *>>  v_gene_patterns_parts_original;
		vector<vector<C3LOPattern *>>  v_gene_patterns_parts;
		vector<vector<C3LOPattern *>>  v_gene_patterns_trees;
		vector<vector<C3LOPattern *>>  v_higher_level_trees_genes;

		vector  <vector<C3LOIndividual  *>>  v_population_levels;

		vector  <int  *>  v_genes_marked_by_linkage;

		CGenotypeInfoNode  *pc_genotype_root;


		//stats generation
		int  i_random_indiv_adds;
		time_t t_start;


		//for single iteration:
		C3LOIndividual  *pc_best;
		C3LOIndividual  *pc_indiv_main;

		int  *pi_genotype_diffr_tool;
		int32_t  *pi_best_genotype;//for COptimizer best individual update

		CString  s_debug;

		int i_pop_to_add;
		int i_upgraded_new_ind_at_last_insert;
		int i_upgraded_new_ind;
		int i_worse_but_different_used;
		int i_worse_but_different_used_at_last_insert;
		int  i_crossings_with_effect_in_the_pop;
		int  i_all_crossings;
		int  i_better_but_cannot_be_added_at_last_insert;
		int  i_better_but_cannot_be_added;
		int  i_tribe_effective_in_this_iteration;
		int  i_brutal_random_search;
		int  i_brutal_random_search_effective;
		double  d_fit_max_cur;
		double  d_unit_max_cur;
		int  i_cur_gen;
		bool  b_tribe_effective;

		TimeCounters::
		CTimeCounter  c_time_counter;

	};//class CDummyOptimizer : public CBinaryOptimizer




	class  C3LOIndividual 
	{
	#define  C3LO_INDIVIDUAL_MAX_GENES_FOR_BS					12
	#define  C3LO_INDIVIDUAL_MAX_HIGH_LEVEL_GENES_VALUES					2

		friend class C3LO;
		friend class CGenotypeInfoNode;
		friend class C3LOHighLvlGeneFreq;

	public:
		C3LOIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, vector<vector<int>> *pvOptimizationOrders, C3LO  *pcParent);
		~C3LOIndividual();

		void vRandomInit();
		double  dComputeFitness(int  iPatternLevel, bool  bOptimize = true);
		double  dComputeFitnessOfCurrentPhenotype(int  iPhenotype);
		void  vSetNotOptimized() { b_optimized = false; }


		void  vIncrementalBrutalUpdate(vector<C3LOPattern *> *pvGenePatterns, vector<C3LOPattern *> *pvGenePatternPartsOriginal, int iPatternLevel);
		bool  bLinkedGenesBrutalSearch(C3LOPattern *pcLinkedGenes, int iPatternLevel, vector<C3LOPattern *> *pvGenePatternPartsOriginal, C3LOIndividual  **pcBestUpdate, C3LOIndividual  **pcBestButDifferent);
		bool  bLinkedGenesBrutalSearchZero(C3LOPattern *pcLinkedGenes, vector<C3LOPattern *> *pvGenePatternPartsOriginal, C3LOIndividual  **pcBestUpdate, C3LOIndividual  **pcBestButDifferent);
		bool  bLinkedGenesBrutalSearchHigher(C3LOPattern *pcLinkedGenes, int iPatternLevel, C3LOIndividual  **pcBestUpdate, C3LOIndividual  **pcBestButDifferent);


		bool  bGetTreesGenerated(int  iPatternLevel);
		void  vGeneratePatternSingle(vector<C3LOPattern  *>  *pvGenePatternsParts, vector<C3LOPattern  *>  *pvGenePatternsPartsOriginal, int iPatternLevel);
		void  vGetPatternsParts(vector<C3LOPattern  *>  *pvGenePatternsParts, int iPatternLevel);

		void  vCopyTo(C3LOIndividual  *pcOther);
		void  vCopyPhenotypeTo(C3LOIndividual  *pcOther);

		bool  bComparePhenotype(C3LOIndividual  *pcOther);
		bool  bCompareGenotype(C3LOIndividual  *pcOther);
		int*  piGetPhenotype(int  iPhenotype);

		double  dUnitation(int  iOptimizedGenotype =-1);


		void  vSaveGenePatternParts(CString  sDebugName);
		void  vSave(FILE  *pfReport, int  *piProblemBlockStructure, bool bDoNotForcePhenotype = false);
		//double  dComputeFitness(int  iPatternLevel, bool  bOptimize = true);
		//double  dComputeFitnessOfCurrentPhenotype(int  iPhenotype);*/

	private:
		double  d_compute_fitness_at_level_zero(bool  bOptimize);
		double  d_compute_fitness_at_level(int  iPatternLevel);
		double  d_compute_fitnesss_simple(bool  bOptimize = true);
		double  d_optimize_genotype(int  iOrder);

		bool  b_brutal_check(vector<int>  *pvGenesShuffled, C3LOIndividual  *pcOptimizationBuf, C3LOIndividual  *pcBestThatFar, int  *piBestThatFarInitialized, int  iPos);
		bool  b_brutal_check_high_level(vector<C3LOPattern  *>  *pvHighLevelGenesShuffled, C3LOIndividual  *pcOptimizationBuf, C3LOIndividual  *pcBestThatFar, int  *piBestThatFarInitialized, int iPatternLevel, int  iPos);
		C3LOPattern*  pc_get_pattern_part(int  iGenePosition, int *piFilledGenes, vector<C3LOPattern *> *pvGenePatternPartsOriginal);

		
		void  v_get_patterns_parts_zero_level(vector<C3LOPattern  *>  *pvGenePatternsParts);
		void  v_get_patterns_parts_high_level(vector<C3LOPattern  *>  *pvGenePatternsParts, int iPatternLevel);
		bool  b_phenotypes_the_same(int  iPosition, C3LOIndividual *pcOther);

		//double  d_compute_fitness_at_level_zero(bool  bOptimize);
		//double  d_compute_fitness_at_level(int  iPatternLevel);

		C3LO  *pc_parent;
		int  i_level;

		bool  b_trees_generated;
		vector<bool>  v_pattern_generated;
		vector<vector<C3LOPattern *>>  v_gene_patterns_parts;
		vector<vector<C3LOPattern *>>  v_gene_patterns_trees;

		int  i_optimized_at_pattern_level;

				

		CProblem<CBinaryCoding, CBinaryCoding > *pc_problem;
		vector<vector<int>> *pv_optimization_orders;



		//data
		int  i_templ_length;
		bool  b_optimized;
		int  *pi_genotype;
		int  **pi_optimized_genotypes;
		double  *pd_fit_values;

		double  d_fit_value;

	};//class  C3LOIndividual



	class  C3LOPattern
	{
	#define  C3LO_PATTERN_TAB_INCREASE					"  "
		friend class C3LO;
		friend class C3LOIndividual;
	public:
		C3LOPattern(int iTemplLength);
		~C3LOPattern();

		vector<C3LOHighLvlGeneFreq  *>  *pvGetHighLevelGeneFreq() { return(&v_high_level_gene_freq); }
		vector<CMessyGene>  *pvGetPattern() { return(&v_pattern); };

		vector<C3LOPattern *>  *pvGetChildren() { return(&v_children); };

		int  iGetPatternLevel() { return(i_pattern_level); }

		void  vGetCommonAndUNcommonPositions(C3LOPattern  *pcOther, int *piCommonPos, int *piUncommonPos, int *piUnmarkedPos);
		void  vGetCommonAndUNcommonPositions(int  *piDifferences, int *piCommonPos, int *piUncommonPos, int *piUnmarkedPos);
		int  iCommonPositions(C3LOPattern  *pcOther, bool  bCheckValues = false, bool  bAllMustBeTheSame = true);
		int  iDifferentPositions(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int iPatternLevel);

		void  vCountHighLvlGeneFreq(vector<C3LOIndividual *>  *pvPopoulation, int iPatternLevel);

		C3LOPattern*  pcGetBestCrossingNode(int iPatternLevel, C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int *piDiffrentPositions = NULL, double  *pdDifrPosPerc = NULL);
		void  vGetRandomTreeBranch(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, vector<C3LOPattern  *>  *pvTreeBranch, int iPatternLevel);
		C3LOPattern*  pcGetLongestReasonableBranch(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int *piDifferenceSearchTool, int iPatternLevel);
		void  vGetBestCovering(vector<C3LOPattern*> *pvDiffrCoveringPatterns, int  *piDifferences, int iAcceptableLevel);
		bool  bMarkedPhenotypeDifferences(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int iPatternLevel);
		bool  bUnMarkedPhenotypeDifferences(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int *piDifferenceSearchTool, int iPatternLevel);

		void  vJoinSinglePatternAdd(C3LOPattern  *pcPatOther);
		void  vJoinTwoPatterns(C3LOPattern  *pcPat0, C3LOPattern  *pcPat1);


		bool  bAmIThere(vector<C3LOPattern  *>  *pvGenePatternsParts, bool  bCheckValues = false);
		bool  bGeneThere(int  iGenePosition);

		void  vSavePattern(FILE  *pfDest, int  *piProblemBlockStructure, CString  sTab = "", bool bOnlyRoot = false);
		void  vSaveHighLevelGene(FILE  *pfDest, int  *piProblemBlockStructure);


	private:
		void  v_check_high_level_gene_for_ind(C3LOIndividual *pcInd, int iPatternLevel);

		int  i_pattern_level;
		int  i_templ_length;
		vector<CMessyGene>  v_pattern;

		vector<C3LOPattern *>  v_parents;
		vector<C3LOPattern *>  v_children;



		vector<C3LOHighLvlGeneFreq  *>  v_high_level_gene_freq;
	};//class  C3LOPattern


	class  C3LOPatternPair
	{
	public:
		C3LOPattern  *pc_first;
		C3LOPattern  *pc_second;
		double  d_similarity;

	};//class  C3LOPatternPair




	class  C3LOHighLvlGeneFreq
	{
	public:
		C3LOHighLvlGeneFreq(int  iTemplLength);
		~C3LOHighLvlGeneFreq();

		void  vSetTemplLen(int  iTemplLength);
		void  vCreate(C3LOPattern  *pcPattern, C3LOIndividual *pcInd, int iPatternLevel);
		bool  bCheckHighLevelGene(C3LOIndividual *pcInd, int iPatternLevel);

		void  vInfect(C3LOIndividual  *pcInd);
		void  vInfectPhenotype(C3LOIndividual  *pcInd, int iPhenotype);

		void  vSave(FILE  *pfDest, CString  sTab = " ");

		int  iGetGeneNumber() { return(i_gene_number); }

	private:
		int  *pi_gene_def;
		int  i_gene_number;

		int  i_templ_length;

	};//class  C3LOHighLvlGeneFreq




	class  CGenotypeInfoNode
	{
	public:
		CGenotypeInfoNode();
		~CGenotypeInfoNode();

		int  iGetSuccOpt() { return(i_succ_opt); }
		C3LOIndividual *pcCheckIndividual(C3LOIndividual *pcIndToCheck);

	private:
		int  i_succ_opt;
		int  i_value;
		vector<CGenotypeInfoNode *>  v_children;
		vector<C3LOIndividual *>  v_individuals;

		CGenotypeInfoNode  *pc_get_child_node(int  iVal);
		C3LOIndividual *pc_check_individual(C3LOIndividual *pcIndToCheck, int  iPos);


	};//class  CGenotypeInfoNode



	class  CMessyGene
	{
	public:
		CMessyGene();
		CMessyGene(int  iGeneVal, int  iGenePos);
		CMessyGene(CMessyGene  *pcOther);
		~CMessyGene();

		int  iGeneVal() { return(i_gene_val); }
		int  iGenePos() { return(i_gene_pos); }

	private:

		int  i_gene_val;
		int  i_gene_pos;
	};//class  CMessyGene
	
}//namespace 3LO


#endif//C3LO_OPTIMIZER_H
