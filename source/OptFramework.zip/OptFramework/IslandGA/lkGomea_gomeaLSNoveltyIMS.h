#pragma once


#pragma once

#include <vector>
#include <unordered_map>
using namespace std;

#include "lkGomea_Config.h"
#include "lkGomea_PopulationNovelty.h"
//#include "problems.hpp"
#include "lkGomea_shared.h"
#include "lkGomea_gomea.h"






class C_lkGomea_gomeaLSNoveltyIMS: public C_lkGomea_GOMEA
{
public:
	int maximumNumberOfGOMEAs;
	int generationsWithoutImprovement;
	int IMSsubgenerationFactor, basePopulationSize, numberOfGOMEAs, numberOfGenerationsIMS, minimumGOMEAIndex;
	int subscheme;
	int step;
	int currentPopulationSize, currentRunCount;

	// Two options that can be enabled / disabled
	// WARNING: abort_smaller_populations_with_worse_average_fitness does lead to a performance regression
	//          due to smaller populations being aborted too early.
	bool abort_smaller_populations_with_worse_average_fitness = true;
	bool perform_cluster_aware_convergence_detection = false;

	vector<C_lkGomea_PopulationNovelty*> GOMEAs;

	C_lkGomea_gomeaLSNoveltyIMS(C_lkGomea_Config *config_);
	~C_lkGomea_gomeaLSNoveltyIMS();
	
	void initializeNewGOMEA();
	bool checkTermination();
	bool b_generationalStepAllGOMEAs();
	bool b_generationalStepSmallestGOMEAUntilAllTerminated(int indexSmallest, int indexBiggest);
	bool b_generationalStepAllEvenlyGOMEAUntilAllTerminated(int indexSmallest, int indexBiggest);
	bool checkTerminationGOMEA(int GOMEAIndex);
	bool b_GOMEAGenerationalStepAllGOMEAsRecursiveFold(int indexSmallest, int indexBiggest);
	bool b_run();


	bool  bRunSingleIteration();
	C_lkGomea_Individual  *pcGetBestInd();
};