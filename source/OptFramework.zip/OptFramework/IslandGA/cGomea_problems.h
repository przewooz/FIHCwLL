#pragma once

#include <vector>
#include <unordered_map>
#include <string>
#include <fstream>
#include <deque>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <cassert>
using namespace std;

#include "cGomea_Individual.h"
#include "cGomea_utils.h"

class C_CGomea_Config;
#include "cGomea_Config.h"

#include "BinaryCoding.h"
#include "BinaryOptimizer.h"

class C_CGomea_Problem
{
public:
	int numberOfVariables;
	int usePartialEvaluations;
	
	C_CGomea_Problem(){};
	virtual ~C_CGomea_Problem(){};
	virtual void initializeProblem(int numberOfVariables)=0;
	virtual double calculateFitness(C_CGomea_Individual *solution)=0;
	virtual double calculateFitnessPartialEvaluations(C_CGomea_Individual *solution, C_CGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

class C_CGomea_oneMax:public C_CGomea_Problem
{
public:
	C_CGomea_oneMax(){cout<<"creating oneMax\n";}
	void initializeProblem(int numberOfVariables_)
	{
		numberOfVariables = numberOfVariables_;
	};
	double calculateFitness(C_CGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_CGomea_Individual *solution, C_CGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

class C_CGomea_concatenatedDeceptiveTrap:public C_CGomea_Problem
{
	int k, s;
	bool bimodal;
	vector<vector<int> > trapsForVariable; //determines traps which each variables belongs to
public:
	C_CGomea_concatenatedDeceptiveTrap(int k_, int s_, bool bimodal_): k(k_), s(s_), bimodal(bimodal_)
	{
		if (bimodal_ == false)
			cout<<"creating concatenated Deceptive Trap with trap size=" << k << " and shift=" << s << endl;
		else
		{
			if (k != 10 && k != 6)
			{
				cout << "Bimodal trap with k=" << k << " not implemented!" << endl;
				exit(0);
			}
			cout<<"creating bimodal concatenated Deceptive Trap with trap size=" << k << " and shift=" << s << endl;
		}
	}
	void initializeProblem(int numberOfVariables_);
	double calculateFitness(C_CGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_CGomea_Individual *solution, C_CGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

struct C_CGomea_NKSubfunction
{
	vector<int> variablesPositions;
	vector<double> valuesTable;
};

class C_CGomea_ADF:public C_CGomea_Problem
{
	string problemInstanceFilename;
	vector<C_CGomea_NKSubfunction> subfunctions;
	vector<vector<int> > subfunctionsForVariable;

public:
	C_CGomea_ADF(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating ADF\n";
	}

	void initializeProblem(int numberOfVariables_);

	double calculateFitness(C_CGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_CGomea_Individual *solution, C_CGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

class C_CGomea_hierarchialDeceptiveTrap:public C_CGomea_Problem
{
	int k;
	vector<int> transform;
public:
	C_CGomea_hierarchialDeceptiveTrap(int k_): k(k_)
	{
		cout<<"creating hierarchialDeceptiveTrap\n";
	}

	void initializeProblem(int numberOfVariables_)
	{
		numberOfVariables = numberOfVariables_;
		if (!C_CGomea_isPowerOfK(numberOfVariables, k))
		{
			cerr << "Number of bits should be a power of k! " << numberOfVariables << " is not a power of " << k << endl;
			exit(0);
		}
		transform.resize(numberOfVariables);		
	};

	double generalTrap(int unitation, double leftPeak, double rightPeak);
	double calculateFitness(C_CGomea_Individual *solution);
	//double calculateFitnessPartialEvaluations(Individual *solution, Individual *solutionBefore, vector<double> &touchedGenes, double fitnessBefore);
};

class C_CGomea_hierarchialIfAndOnlyIf:public C_CGomea_Problem
{
public:
	C_CGomea_hierarchialIfAndOnlyIf()
	{
		cout<<"creating hierarchialIfAndOnlyIf\n";
	}
	void initializeProblem(int numberOfVariables_)
	{
		numberOfVariables = numberOfVariables_;
		if (!C_CGomea_isPowerOfK(numberOfVariables, 2))
		{
			cerr << "Number of bits should be a power of 2! " << numberOfVariables<< " is not a power of 2" << endl;
			exit(0);
		}
	};

	double calculateFitness(C_CGomea_Individual *solution);
};

class C_CGomea_maxCut:public C_CGomea_Problem
{
	string problemInstanceFilename;
	vector<pair<pair<int, int>, double > > edges;
	vector<vector<int> > edgesForVariable;

public:
	C_CGomea_maxCut(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating maxCut\n";
	}
	void initializeProblem(int numberOfVariables_);
	double calculateFitness(C_CGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_CGomea_Individual *solution, C_CGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

class C_CGomea_leadingOnes:public C_CGomea_Problem
{
public:
	C_CGomea_leadingOnes()
	{
		cout<<"creating leadingOnes\n";
	}
	void initializeProblem(int numberOfVariables_)
	{
		numberOfVariables = numberOfVariables_;
	};

	double calculateFitness(C_CGomea_Individual *solution);
	//double calculateFitnessPartialEvaluations(Individual *solution, Individual *solutionBefore, vector<double> &touchedGenes, double fitnessBefore);
};

class C_CGomea_Clustering:public C_CGomea_Problem
{
	string problemInstanceFilename;
	vector<vector<double> > points;
	vector<vector<double> > distances;
	
	int Dim;
public:
	C_CGomea_Clustering(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating Clustering\n";
	}
	void initializeProblem(int numberOfVariables_);
	double calculateFitness(C_CGomea_Individual *solution);
};

class C_CGomea_MAXSAT:public C_CGomea_Problem
{
	string problemInstanceFilename;
	vector<vector<int> > subfunctions;
	vector<vector<int> > signs;
	
	vector<vector<int> > subfunctionsForVariable;

public:
	C_CGomea_MAXSAT(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating MAXSAT\n";
	}

	void initializeProblem(int numberOfVariables_);

	double calculateFitness(C_CGomea_Individual *solution);
};

class C_CGomea_SpinGlass:public C_CGomea_Problem
{
	string problemInstanceFilename;
	vector<vector<int> > subfunctions;
	
	vector<vector<int> > subfunctionsForVariable;

public:
	C_CGomea_SpinGlass(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating SpinGlass\n";
	}

	void initializeProblem(int numberOfVariables_);	

	double calculateFitness(C_CGomea_Individual *solution);
};



class C_CGomea_External :public C_CGomea_Problem
{

public:
	C_CGomea_External(CProblem<CBinaryCoding, CBinaryCoding> *pcExternalProblem)
	{
		pc_external_problem = pcExternalProblem;
		//cout << "creating C_CGomea_External\n";
	}

	virtual ~C_CGomea_External();

	void initializeProblem(int numberOfVariables_);

	double calculateFitness(C_CGomea_Individual *solution);

private:
	CProblem<CBinaryCoding, CBinaryCoding>  *pc_external_problem;
	CIndividual<CBinaryCoding, CBinaryCoding> *pc_evaluation_individual;
	int32_t *pi_bits;

};


double C_CGomea_deceptiveTrap(int unitation, int k);
double C_CGomea_bimodalDeceptiveTrap(int unitation, int k);

void createProblemInstance(int problemIndex, int numberOfVariables, C_CGomea_Config *config, C_CGomea_Problem **problemInstance, string &instancePath, int k = 1, int s = 1);
bool problemNameByIndex(C_CGomea_Config *config, string &problemName);

