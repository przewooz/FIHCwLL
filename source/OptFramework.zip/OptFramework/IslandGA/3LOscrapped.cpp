#include "3LOscrapped.h"



using  namespace ThreeLOScr;


uint32_t C3LOscrappedMultiPop::iERROR_PARENT_C3LOScrappedMultiPopOptimizer  = CError::iADD_ERROR_PARENT("iERROR_PARENT_C3LOScrappedMultiPopOptimizer");

uint32_t C3LOscrapped::iERROR_PARENT_C3LOScrappedOptimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_C3LOScrappedOptimizer");
uint32_t C3LOscrapped::iERROR_CODE_3LO_SCRAPPED_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_3LO_SCRAPPED_GENOTYPE_LEN_BELOW_0");


//---------------------------------------------C3LOscrapped-------------------------------------------------------
C3LOscrapped::C3LOscrapped(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	pv_other_pops = NULL;
	pc_last_added = NULL;
};//C3LOscrapped::C3LOscrapped(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



C3LOscrapped::C3LOscrapped(C3LOscrapped *pcOther) : CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "Brak implementacji: C3LOscrapped::C3LOscrapped(C3LOscrapped *pcOther) : CBinaryOptimizer(pcOther)", "BRAK", MB_OK);
}//C3LOscrapped::C3LOscrapped(C3LOscrapped *pcOther) : CBinaryOptimizer(pcOther)*/



C3LOscrapped::~C3LOscrapped()
{
	for (int i_lev = 0; i_lev < v_pop.size(); i_lev++)
	{
		for (int ii = 0; ii < v_pop.at(i_lev).size(); ii++)
			delete  v_pop.at(i_lev).at(ii);
	}//for  (int  i_lev = 0; i_lev < v_pop.size(); i_lev++)


	for (int i_lev = 0; i_lev < v_pop_superpop.size(); i_lev++)
	{
		for (int ii = 0; ii < v_pop_superpop.at(i_lev).size(); ii++)
			delete  v_pop_superpop.at(i_lev).at(ii);
	}//for  (int  i_lev = 0; i_lev < v_pop.size(); i_lev++)


	delete  pc_best;
	delete  pc_ind_buf;
}//C3LOscrapped::~C3LOscrapped()


void  C3LOscrapped::vInitialize()
{
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();
	i_the_same_checks = 0;
	i_succ_oms = 0;
	c_time_counter.vSetStartNow();
	pv_other_pops = NULL;
	pc_last_added = NULL;

	pc_best = pc_get_random_individual(0);
	pc_best->dComputeFitness();
	pc_ind_buf = pc_get_random_individual(0);

	c_ltree_global.vSetParent(this);
}//void  C3LOscrapped::vInitialize(time_t tStartTime)



void  C3LOscrapped::vCopyFrom(C3LOscrapped *pcOther)
{
	i_leave_ind_at_level = pcOther->i_leave_ind_at_level;
	i_om_slide = pcOther->i_om_slide;
	i_random_linkage = pcOther->i_random_linkage;
	i_linkage_scrap = pcOther->i_linkage_scrap;
	i_linkage_scrap_analysis = pcOther->i_linkage_scrap_analysis;
	i_linkage_scrap_create_effect_scrap = pcOther->i_linkage_scrap_create_effect_scrap;
	i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp = pcOther->i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp;

	i_the_same_checks = pcOther->i_the_same_checks;
	i_succ_oms = pcOther->i_succ_oms;
	i_random_indiv_adds = pcOther->i_random_indiv_adds;

	i_templ_length = pcOther->i_templ_length;
}//void  C3LOscrapped::vCopyForm(C3LOscrapped *pcOther)



CError C3LOscrapped::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_C3LOScrappedOptimizer);


	c_err = CBinaryOptimizer::eConfigure3LO(psSettings);


	CUIntCommandParam p_leave_at_level(_3LO_SCRAPPED_ARGUMENT_LEAVE_AT_LEVEL);
	i_leave_ind_at_level = p_leave_at_level.iGetValue(psSettings, &c_err);
	if (p_leave_at_level.bHasValue() == false)  i_leave_ind_at_level = 0;
	if (c_err)  return(c_err);


	CUIntCommandParam p_leave_om_slide(_3LO_SCRAPPED_ARGUMENT_OM_SLIDE);
	i_om_slide = p_leave_om_slide.iGetValue(psSettings, &c_err);
	if (p_leave_om_slide.bHasValue() == false)  i_om_slide = 0;
	if (c_err)  return(c_err);


	CUIntCommandParam p_random_linkage(_3LO_SCRAPPED_ARGUMENT_RANDOM_LINKAGE);
	i_random_linkage = p_random_linkage.iGetValue(psSettings, &c_err);
	if (p_random_linkage.bHasValue() == false)  i_random_linkage = 0;
	if (c_err)  return(c_err);

	CUIntCommandParam p_random_linkage_scrap(_3LO_SCRAPPED_ARGUMENT_LINKAGE_SCRAP);
	i_linkage_scrap = p_random_linkage_scrap.iGetValue(psSettings, &c_err);
	if (p_random_linkage_scrap.bHasValue() == false)  i_linkage_scrap = 0;
	if (c_err)  return(c_err);

	CUIntCommandParam p_random_linkage_scrap_analysis(_3LO_SCRAPPED_ARGUMENT_LINKAGE_SCRAP_ANALYSIS);
	i_linkage_scrap_analysis = p_random_linkage_scrap_analysis.iGetValue(psSettings, &c_err);
	if (p_random_linkage_scrap_analysis.bHasValue() == false)  i_linkage_scrap_analysis = 0;
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_linkage_scrap_create_effect_scrap(_3LO_SCRAPPED_ARGUMENT_LINKAGE_SCRAP_EFFECT_SCRAP);
	i_linkage_scrap_create_effect_scrap = p_linkage_scrap_create_effect_scrap.iGetValue(psSettings, &c_err);
	if (p_linkage_scrap_create_effect_scrap.bHasValue() == false)  i_linkage_scrap_create_effect_scrap = 0;
	if (c_err)  return(c_err);

	CUIntCommandParam p_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp(_3LO_SCRAPPED_ARGUMENT_LINKAGE_SCRAP_EFFECT_SCRAP_PLUS_PROVOKING_SCRAP);
	i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp = p_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp.iGetValue(psSettings, &c_err);
	if (p_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp.bHasValue() == false)  i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp = 0;
	if (c_err)  return(c_err);


	return c_err;
};//CError C3LOscrapped::eConfigure(istream *psSettings)



bool  C3LOscrapped::bCheckPopulationIfExists(C3LOscrappedIndividual  *pcNewInd)
{
	for (int i_level = 0; i_level < v_pop.size(); i_level++)
	{
		for (int i_ind = 0; i_ind < v_pop.at(i_level).size(); i_ind++)
		{
			if (v_pop.at(i_level).at(i_ind)->bIsTheSame(pcNewInd) == true)
			{
				i_the_same_checks++;
				return(true);
			}//if  (v_pop.at(i_level).at(i_ind)->bIsTheSame(pcNewInd) == true)
		}//for  (int i_ind = 0; i_ind < v_pop.at(i_level).size(); i_ind++)		
	}//for  (int i_level = 0; i_level < v_pop.size(); i_level++)
	return(false);
}//bool  C3LOscrapped::bCheckPopulationIfExists(CSingleTrajectorySet  *pcNewInd)


int  C3LOscrapped::iGetIndNumber()
{
	int  i_sum = 0;

	for (int i_level = 0; i_level < v_pop.size(); i_level++)
	{
		i_sum += v_pop.at(i_level).size();
	}//for  (int i_level = 0; i_level < v_pop.size(); i_level++)

	return(i_sum);
}//int  C3LOscrapped::iGetIndNumber()




void C3LOscrapped::v_pyramid_clear()
{
	v_pop.clear();
}//void C3LOscrapped::v_pyramid_clear()


void C3LOscrapped::v_pyramid_join(vector<vector<C3LOscrappedIndividual *>> *pvPyramidToJoin)
{
	for (int i_lev = 0; i_lev < pvPyramidToJoin->size(); i_lev++)
	{
		while (v_pop.size() <= i_lev)  v_pop.push_back(vector<C3LOscrappedIndividual *>());

		for (int ii = 0; ii < pvPyramidToJoin->at(i_lev).size(); ii++)
			v_pop.at(i_lev).push_back(pvPyramidToJoin->at(i_lev).at(ii));
	}//for  (int  i_lev = 0; i_lev < v_pop.size(); i_lev++)
}//void C3LOscrapped::v_pyramid_join(vector<vector<C3LOscrappedIndividual *>> *pvPyramidToJoin)



bool C3LOscrapped::b_run_iteration_super_pop_single_best(uint32_t iIterationNumber, vector<C3LOscrapped *> *pvPops)
{
	CString  s_buf;

	double  d_fit_before, d_fit_after;

	pv_other_pops = pvPops;

	pc_best->vClearOptOrder();
	d_fit_before = pc_best->dComputeFitnessOptimize();


	/*for (int i_pop = 0; i_pop < pvPops->size(); i_pop++)
	{
		if (pvPops->at(i_pop)->pc_best->dComputeFitness() > pc_best->dComputeFitness())  pc_best->vCopyFrom(pvPops->at(i_pop)->pc_best);
	}//for (int i_pop = 0; i_pop < pvPops->size(); i_pop++)*/



	c_ltree_global.pvGetNodes()->clear();
	for (int i_pop = 0; i_pop < pvPops->size(); i_pop++)
	{
		for (int ii = 0; ii < pvPops->at(i_pop)->c_ltree_global.pvGetNodes()->size(); ii++)
		{
			c_ltree_global.pvGetNodes()->push_back(pvPops->at(i_pop)->c_ltree_global.pvGetNodes()->at(ii));
		}//for (int ii = 0; ii < pvPops->at(i_pop)->c_ltree_global.pvGetNodes()->size(); ii++)
	}//for (int i_pop = 0; i_pop < pvPops->size(); i_pop++)*/

	
	

	int  i_om_res;

	double  d_loc_fit_before, d_loc_fit_after;
	
	for (int i_pop = 0; i_pop < pvPops->size(); i_pop++)
	{
		i_om_res = 1;
		while (i_om_res > 0)
		{
			d_loc_fit_before = pc_best->dComputeFitness();
			i_om_res = pc_best->iOptimalMixing(pvPops->at(i_pop)->pc_last_added, &c_ltree_global, pc_ind_buf);
			d_loc_fit_after = pc_best->dComputeFitness();
			s_buf.Format("SUPER ind: Pop: %d change:%d   (%.8lf -> %.8lf)", i_pop, i_om_res, d_loc_fit_before, d_loc_fit_after);
			pc_log->vPrintLine(s_buf, true);

			d_loc_fit_before = d_loc_fit_after;
			pc_best->vClearOptOrder();
			d_loc_fit_after = pc_best->dComputeFitnessOptimize();
			s_buf.Format("SUPER ind: SelfOpt: (%.8lf -> %.8lf)", d_loc_fit_before, d_loc_fit_after);
			pc_log->vPrintLine(s_buf, true);
			
		}//while (i_om_res > 0)
	}//for (int i_pop = 0; i_pop < pvPops->size(); i_pop++)
	d_fit_after = pc_best->dComputeFitness();


	s_buf.Format("SUPER ind: %.8lf -> %.8lf  ", d_fit_before, d_fit_after);
	pc_log->vPrintLine(s_buf, true);


	c_ltree_global.pvGetNodes()->clear();
	v_pyramid_clear();

	return(true);
}//bool C3LOscrapped::b_run_iteration_super_pop_single_best(uint32_t iIterationNumber, time_t tStartTime, vector<C3LOscrapped *> *pvPops)


bool C3LOscrapped::b_run_iteration_super_pop(uint32_t iIterationNumber, vector<C3LOscrapped *> *pvPops)
{
	pv_other_pops = pvPops;

	for (int ii = 0; ii < pvPops->size(); ii++)
		v_pyramid_join(&(pvPops->at(ii)->v_pop));

	c_ltree_global.pvGetNodes()->clear();
	/*for (int i_pop = 0; i_pop < pvPops->size(); i_pop++)
	{
		for (int ii = 0; ii < pvPops->at(i_pop)->c_ltree_global.pvGetNodes()->size(); ii++)
		{
			c_ltree_global.pvGetNodes()->push_back(pvPops->at(i_pop)->c_ltree_global.pvGetNodes()->at(ii));
		}//for (int ii = 0; ii < pvPops->at(i_pop)->c_ltree_global.pvGetNodes()->size(); ii++)
	}//for (int i_pop = 0; i_pop < pvPops->size(); i_pop++)*/

	bRunIteration(iIterationNumber);


	c_ltree_global.pvGetNodes()->clear();
	v_pyramid_clear();

	return(true);
}//bool C3LOscrapped::b_run_iteration_super_pop(uint32_t iIterationNumber, time_t tStartTime, vector<C3LOscrapped *> *pvPops)


bool C3LOscrapped::bRunIterationSuperPop(uint32_t iIterationNumber, vector<C3LOscrapped *> *pvPops)
{
	b_run_iteration_super_pop_single_best(iIterationNumber, pvPops);
	return(true);
}//bool C3LOscrapped::bRunIterationSuperPop(uint32_t iIterationNumber, time_t tStartTime, vector<C3LOscrapped *> *pvPops)



bool C3LOscrapped::bRunIteration(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_C3LOScrappedOptimizer);

	CString  s_buf;
	

	double  d_best_fit_before;
	//pc_best_prev->vCopy(pc_best);
	d_best_fit_before = pc_best->dComputeFitness();

	//first we add new individual
	C3LOscrappedIndividual  *pc_new_ind;
	pc_new_ind = pc_get_random_individual(0);

	double  d_start;
	pc_new_ind->dComputeFitness();
	d_start = pc_new_ind->dComputeFitnessOptimize();//we optimize separately


	if (v_pop.size() == 0)
	{
		v_add_level(pc_new_ind);

		pc_new_ind = pc_get_random_individual(0);
		pc_new_ind->dComputeFitness();
		pc_new_ind->dComputeFitnessOptimize();

		v_add_level(pc_new_ind);

		if (v_pop.at(0).at(0)->dComputeFitness() > v_pop.at(0).at(1)->dComputeFitness())
		{
			if (i_random_linkage == 0)
			{
				v_pop.at(0).at(0)->vGetLinkageScraps(pc_ind_buf, pc_best);
				v_pop.at(0).at(0)->vCreateLT(i_linkage_scrap, i_linkage_scrap_analysis);
				//v_pop.at(0).at(0)->pcGetLTree()->vSave("zzz_tree_0_1.txt");
				v_link_scraps_global = v_pop.at(0).at(0)->v_link_scraps;
				c_ltree_global.vCopyFrom(v_pop.at(0).at(0)->pc_ltree);
			}//if  (i_random_linkage  == 0)
			else
			{
				c_ltree_global.vGenerateRandomLT(i_linkage_scrap, i_templ_length);

				s_buf.Format("New LT: scraps:%d  new:%d", v_link_scraps_global.size(), pc_new_ind->v_link_scraps.size());
				pc_log->vPrintLine(s_buf, true);
			}//else if  (i_random_linkage  == 0)
			//v_pop.at(0).at(0)->vSaveScraps("zzzz_report_scraps_0.txt");
		}//if  (pc_new_ind->dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty) > pc_best->dCountFOM(pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty))
		else
		{
			if (i_random_linkage == 0)
			{
				v_pop.at(0).at(1)->vGetLinkageScraps(pc_ind_buf, pc_best);
				v_pop.at(0).at(1)->vCreateLT(i_linkage_scrap, i_linkage_scrap_analysis);
				v_link_scraps_global = v_pop.at(0).at(1)->v_link_scraps;
				c_ltree_global.vCopyFrom(v_pop.at(0).at(1)->pc_ltree);
			}//if  (i_random_linkage  == 0)
			else
			{
				c_ltree_global.vGenerateRandomLT(i_linkage_scrap, i_templ_length);

				s_buf.Format("New LT: scraps:%d  new:%d", v_link_scraps_global.size(), pc_new_ind->v_link_scraps.size());
				pc_log->vPrintLine(s_buf, true);
			}//else if  (i_random_linkage  == 0)
			//v_pop.at(0).at(1)->vSaveScraps("zzzz_report_scraps_0.txt");
		}//else  v_pop.at(0)->vGetLinkageScraps(v_pop.at(1), pc_ind_buf, pc_best, pc_parent->c_translator.pcGetFittnesCounter(), pc_parent->pl_capacities, lPenalty);


		double  d_similar;
		d_similar = v_pop.at(0).at(0)->dGetSimilarity(v_pop.at(0).at(1), NULL);

		s_buf.Format("Ind Similarity: %.4lf", d_similar);
		pc_log->vPrintLine(s_buf, true);

		//::Tools::vShow("ok");

		//c_ltree_global.vSave("zzzz_report_scraps_0_tree.txt");
		b_update_best_individual(iIterationNumber, pc_best->piGetGenotype(), pc_best->dComputeFitness());

		return(c_err);
	}//if  (v_pop.size() == 0)


	v_add_level(pc_new_ind);

	for (int i_level = 0; i_level < v_pop.size(); i_level++)
	{
		b_run_for_level(i_level, pc_new_ind);
		//b_run_for_level_p3_like(i_level, pc_new_ind);
	}//for  (int  i_level = 0; i_level < v_pop.size(); i_level++)

	double  d_new_ind_fit_final_step_before, d_new_ind_fit_final_step_after;
	d_new_ind_fit_final_step_before = pc_new_ind->dComputeFitness();
	pc_new_ind->dComputeFitnessOptimize();//we optimize separately
	d_new_ind_fit_final_step_after = pc_new_ind->dComputeFitness();

	if (d_new_ind_fit_final_step_before < d_new_ind_fit_final_step_after)
	{
		if (bCheckPopulationIfExists(pc_new_ind) == false)
		{
			pc_new_ind->i_level++;
			if (i_leave_ind_at_level == 1)  v_add_level(pc_new_ind);
		}//if  (bCheckPopulationIfExists(pc_new_ind) == false)
	}//if  (d_new_ind_fit_final_step_before  <  d_new_ind_fit_final_step_after)

	if (bCheckPopulationIfExists(pc_new_ind) == false)  pc_new_ind->vStoreLastInsertableVersion();
	if (i_leave_ind_at_level == 0)  v_add_level(pc_new_ind->pcGetLastInsertableVersion());


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);



	double  d_best_fit_after;
	d_best_fit_after = pc_best->dComputeFitness();


	if ( (d_best_fit_before < d_best_fit_after)&&(pv_other_pops == NULL) )
	{
		if (i_random_linkage == 0)
		{
			pc_new_ind->vGetLinkageScraps(pc_ind_buf, pc_best);


			//v_link_scraps_global = pc_new_ind->v_link_scraps;
			for  (int ii = 0; ii < pc_new_ind->v_link_scraps.size(); ii++)
				v_link_scraps_global.push_back(pc_new_ind->v_link_scraps.at(ii));
			c_ltree_global.bCreateLT(&v_link_scraps_global, i_linkage_scrap, i_linkage_scrap_analysis, i_templ_length);

			//c_ltree_global.vSave("zzzz_report_scraps_tree_global.txt");

			s_buf.Format("New LT: scraps:%d  new:%d", v_link_scraps_global.size(), c_ltree_global.pvGetNodes()->size());
			pc_log->vPrintLine(s_buf, true);
		}//if  (i_random_linkage  == 0)
		else
		{
			c_ltree_global.vGenerateRandomLT(i_linkage_scrap, i_templ_length);

			s_buf.Format("Random Tree   Nodes:%d", c_ltree_global.pvGetNodes()->size(), v_link_scraps_global.size(), pc_new_ind->v_link_scraps.size());
			pc_log->vPrintLine(s_buf, true);
		}//else if  (i_random_linkage  == 0)
	}//if  (d_best_fit_before < d_best_fit_after)*/
	/*else
	{
		if ( (i_random_linkage == 0)&&(i_linkage_scrap == 1)&&(i_linkage_scrap_analysis == 1) )
		{
			//pc_new_ind->vGetLinkageScraps(pc_ind_buf, pc_best);
			//for (int ii = 0; ii < pc_new_ind->v_link_scraps.size(); ii++)
				//v_link_scraps_global.push_back(pc_new_ind->v_link_scraps.at(ii));

			c_ltree_global.bCreateLT(&v_link_scraps_global, i_linkage_scrap, i_linkage_scrap_analysis, i_templ_length);

			//c_ltree_global.vSave("zzzz_report_scraps_tree_global.txt");

			s_buf.Format("New LT: scraps:%d  new:%d", v_link_scraps_global.size(), c_ltree_global.pvGetNodes()->size());
			pc_log->vPrintLine(s_buf, true);
		}//if ( (i_random_linkage == 0)&&(i_linkage_scrap == 1)&&(i_linkage_scrap_analysis == 1) )
	}//else  if (d_best_fit_before < d_best_fit_after)*/



	
	b_update_best_individual(iIterationNumber, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
		(
			"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]", 
			pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms, 
			c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
			d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
		);
	pc_log->vPrintLine(s_buf, true);

	
	return(true);
}//bool C3LOscrapped::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



bool  C3LOscrapped::b_run_for_level_p3_like(int  iLevel, C3LOscrappedIndividual  *pcNewInd)
{
	bool  b_result = false;
	if (v_pop.size() <= iLevel)  return(b_result);


	int  i_om_len;
	i_om_len = pcNewInd->iOptimalMixingP3Like(&(v_pop.at(iLevel)), &c_ltree_global, pc_ind_buf);
	
	if (i_om_len > 0)
	{
		if (i_leave_ind_at_level == 1)
		{
			if (pcNewInd->pcGetLastInsertableVersion() != NULL)
			{
				if (pcNewInd->pcGetLastInsertableVersion()->i_level == pcNewInd->i_level) v_add_level(pcNewInd);
			}//if (pcNewInd->pcGetLastInsertableVersion() != NULL)
		}//if (i_leave_ind_at_level == 1)

		b_result = true;
		pcNewInd->dComputeFitnessOptimize();
	}//if  (i_om_len  >  0)

	return(b_result);
}//bool  C3LOscrapped::b_run_for_level_p3_like(int  iLevel, C3LOscrappedIndividual  *pcNewInd)


bool  C3LOscrapped::b_run_for_level(int  iLevel, C3LOscrappedIndividual  *pcNewInd)
{
	bool  b_result = false;
	if (v_pop.size() <= iLevel)  return(b_result);

	vector<C3LOscrappedIndividual *> v_level_pop, v_buf;

	v_buf = v_pop.at(iLevel);

	int  i_pos;
	while (v_buf.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_buf.size() - 1); //lRand(v_buf.size());
		v_level_pop.push_back(v_buf.at(i_pos));
		v_buf.erase(v_buf.begin() + i_pos);
	}//while  (v_temp.size() > 0)

	int  i_chosen_pop;
	int  i_om_len;
	C3LOscr_LTree  *pc_tree_for_om = NULL;
	for (int i_ind = 0; i_ind < v_level_pop.size(); i_ind++)
	{
		if (pv_other_pops == NULL)
			pc_tree_for_om = &c_ltree_global;
		else
		{
			//for supersubpopulation
			if (v_level_pop.at(i_ind)->pc_parent->c_ltree_global.pvGetNodes() > 0)
				pc_tree_for_om = &(v_level_pop.at(i_ind)->pc_parent->c_ltree_global);
			else
			{
				i_chosen_pop = RandUtils::iRandNumber(0, pv_other_pops->size() - 1);
				pc_tree_for_om = &(pv_other_pops->at(i_chosen_pop)->c_ltree_global);
			}//else  if (pcNewInd->pc_parent != NULL)  
		}//else  if (pv_other_pops == NULL)

		i_om_len = pcNewInd->iOptimalMixing(v_level_pop.at(i_ind), pc_tree_for_om, pc_ind_buf);
		if (i_om_len > 0)
		{
			if (i_leave_ind_at_level == 1)
			{
				if (pcNewInd->pcGetLastInsertableVersion() != NULL)
				{
					if (pcNewInd->pcGetLastInsertableVersion()->i_level == pcNewInd->i_level) v_add_level(pcNewInd);
				}//if (pcNewInd->pcGetLastInsertableVersion() != NULL)
			}//if (i_leave_ind_at_level == 1)

			b_result = true;
			pcNewInd->dComputeFitnessOptimize();
		}//if  (i_om_len  >  0)
	}//for  (int i_ind = 0; i_ind < v_level_pop.size(); i_ind++)

	return(b_result);
}//void  C3LOalg::v_run_for_level(int  iLevel, CSingleTrajectorySet  *pcNewInd)



void  C3LOscrapped::v_add_level(C3LOscrappedIndividual  *pcNewInd)
{
	if (pcNewInd == NULL)  return;

	while (v_pop.size() <= pcNewInd->i_level)
		v_pop.push_back(vector<C3LOscrappedIndividual *>());

	C3LOscrappedIndividual  *pc_copy;
	pc_copy = new C3LOscrappedIndividual(0, i_templ_length, pc_problem, this);

	pc_copy->vCopyFrom(pcNewInd);
	pc_last_added = pc_copy;

	if  (pv_other_pops == NULL)
		v_pop.at(pcNewInd->i_level).push_back(pc_copy);
	else
	{
		while (v_pop_superpop.size() <= pcNewInd->i_level)  v_pop_superpop.push_back(vector<C3LOscrappedIndividual *>());
		v_pop_superpop.at(pcNewInd->i_level).push_back(pc_copy);
	}//else  if  (i_run_as_super_pop == 0)
}//void  C3LOalg::v_add_level(CSingleTrajectorySet  *pcNewInd)


C3LOscrappedIndividual* C3LOscrapped::pc_get_random_individual(int iLevel)
{
	C3LOscrappedIndividual  *pc_indiv_new;

	pc_indiv_new = new C3LOscrappedIndividual(iLevel, i_templ_length, pc_problem, this);
	pc_indiv_new->vRandomizeGenotype();


	pc_indiv_new->dComputeFitness();

	i_random_indiv_adds++;

	return(pc_indiv_new);
}//C3LOIndividual* C3LOscrapped::pc_get_random_individual(int iLevel)



double C3LOscrapped::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_compute_fitness_value(piBits);
	return(d_fitness_value);
}//double C3LOscrapped::dComputeFitness(int32_t *piBits)




CString  C3LOscrapped::sAdditionalSummaryInfo() 
{ 
	CString  s_buf;  
	
	return(s_buf); 
};//CString  C3LOscrapped::sAdditionalSummaryInfo() 







 //---------------------------------------------C3LOscrappedIndividual-------------------------------------------------------
C3LOscrappedIndividual::C3LOscrappedIndividual(int iLevel, int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, C3LOscrapped  *pcParent)
{
	i_templ_length = iTemplLength;
	pc_parent = pcParent;
	i_level = iLevel;

	pi_genotype = new int[i_templ_length];

	pc_problem = pcProblem;

	d_fitnes_buf = -1;
	b_fitness_actual = false;

	pc_ltree = NULL;
	pc_last_insertable_version = NULL;

	vRandomizeGenotype();
}//C3LOscrappedIndividual::C3LOscrappedIndividual(int iLevel, int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, C3LOscrapped  *pcParent)


C3LOscrappedIndividual::C3LOscrappedIndividual(C3LOscrappedIndividual &pcOther)
{
	::Tools::vShow("No implementation: C3LOscrappedIndividual::C3LOscrappedIndividual(C3LOscrappedIndividual &pcOther) ");
};//C3LOscrappedIndividual::C3LOscrappedIndividual(C3LOscrappedIndividual &pcOther)


C3LOscrappedIndividual::~C3LOscrappedIndividual()
{
	if (pc_ltree != NULL)  delete  pc_ltree;
	if (pc_last_insertable_version != NULL)  delete  pc_last_insertable_version;
	delete  pi_genotype;
};//C3LOscrappedIndividual::~C3LOscrappedIndividual()


void  C3LOscrappedIndividual::vCopyFrom(C3LOscrappedIndividual  *pcOther)
{
	this->pc_parent = pcOther->pc_parent;
	this->i_templ_length = pcOther->i_templ_length;
	this->v_opt_order = pcOther->v_opt_order;
	this->d_fitnes_buf = pcOther->d_fitnes_buf;
	this->b_fitness_actual = pcOther->b_fitness_actual;
	this->i_level = pcOther->i_level;
	this->pc_problem = pcOther->pc_problem;

	
	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = pcOther->pi_genotype[ii];


	this->v_link_scraps = pcOther->v_link_scraps;

	if (pcOther->pc_ltree != NULL)
	{
		if (pc_ltree == NULL)  pc_ltree = new C3LOscr_LTree();
		pc_ltree->vCopyFrom(pcOther->pc_ltree);
	}//if  (pcOther->pc_ltree != NULL)
	else
	{
		if (pc_ltree != NULL)
		{
			delete  pc_ltree;
			pc_ltree = NULL;
		}//if  (pc_ltree  !=  NULL)  	
	}//else  if  (pcOther->pc_ltree != NULL)
}//void  C3LOscrappedIndividual::vCopyFrom(C3LOscrappedIndividual  *pcNewInd)


bool  C3LOscrappedIndividual::bIsTheSame(C3LOscrappedIndividual  *pcOther)
{
	if ((pi_genotype == NULL))  return(false);
	if ((pcOther->pi_genotype == NULL))  return(false);

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] != pcOther->pi_genotype[ii])  return(false);
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(true);
}//bool  C3LOscrappedIndividual::bIsTheSame(CSingleTrajectorySet  *pcOther)


double  C3LOscrappedIndividual::dGetSimilarity(C3LOscrappedIndividual  *pcOther, int  *piGenesTheSame)
{
	int  i_genes_the_same;
	if (piGenesTheSame == NULL)  piGenesTheSame = &i_genes_the_same;
	*piGenesTheSame = 0;

	if ((pi_genotype == NULL))  return(0);
	if ((pcOther->pi_genotype == NULL))  return(0);


	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] == pcOther->pi_genotype[ii])  (*piGenesTheSame)++;
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	double  d_res;
	d_res = *piGenesTheSame;
	d_res = d_res / i_templ_length;

	return(d_res);
}//double  C3LOscrappedIndividual::dGetSimilarity(C3LOscrappedIndividual  *pcOther, int  *piGenesTheSame)


void  C3LOscrappedIndividual::vRandomizeGenotype()
{
	d_fitnes_buf = -1;
	b_fitness_actual = false;

	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = RandUtils::iRandNumber(0, 1);

};//void  C3LOscrappedIndividual::vRandomizeGenotype()


double  C3LOscrappedIndividual::dComputeFitness()
{
	if (b_fitness_actual == true)  return(d_fitnes_buf);

	d_fitnes_buf = pc_parent->dComputeFitness(pi_genotype);
	b_fitness_actual = true;

	return(d_fitnes_buf);
};//double  C3LOscrappedIndividual::dComputeFitness()



void  C3LOscrappedIndividual::vCreateLT(int  iLinkageScrap, int iLinkageScrapAnalysis)
{
	if (pc_ltree == NULL) 
	{ 
		pc_ltree = new C3LOscr_LTree(); 
		pc_ltree->vSetParent(pc_parent);
	}//if (pc_ltree == NULL) 
	pc_ltree->bCreateLT(&v_link_scraps, iLinkageScrap, iLinkageScrapAnalysis, i_templ_length);
	//c_ltree.vSave("zzzz_report_scraps_dsm_tree.txt");
}//void  C3LOscrappedIndividual::vCreateLT(int  iLinkageScrap, int iLinkageScrapAnalysis)


void  C3LOscrappedIndividual::vCreateLT_Random(int  iLinkageScrap)
{
	if (pc_ltree == NULL)  pc_ltree = new C3LOscr_LTree();
	pc_ltree->vGenerateRandomLT(iLinkageScrap, i_templ_length);
	//c_ltree.vSave("zzzz_report_scraps_dsm_tree.txt");
}//void  C3LOscrappedIndividual::vCreateLT()



void  C3LOscrappedIndividual::v_create_opt_order(vector<int>  *pvOrder)
{
	vector<int>  v_temp;

	pvOrder->clear();

	for (int ii = 0; ii < i_templ_length; ii++)
		v_temp.push_back(ii);

	int  i_pos;
	while (v_temp.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_temp.size()-1);
		pvOrder->push_back(v_temp.at(i_pos));
		v_temp.erase(v_temp.begin() + i_pos);
	}//while  (v_temp.size() > 0)
}//void  CSingleTrajectorySet::v_create_opt_order(vector<int>  *pvOrder)


double  C3LOscrappedIndividual::d_optimize_single_gene(int  iOptGene)
{
	double  d_fitness_current, d_fit_new;
	d_fitness_current = dComputeFitness();

	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;

	b_fitness_actual = false;
	d_fit_new = dComputeFitness();

	if (d_fit_new > d_fitness_current)  return(d_fit_new);


	//flip back...
	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;
	b_fitness_actual = true;
	this->d_fitnes_buf = d_fitness_current;

	return(this->d_fitnes_buf);
}//double  C3LOscrappedIndividual::d_optimize_single_gene(int  iOptGene)



double  C3LOscrappedIndividual::dComputeFitnessOptimize(vector<int>  *pvOrder /*= NULL*/)
{
	CString  s_buf;

	if (pvOrder == NULL)  pvOrder = &v_opt_order;
	if (pvOrder->size() != i_templ_length)  v_create_opt_order(pvOrder);


	int  i_opt_gene;
	int  i_orig_gene_val;
	bool  b_changed;

	b_changed = true;

	//::Tools::vShow("IN");


	int  i_opt_counter = 0;
	while (b_changed == true)
	{
		//double  d_start, d_end;
		//d_start = dComputeFitness();
		
		i_opt_counter++;
		b_changed = false;
		for (int ii = 0; ii < pvOrder->size(); ii++)
		{
			i_opt_gene = pvOrder->at(ii);
			i_orig_gene_val = pi_genotype[i_opt_gene];

			d_optimize_single_gene(i_opt_gene);

			if  (i_orig_gene_val != pi_genotype[i_opt_gene])  b_changed = true;
		}//for  (int  i_opt_traj = 0; i_opt_traj < i_number_of_pairs; i_opt_traj++)

		//d_end = dComputeFitness();
		//s_buf.Format("%.8lf -> %.8lf", d_start, d_end);
		//::Tools::vShow(s_buf);
	}//while (b_changed == true)

	//::Tools::vShow(i_opt_counter);


	return(dComputeFitness());
};//double  C3LOscrappedIndividual::dComputeFitnessOptimize()



int  C3LOscrappedIndividual::iOptimalMixingP3Like(vector<C3LOscrappedIndividual *>  *pvLevel, C3LOscr_LTree  *pcLTree, C3LOscrappedIndividual  *pcBuffer)
{
	if (pcLTree == NULL)
	{
		::Tools::vShow("CSingleTrajectorySet::iOptimalMixing -> if  (pcLTree == NULL)  ");
		return(-2);
	}//if  (pcLTree == NULL)  
	if (pvLevel == NULL)  return(-2);

	int  i_result, i_buf, i_rand;
	i_result = -1;

	if (pvLevel->size() == 0)  return(-1);


	C3LOscrappedIndividual  *pc_donor;

	pcLTree->vShuffleNodesShorterFirst();
	for (int i_node = 0; i_node < pcLTree->pvGetNodes()->size(); i_node++)
	{
		if (
			(pcLTree->pvGetNodes()->at(i_node)->pvGetGenes()->size() > 0) &&
			(pcLTree->pvGetNodes()->at(i_node)->pvGetGenes()->size() < i_templ_length)
			)
		{
			i_rand = RandUtils::iRandNumber(0, pvLevel->size() - 1);
			pc_donor = pvLevel->at(i_rand);

			i_buf = iOptimalMixing(pc_donor, pcLTree, pcLTree->pvGetNodes()->at(i_node), pcBuffer);
			if (i_buf > 0)  return(i_buf);
			if (i_buf == 0)  i_result = 0;  //we have slided...
		}//if  (pcLTree->pvGetNodes()->at(i_node)->pvGetGenes()->size() > 1)
	}//for (int i_node = 0; i_node < pcLTree->pvGetNodes()->size(); i_node++)


	return(i_result);
}//int  C3LOscrappedIndividual::iOptimalMixingP3Like(vector<C3LOscrappedIndividual *>  *pvLevel, C3LOscr_LTree  *pcLTree, C3LOscrappedIndividual  *pcBuffer)


int  C3LOscrappedIndividual::iOptimalMixing(C3LOscrappedIndividual  *pcDonor, C3LOscr_LTree  *pcLTree, C3LOscrappedIndividual  *pcBuffer)
{
	if (pcLTree == NULL)
	{
		::Tools::vShow("CSingleTrajectorySet::iOptimalMixing -> if  (pcLTree == NULL)  ");
		return(-2);
	}//if  (pcLTree == NULL)  
	if (pcDonor == NULL)  return(-2);

	int  i_result, i_buf;
	i_result = -1;

	
	//pcLTree->vShuffleNodes();
	pcLTree->vShuffleNodesShorterFirst();
	for (int i_node = 0; i_node < pcLTree->pvGetNodes()->size(); i_node++)
	{
		if (
			(pcLTree->pvGetNodes()->at(i_node)->pvGetGenes()->size() > 0) &&
			(pcLTree->pvGetNodes()->at(i_node)->pvGetGenes()->size() < i_templ_length)
			)
		{
			i_buf = iOptimalMixing(pcDonor, pcLTree, pcLTree->pvGetNodes()->at(i_node), pcBuffer);
			if (i_buf > 0)  return(i_buf);
			if (i_buf == 0)  i_result = 0;  //we have slided...
		}//if  (pcLTree->pvGetNodes()->at(i_node)->pvGetGenes()->size() > 1)
	}//for (int i_node = 0; i_node < pcLTree->pvGetNodes()->size(); i_node++)

	
	return(i_result);
}//int  C3LOscrappedIndividual::iOptimalMixing(C3LOscrappedIndividual  *pcSource, C3LOscr_LTree  *pcLTree, C3LOscrappedIndividual  *pcBuffer)



int  C3LOscrappedIndividual::iOptimalMixing(C3LOscrappedIndividual  *pcDonor, C3LOscr_LTree  *pcLTree, C3LOscr_LTreeNode  *pcLTreeNode, C3LOscrappedIndividual  *pcBuffer)
{
	double  d_fitness_start, d_fitness_end;

	C3LOscrappedIndividual  *pc_copy;

	d_fitness_start = dComputeFitness();
	pcBuffer->vCopyFrom(this);

	bool  b_any_change_introduced;
	int  i_opt_traj;
	b_any_change_introduced = false;
	for (int i_gene_off = 0; i_gene_off < pcLTreeNode->pvGetGenes()->size(); i_gene_off++)
	{
		i_opt_traj = pcLTreeNode->pvGetGenes()->at(i_gene_off);
		if (pi_genotype[i_opt_traj] != pcDonor->pi_genotype[i_opt_traj])
		{
			b_any_change_introduced = true;
			b_fitness_actual = false;

			pi_genotype[i_opt_traj] = pcDonor->pi_genotype[i_opt_traj];
		}//if (pi_genotype[i_opt_traj] != pcDonor->pi_genotype[i_opt_traj])
	}//for  (int i_gene_off = 0; i_gene_off < pcLTreeNode->pvGetGenes(); i_gene_off++)

	//dComputeFitnessOptimize();

	/*if (pc_parent->bCheckPopulationIfExists(this) == true)
	{
		//auto fail
		this->vCopyFrom(pcBuffer);
		return(-1);
	}//if  (pcMethod->bCheckPopulationIfExists(this) == true)*/

	d_fitness_end = dComputeFitness();
	/*CString  s_buf;
	s_buf.Format("%.8lf -> %.8lf", d_fitness_start, d_fitness_end);
	::Tools::vShow(s_buf);*/

	//fail we restore previous genotype
	if (d_fitness_end < d_fitness_start)
	{
		this->vCopyFrom(pcBuffer);
		return(-1);
	}//if  (d_fitness_end < d_fitness_start)

	if (d_fitness_end == d_fitness_start)
	{
		if  (pc_parent->i_om_slide == 1)
			return(0);//we slide...
		else
		{
			//we do not slide
			this->vCopyFrom(pcBuffer);
			return(-1);
		}//if  (pc_parent->i_om_slide == 1)
	}//if (d_fitness_end == d_fitness_start)

	i_level++;
	if (pc_parent->bCheckPopulationIfExists(this) == false)  vStoreLastInsertableVersion();


	CString  s_buf;
	//s_buf.Format("iLinkageScrapCreateEffectScrap = %d;  iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScracp = %d", pcMethod->iLinkageScrapCreateEffectScrap(), pcMethod->iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScracp());
	//::Tools::vShow(s_buf);
	if (pc_parent->iLinkageScrapCreateEffectScrap() == 1)
	{
		C3LOscr_LTreeNode  *pc_new_scrap = new C3LOscr_LTreeNode();
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pi_genotype[ii] != pcBuffer->pi_genotype[ii])
				pc_new_scrap->pvGetGenes()->push_back(ii);
		}//for  (int ii = 0; ii < i_number_of_pairs; ii++)

		C3LOscrLinkageScrap  c_scrap;
		*(c_scrap.pvGetScrap()) = *(pc_new_scrap->pvGetGenes());
		pc_new_scrap->vIncrSuccCross();
		pcLTree->pvGetNodes()->push_back(pc_new_scrap);
		pc_parent->pvGetGlobalScraps()->push_back(c_scrap);
	}//if  (pcMethod->iLinkageScrapCreateEffectScrap() == 1)


	if (pc_parent->iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScracp() == 1)
	{
		C3LOscr_LTreeNode  *pc_new_scrap = new C3LOscr_LTreeNode();
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pi_genotype[ii] != pcBuffer->pi_genotype[ii])
				pc_new_scrap->pvGetGenes()->push_back(ii);
			else
			{
				if (pcLTreeNode->bDoIContain(ii) == true)  pc_new_scrap->pvGetGenes()->push_back(ii);
			}//else  if  (pc_trajectories[ii]->iId  !=  pcBuffer->pc_trajectories[ii]->iId)*/
		}//for  (int ii = 0; ii < i_number_of_pairs; ii++)

		C3LOscrLinkageScrap  c_scrap;
		*(c_scrap.pvGetScrap()) = *(pc_new_scrap->pvGetGenes());
		pc_new_scrap->vIncrSuccCross();
		pcLTree->pvGetNodes()->push_back(pc_new_scrap);
		pc_parent->pvGetGlobalScraps()->push_back(c_scrap);
	}//if  (pcMethod->iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScracp() == 1)



	//if we are here, then we SUCCEDED!
	pcLTreeNode->vIncrSuccCross();
	pc_parent->vIncSuccOms();
	return(pcLTreeNode->pvGetGenes()->size());
}//bool  CSingleTrajectorySet::bOptimalMixing(CSingleTrajectorySet  *pcSource, CLTreeNode  *pcLTreeNode, CSingleTrajectorySet  *pcBuffer)



void  C3LOscrappedIndividual::vStoreLastInsertableVersion()
{
	if (pc_last_insertable_version == NULL)  pc_last_insertable_version = pc_parent->pc_get_random_individual(0);
	pc_last_insertable_version->vCopyFrom(this);
}//void  C3LOscrappedIndividual::vStoreLastInsertableVersion()



void  C3LOscrappedIndividual::vGetLinkageScraps(C3LOscrappedIndividual  *pcBuffer, C3LOscrappedIndividual  *pcBest, vector<int>  *pvOrder)
{
	//if we gather the scraps then our tree is out of date anyway
	if (pc_ltree != NULL)
	{
		delete  pc_ltree;
		pc_ltree = NULL;
	}//if  (pc_ltree != NULL)  

	if (pvOrder == NULL)  pvOrder = &v_opt_order;
	if (pvOrder->size() != i_templ_length)  v_create_opt_order(pvOrder);

	double  d_fom_buf;
	d_fom_buf = dComputeFitnessOptimize();
	pcBuffer->vCopyFrom(this);//store original state

	if (pcBest->dComputeFitness() < dComputeFitness())  pcBest->vCopyFrom(this);



	int  i_buf;
	long  *pl_buf;
	long  l_conn_set_result;

	vector <C3LOscrLinkageScrap>  v_scraps;
	C3LOscrLinkageScrap c_scrap_buf;
	vector<int>  v_scrap_buf;
	v_scrap_buf.reserve(i_templ_length);

	int  i_opt_traj;
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		//i_opt_traj = pvOrder->at(ii);
		i_opt_traj = ii;

		v_scrap_buf.clear();
		v_scrap_buf.push_back(i_opt_traj);

		if (pi_genotype[i_opt_traj] == 1)
			pi_genotype[i_opt_traj] = 0;
		else
			pi_genotype[i_opt_traj] = 1;

		b_fitness_actual = false;
		dComputeFitnessOptimize(pvOrder);

		//here get the scraps
		for (int i_gene = 0; i_gene < i_templ_length; i_gene++)
		{
			if (pi_genotype[i_gene] != pcBuffer->pi_genotype[i_gene])
			{
				if (i_gene != i_opt_traj)  v_scrap_buf.push_back(i_gene);
			}//if  (pc_trajectories[i_gene]->iId  !=  pcBuffer->pc_trajectories[i_gene]->iId)
		}//for  (int i_gene = 0; i_gene < i_number_of_pairs; i_gene++)

		if (v_scrap_buf.size() > 1)
		{
			c_scrap_buf.vSetScrap(&v_scrap_buf);
			v_scraps.push_back(c_scrap_buf);
		}//if  (v_scrap_buf.size() > 0)


		if (pcBest->dComputeFitness() < dComputeFitness())  pcBest->vCopyFrom(this);


		vCopyFrom(pcBuffer);
	}//for  (int  i_opt_traj = 0; i_opt_traj < i_number_of_pairs; i_opt_traj++)


	for (int ii = 0; ii < v_scraps.size(); ii++)
		v_link_scraps.push_back(v_scraps.at(ii));


	/*CString  s_scraps_rep_name, s_buf;
	FILE  *pf_rep;
	pf_rep = fopen("zzzzz_scraps_rep.txt", "w+");
	s_buf.Format("SIZE: %d\n", v_link_scraps.size());
	fprintf(pf_rep, s_buf);
	for (int ii = 0; ii < v_link_scraps.size(); ii++)
	{
		v_link_scraps.at(ii).vSave(pf_rep);
		fprintf(pf_rep, "\n");
	}//for (int ii = 0; ii < v_link_scraps.size(); ii++)
	fclose(pf_rep);
	::Tools::vShow("scraps");//*/

};//void  C3LOscrappedIndividual::vGetLinkageScraps(C3LOscrappedIndividual  *pcBuffer, C3LOscrappedIndividual  *pcBest, vector<int>  *pvOrder = NULL)



int  C3LOscr_LTNodePair::iReplaceNodeWithNode(C3LOscr_LTreeNode  *pcNodeToCheck, C3LOscr_LTreeNode  *pcNewNode)
{
	int  i_result = 0;

	if (pc_node_0 == pcNodeToCheck)
	{
		i_result++;
		pc_node_0 = pcNewNode;
	}//if  (pc_node_0 == pcNodeToCheck)  

	if (pc_node_1 == pcNodeToCheck)
	{
		i_result++;
		pc_node_1 = pcNewNode;
	}//if  (pc_node_0 == pcNodeToCheck)  

	return(i_result);
}//int  C3LOscr_LTNodePair::iReplaceNodeWithNode(C3LOscr_LTreeNode  *pcNodeToCheck, C3LOscr_LTreeNode  *pcNewNode)



//---------------------------------------------C3LOscr_LTreeNode-------------------------------------------------------

CString  C3LOscr_LTreeNode::sGetAsString()
{
	CString  s_result, s_buf;
	for (int ii = 0; ii < v_genes.size(); ii++)
	{
		s_buf.Format(" %d;", v_genes.at(ii));
		s_result += s_buf;
	}//for  (int  ii = 0; ii < v_genes.size(); ii++)

	return(s_result);
}//CString  CLTreeNode::sGetAsString()






double  C3LOscr_LTreeNode::dGetDist(C3LOscr_LTreeNode  *pcOtherNode, C3LOscr_DSM *pdDsm)
{
	for (int ii = 0; ii < v_nodes_checked_dsm_similarity.size(); ii++)
	{
		if (v_nodes_checked_dsm_similarity.at(ii).pc_node_0 == pcOtherNode)  return(v_nodes_checked_dsm_similarity.at(ii).d_dist);
		if (v_nodes_checked_dsm_similarity.at(ii).pc_node_1 == pcOtherNode)  return(v_nodes_checked_dsm_similarity.at(ii).d_dist);
	}//for (int ii = 0; v_pattern_distances.size(); ii++)	
	
	
	double  d_max_val, d_buf;

	d_max_val = 0;

	for (int i_first = 0; i_first < v_genes.size(); i_first++)
	{
		for (int i_second = 0; i_second < pcOtherNode->v_genes.size(); i_second++)
		{
			d_buf = pdDsm->pd_dsm[v_genes.at(i_first)][pcOtherNode->v_genes.at(i_second)];
			if (d_buf > d_max_val)  d_max_val = d_buf;
		}//for  (int  i_second = 0; i_second < v_genes.size(); i_second++)	
	}//for  (int  i_first = 0; i_first < v_genes.size(); i_first++)


	C3LOscr_LTNodePair  c_new_pair;
	c_new_pair.pc_node_0 = this;
	c_new_pair.pc_node_1 = pcOtherNode;
	c_new_pair.d_dist = d_max_val;

	v_nodes_checked_dsm_similarity.push_back(c_new_pair);
	pcOtherNode->v_nodes_checked_dsm_similarity.push_back(c_new_pair);

	return(d_max_val);
}//double  C3LOscr_LTreeNode::dGetDist(C3LOscr_LTreeNode  *pcOtherNode, C3LOscr_DSM *pdDsm)



double  C3LOscr_LTreeNode::dGetMaxDSM()
{
	double  d_dsm_max, d_dsm_cur;
	d_dsm_max = 0;

	for (int ii = 0; ii < v_nodes_checked_dsm_similarity.size(); ii++)
	{
		d_dsm_cur = v_nodes_checked_dsm_similarity.at(ii).d_dist;
		if (d_dsm_max < d_dsm_cur)  d_dsm_max = d_dsm_cur;
	}//for (int ii = 0; v_pattern_distances.size(); ii++)

	return(d_dsm_max);
}//double  C3LOscr_LTreeNode::dGetMaxDSM()



void  C3LOscr_LTreeNode::vGetAll_DSM_PairsWithSimilarity(double  dDSM_Similarity, vector<C3LOscr_LTNodePair> *pvDest)
{
	for (int ii = 0; ii < v_nodes_checked_dsm_similarity.size(); ii++)
	{
		if (v_nodes_checked_dsm_similarity.at(ii).d_dist == dDSM_Similarity)
		{
			pvDest->push_back(v_nodes_checked_dsm_similarity.at(ii));
		}//if (v_pattern_distances.at(ii).dGetDSM_Similarity() == dDSM_Similarity)
	}//for (int ii = 0; v_pattern_distances.size(); ii++)

}//void  C3LOPattern::vGetAll_DSM_PairsWithSimilarity(double  dDSM_Max, vector<C3LOPatternPair> *pvDest)



void  C3LOscr_LTreeNode::vRemoveFromDSM_SimilarityList(C3LOscr_LTreeNode  *pcOther)
{
	for (int ii = 0; ii < v_nodes_checked_dsm_similarity.size(); ii++)
	{
		if (ii >= 0)
		{
			if (v_nodes_checked_dsm_similarity.at(ii).pc_node_0 == pcOther)
			{
				v_nodes_checked_dsm_similarity.erase(v_nodes_checked_dsm_similarity.begin() + ii);
				ii--;
			}//if (v_pattern_distances.at(ii).pc_first == pcOther)
		}//if  (ii >= 0)

		if (ii >= 0)
		{
			if (v_nodes_checked_dsm_similarity.at(ii).pc_node_1 == pcOther)
			{
				v_nodes_checked_dsm_similarity.erase(v_nodes_checked_dsm_similarity.begin() + ii);
				ii--;
			}//if (v_pattern_distances.at(ii).pc_first == pcOther)
		}//if  (ii >= 0)
	}//for (int ii = 0; v_pattern_distances.size(); ii++)

}//void  C3LOscr_LTreeNode::vRemoveFromDSM_SimilarityList(C3LOscr_LTreeNode  *pcOther)




bool  C3LOscr_LTreeNode::bDoIContain(int iOffset)
{
	for (int ii = 0; ii < v_genes.size(); ii++)
	{
		if (v_genes.at(ii) == iOffset)  return(true);
	}//for  (int ii = 0; ii < v_genes.size(); ii++)

	return(false);
}//bool  C3LOscr_LTreeNode::bDoIContain(int iOffset)



bool  C3LOscr_LTreeNode::bAnyCommonGenes(C3LOscr_LTreeNode  *pcOther)
{
	int  i_common_genes;
	for (int i_my_off = 0; i_my_off < v_genes.size(); i_my_off++)
	{
		for (int i_other_off = 0; i_other_off < pcOther->v_genes.size(); i_other_off++)
		{
			if (v_genes.at(i_my_off) == pcOther->v_genes.at(i_other_off))  return(true);
		}//for  (int i_other_off = 0; i_other_off < pcOther->v_genes.size(); i_other_off++)
	}//for  (int i_my_off = 0; i_my_off < v_genes.size(); i_my_off++)

	return(false);
}//bool  C3LOscr_LTreeNode::bAnyCommonGenes(C3LOscr_LTreeNode  *pcOther)


void  C3LOscr_LTreeNode::vSortGenes()
{
	std::sort(v_genes.begin(), v_genes.end(), [](const int cVal0, const int cVal1) -> bool { return(cVal0 < cVal1); });
}//void  C3LOscr_LTreeNode::vSortGenes()


void  C3LOscr_LTreeNode::vSetDependentGenes(vector<int> *pvLinkScrap)
{
	v_genes.clear();

	for (int ii = 0; ii < pvLinkScrap->size(); ii++)
		v_genes.push_back(pvLinkScrap->at(ii));

	vSortGenes();
}//void  C3LOscr_LTreeNode::vSetDependentGenes(vector<int> *pvLinkScrap)





C3LOscr_LTreeNode  *C3LOscr_LTreeNode::pcMultiplyNodes(C3LOscr_LTreeNode  *pcOther)
{
	if (v_genes.size() == 0)  return(0);
	if (pcOther->v_genes.size() == 0)  return(0);


	C3LOscr_LTreeNode  *pc_new_node;
	pc_new_node = new C3LOscr_LTreeNode();

	
	int  i_gene_this_off, i_gene_other_off;

	i_gene_this_off = 0;
	i_gene_other_off = 0;

	bool  b_inc_this, b_inc_other;
	int i_the_same_genes = 0;
	while ((i_gene_this_off < v_genes.size()) && (i_gene_other_off < pcOther->v_genes.size()))
	{
		b_inc_this = false;
		b_inc_other = false;

		if (v_genes.at(i_gene_this_off) == pcOther->v_genes.at(i_gene_other_off))
		{
			pc_new_node->v_genes.push_back(v_genes.at(i_gene_this_off));
			b_inc_this = true;
			b_inc_other = true;
			i_the_same_genes++;
		}//if (v_genes.at(i_gene_this_off) == pcOtherNode->v_genes.at(i_gene_other_off))

		if (v_genes.at(i_gene_this_off) < pcOther->v_genes.at(i_gene_other_off))
		{
			b_inc_this = true;
		}//if (v_genes.at(i_gene_this_off) < pcOther->v_genes.at(i_gene_other_off))

		if (v_genes.at(i_gene_this_off) > pcOther->v_genes.at(i_gene_other_off))
		{
			b_inc_other = true;
		}//if (v_genes.at(i_gene_this_off) > pcOther->v_genes.at(i_gene_other_off))


		if (b_inc_this == true)  i_gene_this_off++;
		if (b_inc_other == true)  i_gene_other_off++;
	}//while ((i_gene_this_off < v_genes.size()) && (i_gene_this_off < pcOtherNode->v_genes.size()))*/



	if (
		pc_new_node->v_genes.size() != i_the_same_genes
		)
		::Tools::vShow("BAD LENGTH:  C3LOscr_LTreeNode  *C3LOscr_LTreeNode::pcMultiplyNodes(C3LOscr_LTreeNode  *pcOther)");

	pc_new_node->vSortGenes();


	return(pc_new_node);
}//C3LOscr_LTreeNode  *C3LOscr_LTreeNode::pcMultiplyNodes(C3LOscr_LTreeNode  *pcOther)



C3LOscr_LTreeNode  *C3LOscr_LTreeNode::pcJoinNodes(C3LOscr_LTreeNode  *pcOther)
{
	if (v_genes.size() == 0)  return(0);
	if (pcOther->v_genes.size() == 0)  return(0);


	C3LOscr_LTreeNode  *pc_new_node;
	pc_new_node = new C3LOscr_LTreeNode();


	int  i_gene_this_off, i_gene_other_off;

	i_gene_this_off = 0;
	i_gene_other_off = 0;

	bool  b_inc_this, b_inc_other;
	int i_the_same_genes = 0;
	while ((i_gene_this_off < v_genes.size()) && (i_gene_other_off < pcOther->v_genes.size()))
	{
		b_inc_this = false;
		b_inc_other = false;

		if (v_genes.at(i_gene_this_off) == pcOther->v_genes.at(i_gene_other_off))
		{
			pc_new_node->v_genes.push_back(v_genes.at(i_gene_this_off));
			b_inc_this = true;
			b_inc_other = true;
			i_the_same_genes++;
		}//if (v_genes.at(i_gene_this_off) == pcOtherNode->v_genes.at(i_gene_other_off))

		if (v_genes.at(i_gene_this_off) < pcOther->v_genes.at(i_gene_other_off))
		{
			pc_new_node->v_genes.push_back(v_genes.at(i_gene_this_off));
			b_inc_this = true;
		}//if (v_genes.at(i_gene_this_off) < pcOther->v_genes.at(i_gene_other_off))

		if (v_genes.at(i_gene_this_off) > pcOther->v_genes.at(i_gene_other_off))
		{
			pc_new_node->v_genes.push_back(pcOther->v_genes.at(i_gene_other_off));
			b_inc_other = true;
		}//if (v_genes.at(i_gene_this_off) > pcOther->v_genes.at(i_gene_other_off))


		if (b_inc_this == true)  i_gene_this_off++;
		if (b_inc_other == true)  i_gene_other_off++;
	}//while ((i_gene_this_off < v_genes.size()) && (i_gene_this_off < pcOtherNode->v_genes.size()))*/


	for (int ii = i_gene_this_off; ii < v_genes.size(); ii++)
		pc_new_node->v_genes.push_back(v_genes.at(ii));

	for (int ii = i_gene_other_off; ii < pcOther->v_genes.size(); ii++)
		pc_new_node->v_genes.push_back(pcOther->v_genes.at(ii));


	if (
		pc_new_node->v_genes.size() !=
		this->v_genes.size() + pcOther->v_genes.size() - i_the_same_genes
		)
		::Tools::vShow("BAD LENGTH:  C3LOscr_LTreeNode  *C3LOscr_LTreeNode::pcJoinNodes(C3LOscr_LTreeNode  *pcOther)");

	pc_new_node->vSortGenes();


	return(pc_new_node);
}//CLTreeNode  *C3LOscr_LTreeNode::pcJoinNodes(CLTreeNode  *pcOther)



bool  C3LOscr_LTreeNode::bIsTheSame(C3LOscr_LTreeNode  *pcOther)
{
	if (v_genes.size() != pcOther->v_genes.size())  return(false);
	if (v_genes.size() == 0)  return(false);
	if (pcOther->v_genes.size() == 0)  return(false);

	int  i_gene_off;

	i_gene_off = 0;
	while (i_gene_off < v_genes.size())
	{
		if (v_genes.at(i_gene_off) != pcOther->v_genes.at(i_gene_off))  return(false);
		i_gene_off++;
	}//while (i_gene_off < pcOther->v_genes.size())

	return(true);
}//bool  C3LOscr_LTreeNode::bIsTheSame(C3LOscr_LTreeNode  *pcOther)



int  C3LOscr_LTreeNode::iGetCommonGeneNum(C3LOscr_LTreeNode  *pcOtherNode)
{
	int  i_counter;
	i_counter = 0;
	

	if (v_genes.size() == 0)  return(0);
	if (pcOtherNode->v_genes.size() == 0)  return(0);

	int  i_gene_this_off, i_gene_other_off;

	i_gene_this_off = 0;
	i_gene_other_off = 0;
	bool  b_inc_this;
	while ((i_gene_this_off < v_genes.size()) && (i_gene_other_off < pcOtherNode->v_genes.size()))
	{
		if (v_genes.at(i_gene_this_off) == pcOtherNode->v_genes.at(i_gene_other_off))
		{
			i_counter++;
			b_inc_this = true;
		}//if (v_genes.at(i_gene_this_off) == pcOtherNode->v_genes.at(i_gene_other_off))

		if (v_genes.at(i_gene_this_off) < pcOtherNode->v_genes.at(i_gene_other_off))  b_inc_this = true;
		if (v_genes.at(i_gene_this_off) > pcOtherNode->v_genes.at(i_gene_other_off))  b_inc_this = false;

		if (b_inc_this == true)
			i_gene_this_off++;
		else
			i_gene_other_off++;
	}//while ((i_gene_this_off < v_genes.size()) && (i_gene_this_off < pcOtherNode->v_genes.size()))*/


	/*int  i_counter_control = 0;
	bool  b_found;
	for (int i_gene_this = 0; i_gene_this < v_genes.size(); i_gene_this++)
	{
		b_found = false;
		for (int i_gene_other = 0; (i_gene_other < pcOtherNode->v_genes.size())&&(b_found == false); i_gene_other++)
		{
			if (v_genes.at(i_gene_this) == pcOtherNode->v_genes.at(i_gene_other))
			{
				i_counter_control++;
				b_found = true;
			}//if (v_genes.at(i_gene_this) == pcOtherNode->v_genes.at(i_gene_other))
		}//for (int i_gene_other = 0; i_gene_other < pcOtherNode->v_genes.size(); i_gene_other++)
	}//for (int i_gene_this = 0; i_gene_this < v_genes.size(); i_gene_this++)

	if (i_counter_control != i_counter)
	{
		return(i_counter_control);
	}//if (i_counter_control != i_counter)//*/


	/*C3LOscr_NodeSimilarity  c_similarity;
	c_similarity.pcNodeThis = this;
	c_similarity.pcNodeOther = pcOtherNode;
	c_similarity.iCommonGenesNum = i_counter;

	v_nodes_checked_similarity.push_back(c_similarity);*/
	return(i_counter);
}//int  C3LOscr_LTreeNode::iGetCommonGeneNum(C3LOscr_LTreeNode  *pcOtherNode)





C3LOscr_LTreeNode  *C3LOscr_LTreeNode::pcNodeAnalysisDown(vector<C3LOscr_LTreeNode *>  *pvCandidateNodes)
{
	CString  s_buf;
	vector<C3LOscr_NodeSimilarity>  v_candidates;
	C3LOscr_NodeSimilarity  c_candidate;

	int  i_common_gene_number;

	for (int ii = 0; ii < pvCandidateNodes->size(); ii++)
	{
		if (pvCandidateNodes->at(ii) != this)
		{
			i_common_gene_number = iGetCommonGeneNum(pvCandidateNodes->at(ii));

			//we assure that one node is not a part of the other...
			if ((i_common_gene_number < this->v_genes.size()) && (i_common_gene_number < pvCandidateNodes->at(ii)->v_genes.size()))
			{
				if (i_common_gene_number > 1)
				{
					c_candidate.pcNodeThis = this;
					c_candidate.pcNodeOther = pvCandidateNodes->at(ii);
					c_candidate.iCommonGenesNum = i_common_gene_number;
					v_candidates.push_back(c_candidate);
				}//if (i_common_gene_number > 0)
			}//if ((i_common_gene_number < this->v_genes.size()) && (pvCandidateNodes->at(ii)->v_genes.size()))
		}//if  (pvCandidateNodes->at(ii)  != this)
	}//for (int ii = 0; ii < pvCandidateNodes->size(); ii++)

	if (v_candidates.size() == 0)  return(NULL);

	int  i_sum = 0;
	for (int ii = 0; ii < v_candidates.size(); ii++)
		i_sum += v_candidates.at(ii).iCommonGenesNum;

	int  i_rand;
	i_rand = ::RandUtils::iRandNumber(0, i_sum - 1);

	C3LOscr_NodeSimilarity  *pc_candidate = NULL;
	int i_res = 0;
	for (int ii = 0; (ii < v_candidates.size()) && (pc_candidate == NULL); ii++)
	{
		i_res += v_candidates.at(ii).iCommonGenesNum;
		if (i_res > i_rand)  pc_candidate = &(v_candidates.at(ii));
	}//for (int ii = 0; ii < v_candidates.size(); ii++)


	C3LOscr_LTreeNode  *pc_new_node = NULL;

	if (pc_candidate != NULL)  pc_new_node = this->pcMultiplyNodes(pc_candidate->pcNodeOther);


	/*CString  s_candidate_rep_name;
	s_candidate_rep_name = "zzzz_candidate.txt";
	s_buf.Format("SIZE: %d", pvCandidateNodes->size());
	::Tools::vReportInFile(s_candidate_rep_name, s_buf, true);
	for (int ii = 0; ii < v_candidates.size(); ii++)
	{
		s_buf.Format("%.2d  \t Similarity: %d  \t GeneThis: %d  \t GeneOther: %d \t\t %s \t\t %s ", ii, v_candidates.at(ii).iCommonGenesNum, v_candidates.at(ii).pcNodeThis->v_genes.size(), v_candidates.at(ii).pcNodeOther->v_genes.size(), v_candidates.at(ii).pcNodeThis->sGetAsString(), v_candidates.at(ii).pcNodeOther->sGetAsString());
		::Tools::vReportInFile(s_candidate_rep_name, s_buf);
	}//for (int ii = 0; ii < v_candidates.size(); ii++)

	::Tools::vShow("OK");//*/

	return(pc_new_node);
}//C3LOscr_LTreeNode  *C3LOscr_LTreeNode::pcNodeAnalysisDown(vector<C3LOscr_LTreeNode *>  *pvCandidateNodes)



double  C3LOscr_NodeSimilarity::dGetSimilarity()
{
	double  d_similarity;

	d_similarity = iCommonGenesNum;
	d_similarity = d_similarity / (pcNodeThis->pvGetGenes()->size() + pcNodeOther->pvGetGenes()->size());

	return(d_similarity);
}//double  C3LOscr_NodeSimilarity::dGetSimilarity()

C3LOscr_LTreeNode  *C3LOscr_LTreeNode::pcNodeAnalysisUp(vector<C3LOscr_LTreeNode *>  *pvCandidateNodes)
{
	CString  s_buf;
	vector<C3LOscr_NodeSimilarity>  v_candidates;
	C3LOscr_NodeSimilarity  c_candidate;

	int  i_common_gene_number;

	for (int ii = 0; ii < pvCandidateNodes->size(); ii++)
	{
		if (pvCandidateNodes->at(ii) != this)
		{
			i_common_gene_number = iGetCommonGeneNum(pvCandidateNodes->at(ii));
			//we assure that one node is not a part of the other...
			if ((i_common_gene_number < this->v_genes.size()) && (i_common_gene_number < pvCandidateNodes->at(ii)->v_genes.size()))
			{
				if (i_common_gene_number > 0)
				{
					c_candidate.pcNodeThis = this;
					c_candidate.pcNodeOther = pvCandidateNodes->at(ii);
					c_candidate.iCommonGenesNum = i_common_gene_number;
					v_candidates.push_back(c_candidate);
				}//if (i_common_gene_number > 0)
			}//if ((i_common_gene_number < this->v_genes.size()) && (pvCandidateNodes->at(ii)->v_genes.size()))
		}//if  (pvCandidateNodes->at(ii)  != this)
	}//for (int ii = 0; ii < pvCandidateNodes->size(); ii++)

	

	C3LOscr_NodeSimilarity  *pc_candidate = NULL;
	double  d_similarity_max = 0;
	for (int ii = 0; ii < v_candidates.size(); ii++)
	{
		if (d_similarity_max < v_candidates.at(ii).dGetSimilarity())  d_similarity_max = v_candidates.at(ii).dGetSimilarity();
	}//for (int ii = 0; ii < v_candidates.size(); ii++)

	vector <C3LOscr_NodeSimilarity  *>  v_most_similar;
	for (int ii = 0; ii < v_candidates.size(); ii++)
	{
		if (d_similarity_max == v_candidates.at(ii).dGetSimilarity())  v_most_similar.push_back(&(v_candidates.at(ii)));
	}//for (int ii = 0; ii < v_candidates.size(); ii++)

	if (v_most_similar.size() > 0)
	{
		int  i_rand;
		i_rand = ::RandUtils::iRandNumber(0, v_most_similar.size() - 1);
		pc_candidate = v_most_similar.at(i_rand);
	}//if  (v_most_similar.size() > 0)

	/*if (v_candidates.size() == 0)  return(NULL);

	int  i_sum = 0;
	for (int ii = 0; ii < v_candidates.size(); ii++)
		i_sum += v_candidates.at(ii).iCommonGenesNum;

	int  i_rand;
	i_rand = ::RandUtils::iRandNumber(0, i_sum - 1);

	int i_res = 0;
	for (int ii = 0; (ii < v_candidates.size())&&(pc_candidate == NULL); ii++)
	{
		i_res += v_candidates.at(ii).iCommonGenesNum;
		if (i_res > i_rand)  pc_candidate = &(v_candidates.at(ii));
	}//for (int ii = 0; ii < v_candidates.size(); ii++)*/


	C3LOscr_LTreeNode  *pc_new_node = NULL;

	if  (pc_candidate != NULL)  pc_new_node = this->pcJoinNodes(pc_candidate->pcNodeOther);


	/*CString  s_candidate_rep_name;
	s_candidate_rep_name = "zzzz_candidate.txt";
	s_buf.Format("SIZE: %d", pvCandidateNodes->size());
	::Tools::vReportInFile(s_candidate_rep_name, s_buf, true);
	for (int ii = 0; ii < v_candidates.size(); ii++)
	{
		s_buf.Format("%.2d  \t Similarity: %d  \t GeneThis: %d  \t GeneOther: %d \t\t %s \t\t %s ", ii, v_candidates.at(ii).iCommonGenesNum, v_candidates.at(ii).pcNodeThis->v_genes.size(), v_candidates.at(ii).pcNodeOther->v_genes.size(), v_candidates.at(ii).pcNodeThis->sGetAsString(), v_candidates.at(ii).pcNodeOther->sGetAsString());
		::Tools::vReportInFile(s_candidate_rep_name, s_buf);
	}//for (int ii = 0; ii < v_candidates.size(); ii++)

	::Tools::vShow("OK");//*/
	
	return(pc_new_node);
}//C3LOscr_LTreeNode  *C3LOscr_LTreeNode::pcNodeAnalysisUp(vector<C3LOscr_LTreeNode *>  *pvCandidateNodes)



//---------------------------------------------C3LOscr_LTree-------------------------------------------------------
C3LOscr_LTree::C3LOscr_LTree()
{
	d_node_size_min = 0;
	d_node_size_max = 0;
	d_node_size_avr = 0;
	d_node_size_median = 0;
	pc_parent = NULL;
}//C3LOscr_LTree::~C3LOscr_LTree()


C3LOscr_LTree::~C3LOscr_LTree()
{
	vFlushTree();
}//C3LOscr_LTree::~C3LOscr_LTree()


bool bLTNodePairGreater(C3LOscr_LTNodePair *elem1, C3LOscr_LTNodePair *elem2)
{
	if (elem1->d_dist < elem2->d_dist)	return elem1->d_dist < elem2->d_dist;

	if (
		elem1->pc_node_0->pvGetGenes()->size() + elem1->pc_node_1->pvGetGenes()->size()
		<
		elem2->pc_node_0->pvGetGenes()->size() + elem2->pc_node_1->pvGetGenes()->size()
		)
		return
		(
			elem1->pc_node_0->pvGetGenes()->size() + elem1->pc_node_1->pvGetGenes()->size()
		>	//it MUST be twisted - the shorter, the better
			elem2->pc_node_0->pvGetGenes()->size() + elem2->pc_node_1->pvGetGenes()->size()
			);

	return elem1->d_dist < elem2->d_dist;
}//bool bLTNodePairGreater(C3LOscr_LTNodePair *elem1, C3LOscr_LTNodePair *elem2)




bool  C3LOscr_LTree::bCreateFromDSM(C3LOscr_DSM  *pcDsm)
{
	CString  s_buf;
	C3LOscr_LTreeNode  *pc_node_buf;

	vector<C3LOscr_LTreeNode *>  v_active_nodes;


	for (int ii = 0; ii < pcDsm->iGetSize(); ii++)
	{
		pc_node_buf = new C3LOscr_LTreeNode();
		pc_node_buf->v_genes.push_back(ii);
		v_active_nodes.push_back(pc_node_buf);
		v_nodes.push_back(pc_node_buf);
	}//for  (int ii = 0; ii < pcDsm->i_size; ii++)

	

	for (int i_pat_0 = 0; i_pat_0 < v_active_nodes.size() - 1; i_pat_0++)
	{
		for (int i_pat_1 = i_pat_0 + 1; i_pat_1 < v_active_nodes.size(); i_pat_1++)
		{
			v_active_nodes.at(i_pat_0)->dGetDist(v_active_nodes.at(i_pat_1), pcDsm);
		}//for (int i_pat_1 = i_pat_0 + 1; i_pat_1 < v_trees_to_join.size(); i_pat_1++)
	}//for (int i_pat_0 = 0; i_pat_0 < v_trees_to_join.size(); i_pat_0++)


	

	/*for  (int ii = 0; ii < v_node_pairs.size(); ii++)
	{
		s_buf.Format("%d %d  %lf",  v_node_pairs.at(ii)->pc_node_0->v_genes.at(0), v_node_pairs.at(ii)->pc_node_1->v_genes.at(0), v_node_pairs.at(ii)->d_dist);
		::Tools::vRepInFile("zzzz_report_scraps_dsm_nodes.txt", s_buf);
	}//for  (int ii = 0; ii < v_node_pairs.size(); ii++)*/

	vector<C3LOscr_LTNodePair>  v_possible_pairs;
	double  d_dsm_max, d_dsm_buf;
	int  i_tree_pair_to_join;

	C3LOscr_LTreeNode  *pc_new_node;

	d_dsm_max = 1;


	while ((d_dsm_max >= 1) && (v_active_nodes.size() > 1))
	{
		d_dsm_max = 0;
		for (int ii = 0; ii < v_active_nodes.size(); ii++)
		{
			d_dsm_buf = v_active_nodes.at(ii)->dGetMaxDSM();
			if (d_dsm_max < d_dsm_buf)  d_dsm_max = d_dsm_buf;
		}//for (int ii = 0; ii < v_trees_to_join.size(); ii++)

		if (d_dsm_max >= 1)//if similarity is below 1 then it is only based on the length, no real similarity was discovered
		{
			//get possible pairs
			v_possible_pairs.clear();
			for (int ii = 0; ii < v_active_nodes.size(); ii++)
				v_active_nodes.at(ii)->vGetAll_DSM_PairsWithSimilarity(d_dsm_max, &v_possible_pairs);

			if (v_possible_pairs.size() == 0)  ::MessageBox(NULL, "Can't make a tree LLScr!", "Can't make a tree! LLScr", MB_OK);

			//create joined pattern...
			i_tree_pair_to_join = RandUtils::iRandNumber(0, v_possible_pairs.size() - 1);
			pc_new_node = v_possible_pairs.at(i_tree_pair_to_join).pc_node_0->pcJoinNodes(v_possible_pairs.at(i_tree_pair_to_join).pc_node_1);

			v_active_nodes.push_back(pc_new_node);
			v_nodes.push_back(pc_new_node);

			//remove joined patterns
			for (int ii = 0; ii < v_active_nodes.size(); ii++)
			{
				if (ii >= 0)
				{
					if (v_active_nodes.at(ii) == v_possible_pairs.at(i_tree_pair_to_join).pc_node_0)
					{
						v_active_nodes.erase(v_active_nodes.begin() + ii);
						ii--;
					}//if (v_trees_to_join.at(ii) == v_possible_pairs.at(i_tree_pair_to_join).pc_first)
				}//if (ii >= 0)

				if (ii >= 0)
				{
					if (v_active_nodes.at(ii) == v_possible_pairs.at(i_tree_pair_to_join).pc_node_1)
					{
						v_active_nodes.erase(v_active_nodes.begin() + ii);
						ii--;
					}//if (v_trees_to_join.at(ii) == v_possible_pairs.at(i_tree_pair_to_join).pc_first)
				}//if  (ii  >= 0)
			}//for (int ii = 0; ii < v_trees_to_join.size(); ii++)

			//remove joined trees from cached dsm similarity
			for (int ii = 0; ii < v_active_nodes.size(); ii++)
			{
				v_active_nodes.at(ii)->vRemoveFromDSM_SimilarityList(v_possible_pairs.at(i_tree_pair_to_join).pc_node_0);
				v_active_nodes.at(ii)->vRemoveFromDSM_SimilarityList(v_possible_pairs.at(i_tree_pair_to_join).pc_node_1);
			}//for (int ii = 0; ii < v_trees_to_join.size(); ii++)


			//update cached similarities...
			for (int ii = 0; ii < v_active_nodes.size(); ii++)
				v_active_nodes.at(ii)->dGetDist(pc_new_node, pcDsm);

			//if (pc_pattern->bAmIThere(&(v_gene_patterns_parts_interceptions_and_differencies.at(iLevel))) == false)
				//v_gene_patterns_parts_interceptions_and_differencies.at(iLevel).push_back(pc_pattern);
		}//if (d_dsm_max > 0)

	}//while (v_trees_to_join.size() > 1)


	/*int  i_nodes_replaced;
	CLTreeNode  *pc_node_test_0, *pc_node_test_1;
	while (v_node_pairs.size() > 1)
	{
		pc_node_pair = v_node_pairs.back();
		v_node_pairs.pop_back();

		pc_node_buf = pc_node_pair->pc_node_0->pcJoinNodes(pc_node_pair->pc_node_1);

		if (pc_node_buf != NULL)
		{
			v_nodes.push_back(pc_node_buf);

			//we remove the joined nodes
			for (int ii = 0; ii < v_node_pairs.size(); ii++)
			{
				i_nodes_replaced = 0;
				if (v_node_pairs.at(ii)->bNodeInside(pc_node_pair->pc_node_0) == true)
				{
					pc_node_test_0 = pc_node_pair->pc_node_0;
					i_nodes_replaced += v_node_pairs.at(ii)->iReplaceNodeWithNode(pc_node_pair->pc_node_0, pc_node_buf);
				}//if  (v_node_pairs.at(ii)->bNodeInside(pc_node_pair->pc_node_0) true)

				if (v_node_pairs.at(ii)->bNodeInside(pc_node_pair->pc_node_1) == true)
				{
					pc_node_test_1 = pc_node_pair->pc_node_1;
					i_nodes_replaced += v_node_pairs.at(ii)->iReplaceNodeWithNode(pc_node_pair->pc_node_1, pc_node_buf);
				}//if  (v_node_pairs.at(ii)->bNodeInside(pc_node_pair->pc_node_0) true)

				//DO SOMETHING IF THERE IS MORE THAN 1!!!!
				if (i_nodes_replaced > 1)
				{
					//s_buf = "";
					//s_buf += pc_node_test_0->sGetAsString() + "\n";
					//s_buf += pc_node_test_1->sGetAsString() + "\n";
					//s_buf += pc_node_buf->sGetAsString() + "\n";

					//::Tools::vRepInFile("zzzz_report_DOUBLE_PAIR.txt", s_buf);

					delete  v_node_pairs.at(ii);
					v_node_pairs.erase(v_node_pairs.begin() + ii);
					ii--;
				}//if  (i_nodes_replaced  >  1)


			}//for  (int ii = 0; ii < v_node_pairs.size(); ii++)

		}//if  (pc_node_buf != NULL)
		else
		{
			delete  pc_node_pair;
		}//else  if  (pc_node_buf != NULL)

	}//while  (v_active_nodes.size() > 1)*/


	return(true);
}//bool  CLTree::bCreateFromDSM(CDSM  *pcDsm)



bool  C3LOscr_LTree::bCreateLT(vector<C3LOscrLinkageScrap>  *pvLinkScraps, int  iLinkageScrap, int iLinkageScrapAnalysis, int iTemplLength)
{
	bool  b_result = true;

	if (iLinkageScrap == 0)
	{

		C3LOscr_DSM  c_dsm;

		c_dsm.bSetSize(iTemplLength);


		for (int ii = 0; ii < pvLinkScraps->size(); ii++)
		{
			pvLinkScraps->at(ii).bUpdateDSM(&c_dsm);
		}//for  (int  ii = 0; ii < v_link_scraps.size(); ii++)

		//c_dsm.vSave("zzzz_report_scraps_dsm.txt");


		vFlushTree();
		b_result = bCreateFromDSM(&c_dsm);
	}//if  (iLinkageScrap == 0)
	else
	{
		if (iLinkageScrapAnalysis == 1)
		{
			v_linkage_scraps_analysis(pvLinkScraps, iTemplLength);
		}//if (iLinkageScrapAnalysis == 1)
		else
		{
			C3LOscr_LTreeNode  *pc_node_buf;

			for (int ii = 0; ii < v_nodes.size(); ii++)
			{
				if (v_nodes.at(ii)->iGetSuccCross() == 0)
				{
					delete  v_nodes.at(ii);
					v_nodes.erase(v_nodes.begin() + ii);
					ii--;
				}//if  (v_nodes.at(ii)->iGetSuccCross() == 0)
			}//for  (int ii = 0; ii < v_nodes.size(); ii++)

			CString s_buf;
			s_buf.Format("After deleteing: %d", v_nodes.size());
			pc_parent->pcGetLog()->vPrintLine(s_buf, true);


			for (int i_scrap = 0; i_scrap < pvLinkScraps->size(); i_scrap++)
			{
				pc_node_buf = new C3LOscr_LTreeNode();
				v_nodes.push_back(pc_node_buf);

				pc_node_buf->vSetDependentGenes(pvLinkScraps->at(i_scrap).pvGetScrap());
			}//for  (int i_scrap = 0; i_scrap < pvLinkScraps->size(); i_scrap++)
		}//else if (iLinkageScrapAnalysis == 1)
	}//else  if  (iLinkageScrap == 0)

	v_nodes_stats_compute(&v_nodes, &d_node_size_min, &d_node_size_max, &d_node_size_avr, &d_node_size_median);
	v_nodes_stats_coverage(&v_nodes, iTemplLength, &v_coverage, &d_coverage_perc);

	return(b_result);
}//bool  C3LOscr_LTree::bCreateLT(vector<CLinkageScrap>  *pvLinkScraps)



void  C3LOscr_LTree::v_linkage_scraps_analysis(vector<C3LOscrLinkageScrap>  *pvLinkScraps, int iTemplLength)
{
	CString  s_buf;

	C3LOscr_LTreeNode  *pc_node_buf;

	vector<vector<C3LOscr_LTreeNode *>>  v_nodes_up;
	vector<C3LOscr_LTreeNode *>  v_nodes_base;
	vector<vector<C3LOscr_LTreeNode *>>  v_nodes_down;

	double  d_node_size_min_loc, d_node_size_max_loc, d_node_size_avr_loc, d_node_size_median_loc;

	v_linkage_scraps_analysis_base(&v_nodes_base, pvLinkScraps, iTemplLength);
	v_nodes_stats_compute(&v_nodes_base, &d_node_size_min_loc, &d_node_size_max_loc, &d_node_size_avr_loc, &d_node_size_median_loc);	
	v_nodes_stats_coverage(&v_nodes_base, iTemplLength, &v_coverage, &d_coverage_perc);
	s_buf.Format("BASE level: [%d] <%.0lf;%.0lf>, Av: %.1lf Med: %.1lf  COVERAGE: %.4lf", v_nodes_base.size(), d_node_size_min_loc, d_node_size_max_loc, d_node_size_avr_loc, d_node_size_median_loc, d_coverage_perc);
	if (pc_parent != NULL)  pc_parent->pcGetLog()->vPrintLine(s_buf, true);

	v_filter_the_same_nodes(&v_nodes_base, iTemplLength);
	v_nodes_stats_compute(&v_nodes_base, &d_node_size_min_loc, &d_node_size_max_loc, &d_node_size_avr_loc, &d_node_size_median_loc);
	v_nodes_stats_coverage(&v_nodes_base, iTemplLength, &v_coverage, &d_coverage_perc);
	s_buf.Format("BASE filtered level: [%d] <%.0lf;%.0lf>, Av: %.1lf Med: %.1lf  COVERAGE: %.4lf", v_nodes_base.size(), d_node_size_min_loc, d_node_size_max_loc, d_node_size_avr_loc, d_node_size_median_loc, d_coverage_perc);
	if (pc_parent != NULL)  pc_parent->pcGetLog()->vPrintLine(s_buf, true);

	

	/*CString  s_line_coverage;
	for (int ii = 0; ii < v_coverage.size(); ii++)
	{
		s_buf.Format(" %d ", v_coverage.at(ii));
		s_line_coverage += s_buf;
	}//for (int ii = 0; ii < v_coverage.size(); ii++)

	::Tools::vReportInFile("zzzz_coverage.txt", s_line_coverage, true);*/




	//::Tools::vShow("coverage");
	bool  b_make_level_up = true;
	while (b_make_level_up == true)
	{
		b_make_level_up = false;
		v_linkage_scraps_analysis_up(&v_nodes_base, &v_nodes_up, iTemplLength);
		v_filter_the_same_nodes(&(v_nodes_up.at(v_nodes_up.size() - 1)), iTemplLength);
		v_nodes_stats_compute(&(v_nodes_up.at(v_nodes_up.size() - 1)), &d_node_size_min_loc, &d_node_size_max_loc, &d_node_size_avr_loc, &d_node_size_median_loc);
		v_nodes_stats_coverage(&(v_nodes_up.at(v_nodes_up.size() - 1)), iTemplLength, &v_coverage, &d_coverage_perc);

		s_buf.Format("Level Up %d filtered: [%d] <%.0lf;%.0lf>, Av: %.1lf Med: %.1lf  COVERAGE: %.4lf", v_nodes_up.size(), v_nodes_up.at(v_nodes_up.size() - 1).size(), d_node_size_min_loc, d_node_size_max_loc, d_node_size_avr_loc, d_node_size_median_loc, d_coverage_perc);
		if (pc_parent != NULL)  pc_parent->pcGetLog()->vPrintLine(s_buf, true);

		if (v_nodes_up.at(v_nodes_up.size() - 1).size() > 0)  b_make_level_up = true;
	}//while  (b_make_level_up == true)



	bool  b_make_level_down = true;
	while (b_make_level_down == true)
	{
		b_make_level_down = false;
		v_linkage_scraps_analysis_down(&v_nodes_base, &v_nodes_down, iTemplLength);
		v_filter_the_same_nodes(&(v_nodes_down.at(v_nodes_down.size() - 1)), iTemplLength);
		v_nodes_stats_compute(&(v_nodes_down.at(v_nodes_down.size() - 1)), &d_node_size_min_loc, &d_node_size_max_loc, &d_node_size_avr_loc, &d_node_size_median_loc);
		v_nodes_stats_coverage(&(v_nodes_down.at(v_nodes_down.size() - 1)), iTemplLength, &v_coverage, &d_coverage_perc);

		s_buf.Format("Level Down %d filtered: [%d] <%.0lf;%.0lf>, Av: %.1lf Med: %.1lf  COVERAGE: %.4lf", v_nodes_down.size(), v_nodes_down.at(v_nodes_down.size() - 1).size(), d_node_size_min_loc, d_node_size_max_loc, d_node_size_avr_loc, d_node_size_median_loc, d_coverage_perc);
		if (pc_parent != NULL)  pc_parent->pcGetLog()->vPrintLine(s_buf, true);

		if (v_nodes_down.at(v_nodes_down.size() - 1).size() > 0)  b_make_level_down = true;
	}//while  (b_make_level_up == true)





	vFlushTree();

	for (int ii = 0; ii < v_nodes_base.size(); ii++)
		v_nodes.push_back(v_nodes_base.at(ii));
	
	for (int i_lev = 0; i_lev < v_nodes_up.size(); i_lev++)
	{
		for (int ii = 0; ii < v_nodes_up.at(i_lev).size(); ii++)
			v_nodes.push_back(v_nodes_up.at(i_lev).at(ii));
	}//for (int i_lev = 0; i_lev < v_nodes_up.size(); i_lev++)


	for (int i_lev = 0; i_lev < v_nodes_down.size(); i_lev++)
	{
		for (int ii = 0; ii < v_nodes_down.at(i_lev).size(); ii++)
			v_nodes.push_back(v_nodes_down.at(i_lev).at(ii));
	}//for (int i_lev = 0; i_lev < v_nodes_up.size(); i_lev++)
	

	//::Tools::vShow("level Up");
}//void  C3LOscr_LTree::v_linkage_scraps_analysis(vector<C3LOscrLinkageScrap>  *pvLinkScraps, int iTemplLength)


void  C3LOscr_LTree::v_filter_the_same_nodes(vector<C3LOscr_LTreeNode *>  *pvNodesBase, int  iTemplLength)
{
	//CString  s_buf;
	//s_buf.Format("void  C3LOscr_LTree::v_filter_the_same_nodes(vector<C3LOscr_LTreeNode *>  *pvNodesBase, int  iTemplLength)");
	//if (pc_parent != NULL)  pc_parent->pcGetLog()->vPrintLine(s_buf, true);

	for (int i_first = 0; i_first < pvNodesBase->size(); i_first++)
	{
		for (int i_second = i_first + 1; i_second < pvNodesBase->size(); i_second++)
		{
			//s_buf.Format("for/for %d/%d", i_first, i_second);
			//if (pc_parent != NULL)  pc_parent->pcGetLog()->vPrintLine(s_buf, true);

			if (pvNodesBase->at(i_first)->bIsTheSame(pvNodesBase->at(i_second)) == true)
			{
				//s_buf.Format("if (pvNodesBase->at(i_first)->bIsTheSame(pvNodesBase->at(i_second)) == true)");
				//if (pc_parent != NULL)  pc_parent->pcGetLog()->vPrintLine(s_buf, true);

				if (i_first != i_second)
				{
					delete  pvNodesBase->at(i_second);
					pvNodesBase->erase(pvNodesBase->begin() + i_second);
					i_second--;
				}//if (i_first != i_second)
			}//if (pvNodesBase->at(i_first)->bIsTheSame(pvNodesBase->at(i_second)) == true)
		}//for (int i_second = i_first + 1; i_second < pvNodesBase->size(); i_second++)
	}//for (int i_first = 0; i_first < pvNodesBase->size(); i_first++)
}//void  C3LOscr_LTree::v_filter_the_same_nodes(vector<C3LOscr_LTreeNode *>  *pvNodesBase, int  iTemplLength)


void  C3LOscr_LTree::v_linkage_scraps_analysis_base(vector<C3LOscr_LTreeNode *>  *pvNodesBase, vector<C3LOscrLinkageScrap>  *pvLinkScraps, int iTemplLength)
{
	C3LOscr_LTreeNode  *pc_node_buf;

	for (int i_scrap = 0; i_scrap < pvLinkScraps->size(); i_scrap++)
	{
		if (pvLinkScraps->at(i_scrap).pvGetScrap()->size() > 1)
		{
			pc_node_buf = new C3LOscr_LTreeNode();
			pvNodesBase->push_back(pc_node_buf);

			if (pvLinkScraps->at(i_scrap).pvGetScrap()->size() == 1)  ::Tools::vShow("if (pvLinkScraps->at(i_scrap).pvGetScrap()->size() == 1)  ");

			pc_node_buf->vSetDependentGenes(pvLinkScraps->at(i_scrap).pvGetScrap());
		}//if  (pvLinkScraps->at(i_scrap).pvGetScrap()->size()  >  1)
	}//for  (int i_scrap = 0; i_scrap < pvLinkScraps->size(); i_scrap++)
}//void  C3LOscr_LTree::v_linkage_scraps_analysis_base(vector<C3LOscr_LTreeNode *>  *pvNodesBase, vector<C3LOscrLinkageScrap>  *pvLinkScraps, int iTemplLength)




void  C3LOscr_LTree::v_linkage_scraps_analysis_up(vector<C3LOscr_LTreeNode *>  *pvNodesBase, vector<vector<C3LOscr_LTreeNode *>>  *pvNodesUp, int iTemplLength)
{
	vector<C3LOscr_LTreeNode *>  *pv_level_up;
	vector<C3LOscr_LTreeNode *>  *pv_level_current;
	C3LOscr_LTreeNode  *pc_node_joined;

	vector<C3LOscr_LTreeNode *>  v_unjoinable_nodes;

	pvNodesUp->push_back(vector<C3LOscr_LTreeNode *>());
	pv_level_up = &(pvNodesUp->at(pvNodesUp->size() - 1));
	if  (pvNodesUp->size() == 1)
		pv_level_current = pvNodesBase;
	else
		pv_level_current = &(pvNodesUp->at(pvNodesUp->size() - 2));


	for (int i_node_cur = 0; i_node_cur < pv_level_current->size(); i_node_cur++)
	{
		pc_node_joined = pv_level_current->at(i_node_cur)->pcNodeAnalysisUp(pv_level_current);
		if  (pc_node_joined != NULL)  
			pv_level_up->push_back(pc_node_joined);
		else
		{
			//if I can not join then nobody will join me...
			v_unjoinable_nodes.push_back(pv_level_current->at(i_node_cur));
			pv_level_current->erase(pv_level_current->begin() + i_node_cur);
			i_node_cur--;
		}//else  if  (pc_node_joined != NULL)  
	}//for (int i_node_cur = 0; i_node_cur < pv_level_current->size(); i_node_cur++)

	//finally we put back unjoinable nodes
	for (int ii = 0; ii < v_unjoinable_nodes.size(); ii++)
		pv_level_current->push_back(v_unjoinable_nodes.at(ii));

}//void  C3LOscr_LTree::v_linkage_scraps_analysis_up(vector<C3LOscr_LTreeNode *>  *pvNodesBase, vector<vector<C3LOscr_LTreeNode *>>  *pvNodesUp, int iTemplLength)




void  C3LOscr_LTree::v_linkage_scraps_analysis_down(vector<C3LOscr_LTreeNode *>  *pvNodesBase, vector<vector<C3LOscr_LTreeNode *>>  *pvNodesDown, int iTemplLength)
{
	vector<C3LOscr_LTreeNode *>  *pv_level_down;
	vector<C3LOscr_LTreeNode *>  *pv_level_current;
	C3LOscr_LTreeNode  *pc_node_joined;

	vector<C3LOscr_LTreeNode *>  v_unjoinable_nodes;

	pvNodesDown->push_back(vector<C3LOscr_LTreeNode *>());
	pv_level_down = &(pvNodesDown->at(pvNodesDown->size() - 1));
	if (pvNodesDown->size() == 1)
		pv_level_current = pvNodesBase;
	else
		pv_level_current = &(pvNodesDown->at(pvNodesDown->size() - 2));


	for (int i_node_cur = 0; i_node_cur < pv_level_current->size(); i_node_cur++)
	{
		pc_node_joined = pv_level_current->at(i_node_cur)->pcNodeAnalysisDown(pv_level_current);
		if (pc_node_joined != NULL)
			pv_level_down->push_back(pc_node_joined);
		else
		{
			//if I can not join then nobody will join me...
			v_unjoinable_nodes.push_back(pv_level_current->at(i_node_cur));
			pv_level_current->erase(pv_level_current->begin() + i_node_cur);
			i_node_cur--;
		}//else  if  (pc_node_joined != NULL)  
	}//for (int i_node_cur = 0; i_node_cur < pv_level_current->size(); i_node_cur++)

	//finally we put back unjoinable nodes
	for (int ii = 0; ii < v_unjoinable_nodes.size(); ii++)
		pv_level_current->push_back(v_unjoinable_nodes.at(ii));
}//void  C3LOscr_LTree::v_linkage_scraps_analysis_down(vector<C3LOscr_LTreeNode *>  *pvNodesBase, vector<vector<C3LOscr_LTreeNode *>>  *pvNodesUDown, int iTemplLength)



void  C3LOscr_LTree::v_nodes_stats_compute(vector<C3LOscr_LTreeNode *>  *pvNodes, double  *pdMin, double  *pdMax, double  *pdAvr, double *pdMedian)
{
	double  d_node_size_min_loc, d_node_size_max_loc, d_node_size_avr_loc, d_node_size_median_loc;

	d_node_size_min_loc = 0;
	d_node_size_max_loc = 0;
	d_node_size_avr_loc = 0;
	d_node_size_median_loc = 0;

	if (pvNodes->size() == 0)  return;

	vector<int> v_lengths;

	v_lengths.push_back(pvNodes->at(0)->v_genes.size());

	d_node_size_min_loc = pvNodes->at(0)->v_genes.size();
	d_node_size_max_loc = pvNodes->at(0)->v_genes.size();
	d_node_size_avr_loc = pvNodes->at(0)->v_genes.size();


	for (int ii = 1; ii < pvNodes->size(); ii++)
	{
		v_lengths.push_back(pvNodes->at(ii)->v_genes.size());

		if  (d_node_size_min_loc > pvNodes->at(ii)->v_genes.size())  d_node_size_min_loc = pvNodes->at(ii)->v_genes.size();
		if  (d_node_size_max_loc < pvNodes->at(ii)->v_genes.size())  d_node_size_max_loc = pvNodes->at(ii)->v_genes.size();
				
		d_node_size_avr_loc += pvNodes->at(ii)->v_genes.size();
	}//for (int ii = 1; ii < pvNodes->size(); ii++)

	d_node_size_avr_loc = d_node_size_avr_loc / pvNodes->size();

	std::sort(v_lengths.begin(), v_lengths.end(), [](const int cVal0, const int cVal1) -> bool { return(cVal0 < cVal1); });

	if (pvNodes->size() % 2 == 0)
	{
		d_node_size_median_loc = v_lengths.at(v_lengths.size() / 2 - 1) + v_lengths.at(v_lengths.size() / 2);
		d_node_size_median_loc = d_node_size_median_loc / 2;
	}//if (pvNodes->size() % 2 == 0)
	else
		d_node_size_median_loc = v_lengths.at(v_lengths.size() / 2);


	*pdMin = d_node_size_min_loc;
	*pdMax = d_node_size_max_loc;
	*pdAvr = d_node_size_avr_loc;
	*pdMedian = d_node_size_median_loc;
}//void  C3LOscr_LTree::v_nodes_stats_compute()


void  C3LOscr_LTree::v_nodes_stats_coverage(vector<C3LOscr_LTreeNode *>  *pvNodes, int iTemplLength, vector<int>  *pvCoverage, double  *pdPerc)
{
	vector<int>  v_coverage;
	if (pvCoverage == NULL)  pvCoverage = &v_coverage;

	while  (pvCoverage->size() < iTemplLength)
		pvCoverage->push_back(0);
	
	for (int ii = 0; ii < pvCoverage->size(); ii++)
		pvCoverage->at(ii) = 0;

	for (int i_node = 0; i_node < pvNodes->size(); i_node++)
	{
		if (pvNodes->at(i_node)->v_genes.size() > 1)
		{
			for (int i_gene_offset = 0; i_gene_offset < pvNodes->at(i_node)->v_genes.size(); i_gene_offset++)
			{
				pvCoverage->at(pvNodes->at(i_node)->v_genes.at(i_gene_offset)) += 1;
			}//for (int i_gene_offset = 0; i_gene_offset < pvNodes->at(i_node)->v_genes.size(); i_gene_offset++)
		}//if (pvNodes->at(i_node)->v_genes.size() > 1)
	}//for (int i_node = 0; i_node < pvNodes->size(); i_node++)


	double  d_perc;
	if (pdPerc == NULL)  pdPerc = &d_perc;

	(*pdPerc) = 0;

	for (int ii = 0; ii < iTemplLength; ii++)
	{
		if (pvCoverage->at(ii) > 0)  (*pdPerc) += 1;
	}//for (int ii = 0; ii < iTemplLength; ii++)

	(*pdPerc) = (*pdPerc) / iTemplLength;
};//void  C3LOscr_LTree::v_nodes_stats_coverage(vector<C3LOscr_LTreeNode *>  *pvNodes, int iTemplLength, vector<int>  *pvCoverage, double  *pdPerc)


void  C3LOscr_LTree::vGenerateRandomLT(int  iLinkageScrap, int iNumberOfPairs)
{
	CString  s_buf;
	C3LOscr_LTreeNode  *pc_node_buf;


	if (iLinkageScrap == 0)
	{
		vFlushTree();

		vector<C3LOscr_LTreeNode *>  v_active_nodes;


		for (int ii = 0; ii < iNumberOfPairs; ii++)
		{
			pc_node_buf = new C3LOscr_LTreeNode();
			pc_node_buf->v_genes.push_back(ii);
			v_active_nodes.push_back(pc_node_buf);
			v_nodes.push_back(pc_node_buf);
		}//for  (int ii = 0; ii < pcDsm->i_size; ii++)


		C3LOscr_LTreeNode  *pc_node_test_0, *pc_node_test_1;
		int  i_random;
		while (v_active_nodes.size() > 1)
		{
			i_random = RandUtils::iRandNumber(0, v_active_nodes.size() - 1); // (int)lRand(v_active_nodes.size());
			pc_node_test_0 = v_active_nodes.at(i_random);
			v_active_nodes.erase(v_active_nodes.begin() + i_random);

			i_random = RandUtils::iRandNumber(0, v_active_nodes.size() - 1); //(int)lRand(v_active_nodes.size());
			pc_node_test_1 = v_active_nodes.at(i_random);
			v_active_nodes.erase(v_active_nodes.begin() + i_random);


			pc_node_buf = pc_node_test_0->pcJoinNodes(pc_node_test_1);
			if (pc_node_buf == NULL)  ::Tools::vShow("void  CLTree::vGenerateRandomLT(int iNumberOfPairs)");
			v_nodes.push_back(pc_node_buf);

		}//while  (v_active_nodes.size() > 1)*/
	}//if  (iLinkageScrap == 0)
	else
	{
		vector<C3LOscrLinkageScrap>  v_link_scraps_temp;
		C3LOscrLinkageScrap  c_scrap_buf;
		int  i_len, i_buf;

		vector<int>  v_offsets, v_offests_buf;

		for (int ii = 0; ii < iNumberOfPairs; ii++)
			v_offsets.push_back(ii);

		for (int i_leading_gene = 0; i_leading_gene < iNumberOfPairs; i_leading_gene++)
		{
			i_len = RandUtils::iRandNumber(0, iNumberOfPairs / 2 - 1); //lRand(iNumberOfPairs / 2);
			c_scrap_buf.pvGetScrap()->push_back(i_leading_gene);

			v_offests_buf = v_offsets;

			while (c_scrap_buf.pvGetScrap()->size() < i_len)
			{
				i_buf = RandUtils::iRandNumber(0, v_offests_buf.size() - 1); //  lRand(v_offests_buf.size());
				if (v_offests_buf.at(i_buf) != i_leading_gene)
				{
					c_scrap_buf.pvGetScrap()->push_back(v_offests_buf.at(i_buf));
					v_offests_buf.erase(v_offests_buf.begin() + i_buf);
				}//if  (v_offests_buf.at(v_offests_buf) != i_leading_gene)
			}//while  (c_scrap_buf.pvGetScrap()->size() < i_len)

			v_link_scraps_temp.push_back(c_scrap_buf);
		}//for  (int  i_leading_gene = 0; i_leading_gene < iNumberOfPairs; i_leading_gene++)


		bCreateLT(&v_link_scraps_temp, 1, 0, iNumberOfPairs);
	}//else  if  (iLinkageScrap == 0)

	v_nodes_stats_compute(&v_nodes, &d_node_size_min, &d_node_size_max, &d_node_size_avr, &d_node_size_median);

}//void  C3LOscr_LTree::vGenerateRandomLT()




void  C3LOscr_LTree::vSave(CString  sDest)
{
	FILE  *pf_dest;

	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;

	vSave(pf_dest);

	fclose(pf_dest);
}//void  C3LOscr_LTree::vSave(CString  sDest)


void  C3LOscr_LTree::vSave(FILE  *pfDest)
{
	CString  s_line, s_buf;

	s_line.Format("Size: %d\n\n", v_nodes.size());
	fprintf(pfDest, s_line);

	for (int ii = 0; ii < v_nodes.size(); ii++)
	{
		if (v_nodes.at(ii)->pvGetGenes()->size() > 1)
		{
			s_line = v_nodes.at(ii)->sGetAsString() + "\n";
			fprintf(pfDest, s_line);
		}//if  (v_nodes.at(ii)->pvGetGenes()->size() > 1)
	}//for  (int ii = 0; ii < i_size; ii++)
}//void  C3LOscr_LTree::vSave(FILE  *pfDest);



void  C3LOscr_LTree::vShuffleNodesShorterFirst()
{
	vector<C3LOscr_LTreeNode *>  v_nodes_tmp;

	v_nodes_tmp = v_nodes;
	v_nodes.clear();

	int  i_pos;
	while (v_nodes_tmp.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_nodes_tmp.size() - 1); //lRand(v_nodes_tmp.size());
		v_nodes.push_back(v_nodes_tmp.at(i_pos));
		v_nodes_tmp.erase(v_nodes_tmp.begin() + i_pos);
	}//while  (v_nodes_tmp.size()  >  0)

	std::sort(v_nodes.begin(), v_nodes.end(), [](C3LOscr_LTreeNode* cVal0, C3LOscr_LTreeNode* cVal1) -> bool { return(cVal0->pvGetGenes()->size() < cVal1->pvGetGenes()->size()); });

}//void  C3LOscr_LTree::vShuffleNodes()



void  C3LOscr_LTree::vShuffleNodes()
{
	vector<C3LOscr_LTreeNode *>  v_nodes_tmp;

	v_nodes_tmp = v_nodes;
	v_nodes.clear();

	int  i_pos;
	while (v_nodes_tmp.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_nodes_tmp.size() - 1); //lRand(v_nodes_tmp.size());
		v_nodes.push_back(v_nodes_tmp.at(i_pos));
		v_nodes_tmp.erase(v_nodes_tmp.begin() + i_pos);
	}//while  (v_nodes_tmp.size()  >  0)

}//void  C3LOscr_LTree::vShuffleNodes()



void  C3LOscr_LTree::vFlushTree()
{
	for (int ii = 0; ii < v_nodes.size(); ii++)
		delete  v_nodes.at(ii);
	v_nodes.clear();
}//void  C3LOscr_LTree::vFlushTree()


void  C3LOscr_LTree::vCopyFrom(C3LOscr_LTree  *pcSource)
{
	vFlushTree();

	C3LOscr_LTreeNode  *pc_new_node;
	for (int ii = 0; ii < pcSource->v_nodes.size(); ii++)
	{
		pc_new_node = new C3LOscr_LTreeNode();
		(*pc_new_node) = *(pcSource->v_nodes.at(ii));
		v_nodes.push_back(pc_new_node);
	}//for  (int ii = 0; ii < pcSource->v_nodes.size(); ii++)
}//void  C3LOscr_LTree::vCopyFrom(CLTree  *pcSource)



//---------------------------------------------C3LOscr_LTree-------------------------------------------------------


C3LOscr_DSM::C3LOscr_DSM()
{
	pd_dsm = NULL;
	i_size = 0;
}//C3LOscr_DSM::C3LOscr_DSM()


C3LOscr_DSM::~C3LOscr_DSM()
{
	if (pd_dsm != NULL)
	{
		for (int ii = 0; ii < i_size; ii++)
			delete  pd_dsm[ii];
	}//if  (pd_dsm != NULL)
	delete  pd_dsm;
}//C3LOscr_DSM::C3LOscr_DSM()



bool  C3LOscr_DSM::bSetSize(int  iSize)
{
	if (i_size > 0)  return(false);

	i_size = iSize;
	pd_dsm = new double*[i_size];
	for (int ii = 0; ii < i_size; ii++)
		pd_dsm[ii] = new double[i_size];

	bZeroDSM();
	return(true);
}//bool  C3LOscr_DSM::bSetSize(int  iSize)


bool  C3LOscr_DSM::bZeroDSM()
{
	if (i_size <= 0)  return(false);

	for (int ix = 0; ix < i_size; ix++)
	{
		for (int iy = 0; iy < i_size; iy++)
			pd_dsm[ix][iy] = 0;
	}//for  (int ix = 0; ix < i_size; ix++)
	return(true);
}//bool  C3LOscr_DSM::bZeroDSM()


bool  C3LOscr_DSM::vFillRandomly()
{
	if (i_size <= 0)  return(false);

	double d_val;
	for (int ix = 0; ix < i_size; ix++)
	{
		for (int iy = 0; iy < i_size; iy++)
		{
			d_val = ::RandUtils::dRandNumber(0,1);//dRand();

			pd_dsm[ix][iy] = d_val;
			pd_dsm[iy][ix] = d_val;
		}//for  (int iy = 0; iy < i_size; iy++)
	}//for  (int ix = 0; ix < i_size; ix++)

}//bool  C3LOscr_DSM::vFillRandomly()



void  C3LOscr_DSM::vSave(CString  sDest)
{
	FILE  *pf_dest;

	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;

	vSave(pf_dest);

	fclose(pf_dest);
}//void  C3LOscr_DSM::vSave(CString  sDest)


void  C3LOscr_DSM::vSave(FILE  *pfDest)
{
	CString  s_line, s_buf;

	s_line.Format("Size: %d\n\n", i_size);
	fprintf(pfDest, s_line);

	s_line = "xxxx \t";
	for (int ii = 0; ii < i_size; ii++)
	{
		s_buf.Format("%.4d \t", ii);
		s_line += s_buf;
	}//for  (int ii = 0; ii < i_size; ii++)
	s_line += "\n";

	fprintf(pfDest, s_line);


	int  i_buf;
	for (int ix = 0; ix < i_size; ix++)
	{
		s_line.Format("%.4d \t", ix);

		for (int iy = 0; iy < i_size; iy++)
		{
			i_buf = (int)pd_dsm[ix][iy];
			s_buf.Format("%.4d \t", i_buf);

			s_line += s_buf;
		}//for  (int iy = 0; iy < i_size; iy++)
		s_line += "\n";

		fprintf(pfDest, s_line);
	}//for  (int ix = 0; ix < i_size; ix++)

};//void  C3LOscr_DSM::vSave(FILE  *pfDest);


//---------------------------------------------C3LOscrLinkageScrap-------------------------------------------------------

bool  C3LOscrLinkageScrap::bUpdateDSM(C3LOscr_DSM  *pcDest)
{
	int  i_gene_first, i_gene_second;

	for (int i_first_off = 0; i_first_off < v_link_scrap.size() - 1; i_first_off++)
	{
		for (int i_second_off = i_first_off + 1; i_second_off < v_link_scrap.size(); i_second_off++)
		{
			i_gene_first = v_link_scrap.at(i_first_off);
			i_gene_second = v_link_scrap.at(i_second_off);

			if (i_gene_first > pcDest->i_size)  return(false);
			if (i_gene_second > pcDest->i_size)  return(false);

			if (i_gene_first != i_gene_second)
			{
				pcDest->pd_dsm[i_gene_first][i_gene_second] += 1;
				pcDest->pd_dsm[i_gene_second][i_gene_first] += 1;
			}//if  (i_gene_first  !=  i_gene_second)

		}//for  (int  i_second_off = i_first_off + 1; i_second_off < v_link_scrap.size(); i_second_off++)
	}//for  (int  i_first_off = 0; i_first_off < v_link_scrap.size(); i_first_off++)

	return(true);
}//bool  C3LOscrLinkageScrap::bUpdateDSM(C3LOscr_DSM  *pcDest)


void  C3LOscrLinkageScrap::vSave(FILE  *pfDest)
{
	CString  s_result, s_buf;

	s_result.Format("[%d]", v_link_scrap.size());

	if (v_link_scrap.size() > 0)
	{
		s_buf.Format("  %d -> ", v_link_scrap.at(0));
		s_result += s_buf;

		for (int ii = 1; ii < v_link_scrap.size(); ii++)
		{
			s_buf.Format("  %d;", v_link_scrap.at(ii));
			s_result += s_buf;
		}//for  (int ii = 1; ii < v_link_scrap.size(); ii++)
	}//if  (v_link_scrap.size()  >  0)

	fprintf(pfDest, s_result);
};//void  C3LOscrLinkageScrap::vSave(FILE  *pfDest)





//---------------------------------------------C3LOscrappedMultiPop-------------------------------------------------------
C3LOscrappedMultiPop::C3LOscrappedMultiPop(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	pc_pop_add = NULL;
	pc_pop_super = NULL;
	pc_pop_add = NULL;

	i_multi_pop_improvement_counter = 0;
};//C3LOscrappedMultiPop::C3LOscrappedMultiPop(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



C3LOscrappedMultiPop::C3LOscrappedMultiPop(C3LOscrappedMultiPop *pcOther) : CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "Brak implementacji: C3LOscrapped::C3LOscrapped(C3LOscrapped *pcOther) : CBinaryOptimizer(pcOther)", "BRAK", MB_OK);
}//C3LOscrappedMultiPop::C3LOscrappedMultiPop(C3LOscrappedMultiPop *pcOther) : CBinaryOptimizer(pcOther)



C3LOscrappedMultiPop::~C3LOscrappedMultiPop()
{
	for (int ii = 0; ii < v_pops.size(); ii++)
		delete  v_pops.at(ii);

	if (pc_3lo_scr_raw != NULL) delete  pc_3lo_scr_raw;
	if (pc_3lo_scr_raw != NULL) delete  pc_pop_super;
	if (pc_3lo_scr_raw != NULL) delete  pc_pop_add;
}//C3LOscrappedMultiPop::~C3LOscrappedMultiPop()



void  C3LOscrappedMultiPop::vInitialize()
{
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();
	c_time_counter.vSetStartNow();
	d_time_last_time = 0;

	pc_3lo_scr_raw->vInitialize();
	pc_pop_super = pc_create_new_pop();
	pc_pop_add = pc_create_new_pop();
	v_pops.push_back(pc_create_new_pop());

	i_multi_pop_improvement_counter = 0;
}//void  C3LOscrappedMultiPop::vInitialize(time_t tStartTime)



CError C3LOscrappedMultiPop::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_C3LOScrappedMultiPopOptimizer);


	c_err = CBinaryOptimizer::eConfigure3LO(psSettings);

	pc_3lo_scr_raw = new C3LOscrapped(pc_problem, pc_log, i_random_seed);
	
	pc_3lo_scr_raw->eConfigure(psSettings);
	if (c_err)  return(c_err);


	return c_err;
};//CError C3LOscrappedMultiPop::eConfigure(istream *psSettings)


C3LOscrapped  *C3LOscrappedMultiPop::pc_create_new_pop()
{
	C3LOscrapped  *pc_new_pop;
	pc_new_pop = new C3LOscrapped(pc_problem, pc_log, i_random_seed);

	pc_new_pop->vCopyFrom(pc_3lo_scr_raw);
	pc_new_pop->vInitialize();

	pc_log->vPrintEmptyLine(true);
	pc_log->vPrintLine("Adding NEW POP", true);
	pc_new_pop->bRunIteration(0);
	pc_log->vPrintEmptyLine(true);

	return(pc_new_pop);
}//void  C3LOscrappedMultiPop::v_intialize_pop(C3LOscrapped  *pcPopToInit)




bool C3LOscrappedMultiPop::bRunIteration(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_C3LOScrappedMultiPopOptimizer);

	CString  s_buf;


	double  d_best_before, d_best_after;
	bool  b_something_improved;
	C3LOscrappedIndividual  *pc_current_best;

	pc_current_best = v_pops.at(0)->pcGetBest();
	b_something_improved = false;
	for (int i_pop = 0; i_pop < v_pops.size(); i_pop++)
	{
		pc_log->vPrintEmptyLine(true);
		s_buf.Format("RUNNING pop %d", i_pop);
		pc_log->vPrintLine(s_buf, true);

		d_best_before = v_pops.at(i_pop)->pcGetBest()->dComputeFitness();
		v_pops.at(i_pop)->bRunIteration(iIterationNumber);
		d_best_after = v_pops.at(i_pop)->pcGetBest()->dComputeFitness();

		if (d_best_before < d_best_after)  b_something_improved = true;
		if (pc_current_best->dComputeFitness() < v_pops.at(i_pop)->pcGetBest()->dComputeFitness())  pc_current_best = v_pops.at(i_pop)->pcGetBest();

	}//for (int i_pop = 0; i_pop < v_pops.size(); i_pop++)


	pc_log->vPrintEmptyLine(true);
	s_buf.Format("RUNNING SUPERPOP");
	pc_log->vPrintLine(s_buf, true);

	d_best_before = pc_pop_super->pcGetBest()->dComputeFitness();
	pc_pop_super->bRunIterationSuperPop(iIterationNumber, &v_pops);
	d_best_after = pc_pop_super->pcGetBest()->dComputeFitness();

	if (d_best_before < d_best_after)  b_something_improved = true;
	

	if (b_something_improved == true)
	{
		i_multi_pop_improvement_counter++;
	}//if (b_something_improved == true)
	else
	{
		i_multi_pop_improvement_counter--;

		if (i_multi_pop_improvement_counter < 0)
		{
			i_multi_pop_improvement_counter = 0;

			pc_log->vPrintEmptyLine(true);
			s_buf.Format("ADDING new pop");
			v_pops.push_back(pc_create_new_pop());
		}//if (i_multi_pop_improvement_counter < 0)
	}//else  if (b_something_improved == true)


	if (pc_current_best->dComputeFitness() < pc_pop_super->pcGetBest()->dComputeFitness())  pc_current_best = pc_pop_super->pcGetBest();



	b_update_best_individual(iIterationNumber, pc_current_best->piGetGenotype(), pc_current_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	/*s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);*/
	s_buf.Format("MULTI 3loScr BEST: %.8lf   pops: %d  counter: %d", pc_current_best->dComputeFitness(), v_pops.size(), i_multi_pop_improvement_counter);
	pc_log->vPrintLine(s_buf, true);

	


	return(true);
}//bool C3LOscrappedMultiPop::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)