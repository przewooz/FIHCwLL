#pragma once
#include "BinaryOptimizer.h"
#include "PopulationSizingOptimizer.h"
#include <random>
#include <vector>

#define BINARY_GREY_WOLF_OPTIMIZER_ARGUMENT_POPULATION_SIZE "population_size"
#define BINARY_GREY_WOLF_OPTIMIZER_ARGUMENT_STALE_DETECTION "stale_detection"
#define BINARY_GREY_WOLF_OPTIMIZER_ARGUMENT_DECAY_COEFFICIENT "decay_coefficient"



class CBinaryGreyWolfIndividual;

class CBinaryGreyWolfOptimizer : public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>
{
public:
	static uint32_t iERROR_PARENT_CBinaryGreyWolfOptimizer;
	static const float F_DEFAULT_DECAY_COEFFICIENT;

	CBinaryGreyWolfOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog* pcLog, uint32_t iRandomSeed);


	CBinaryGreyWolfOptimizer(CBinaryGreyWolfOptimizer* pcOther);
	~CBinaryGreyWolfOptimizer() override;

	COptimizer<CBinaryCoding, CBinaryCoding>* pcCopy() override;

	bool bRunIteration(uint32_t iIterationNumber) override;

	CError eConfigure(istream* psSettings) override;

	CBinaryGreyWolfIndividual* pcGetRandomIndividual();

	double dComputeAverageFitnessValue() override;
	bool bIsSteadyState() override;
	uint32_t iGetPopulationSize() override { return i_population_size; }
	void vSetPopulationSize(uint32_t iPopulationSize) override { i_population_size = iPopulationSize; }
	void vDeleteIndividuals();
	void vEvaluate(uint32_t iIterationNumber);
	bool bMaybeUpdateBest(CBinaryGreyWolfIndividual& cPossiblyNewBest, uint32_t iIterationNumber);
	double dEvaluate(CBinaryGreyWolfIndividual& cIndividual);
	void vInitializeIndividuals();
	void vInitialize() override;

protected:
	uniform_real_distribution<double> c_uniform_zero_one_distribution;
	default_random_engine c_random_engine;

	bool b_is_initialized;
	bool b_use_stale_detection;
	double d_decay_coefficient;
	int  i_decay_step;
	int  i_decay_remove_step;
	double d_a;
	double d_r1;
	double d_r2;


	vector<double> v_a;
	vector<double> v_c;
	vector<double> v_d;
	vector<double> v_x;
	
	uint16_t i_genotype_length;
	uint32_t i_population_size;
	vector<CBinaryGreyWolfIndividual*> v_population;
	CBinaryGreyWolfIndividual* pc_best;
	CBinaryGreyWolfIndividual* pc_alpha;
	CBinaryGreyWolfIndividual* pc_beta;
	CBinaryGreyWolfIndividual* pc_delta;

	void v_maybe_replace_leaders(CBinaryGreyWolfIndividual* pcIndividual);
};//class CBinaryGreyWolfOptimizer : public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>

class CBinaryGreyWolfIndividual
{
public:
	friend class CBinaryGreyWolfOptimizer;
	CBinaryGreyWolfIndividual(uint16_t iGenotypeLength);
	static CBinaryGreyWolfIndividual* pcGetRandomIndividual(uint16_t iGenotypeLength, uniform_real_distribution<double>& cZeroOneDistribution, default_random_engine& cRandomEngine);
protected:
	void v_transform_sigmoid(uniform_real_distribution<double>& cThresholdDistribution, default_random_engine& cRandomEngine);
	double d_fitness;
	vector<double> v_position;
	vector<int32_t> v_genotype;
};//class CBinaryGreyWolfIndividual
