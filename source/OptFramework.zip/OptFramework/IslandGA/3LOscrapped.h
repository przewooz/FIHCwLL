#ifndef C3LO_SCRAPPED_OPTIMIZER_H
#define C3LO_SCRAPPED_OPTIMIZER_H


#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "CommandParam.h"
#include "Error.h"
#include "Log.h"
#include "MathUtils.h"
#include "Optimizer.h"
#include "Problem.h"
#include  "util\timer.h"
#include  "util\tools.h"



#include <istream>
#include <algorithm>





namespace ThreeLOScr
{
	#define  _3LO_SCRAPPED_ARGUMENT_LEAVE_AT_LEVEL									"LeaveIndAtLevel" 
	#define  _3LO_SCRAPPED_ARGUMENT_OM_SLIDE										"OmSlide" 
	#define  _3LO_SCRAPPED_ARGUMENT_RANDOM_LINKAGE									"RandomLinkage" 
	#define  _3LO_SCRAPPED_ARGUMENT_LINKAGE_SCRAP									"LinkageScrap" 
	#define  _3LO_SCRAPPED_ARGUMENT_LINKAGE_SCRAP_ANALYSIS							"LinkageScrapAnalysis" 
	#define  _3LO_SCRAPPED_ARGUMENT_LINKAGE_SCRAP_EFFECT_SCRAP						"ScrapLinkageEffectScrap"
	#define  _3LO_SCRAPPED_ARGUMENT_LINKAGE_SCRAP_EFFECT_SCRAP_PLUS_PROVOKING_SCRAP	"ScrapLinkageEffectScrapPlusProvokingScrap"

	class  C3LOscrappedIndividual;
	class  C3LOscr_DSM;//predefinition
	class  C3LOscrLinkageScrap;//predefinition
	class  C3LOscr_LTreeNode;//predefinition
	class  C3LOscr_LTree;//predefinition
	class  C3LOscrapped;//predefinition


	class  C3LOscr_LTNodePair
	{
	public:
		bool  bNodeInside(C3LOscr_LTreeNode  *pcNodeToCheck) { if (pc_node_0 == pcNodeToCheck)  return(true); if (pc_node_1 == pcNodeToCheck)  return(true); return(false); };

		int  iReplaceNodeWithNode(C3LOscr_LTreeNode  *pcNodeToCheck, C3LOscr_LTreeNode  *pcNewNode);

		C3LOscr_LTreeNode  *pc_node_0;
		C3LOscr_LTreeNode  *pc_node_1;
		double  d_dist;
	};//class  C3LOscr_LTNodePair



	class  C3LOscr_NodeSimilarity
	{
	public:
		C3LOscr_LTreeNode  *pcNodeThis;
		C3LOscr_LTreeNode  *pcNodeOther;
		int  iCommonGenesNum;

		double  dGetSimilarity();
	};


	class  C3LOscr_LTreeNode
	{
		friend class  C3LOscr_LTree;
	public:
		C3LOscr_LTreeNode() { i_succ_crossings = 0; pc_parent_node = NULL; };
		~C3LOscr_LTreeNode() {};

		CString  sGetAsString();
		double  dGetDist(C3LOscr_LTreeNode  *pcOtherNode, C3LOscr_DSM *pdDsm);
		double  dGetMaxDSM();
		void  vGetAll_DSM_PairsWithSimilarity(double  dDSM_Similarity, vector<C3LOscr_LTNodePair> *pvDest);
		void  vRemoveFromDSM_SimilarityList(C3LOscr_LTreeNode  *pcOther);

		bool  bAnyCommonGenes(C3LOscr_LTreeNode  *pcOther);
		bool  bDoIContain(int iOffset);

		C3LOscr_LTreeNode  *pcJoinNodes(C3LOscr_LTreeNode  *pcOther);
		C3LOscr_LTreeNode  *pcMultiplyNodes(C3LOscr_LTreeNode  *pcOther);

		bool  bIsTheSame(C3LOscr_LTreeNode  *pcOther);
		int  iGetCommonGeneNum(C3LOscr_LTreeNode  *pcOtherNode);
		C3LOscr_LTreeNode  *pcNodeAnalysisUp(vector<C3LOscr_LTreeNode *>  *pvCandidateNodes);
		C3LOscr_LTreeNode  *pcNodeAnalysisDown(vector<C3LOscr_LTreeNode *>  *pvCandidateNodes);

		void  vSortGenes();
		void  vSetDependentGenes(vector<int> *pvLinkScrap);

		int  iGetSuccCross() { return(i_succ_crossings); };
		void  vIncrSuccCross() { i_succ_crossings++; };
		vector<int>  *pvGetGenes() { return(&v_genes); };
	private:
		C3LOscr_LTreeNode  *pc_parent_node;
		vector<C3LOscr_LTreeNode *> v_children_nodes;

		vector<C3LOscr_LTNodePair>  v_nodes_checked_dsm_similarity;

		vector<int>  v_genes;
		int  i_succ_crossings;
	};//class  C3LOscr_LTreeNode


	class  C3LOscr_LTree
	{
	public:
		C3LOscr_LTree();
		~C3LOscr_LTree();

		void  vSetParent(C3LOscrapped  *pcParent) { pc_parent = pcParent; };

		void  vCopyFrom(C3LOscr_LTree  *pcSource);
		void  vFlushTree();
		void  vShuffleNodes();
		void  vShuffleNodesShorterFirst();

		vector<C3LOscr_LTreeNode *>  *pvGetNodes() { return(&v_nodes); };
		bool  bCreateLT(vector<C3LOscrLinkageScrap>  *pvLinkScraps, int iLinkageScrap, int  iLinkageScrapAnalysis, int iTemplLength);
		void  vGenerateRandomLT(int  iLinkageScrap, int iTemplLength);

		bool  bCreateFromDSM(C3LOscr_DSM  *pcDsm);
		void  vSave(CString  sDest);
		void  vSave(FILE  *pfDest);

		double  dGetNodeSizeMin() { return(d_node_size_min); }
		double  dGetNodeSizeMax() { return(d_node_size_max); }
		double  dGetNodeSizeAvr() { return(d_node_size_avr); }
		double  dGetNodeSizeMedian() { return(d_node_size_median); }

	private:
		void  v_nodes_stats_compute(vector<C3LOscr_LTreeNode *>  *pvNodes, double  *pdMin, double  *pdMax, double  *pdAvr, double *pdMedian);
		void  v_nodes_stats_coverage(vector<C3LOscr_LTreeNode *>  *pvNodes, int iTemplLength, vector<int>  *pvCoverage, double  *pdPerc);
		void  v_filter_the_same_nodes(vector<C3LOscr_LTreeNode *>  *pvNodesBase, int  iTemplLength);

		void  v_linkage_scraps_analysis(vector<C3LOscrLinkageScrap>  *pvLinkScraps, int iTemplLength);
		void  v_linkage_scraps_analysis_base(vector<C3LOscr_LTreeNode *>  *pvNodesBase, vector<C3LOscrLinkageScrap>  *pvLinkScraps, int iTemplLength);
		void  v_linkage_scraps_analysis_up(vector<C3LOscr_LTreeNode *>  *pvNodesBase, vector<vector<C3LOscr_LTreeNode *>>  *pvNodesUp, int iTemplLength);
		void  v_linkage_scraps_analysis_down(vector<C3LOscr_LTreeNode *>  *pvNodesBase, vector<vector<C3LOscr_LTreeNode *>>  *pvNodesDown, int iTemplLength);

		vector<C3LOscr_LTreeNode *>  v_nodes;
		vector<int>  v_coverage;
		double  d_coverage_perc;

		double  d_node_size_min, d_node_size_max, d_node_size_avr, d_node_size_median, d_coverage_base;

		C3LOscrapped  *pc_parent;

	};//class  C3LOscr_LTree


	class  C3LOscr_DSM
	{
		friend class C3LOscrLinkageScrap;
		friend class C3LOscr_LTreeNode;
	public:
		C3LOscr_DSM();
		~C3LOscr_DSM();
		bool  bSetSize(int  iSize);

		int  iGetSize() { return(i_size); };

		bool  bZeroDSM();
		bool  vFillRandomly();

		void  vSave(CString  sDest);
		void  vSave(FILE  *pfDest);

	private:
		double  **pd_dsm;
		int  i_size;
	};//class  C3LOscr_DSM


	class C3LOscrLinkageScrap
	{
	public:
		C3LOscrLinkageScrap() {};
		~C3LOscrLinkageScrap() {};

		bool  bUpdateDSM(C3LOscr_DSM  *pcDest);
		void  vSetScrap(vector<int> *pvLinkScrap) { v_link_scrap = *pvLinkScrap; };
		void  vSave(FILE  *pfDest);
		vector<int>  *pvGetScrap() { return(&v_link_scrap); }
	private:

		vector<int>  v_link_scrap;

	};//class C3LOscrLinkageScrap


	class C3LOscrappedMultiPop : public CBinaryOptimizer
	{
	public:
		static uint32_t iERROR_PARENT_C3LOScrappedMultiPopOptimizer;

		C3LOscrappedMultiPop(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
		C3LOscrappedMultiPop(C3LOscrappedMultiPop *pcOther);
		~C3LOscrappedMultiPop();

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new C3LOscrappedMultiPop(this); };
		virtual bool bRunIteration(uint32_t iIterationNumber);

		virtual CError eConfigure(istream *psSettings);
		virtual void vInitialize();

		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo() { CString  s_buf; return(s_buf); };

	private:
		C3LOscrapped  *pc_create_new_pop();

		C3LOscrapped  *pc_3lo_scr_raw;

		C3LOscrapped  *pc_pop_super;
		C3LOscrapped  *pc_pop_add;

		vector<C3LOscrapped  *>  v_pops;
		int  i_multi_pop_improvement_counter;

		int  i_templ_length;
		CTimeCounter  c_time_counter;
		double  d_time_last_time;
	};//class C3LOscrappedMultiPop : public CBinaryOptimizer


	class C3LOscrapped : public CBinaryOptimizer
	{
		friend class C3LOscrappedIndividual;
	public:
		static uint32_t iERROR_PARENT_C3LOScrappedOptimizer;
		static uint32_t iERROR_CODE_3LO_SCRAPPED_GENOTYPE_LEN_BELOW_0;


		C3LOscrapped(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
		C3LOscrapped(C3LOscrapped *pcOther);
		~C3LOscrapped();

		void  vCopyFrom(C3LOscrapped *pcOther);

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new C3LOscrapped(this); };
		virtual bool bRunIteration(uint32_t iIterationNumber);
		bool bRunIterationSuperPop(uint32_t iIterationNumber, vector<C3LOscrapped *> *pvPops);

		virtual CError eConfigure(istream *psSettings);
		virtual void vInitialize();

		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo();

		double dComputeFitness(int32_t *piBits);

		vector<C3LOscrLinkageScrap>  *pvGetGlobalScraps() { return(&v_link_scraps_global); }
		void  vIncSuccOms() { i_succ_oms++; };
		bool  bCheckPopulationIfExists(C3LOscrappedIndividual  *pcNewInd);
		int  iGetIndNumber();

		int  iLinkageScrapCreateEffectScrap() { return(i_linkage_scrap_create_effect_scrap); }
		int  iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScracp() { return(i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp); }

		C3LOscrappedIndividual  *pcGetBest() { return(pc_best); };

		

	private:
		bool b_run_iteration_super_pop(uint32_t iIterationNumber, vector<C3LOscrapped *> *pvPops);
		bool b_run_iteration_super_pop_single_best(uint32_t iIterationNumber, vector<C3LOscrapped *> *pvPops);


		C3LOscrappedIndividual* pc_get_random_individual(int iLevel);
		void  v_add_level(C3LOscrappedIndividual  *pcNewInd);
		bool  b_run_for_level(int  iLevel, C3LOscrappedIndividual  *pcNewInd);
		bool  b_run_for_level_p3_like(int  iLevel, C3LOscrappedIndividual  *pcNewInd);

		void  v_pyramid_clear();
		void  v_pyramid_join(vector<vector<C3LOscrappedIndividual *>> *pvPyramidToJoin);


		vector<C3LOscrapped *> *pv_other_pops;

		C3LOscr_LTree  c_ltree_global;
		vector<C3LOscrLinkageScrap>  v_link_scraps_global;

		CTimeCounter  c_time_counter;
		double  d_time_last_time;

		vector<vector<C3LOscrappedIndividual *>> v_pop;
		vector<vector<C3LOscrappedIndividual *>> v_pop_superpop;
		C3LOscrappedIndividual  *pc_best;
		C3LOscrappedIndividual  *pc_ind_buf;
		C3LOscrappedIndividual  *pc_last_added;

		int  i_leave_ind_at_level;
		int  i_om_slide;
		int  i_random_linkage;
		int  i_linkage_scrap;
		int  i_linkage_scrap_analysis;
		int  i_linkage_scrap_create_effect_scrap;
		int  i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp;

		int  i_the_same_checks;
		int  i_succ_oms;
		int  i_random_indiv_adds;

		int  i_templ_length;
	};//class C3LOscrapped : public CBinaryOptimizer	



	class  C3LOscrappedIndividual
	{
		friend class C3LOscrapped;
	public:
		C3LOscrappedIndividual(int iLevel, int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, C3LOscrapped *pcParent);
		C3LOscrappedIndividual(C3LOscrappedIndividual &pcOther);
		~C3LOscrappedIndividual();

		bool  bIsTheSame(C3LOscrappedIndividual  *pcOther);
		double  dGetSimilarity(C3LOscrappedIndividual  *pcOther, int  *piGenesTheSame);
		void  vRandomizeGenotype();
		int*  piGetGenotype() { return(pi_genotype); }

		void  vCopyFrom(C3LOscrappedIndividual  *pcNewInd);

		void  vCreateLT(int  iLinkageScrap, int iLinkageScrapAnalysis);
		void  vCreateLT_Random(int  iLinkageScrap);


		double  dComputeFitness();
		double  dComputeFitnessOptimize(vector<int>  *pvOrder = NULL);

		void  vGetLinkageScraps(C3LOscrappedIndividual  *pcBuffer, C3LOscrappedIndividual  *pcBest, vector<int>  *pvOrder = NULL);

		int  iOptimalMixingP3Like(vector<C3LOscrappedIndividual *>  *pvLevel, C3LOscr_LTree  *pcLTree, C3LOscrappedIndividual  *pcBuffer);
		int  iOptimalMixing(C3LOscrappedIndividual  *pcDonor, C3LOscr_LTree  *pcLTree, C3LOscrappedIndividual  *pcBuffer);
		int  iOptimalMixing(C3LOscrappedIndividual  *pcDonor, C3LOscr_LTree  *pcLTree, C3LOscr_LTreeNode  *pcLTreeNode, C3LOscrappedIndividual  *pcBuffer);

		C3LOscrappedIndividual  *pcGetLastInsertableVersion() { return(pc_last_insertable_version); };

		void  vStoreLastInsertableVersion();
		void  vClearOptOrder() { v_opt_order.clear(); }

	private:
		void  v_create_opt_order(vector<int>  *pvOrder);
		double  d_optimize_single_gene(int  iOptGene);

		C3LOscrappedIndividual  *pc_last_insertable_version;


		C3LOscr_LTree  *pc_ltree;
		vector<C3LOscrLinkageScrap>  v_link_scraps;
	
		
		C3LOscrapped  *pc_parent;
		int  i_templ_length;
		int  *pi_genotype;
		vector<int>  v_opt_order;

		double  d_fitnes_buf;
		bool  b_fitness_actual;

		int  i_level;
		CProblem<CBinaryCoding, CBinaryCoding > *pc_problem;
	};//class  C3LOscrappedIndividual
	
}//namespace ThreeLOScr

#endif//C3LO_SCRAPPED_OPTIMIZER_H