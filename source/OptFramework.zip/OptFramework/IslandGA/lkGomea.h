#ifndef C_LK_GOMEA_OPTIMIZER_H
#define C_LK_GOMEA_OPTIMIZER_H


#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "CommandParam.h"
#include "Error.h"
#include "Log.h"
#include "MathUtils.h"
#include "Optimizer.h"
#include "Problem.h"
#include  "util\timer.h"
#include  "util\tools.h"

#include "lkGomea_Config.h"
#include "lkGomea_gomeaLSNoveltyIMS.h"



#include <istream>
#include <algorithm>





namespace nLK_Gomea
{
	#define  s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY			"populationTopology(0-Asymetric; 1-symetric)"
	#define  s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY_ASYMETRIC			0
	#define  s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY_SYMETRIC			1


	class C_lkGomea : public CBinaryOptimizer
	{
	public:
		static uint32_t iERROR_PARENT_C_lkGomea;
		static uint32_t iERROR_CODE_C_lkGomea_GENOTYPE_LEN_BELOW_0;
		static uint32_t iERROR_CODE_C_lkGomea_UnknownPopulationMode;


		C_lkGomea(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
		C_lkGomea(C_lkGomea *pcOther);
		~C_lkGomea();

		void  vCopyFrom(C_lkGomea *pcOther);

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new C_lkGomea(this); };
		virtual bool bRunIteration(uint32_t iIterationNumber);

		virtual CError eConfigure(istream *psSettings);
		virtual void vInitialize();

		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo();

		double dComputeFitness(int32_t *piBits);


	private:
		void  v_get_best_genotype(vector<char>  *pvGenotype);//asdasd

		double  d_time_last_time;
		int  i_templ_length;
		int  i_population_topology;//0-asymetric; 1-symetric


		C_lkGomea_Config  *pc_lk_gomea_config;
		C_lkGomea_gomeaLSNoveltyIMS  *pc_cgomea_best_p3;

		int32_t *pi_bits;
	};//class C_CGomea : public CBinaryOptimizer	

}//namespace nLK_Gomea

#endif//C_LK_GOMEA_OPTIMIZER_H