#include "BinaryCuckooOptimizer.h"

uint32_t CBinaryCuckooOptimizer::iERROR_PARENT_CBinaryCuckooOptimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_CBinaryCuckooOptimizer");
const float CBinaryCuckooOptimizer::F_DEFAULT_ALPHA = 1.0;
const float CBinaryCuckooOptimizer::F_DEFAULT_LAMBDA = 1.0;
const float CBinaryCuckooOptimizer::F_DEFAULT_PA = 0.4;
const uint32_t CBinaryCuckooOptimizer::I_DEFAULT_N_MUT = 10;
const uint32_t CBinaryCuckooOptimizer::I_DEFAULT_POPULATION_SIZE = 30;

const double CBinaryCuckooOptimizer::D_DEFAULT_LOWER_BOUND = 0;
const double CBinaryCuckooOptimizer::D_DEFAULT_UPPER_BOUND = 1;
const double CBinaryCuckooOptimizer::D_DEFAULT_LEVY_BETA = 1.5; // from original code


CBinaryCuckooOptimizer::CBinaryCuckooOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed) :
	CPopulationSizingSingleOptimizer(pcProblem, pcLog, iRandomSeed),
	c_individual_distribution(D_DEFAULT_LOWER_BOUND, D_DEFAULT_UPPER_BOUND),
	c_uniform_distribution(0, 1),
	v_population(I_DEFAULT_POPULATION_SIZE, nullptr)
{
	c_random_engine.seed(iRandomSeed);

	d_lambda = F_DEFAULT_ALPHA;
	d_alpha = F_DEFAULT_ALPHA;
	d_pa = F_DEFAULT_PA;
	i_nmut = I_DEFAULT_N_MUT;
	d_lower_bound = D_DEFAULT_LOWER_BOUND;
	d_upper_bound = D_DEFAULT_UPPER_BOUND;
	i_population_size = I_DEFAULT_POPULATION_SIZE;

	double beta = D_DEFAULT_LEVY_BETA;
	double sigma = pow((tgamma(1 + beta) * sin((3.14 * beta) / 2)) / tgamma((1 + beta) / 2) * pow(2, (beta - 1) / 2), 1 / beta);

	d_levy_beta = beta;
	d_levy_sigma = sigma;

	pc_best = nullptr;
	i_genotype_length = pcProblem->pcGetEvaluation()->iGetNumberOfElements();
}//CBinaryCuckooOptimizer::CBinaryCuckooOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed

CBinaryCuckooOptimizer::CBinaryCuckooOptimizer(CBinaryCuckooOptimizer * pcOther) :
	CPopulationSizingSingleOptimizer(pcOther),
	v_population(pcOther->v_population.size(), nullptr),
	c_individual_distribution(pcOther->c_individual_distribution),
	c_uniform_distribution(pcOther->c_uniform_distribution),
	c_random_engine(pcOther->c_random_engine)
{
	i_genotype_length = pcOther->i_genotype_length;
	d_lambda = pcOther->d_lambda;
	d_alpha = pcOther->d_alpha;
	i_nmut = pcOther->i_nmut;
	d_pa = pcOther->d_pa;
	d_lower_bound = pcOther->d_lower_bound;
	d_upper_bound = pcOther->d_upper_bound;
	d_levy_beta = pcOther->d_levy_beta;
	d_levy_sigma = pcOther->d_levy_sigma;
	b_use_stale_detection = pcOther->b_use_stale_detection;
	i_population_size = pcOther->i_population_size;
	pc_best = pcOther->pc_best != nullptr ? new CBinaryCuckooIndividual(pcOther->pc_best) : nullptr;
	d_best_fitness = pcOther->d_best_fitness;

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		if (pcOther->v_population[ii] != nullptr)
		{
			v_population[ii] = new CBinaryCuckooIndividual(pcOther->v_population[ii]);
		}//if (pcOther->v_population[ii] != nullptr)
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//CBinaryCuckooOptimizer::CBinaryCuckooOptimizer(CBinaryCuckooOptimizer * pcOther)

CBinaryCuckooOptimizer::~CBinaryCuckooOptimizer()
{
	v_delete_population();
}//CBinaryCuckooOptimizer::~CBinaryCuckooOptimizer()

COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryCuckooOptimizer::pcCopy()
{
	return new CBinaryCuckooOptimizer(this);
}//COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryCuckooOptimizer::pcCopy()

CError CBinaryCuckooOptimizer::eConfigure(istream * psSettings)
{
	CError c_error(iERROR_PARENT_CBinaryCuckooOptimizer);
	c_error = COptimizer::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_population_size(BINARY_CUCKOO_OPTIMIZER_ARGUMENT_POPULATION_SIZE, 2, UINT32_MAX);
		i_population_size = p_population_size.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_n_mut(BINARY_CUCKOO_OPTIMIZER_ARGUMENT_NMUT, I_DEFAULT_N_MUT);
		i_nmut = p_n_mut.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_lambda(BINARY_CUCKOO_OPTIMIZER_ARGUMENT_LAMBDA, F_DEFAULT_LAMBDA);
		d_lambda = static_cast<double>(p_lambda.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_alpha(BINARY_CUCKOO_OPTIMIZER_ARGUMENT_ALPHA, F_DEFAULT_ALPHA);
		d_alpha = static_cast<double>(p_alpha.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_pa(BINARY_CUCKOO_OPTIMIZER_ARGUMENT_PA, F_DEFAULT_PA);
		d_pa = static_cast<double>(p_pa.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CBoolCommandParam p_stale_detection(BINARY_CUCKOO_OPTIMIZER_ARGUMENT_STALE_DETECTION, true, false);
		b_use_stale_detection = p_stale_detection.bGetValue(psSettings, &c_error);
	}//if (!c_error)

	return c_error;
}//CError CBinaryCuckooOptimizer::eConfigure(istream * psSettings)

bool CBinaryCuckooOptimizer::bRunIteration(uint32_t iIterationNumber)
{
	if (iIterationNumber >= 1) // taken from their code
		v_mutate();
	v_levy_flight();
	v_replace();

	vEvaluate();

	v_update_best();
	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->d_fitness, [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->v_genotype[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});

	CString s_log_message;
	s_log_message.Format(
		"Best fitness: %f; ffe: %llu; time: %.2lf; population size: %u",
		pc_best_individual->dGetFitnessValue(),
		pc_problem->pcGetEvaluation()->iGetFFE(),
		c_optimizer_timer.dGetTimePassed(),
		i_population_size);
	pc_log->vPrintLine(s_log_message, true);

	return b_updated;
}//bool CBinaryCuckooOptimizer::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

void CBinaryCuckooOptimizer::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	vResetBestIndividual();
	v_delete_population();
	v_initialize_population();
	v_update_best();
}//void CBinaryCuckooOptimizer::vInitialize(time_t tStartTime)

void CBinaryCuckooOptimizer::vEvaluate()
{
	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		d_evaluate(v_population[ii]);
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void CBinaryCuckooOptimizer::vEvaluate()

bool CBinaryCuckooOptimizer::bIsSteadyState()
{
	if (!b_use_stale_detection)
	{
		return false;
	}//if (!b_stale_detection)

	bool b_different_found = false;

	for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)
	{
		bool b_all_same = true;

		for (size_t j = 0; b_all_same && j < i_genotype_length; j++)
		{
			if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
			{
				b_all_same = false;
			}//if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
		}//for (size_t j = 0; b_all_same && j < i_genotype_length; j++)

		if (!b_all_same)
		{
			b_different_found = true;
		}//if (!b_all_same)
	}//for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)

	return !b_different_found;
}//bool CBinaryCuckooOptimizer::bIsSteadyState()

double CBinaryCuckooOptimizer::dComputeAverageFitnessValue()
{
	double d_fitness_sum = 0;

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		d_fitness_sum += v_population[ii]->d_fitness;
	}//for (size_t ii = 0; ii < v_population.size(); ii++)

	return d_fitness_sum / static_cast<double>(v_population.size());
}//double CBinaryCuckooOptimizer::dComputeAverageFitnessValue()

void CBinaryCuckooOptimizer::v_delete_population()
{
	delete pc_best;
	pc_best = nullptr;

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		delete v_population[ii];
		v_population[ii] = nullptr;
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void CBinaryCuckooOptimizer::v_delete_population()

void CBinaryCuckooOptimizer::v_initialize_population()
{
	v_population.clear();

	for (uint32_t ii = 0; ii < i_population_size; ii++)
	{
		v_population.push_back(
			CBinaryCuckooIndividual::pcGetRandomIndividual(
				i_genotype_length,
				d_lower_bound,
				d_upper_bound,
				c_individual_distribution,
				c_random_engine
			)
		);
	}//for (uint32_t ii = 0; ii < i_population_size; ii++)

	vEvaluate();
}//void CBinaryCuckooOptimizer::v_initialize_population()

double CBinaryCuckooOptimizer::d_evaluate(CBinaryCuckooIndividual * pc_individual)
{
	CBinaryCoding c_coding(i_genotype_length, pc_individual->v_genotype.data());
	double d_fitness_value = pcGetProblem()->pcGetEvaluation()->dEvaluate(&c_coding);
	pc_individual->d_fitness = d_fitness_value;

	return d_fitness_value;
}//double CBinaryCuckooOptimizer::d_evaluate(CBinaryCuckooIndividual * pc_individual)

void CBinaryCuckooOptimizer::v_update_best()
{
	uint32_t i_best_id = 0;

	for (uint32_t ii = 1; ii < i_population_size; ii++)
	{
		if (pc_problem->bIsBetterFitnessValue(v_population[ii]->d_fitness, v_population[i_best_id]->d_fitness))
		{
			i_best_id = ii;
		}//if (pc_problem->bIsBetterFitnessValue(v_population[ii]->d_fitness, v_population[i_best_id]->d_fitness))
	}//for (uint32_t ii = 1; ii < i_population_size; ii++)

	if (pc_best == nullptr || pc_problem->bIsBetterFitnessValue(v_population[i_best_id]->d_fitness, pc_best->d_fitness))
	{
		delete pc_best;
		pc_best = new CBinaryCuckooIndividual(v_population[i_best_id]);
		d_best_fitness = pc_best->d_fitness;
	}//if (pc_best == nullptr || pc_problem->bIsBetterFitnessValue(v_population[i_best_id]->d_fitness, pc_best->d_fitness))
}//void CBinaryCuckooOptimizer::v_update_best()

void CBinaryCuckooOptimizer::v_mutate()
{
	uniform_int_distribution<uint32_t> c_population_distribution(0, i_population_size - 1);
	uniform_int_distribution<uint16_t> c_gene_distribution(0, i_genotype_length - 1);

	for (uint32_t ii = 0; ii < i_nmut; ii++)
	{
		uint32_t i_solution = c_population_distribution(c_random_engine);
		uint16_t i_gene = c_gene_distribution(c_random_engine);

		if (v_population[i_solution]->v_eggs[i_gene] < 0.5)
		{
			v_population[i_solution]->v_eggs[i_gene] = 0;
		}//if (v_population[i_solution]->v_eggs[i_gene] < 0.5)
		else
		{
			v_population[i_solution]->v_eggs[i_gene] = 1;
		}//else if (v_population[i_solution]->v_eggs[i_gene] < 0.5)
	}

	vEvaluate();  // not necessary, but that's what the original implementation does
}//void CBinaryCuckooOptimizer::v_mutate()

void CBinaryCuckooOptimizer::v_replace()
{
	vector<uint32_t> v_solution_ids_permutation_1(v_population.size());
	iota(v_solution_ids_permutation_1.begin(), v_solution_ids_permutation_1.end(), 0);
	shuffle(v_solution_ids_permutation_1.begin(), v_solution_ids_permutation_1.end(), c_random_engine);

	vector<uint32_t> v_solution_ids_permutation_2(v_population.size());
	iota(v_solution_ids_permutation_2.begin(), v_solution_ids_permutation_2.end(), 0);
	shuffle(v_solution_ids_permutation_2.begin(), v_solution_ids_permutation_2.end(), c_random_engine);

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		if (c_uniform_distribution(c_random_engine) < d_pa)
		{
			CBinaryCuckooIndividual* pc_new_nest = new CBinaryCuckooIndividual(v_population[ii]);

			for (size_t j = 0; j < i_genotype_length; j++)
			{
				// from original implementation, not included in paper
				pc_new_nest->v_eggs[j] += c_uniform_distribution(c_random_engine) * (v_population[v_solution_ids_permutation_1[ii]]->v_eggs[j] - v_population[v_solution_ids_permutation_2[ii]]->v_eggs[j]);
			}//for (size_t j = 0; j < i_genotype_length; j++)

			pc_new_nest->v_clip_to_bounds();
			pc_new_nest->vGenotypeProbing();

			if(d_evaluate(pc_new_nest) < v_population[ii]->d_fitness)
			{
				delete v_population[ii];
				v_population[ii] = pc_new_nest;
			}//if(d_evaluate(pc_new_nest) < v_population[ii]->d_fitness)
			else
			{
				delete pc_new_nest;
			}//else if(d_evaluate(pc_new_nest) < v_population[ii]->d_fitness)
		}//if (c_uniform_distribution(c_random_engine) < d_pa)
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void CBinaryCuckooOptimizer::v_replace()

void CBinaryCuckooOptimizer::v_levy_flight()
{
	normal_distribution<double> c_norm_dist_u(0, d_levy_sigma);
	normal_distribution<double> c_norm_dist_v(0, 1);
	normal_distribution<double> c_norm_dist_step(0, 1);

	uint32_t i_best_id = 0;

	for (uint32_t ii = 1; ii < i_population_size; ii++)
	{
		if (pc_problem->bIsBetterFitnessValue(v_population[ii]->d_fitness, v_population[i_best_id]->d_fitness))
		{
			i_best_id = ii;
		}//if (pc_problem->bIsBetterFitnessValue(v_population[ii]->d_fitness, v_population[i_best_id]->d_fitness))
	}//for (uint32_t ii = 1; ii < i_population_size; ii++)

	for (size_t i = 0; i < v_population.size(); i++)
	{
		CBinaryCuckooIndividual* pc_new_nest = new CBinaryCuckooIndividual(v_population[i]);

		for (size_t j = 0; j < v_population[i]->v_eggs.size(); j++)
		{
			double u = c_norm_dist_u(c_random_engine);
			double v = c_norm_dist_v(c_random_engine);

			double d_step = u / pow(abs(v), 1 / d_levy_beta);

			d_step = d_step * (pc_new_nest->v_eggs[j] - v_population[i_best_id]->v_eggs[j]);

			pc_new_nest->v_eggs[j] = pc_new_nest->v_eggs[j] + d_alpha * d_step * c_norm_dist_step(c_random_engine);
		}//for (size_t j = 0; j < v_population[i]->v_eggs.size(); j++)
		
		pc_new_nest->v_clip_to_bounds();
		pc_new_nest->vGenotypeProbing();
		if (d_evaluate(pc_new_nest) > v_population[i]->d_fitness)
		{
			delete v_population[i];
			v_population[i] = pc_new_nest;
		}//if (d_evaluate(pc_new_nest) > v_population[i]->d_fitness)
		else
		{
			delete pc_new_nest;
		}//else if (d_evaluate(pc_new_nest) > v_population[i]->d_fitness)
	}//for (size_t i = 0; i < v_population.size(); i++)
}//void CBinaryCuckooOptimizer::v_levy_flight()

///////////////////////////////////////////////////////////////////////////////////////

CBinaryCuckooIndividual::CBinaryCuckooIndividual(uint16_t iGenotypeLength, double dLowerBound, double dUpperBound) :
	v_genotype(iGenotypeLength, static_cast<uint32_t>(0)),
	v_eggs(iGenotypeLength, 0.0)
{
	this->d_lower_bound = dLowerBound;
	this->d_upper_bound = dUpperBound;
}//CBinaryCuckooIndividual::CBinaryCuckooIndividual(uint16_t iGenotypeLength, double dLowerBound, double dUpperBound)

CBinaryCuckooIndividual::CBinaryCuckooIndividual(CBinaryCuckooIndividual * pcOther)
{
	this->d_fitness = pcOther->d_fitness;
	this->d_lower_bound = pcOther->d_lower_bound;
	this->d_upper_bound = pcOther->d_upper_bound;

	this->v_eggs = pcOther->v_eggs;
	this->v_genotype = pcOther->v_genotype;
}//CBinaryCuckooIndividual::CBinaryCuckooIndividual(CBinaryCuckooIndividual * pcOther)

CBinaryCuckooIndividual * CBinaryCuckooIndividual::pcGetRandomIndividual(uint16_t iGenotypeLength, double dLowerBound, double dUpperBound, uniform_real_distribution<double>& cIndividualDistribution, default_random_engine & cRandomEngine)
{
	CBinaryCuckooIndividual* pc_individual = new CBinaryCuckooIndividual(iGenotypeLength, dLowerBound, dUpperBound);

	for (uint16_t ii = 0; ii < iGenotypeLength; ii++)
	{
		pc_individual->v_eggs[ii] = cIndividualDistribution(cRandomEngine);
	}//for (uint16_t ii = 0; ii < iGenotypeLength; ii++)

	pc_individual->v_clip_to_bounds();
	pc_individual->vGenotypeProbing();

	return pc_individual;
}//CBinaryCuckooIndividual * CBinaryCuckooIndividual::pcGetRandomIndividual(uint16_t iGenotypeLength, double dLowerBound, double dUpperBound, uniform_real_distribution<double>& cIndividualDistribution, default_random_engine & cRandomEngine)

void CBinaryCuckooIndividual::vGenotypeProbing()
{
	for (size_t ii = 0; ii < v_eggs.size(); ii++)
	{
		if (v_eggs[ii] < 0.5) // TODO: probably should not look like this ;) but that is how it's done in original code
		{
			v_genotype[ii] = 0;
		}//if (v_eggs[ii] < 0.5)
		else 
		{
			v_genotype[ii] = 1;
		}//else if (v_eggs[ii] < 0.5)
	}//for (size_t ii = 0; ii < v_eggs.size(); ii++)
}//void CBinaryCuckooIndividual::vGenotypeProbing()

void CBinaryCuckooIndividual::v_clip_to_bounds()
{
	for (size_t ii = 0; ii < v_eggs.size(); ii++)
	{
		if (v_eggs[ii] < d_lower_bound)
		{
			v_eggs[ii] = d_lower_bound;
		}//if (v_eggs[ii] < d_lower_bound)
		else if (v_eggs[ii] > d_upper_bound)
		{
			v_eggs[ii] = d_upper_bound;
		}//if (v_eggs[ii] > d_upper_bound)
	}//for (size_t ii = 0; ii < v_eggs.size(); ii++)
}//void CBinaryCuckooIndividual::v_clip_to_bounds()
