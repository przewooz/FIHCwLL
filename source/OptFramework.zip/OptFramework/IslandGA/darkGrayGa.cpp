#include "darkGrayGa.h"



using  namespace nDarkGrayGA;



uint32_t CDarkGrayGA::iERROR_PARENT_CDarkGrayGA = CError::iADD_ERROR_PARENT("iERROR_PARENT_CDarkGrayGA");
uint32_t CDarkGrayGA::iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0");


uint32_t CDarkGrayGASinglePop::iERROR_PARENT_CDarkGrayGASinglePop = CError::iADD_ERROR_PARENT("iERROR_PARENT_CDarkGrayGASinglePop");
uint32_t CDarkGrayGASinglePop::iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0");



//---------------------------------------------CDarkGrayGA-------------------------------------------------------
CDarkGrayGA::CDarkGrayGA(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	i_pop_size = 0;
	pc_evaluation_individual = NULL;
	//pc_best = NULL;
	pc_best_pop = NULL;
	pc_dsm = new CDarkGA_DSM(this);
};//CDarkGrayGA::CDarkGrayGA(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



CDarkGrayGA::CDarkGrayGA(CDarkGrayGA *pcOther) : CBinaryOptimizer(pcOther)
{
	::Tools::vShow("NO IMPLEMENTATION: CDarkGrayGA::CDarkGrayGA(CDarkGrayGA *pcOther)");
}//CDarkGrayGA::CDarkGrayGA(CDarkGrayGASinglePop *pcOther) : CBinaryOptimizer(pcOther)



CDarkGrayGA::~CDarkGrayGA()
{
	//if (pc_best != NULL)  delete  pc_best;
	if (pc_best_pop != NULL)  delete  pc_best_pop;
	if (pc_dsm != NULL)  delete  pc_dsm;
	if (pc_base_pop != NULL)  delete  pc_base_pop;

}//CDarkGrayGA::~CDarkGrayGA()


void  CDarkGrayGA::vInitialize()
{
	c_time_counter.vSetStartNow();
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();
	
	i_next_pop_size = 2;

	pc_dsm->bSetSize(i_templ_length);

	if  (i_sett_perfect_linkage == 1)  pc_dsm->bGetTrueLinkage(pc_problem);

	pc_base_pop = new CDarkGrayGASinglePop(pc_problem, pc_log, i_random_seed, this);
	//pc_best = new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_base_pop);

	pc_best_pop = new CDarkGrayGASinglePop(pc_base_pop);
	pc_best_pop->vSetPopulationSize(1);
	pc_best_pop->vInitialize();
	pc_best_pop->pc_parent = this;

	//pc_dsm->bSave("zzzzz_dsm_test.txt");
	//vSavePopTest();
}//void  CDarkGrayGA::vInitialize(time_t tStartTime)


CDarkGrayGAIndividual  *CDarkGrayGA::pcGetBest()
{
	if  (pc_best_pop == NULL)  return(NULL);
	if (pc_best_pop->v_pop.size() == 0)  return(NULL);

	return(pc_best_pop->v_pop.at(0));
}//CDarkGrayGAIndividual  *CDarkGrayGA::pcGetBest()



void  CDarkGrayGA::vInsertToBestPop(CDarkGrayGASinglePop  *pcSinglePop)
{
	double  d_best_fitness;

	//int  i_best_pop_size_start, i_best_pop_size_end;
	
	//i_best_pop_size_start = pc_best_pop->v_pop.size();
	d_best_fitness = pcSinglePop->pcGetBest()->dComputeFitness();

	for (int ii = 0; ii < pcSinglePop->v_pop.size(); ii++)
	{
		if (pcSinglePop->v_pop.at(ii)->dComputeFitness() >= d_best_fitness)
		{
			vInsertToBestPop(pcSinglePop->v_pop.at(ii));
		}//if (pcSinglePop->v_pop.at(ii)->dComputeFitness() == d_best_fitness)
	}//for (int ii = 0; ii < pcSinglePop->v_pop.size(); ii++)

	//i_best_pop_size_end = pc_best_pop->v_pop.size();

}//void  CDarkGrayGA::vInsertToBestPop(CDarkGrayGASinglePop  *pcSinglePop)



void  CDarkGrayGA::vInsertToBestPop(CDarkGrayGAIndividual  *pcNewInd)
{
	if (pc_best_pop->v_pop.at(0)->dComputeFitness() == pcNewInd->dComputeFitness())
	{
		for (int ii = 0; ii < pc_best_pop->v_pop.size(); ii++)
		{
			if (pc_best_pop->v_pop.at(ii)->bIsTheSame(pcNewInd) == true)  return;
		}//for (int ii = 0; ii < pc_best_pop->v_pop.size(); ii++)

		int  i_ind_to_replace_offset;
		if (
			( (i_sett_global_number_limit == 0) &&(pc_best_pop->v_pop.size() < v_pop_running.at(v_pop_running.size() - 1)->v_pop.size()) )
			||
			(pc_best_pop->v_pop.size() < i_sett_global_number_limit)
			)
		{
			pc_best_pop->v_pop.push_back(new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_best_pop));
			i_ind_to_replace_offset = pc_best_pop->v_pop.size() - 1;
		}//if ((i_sett_global_number_limit < 0) || (pc_best_pop->v_pop.size() < i_sett_global_number_limit))
		else
			i_ind_to_replace_offset = ::RandUtils::iRandNumber(0, pc_best_pop->v_pop.size() - 1);

		pc_best_pop->v_pop.at(i_ind_to_replace_offset)->vCopyFrom(pcNewInd);		
		pc_best_pop->vSetPopulationSize(pc_best_pop->v_pop.size());
	}//if (pc_best_pop->v_pop.at(0)->dComputeFitness() == pcNewInd->dComputeFitness())

	if (pc_best_pop->v_pop.at(0)->dComputeFitness() < pcNewInd->dComputeFitness())
	{
		pc_best_pop->vSetPopulationSize(1);
		pc_best_pop->v_pop.at(0)->vCopyFrom(pcNewInd);

		for (int ii = 1; ii < pc_best_pop->v_pop.size(); ii++)
			delete  pc_best_pop->v_pop.at(ii);
		while (pc_best_pop->v_pop.size() > 1)
			pc_best_pop->v_pop.erase(pc_best_pop->v_pop.begin() + pc_best_pop->v_pop.size() - 1);

		for (int ii = 1; ii < pc_best_pop->v_pop_copy.size(); ii++)
			delete  pc_best_pop->v_pop_copy.at(ii);
		while (pc_best_pop->v_pop_copy.size() > 1)
			pc_best_pop->v_pop_copy.erase(pc_best_pop->v_pop_copy.begin() + pc_best_pop->v_pop_copy.size() - 1);
	}//if (pc_best_pop->v_pop.at(0)->dComputeFitness() < pcNewInd->dComputeFitness())
}//CDarkGrayGA::vInsertToBestPop(CDarkGrayGAIndividual  *pcNewInd)






CError CDarkGrayGA::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA);


	c_err = COptimizer::eConfigure(psSettings);

	CUIntCommandParam p_pop_scheme(s_OPTIMIZER_DARK_GA_POP_SCHEME);
	i_sett_pop_scheme = p_pop_scheme.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	CUIntCommandParam p_perfect_linkage(s_OPTIMIZER_DARK_GA_PERFECT_LINKAGE);
	i_sett_perfect_linkage = p_perfect_linkage.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_donor_improvement(s_OPTIMIZER_DARK_GA_DONOR_IMPROVEMENT);
	i_sett_donor_improvement = p_donor_improvement.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	CUIntCommandParam p_global_best_improvement(s_OPTIMIZER_DARK_GA_GLOBAL_BEST_IMPROVEMENT);
	i_sett_global_best_improvement = p_global_best_improvement.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	CUIntCommandParam p_global_number_limit(s_OPTIMIZER_DARK_GA_GLOBAL_BEST_LIMIT);
	i_sett_global_number_limit = p_global_number_limit.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_global_best_pop_run(s_OPTIMIZER_DARK_GA_GLOBAL_BEST_POP_RUN);
	i_sett_global_best_pop_run = p_global_best_pop_run.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_uniform_crossover_for_slide(s_OPTIMIZER_DARK_GA_UNIFORM_CROSSOVER_FOR_SLIDE);
	i_sett_uniform_crossover_for_slide = p_uniform_crossover_for_slide.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	
	return c_err;
};//CError CDarkGrayGA::eConfigure(istream *psSettings)




bool CDarkGrayGA::bRunIteration(uint32_t iIterationNumber)
{
	if  (i_sett_pop_scheme == 0)  return(bRunIteration_P3(iIterationNumber));
	if (i_sett_pop_scheme == 1)  return(bRunIteration_sGA(iIterationNumber));
	return(false);
	//return(bRunIteration_sGA(iIterationNumber, tStartTime));
}//bool CDarkGrayGA::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



bool CDarkGrayGA::b_p3_the_same_exists(CDarkGrayGAIndividual  *pcIndToAdd)
{
	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
	{
		for (int i_ind = 0; i_ind < v_pyramid.at(i_lev)->v_pop.size(); i_ind++)
		{
			if (v_pyramid.at(i_lev)->v_pop.at(i_ind)->bIsTheSame(pcIndToAdd))  return(false);
		}//for (int i_ind = 0; i_ind < v_pyramid.at(i_lev)->v_pop.size(); i_ind++)
	}//for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
	return(true);
}//bool CDarkGrayGA::b_p3_the_same_exists(CDarkGrayGAIndividual  *pcIndToAdd)

bool CDarkGrayGA::b_p3_add_to_level(int iLevel, CDarkGrayGAIndividual  *pcIndToAdd)
{
	while (v_pyramid.size() <= iLevel)
	{
		CDarkGrayGASinglePop  *pc_new_pop;

		pc_new_pop = new CDarkGrayGASinglePop(pc_base_pop);
		pc_new_pop->vSetPopulationSize(0);
		pc_new_pop->vInitialize();
		pc_new_pop->pc_parent = this;

		v_pyramid.push_back(pc_new_pop);
	}//while (v_pyramid.size() <= iLevel)


	if (b_p3_the_same_exists(pcIndToAdd) == false)  return(false);

	pcIndToAdd->pc_parent = v_pyramid.at(iLevel);
	v_pyramid.at(iLevel)->v_pop.push_back(pcIndToAdd);
	return(true);
}//void CDarkGrayGA::v_p3_add_to_level(int iLevel, CDarkGrayGAIndividual*pcIndToAdd)



int  CDarkGrayGA::iGetPopLevel(CDarkGrayGASinglePop  *pcPopToCheck)
{
	for (int ii = 0; ii < v_pyramid.size(); ii++)
	{
		if (v_pyramid.at(ii) == pcPopToCheck)  return(ii);
	}//for (int ii = 0; ii < v_pyramid.size(); ii++)

	return(-1);
}//int  CDarkGrayGA::iGetPopLevel(CDarkGrayGASinglePop  *pcPopToCheck)


int  CDarkGrayGA::iP3GetPyramidIndNumber()
{
	int  i_result = 0;

	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
		i_result += v_pyramid.at(i_lev)->v_pop.size();

	return(i_result);
}//int  CDarkGrayGA::iP3GetPyramidIndNumber()


bool CDarkGrayGA::bRunIteration_P3(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();

	bool  b_print = false;
	if (iIterationNumber % 100 == 0)  b_print = true;



	CDarkGrayGAIndividual  *pc_climber, *pc_copy;
	pc_climber = new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_base_pop);
	pc_climber->vRandomizeGenotype();
	pc_climber->dComputeFitnessOptimize(NULL);

	pc_copy = new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_base_pop);
	pc_copy->vCopyFrom(pc_climber);

	b_p3_add_to_level(0, pc_copy);


	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
	{
		if (v_pyramid.at(i_lev)->iDonateToIndividual_PxByLen(pc_climber, b_print) == 1)
		{
			pc_copy = new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_base_pop);
			pc_copy->vCopyFrom(pc_climber);

			if (b_p3_add_to_level(i_lev + 1, pc_copy) == false)  delete  pc_copy;

		}//if (v_pyramid.at(i_lev)->bDonateToIndividual_PxByLen(pc_climber) == true)
	}//for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)


	if (pcGetBest()->dComputeFitness() < pc_climber->dComputeFitness())
	{
		vInsertToBestPop(pc_climber);
		//pc_best->vCopyFrom(pc_climber);
		b_print = true;
	}//if (pc_best->dComputeFitness() < pc_climber->dComputeFitness())
	

	
	/*bool  i_donated = 1;
	while (i_donated > 0)
	{
		i_donated = 0;

		for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)
		{
			if (v_pop_running.at(i_pop)->bDonateToIndividual_PxByLen(pc_best) == true)  i_donated = 2;
		}//for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)

		if (i_donated == 2)
		{
			for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
			{
				if (v_pops_obsolete.at(i_pop_obs)->bDonateToIndividual_PxByLen(pc_best) == true)  i_donated = 2;
			}//for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
		}//if (i_donated == 2)

	}//if (b_donated == true)*/





	bool b_updated = b_update_best_individual(iIterationNumber, pcGetBest()->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pcGetBest()->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"pyramid: %d  PyrInds: %d  best: %.8lf  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf] [%diterations]",
		v_pyramid.size(), iP3GetPyramidIndNumber(), pcGetBest()->dComputeFitness(),
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE(), iIterationNumber
	);

	if (b_print)
	{
		pc_log->vPrintLine(s_buf, true);
		pc_log->vPrintLine("", true);
	}//if (b_print)
	


	return(true);
}//bool CDarkGrayGA::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



void  CDarkGrayGA::v_global_best_pop_run()
{
	CString  s_buf;

	double  d_fit_start, d_fit_end;

	d_fit_start = pc_best_pop->pcGetBest()->dComputeFitness();
	pc_log->vPrintLine("BEST POP run:", true);
	pc_best_pop->bRunIteration_sGA(1);
	d_fit_end = pc_best_pop->pcGetBest()->dComputeFitness();
	   	
	if (d_fit_start < d_fit_end)
	{
		s_buf.Format("BEST POP RUN SUCC: %.8lf -> %.8lf", d_fit_start, d_fit_end);
		pc_log->vPrintLine(s_buf, true);
		pc_log->vPrintLine("", true);

		vInsertToBestPop(pc_best_pop->pcGetBest());
	}//if (d_fit_start < d_fit_end)

}//void  CDarkGrayGA::v_global_best_pop_run()


void CDarkGrayGA::v_global_best_improvement()
{
	CString  s_buf;

	bool  i_donated = 1;
	double  d_best_fit_start, d_best_fit_end;
	int  i_epx_res;
	CDarkGrayGAIndividual *pc_ind_buffer;
	CDarkGrayGAIndividual *pc_best_current;

	while (i_donated > 0)
	{
		i_donated = 0;

		for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)
		{
			for (int i_best_pop_ind = 0; i_best_pop_ind < pc_best_pop->v_pop.size(); i_best_pop_ind++)
			{
				pc_best_current = pc_best_pop->v_pop.at(i_best_pop_ind);

				d_best_fit_start = pc_best_current->dComputeFitness();
				if (v_pop_running.at(i_pop)->pc_individual_buffer == NULL)  v_pop_running.at(i_pop)->pc_individual_buffer = new CDarkGrayGAIndividual(i_templ_length, pc_problem, v_pop_running.at(i_pop));
				pc_ind_buffer = v_pop_running.at(i_pop)->pc_individual_buffer;
				pc_ind_buffer->vCopyFrom(pc_best_current);

				i_epx_res = pc_best_current->iMixing_ePX_ByMaskLen(&(v_pop_running.at(i_pop)->v_pop), pc_ind_buffer);
				if (i_epx_res > 0)
				{
					vInsertToBestPop(pc_ind_buffer);
					d_best_fit_end = pcGetBest()->dComputeFitness();
					i_donated = 1;

					s_buf.Format
					(
						"GLOBAL BEST DONATED %.8lf -> %.8lf  BestPopSize:%d   donatorPopSize: %d",
						d_best_fit_start, d_best_fit_end,
						pc_best_pop->v_pop.size(), 
						v_pop_running.at(i_pop)->v_pop.size()
					);
					pc_log->vPrintLine(s_buf, true);
					pc_log->vPrintLine("", true);
				}//if (i_epx_buf > 0)

				//we slide
				if (i_epx_res == 0)
				{
					vInsertToBestPop(pc_ind_buffer);
					d_best_fit_end = pcGetBest()->dComputeFitness();

					s_buf.Format
					(
						"Global best SLIDED %.8lf -> %.8lf  BestPopSize:%d   donatorPopSize: %d",
						d_best_fit_start, d_best_fit_end,
						pc_best_pop->v_pop.size(),
						v_pop_running.at(i_pop)->v_pop.size()
					);
					pc_log->vPrintLine(s_buf, true);
					pc_log->vPrintLine("", true);

					//::Tools::vShow("Best SLIDE!!!!!");
				}//if (i_epx_buf > 0)
			}//for (int i_best_pop_ind = 0; i_best_pop_ind < pc_best_pop->v_pop.size(); i_best_pop_ind++)
		}//for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)

		//if (i_donated == 2)
		//{
		//	for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
		//	{
		//		if (v_pops_obsolete.at(i_pop_obs)->bDonateToIndividual_PxByLen(pc_best) == true)  i_donated = 2;
		//	}//for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
		//}//if (i_donated == 2)

	}//if (b_donated == true)*/
}//bool CDarkGrayGA::v_global_best_improvement()




bool CDarkGrayGA::bRunIteration_sGA(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();



	if (v_pop_running.size() == 0)
	{
		CDarkGrayGASinglePop  *pc_new_pop;

		pc_new_pop = new CDarkGrayGASinglePop(pc_base_pop);
		pc_new_pop->vSetPopulationSize(i_next_pop_size);
		i_next_pop_size = i_next_pop_size * 2;
		pc_new_pop->vInitialize();
		pc_new_pop->pc_parent = this;

		v_pop_running.push_back(pc_new_pop);
	}//if (v_pop_running.size() == 0)


	
	for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)
	{
		v_pop_running.at(i_pop)->bRunIteration_sGA(iIterationNumber);
		//if (pc_best->dComputeFitness() < v_pop_running.at(i_pop)->pcGetBest()->dComputeFitness())  pc_best->vCopyFrom(v_pop_running.at(i_pop)->pcGetBest());
		if (pcGetBest()->dComputeFitness() < v_pop_running.at(i_pop)->pcGetBest()->dComputeFitness())  vInsertToBestPop(v_pop_running.at(i_pop));

		if (v_pop_running.at(i_pop)->bIsSteadyState() == true)
		{
			v_pops_obsolete.push_back(v_pop_running.at(i_pop));
			v_pop_running.erase(v_pop_running.begin() + i_pop);
		}//if (v_pop_running.at(i_pop)->bIsSteadyState() == true)
	}//for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)


	if  (i_sett_global_best_improvement == 1)  v_global_best_improvement();

	if  (i_sett_global_best_pop_run == 1)  v_global_best_pop_run();


	
	bool b_updated = b_update_best_individual(iIterationNumber, pcGetBest()->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pcGetBest()->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"pops: %d  runningPops: %d  best: %.8lf (bestPopSize:%d)  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pops_obsolete.size() + v_pop_running.size(), v_pop_running.size(), pcGetBest()->dComputeFitness(), pc_best_pop->v_pop.size(),
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);
	pc_log->vPrintLine("", true);



	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGA::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



double CDarkGrayGA::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_compute_fitness_value(piBits);
	return(d_fitness_value);
}//double CDarkGrayGA::dComputeFitness(int32_t *piBits)



CString  CDarkGrayGA::sAdditionalSummaryInfo()
{
	CString  s_buf;

	return(s_buf);
};//CString  CDarkGrayGA::sAdditionalSummaryInfo() 



CString  CDarkGrayGA::sLinkageSummaryReport()
{
	CString  s_res;
	s_res = pc_dsm->sLinkageSummaryReport();
	return(s_res);
}//CString  CDarkGrayGA::sLinkageSummaryReport()

















//---------------------------------------------CDarkGrayGASinglePop-------------------------------------------------------
CDarkGrayGASinglePop::CDarkGrayGASinglePop(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed, CDarkGrayGA  *pcParent)
	: CPopulationSizingSingleOptimizer(pcProblem, pcLog, iRandomSeed)
{
	i_pop_size = 0;
	pc_evaluation_individual = NULL;
	pc_individual_buffer = NULL;
	pi_genotope_buffer_tool_0 = NULL;
	pi_genotope_buffer_tool_1 = NULL;

	pc_best = NULL;
	b_steady_state = false;

	pc_parent = pcParent;

	if (pc_parent == NULL)
		pc_dsm = new CDarkGA_DSM(pc_parent);
	else
		pc_dsm = pc_parent->pcGetDSM();

	pc_px_masks_manager = new CDarkGrayGAPxMaskManager();
};//CDarkGrayGASinglePop::CDarkGrayGASinglePop(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



CDarkGrayGASinglePop::CDarkGrayGASinglePop(CDarkGrayGASinglePop *pcOther) : CPopulationSizingSingleOptimizer(pcOther)
{
	pc_evaluation_individual = NULL;
	pc_individual_buffer = NULL;
	pi_genotope_buffer_tool_0 = NULL;
	pi_genotope_buffer_tool_1 = NULL;

	pc_best = NULL;
	pc_problem = pcOther->pc_problem;
	pc_log = pcOther->pc_log;
	b_steady_state = false;

	pc_parent = pcOther->pc_parent;
	if (pc_parent == NULL)
		pc_dsm = new CDarkGA_DSM(pc_parent);
	else
		pc_dsm = pc_parent->pcGetDSM();

	pc_px_masks_manager = new CDarkGrayGAPxMaskManager();
}//CDarkGrayGASinglePop::CDarkGrayGASinglePop(CDarkGrayGASinglePop *pcOther) : CBinaryOptimizer(pcOther)



CDarkGrayGASinglePop::~CDarkGrayGASinglePop()
{
	for (int ii = 0; ii < v_pop.size(); ii++)
		delete  v_pop.at(ii);

	for (int ii = 0; ii < v_pop_copy.size(); ii++)
		delete  v_pop_copy.at(ii);

	
	if (pc_evaluation_individual != NULL)  delete  pc_evaluation_individual;

	if (pc_best != NULL)  delete  pc_best;

	if (pi_genotope_buffer_tool_0 != NULL)  delete  pi_genotope_buffer_tool_0;
	if (pi_genotope_buffer_tool_1 != NULL)  delete  pi_genotope_buffer_tool_1;

	if (pc_parent == NULL)
	{
		if (pc_dsm != NULL)  delete  pc_dsm;
	}//if (pc_parent == NULL)

	if (pc_px_masks_manager != NULL)  delete  pc_px_masks_manager;
}//CDarkGrayGASinglePop::~CDarkGrayGASinglePop()


void  CDarkGrayGASinglePop::vInitialize()
{
	c_time_counter.vSetStartNow();
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();



	pc_best = new CDarkGrayGAIndividual(i_templ_length, pc_problem, this);
	pc_individual_buffer = new CDarkGrayGAIndividual(i_templ_length, pc_problem, this);
	pi_genotope_buffer_tool_0 = new int[i_templ_length];
	pi_genotope_buffer_tool_1 = new int[i_templ_length];

	i_slide_number = 0;

	//pc_dsm->bSetSize(i_templ_length);
	//pc_dsm->bGetTrueLinkage(pc_problem);
	//pc_dsm->bSave("zzzzz_dsm_test.txt");
	//vSavePopTest();


	CDarkGrayGAIndividual  *pc_indiv_new;
	while  (v_pop.size() < i_pop_size)
	{
		//int i_ffe_start, i_ffe_end;
		//i_ffe_start = pc_problem->pcGetEvaluation()->iGetFFE();

		pc_indiv_new = new CDarkGrayGAIndividual(i_templ_length, pc_problem, this);
		pc_indiv_new->vRandomizeGenotype();
		
		/*::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", "START: \n");
		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", pc_indiv_new->sToStr());
		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", "\n\n\n\n");*/

		//pc_indiv_new->dComputeFitness();
		pc_indiv_new->dComputeFitnessOptimize(NULL);
		//pc_indiv_new->dComputeFitnessOptimize(NULL, true);

		/*i_ffe_end = pc_problem->pcGetEvaluation()->iGetFFE();

		CString  s_buf;
		s_buf.Format("\n\n\n%d\n%d\n%d\n", i_ffe_start, i_ffe_end, i_ffe_end - i_ffe_start);

		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", s_buf);
		::Tools::vReportInFile("zzzzz_ind_opt_summ.txt", pc_indiv_new->sToStr());
		::Tools::vShow("zzzzz_ind_opt_darkGr.txt");//*/

		v_pop.push_back(pc_indiv_new);
	}//while  (v_pop.size() < i_pop_size)


	

	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();



	CString  s_buf;

	s_buf.Format
	(
		"INIT size: %d  best: %.8lf avr: %.8lf  [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	//pc_log->vPrintLine(s_buf, true);
}//void  CDarkGrayGASinglePop::vInitialize(time_t tStartTime)


void  CDarkGrayGASinglePop::vSavePopTest()
{
	FILE  *pf_dest;
	pf_dest = fopen("zzz_test_pop.txt", "w+");

	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		fprintf(pf_dest, "%s\n", v_pop.at(ii)->sToStr());
	}//for (int ii = 0; ii < i_pop_size; ii++)

	fclose(pf_dest);

	::Tools::vShow("void  CDarkGrayGA::vSavePopTest()");
}//void  CDarkGrayGASinglePop::vSavePopTest()



void  CDarkGrayGASinglePop::vCopyFrom(CDarkGrayGASinglePop *pcOther)
{
	i_pop_size = pcOther->i_pop_size;
	i_templ_length = pcOther->i_templ_length;

	v_pop.clear();
	for (size_t ii = 0; ii < pcOther->v_pop.size(); ii++)
	{
		if (pcOther->v_pop[ii] != nullptr)
		{
			v_pop.push_back(new CDarkGrayGAIndividual(*(pcOther->v_pop[ii])));
		}//if (pcOther->v_population[ii] != nullptr)
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void  CDarkGrayGASinglePop::vCopyForm(CDarkGrayGASinglePop *pcOther)



COptimizer<CBinaryCoding, CBinaryCoding> *CDarkGrayGASinglePop::pcCopy()
{
	CDarkGrayGASinglePop  *pc_res = new CDarkGrayGASinglePop(this);

	pc_res->vCopyFrom(this);

	return(pc_res);
}//COptimizer<CBinaryCoding, CBinaryCoding> *CDarkGrayGASinglePop::pcCopy()


bool CDarkGrayGASinglePop::bIsSteadyState()
{
	return(b_steady_state);
	//return(false);
}//bool CDarkGrayGASinglePop::bIsSteadyState()


double CDarkGrayGASinglePop::dComputeAverageFitnessValue()
{
	double  d_avr = 0;
	for (size_t ii = 0; ii < v_pop.size(); ii++)
	{
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (size_t ii = 0; ii < v_population.size(); ii++)

	return(d_avr / v_pop.size());
}//double CDarkGrayGASinglePop::dComputeAverageFitnessValue()



CError CDarkGrayGASinglePop::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_CDarkGrayGASinglePop);


	c_err = COptimizer::eConfigure(psSettings);


	CUIntCommandParam p_pop_size(OPTIMIZER_ARGUMENT_POP_SIZE);
	i_pop_size = p_pop_size.iGetValue(psSettings, &c_err);
	if (p_pop_size.bHasValue() == false)  i_pop_size = 0;
	if (c_err)  return(c_err);

	return c_err;
};//CError CDarkGrayGASinglePop::eConfigure(istream *psSettings)



bool CDarkGrayGASinglePop::bRunIterationForceCross(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGASinglePop);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();


	//save current individuals
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (v_pop_copy.size() <= ii)
			v_pop_copy.push_back(new CDarkGrayGAIndividual(i_templ_length, pc_problem, this));

		v_pop_copy.at(ii)->vCopyFrom(v_pop.at(ii));
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	i_uniform_donations = 0;

	for (int ii = 0; ii < v_pop.size(); ii++)//it must be v_pop.size() here because we assured that v_pop_next is at least of the size of v_pop
	{
		i_epx_buf = v_pop_copy.at(ii)->iMixing_ePX_ByDonor(&v_pop_copy, v_pop.at(ii));

		if (i_epx_buf > 0)
		{
			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();




	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	if (i_epx_succ == 0)  b_steady_state = true;//asdasd

	s_buf.Format
	(
		"size: %d  best: %.8lf avr: %.8lf  epx[SUCC/min/max]: %d/%d/%d  Uniform Donations: %d Slides:%d iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		i_epx_succ, i_epx_min, i_epx_max, i_uniform_donations, i_slide_number,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	if (b_steady_state == true)  s_buf += "   STEADY STATE";
	pc_log->vPrintLine(s_buf, true);

	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGASinglePop::bRunIterationForceCross(uint32_t iIterationNumber, time_t tStartTime)





bool CDarkGrayGASinglePop::bRunIteration_sGA(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGASinglePop);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();


	//save current individuals
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (v_pop_copy.size() <= ii)
			v_pop_copy.push_back(new CDarkGrayGAIndividual(i_templ_length, pc_problem, this));

		v_pop_copy.at(ii)->vCopyFrom(v_pop.at(ii));
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	i_uniform_donations = 0;

	for (int ii = 0; ii < v_pop.size(); ii++)//it must be v_pop.size() here because we assured that v_pop_next is at least of the size of v_pop
	{
		//i_epx_buf = v_pop_copy.at(ii)->iMixing_ePX_ByMaskLen(&v_pop_copy, v_pop.at(ii));
		i_epx_buf = iDonateToIndividual_PxByLen(v_pop_copy.at(ii), false);

		if (i_epx_buf > 0)
		{
			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	for (int ii = 0; ii < v_pop.size(); ii++)
		v_pop.at(ii)->vCopyFrom(v_pop_copy.at(ii));


	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();




	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	if (i_epx_succ == 0)  b_steady_state = true;//asdasd

	s_buf.Format
	(
		"size: %d  best: %.8lf avr: %.8lf  epx[SUCC/min/max]: %d/%d/%d  Uniform Donations: %d Slides:%d iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		i_epx_succ, i_epx_min, i_epx_max, i_uniform_donations, i_slide_number,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	if (b_steady_state == true)  s_buf += "   STEADY STATE";
	pc_log->vPrintLine(s_buf, true);

	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGASinglePop::bRunIteration_sGA(uint32_t iIterationNumber)





bool CDarkGrayGASinglePop::bRunIterationMaskLen(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGASinglePop);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();


	//save current individuals
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (v_pop_copy.size() <= ii)
			v_pop_copy.push_back(new CDarkGrayGAIndividual(i_templ_length, pc_problem, this));

		v_pop_copy.at(ii)->vCopyFrom(v_pop.at(ii));
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	i_uniform_donations = 0;

	for (int ii = 0; ii < v_pop.size(); ii++)//it must be v_pop.size() here because we assured that v_pop_next is at least of the size of v_pop
	{
		i_epx_buf = v_pop_copy.at(ii)->iMixing_ePX_ByMaskLen(&v_pop_copy, v_pop.at(ii));

		if (i_epx_buf > 0)
		{
			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();




	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	if (i_epx_succ == 0)  b_steady_state = true;//asdasd

	s_buf.Format
	(
		"size: %d  best: %.8lf avr: %.8lf  epx[SUCC/min/max]: %d/%d/%d  Uniform Donations: %d Slides:%d iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		i_epx_succ, i_epx_min, i_epx_max, i_uniform_donations, i_slide_number,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	if (b_steady_state == true)  s_buf += "   STEADY STATE";
	pc_log->vPrintLine(s_buf, true);

	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGASinglePop::bRunIterationForceCross(uint32_t iIterationNumber, time_t tStartTime)





bool CDarkGrayGASinglePop::bRunIteration(uint32_t iIterationNumber)
{
	return(bRunIterationMaskLen(iIterationNumber));
	return(bRunIterationForceCross(iIterationNumber));

	CError c_err(iERROR_PARENT_CDarkGrayGASinglePop);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();


	//save current individuals
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (v_pop_copy.size() <= ii)
			v_pop_copy.push_back(new CDarkGrayGAIndividual(i_templ_length, pc_problem, this));

		v_pop_copy.at(ii)->vCopyFrom(v_pop.at(ii));
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)//it must be v_pop.size() here because we assured that v_pop_next is at least of the size of v_pop
	{
		i_epx_buf = v_pop_copy.at(ii)->iMixing_ePX_ByDonor(&v_pop_copy, v_pop.at(ii));
		
		if (i_epx_buf > 0)
		{
			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();

	


	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	if (i_epx_succ == 0)  b_steady_state = true;

	s_buf.Format
	(
		"size: %d  best: %.8lf avr: %.8lf  epx[SUCC/min/max]: %d/%d/%d  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr, 
		i_epx_succ, i_epx_min, i_epx_max,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	if (b_steady_state == true)  s_buf += "   STEADY STATE";
	pc_log->vPrintLine(s_buf, true); 



	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGASinglePop::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)




int  CDarkGrayGASinglePop::iDonateToIndividual_PxByLen(CDarkGrayGAIndividual  *pcReceiver, bool bPrint)
{
	double  d_fitness_start, d_fitness_end;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();

	d_fitness_start = pcReceiver->dComputeFitness();


	if (pc_individual_buffer == NULL)  pc_individual_buffer = new CDarkGrayGAIndividual(i_templ_length, pc_problem, this);


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;


	i_epx_buf = pcReceiver->iMixing_ePX_ByMaskLen(&v_pop, pc_individual_buffer);
	if (i_epx_buf > 0)
	{
		pcReceiver->vCopyFrom(pc_individual_buffer);

		i_epx_succ++;
		if (i_epx_min < 0)  i_epx_min = i_epx_buf;
		if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
		if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;

		return(1);
	}//if (i_epx_buf > 0)

	//we slide
	if (i_epx_buf == 0)
	{
		pcReceiver->vCopyFrom(pc_individual_buffer);

		i_slide_number++;
		if (i_epx_min < 0)  i_epx_min = i_epx_buf;
		if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
		if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;

		return(0);
	}//if (i_epx_buf > 0)


	/*d_fitness_end = pcReceiver->dComputeFitness();


	CString  s_buf, s_change;
	if (d_fitness_start < d_fitness_end)  s_change = "CHANGE!!!";


	s_buf.Format
	(
		"Donate toindividual PxByLen: size: %d  %s: %.8lf -> %.8lf      epx[SUCC/min/max]: %d/%d/%d  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(),
		s_change,
		d_fitness_start, d_fitness_end,
		i_epx_succ, i_epx_min, i_epx_max,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);

	if  (bPrint == true)  pc_log->vPrintLine(s_buf, true);*/

	return(-1);
}//bool  CDarkGrayGASinglePop::bDonateToIndividual(CDarkGrayGAIndividual  *pcReceiver)


bool  CDarkGrayGASinglePop::bDonateToIndividual(CDarkGrayGAIndividual  *pcReceiver)
{
	double  d_fitness_start, d_fitness_end;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();

	d_fitness_start = pcReceiver->dComputeFitness();


	if (pc_individual_buffer == NULL)  pc_individual_buffer = new CDarkGrayGAIndividual(i_templ_length, pc_problem, this);
	

	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;

	i_epx_buf = 1;
	while  (i_epx_buf > 0)
	{
		i_epx_buf = pcReceiver->iMixing_ePX_ByDonor(&v_pop, pc_individual_buffer);

		if (i_epx_buf > 0)
		{
			pcReceiver->vCopyFrom(pc_individual_buffer);

			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
		else
		{

		}//else if (i_epx_buf > 0)
	}//while  (i_epx_succ  == 1)


	d_fitness_end = pcReceiver->dComputeFitness();


	CString  s_buf, s_change;
	if (d_fitness_start < d_fitness_end)  s_change = "CHANGE!!!";

	
	s_buf.Format
	(
		"Donate toindividual: size: %d  %s: %.8lf -> %.8lf      epx[SUCC/min/max]: %d/%d/%d  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(),
		s_change,
		d_fitness_start, d_fitness_end,
		i_epx_succ, i_epx_min, i_epx_max,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);

	if  (i_epx_succ  > 0)  return(true);

	return(false);
}//bool  CDarkGrayGASinglePop::bDonateToIndividual(CDarkGrayGAIndividual  *pcReceiver)



void  CDarkGrayGASinglePop::vGetGenotypeBufferTools(int  **piTool_0, int  **piTool_1)
{
	if (pi_genotope_buffer_tool_0 == NULL)  pi_genotope_buffer_tool_0 = new int[i_templ_length];
	if (pi_genotope_buffer_tool_1 == NULL)  pi_genotope_buffer_tool_1 = new int[i_templ_length];
	
	*piTool_0 = pi_genotope_buffer_tool_0;
	*piTool_1 = pi_genotope_buffer_tool_1;
}//int  *CDarkGrayGASinglePop::piGetGenotypeBufferTool()


double CDarkGrayGASinglePop::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_evaluate(piBits);
	return(d_fitness_value);
}//double CDarkGrayGASinglePop::dComputeFitness(int32_t *piBits)


double CDarkGrayGASinglePop::dComputeFitnessDouble(int32_t *piBits)
{
	double d_fitness_value = d_evaluate_double(piBits);
	return(d_fitness_value);
}//double CDarkGrayGASinglePop::dComputeFitness(int32_t *piBits)




double CDarkGrayGASinglePop::d_evaluate(int32_t *piBits)
{
	if (pc_evaluation_individual == NULL)
	{
		pc_evaluation_individual = new CIndividual<CBinaryCoding, CBinaryCoding>(new CBinaryCoding(pc_problem->pcGetEvaluation()->iGetNumberOfElements(), nullptr), pc_problem->pcGetEvaluation(), nullptr, nullptr, pc_problem->pcGetTransformation());
	}//if (pc_evaluation_tool == NULL)
		
	pc_evaluation_individual->pcGetGenotype()->vSetBits(piBits);
	pc_evaluation_individual->vIsEvaluated(false);
	pc_evaluation_individual->vEvaluate();

	return pc_evaluation_individual->dGetFitnessValue();
}//double CDarkGrayGASinglePop::d_evaluate(CBinaryPSOIndividual * pc_individual)



double CDarkGrayGASinglePop::d_evaluate_double(int32_t *piBits)
{
	if (pc_evaluation_individual == NULL)
	{
		pc_evaluation_individual = new CIndividual<CBinaryCoding, CBinaryCoding>(new CBinaryCoding(pc_problem->pcGetEvaluation()->iGetNumberOfElements(), nullptr), pc_problem->pcGetEvaluation(), nullptr, nullptr, pc_problem->pcGetTransformation());
	}//if (pc_evaluation_tool == NULL)

	pc_evaluation_individual->pcGetGenotype()->vSetBits(piBits);
	pc_evaluation_individual->vIsEvaluated(false);
	pc_evaluation_individual->vEvaluateDouble();

	return pc_evaluation_individual->dGetFitnessValue();
}//double CDarkGrayGASinglePop::d_evaluate(CBinaryPSOIndividual * pc_individual)






CString  CDarkGrayGASinglePop::sAdditionalSummaryInfo()
{
	CString  s_buf;

	return(s_buf);
};//CString  CDarkGrayGASinglePop::sAdditionalSummaryInfo() 





//---------------------------------------------CDarkGA_DSM-------------------------------------------------------

CDarkGA_DSM::CDarkGA_DSM(CDarkGrayGA  *pcParent)
{
	pi_dsm = NULL;
	i_prob_size = -1;
	pc_individual_tool = NULL;

	i_cost_ffe = 0;
	d_cost_time = 0;

	pc_parent = pcParent;
}//CDarkGA_DSM::CDarkGA_DSM(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem)


CDarkGA_DSM::~CDarkGA_DSM()
{
	if (pi_dsm != NULL)
	{
		for (int ii = 0; ii < i_prob_size; ii++)
			delete  pi_dsm[ii];
		delete  pi_dsm;
	}//if (pi_dsm != NULL)

	if (pc_individual_tool != NULL)  delete  pc_individual_tool;
}//CDarkGA_DSM::CDarkGA_DSM(int  iProblemSize)


bool  CDarkGA_DSM::bSetSize(int  iProbSize)
{
	if (i_prob_size > 0)  return(false);

	i_prob_size = iProbSize;
	pi_dsm = new int*[i_prob_size];
	for (int ii = 0; ii < i_prob_size; ii++)
		pi_dsm[ii] = new int[i_prob_size];

	for (int iy = 0; iy < i_prob_size; iy++)
	{
		for (int ix = 0; ix < i_prob_size; ix++)
			pi_dsm[ix][iy] = 0;
	}//for (int iy = 0; iy < i_prob_size; iy++)
		

	return(true);
}//bool  CDarkGA_DSM::bSetSize(int  iProbSize)



bool  CDarkGA_DSM::bSave(CString  sDest)
{
	FILE  *pf_dest;

	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return(false);
	bSave(pf_dest);
	fclose(pf_dest);

	return(true);
}//bool  CDarkGA_DSM::bSave(CString  sDest)


bool  CDarkGA_DSM::bSave(FILE  *pfDest)
{
	CString  s_line, s_buf;

	s_line = " \t ";
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		s_buf.Format("%d\t", ii);
		s_line += s_buf;
	}//for (int ii = 0; ii < i_prob_size; ii++)
	s_line += "\n";
	fprintf(pfDest, s_line);

	for (int iy = 0; iy < i_prob_size; iy++)
	{
		s_line.Format("%d\t", iy);
		for (int ix = 0; ix < i_prob_size; ix++)
		{
			s_buf.Format("%d\t", pi_dsm[ix][iy]);
			s_line += s_buf;
		}//for (int ix = 0; ix < i_prob_size; ix++)
		s_line += "\n";
		fprintf(pfDest, s_line);
	}//for (int iy = 0; iy < i_prob_size; iy++)
}//bool  CDarkGA_DSM::bSave(FILE  *pfDest)



bool  CDarkGA_DSM::bGetTrueLinkage(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem)
{
	vector<vector <int>>  v_dependent_genes;
	pcProblem->vGetTrueGeneDependencies(&v_dependent_genes);


	CString  s_line, s_buf;
	FILE  *pf_test;
	/*pf_test = fopen("zzzz_trueLink.txt", "w+");
	for (int i_set = 0; i_set < v_dependent_genes.size(); i_set++)
	{
		s_line.Format("[%d]:", i_set);
		for (int i_off = 0; i_off < v_dependent_genes.at(i_set).size(); i_off++)
		{
			s_buf.Format("%d, ", v_dependent_genes.at(i_set).at(i_off));
			s_line += s_buf;
		}//for (int i_off = 0; i_off < v_dependent_genes.at(i_set).size(); i_off++)

		s_line += "\n";
		fprintf(pf_test, s_line);
	}//for (int ii = 0; ii < v_dependent_genes.size(); ii++)
	fclose(pf_test);//*/


	for (int i_gene_this = 0; i_gene_this < v_dependent_genes.size(); i_gene_this++)
	{
		for (int i_gene_other_offset = 0; i_gene_other_offset < v_dependent_genes.at(i_gene_this).size(); i_gene_other_offset++)
		{
			pi_dsm[i_gene_this][v_dependent_genes.at(i_gene_this).at(i_gene_other_offset)] = 1;
		}//for (int i_gene_other = 0; i_gene_other < v_dependent_genes.at(i_gene_this).size(); i_gene_other++)
	}//for (int i_gene = 0; i_gene < v_dependent_genes.size(); i_gene++)

	//bSave("zzzz_true_dsm.txt");
	//::Tools::vShow("trueLink");

		

	return(true);
}//bool  CDarkGA_DSM::bGetTrueLinkage(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem)


CString  CDarkGA_DSM::sLinkageSummaryReport()
{
	vector<vector <int>>  v_dependent_genes;
	pc_parent->pc_problem->vGetTrueGeneDependencies(&v_dependent_genes);
	if (v_dependent_genes.size() == 0)  return("");

	int  i_cur_fill;
	double  d_fill_perc_cur, d_fill_perc_min, d_fill_perc_max, d_fill_perc_avr;
	int  i_true_dependent_genes;
	for (int i_gene = 0; i_gene < i_prob_size; i_gene++)
	{
		i_cur_fill = 0;
		
		for (int i_other = 0; i_other < i_prob_size; i_other++)
		{
			if (i_gene != i_other)
			{
				if (pi_dsm[i_gene][i_other] > 0)  i_cur_fill++;
			}//if (i_gene != i_other)
		}//for (int i_other = 0; i_other < i_prob_size; i_other++)

		i_true_dependent_genes = 0;
		for (int ii = 0; ii < v_dependent_genes.at(i_gene).size(); ii++)
		{
			if (v_dependent_genes.at(i_gene).at(ii) != i_gene)  i_true_dependent_genes++;
		}//for (int ii = 0; ii < v_dependent_genes.at(i_gene).size(); ii++)


		

		d_fill_perc_cur = i_cur_fill;
		if (v_dependent_genes.at(i_gene).size() > 0)
			d_fill_perc_cur = d_fill_perc_cur / i_true_dependent_genes;
		else
			d_fill_perc_cur = 1;

		if (i_gene == 0)
		{
			d_fill_perc_min = d_fill_perc_cur;
			d_fill_perc_max = d_fill_perc_cur;
			d_fill_perc_avr = d_fill_perc_cur;
		}//if (i_gene == 0)
		else
		{
			if (d_fill_perc_cur < d_fill_perc_min)  d_fill_perc_min = d_fill_perc_cur;
			if (d_fill_perc_cur > d_fill_perc_max)  d_fill_perc_max = d_fill_perc_cur;
			d_fill_perc_avr += d_fill_perc_cur;
		}//else  if (i_gene == 0)
	}//for (int i_gene = 0; i_gene < i_prob_size; i_gene++)

	d_fill_perc_avr = d_fill_perc_avr / i_prob_size;

	CString  s_res;
	s_res.Format
		(
			"\t%s\t%.8lf\t%s\t%.8lf\t%s\t%.8lf\t%s\t%.2lf\t%s\t%d", 
			OPT_LINK_QUALITY_FILL_MIN, d_fill_perc_min, OPT_LINK_QUALITY_FILL_MAX, d_fill_perc_max, OPT_LINK_QUALITY_FILL_AVR, d_fill_perc_avr, 
			OPT_LINK_COST_TIME, d_cost_time, OPT_LINK_COST_FFE, i_cost_ffe
		);
	return(s_res);
}//CString  CDarkGA_DSM::sLinkageSummaryReport()



void  CDarkGA_DSM::vDarkGrayMapDependentGenes(int  iGeneOffset, int  *piMask)
{
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		if ((pi_dsm[iGeneOffset][ii] > 0) && (iGeneOffset != ii))
		{
			piMask[ii] = 1;
		}//if ((pi_dsm[iGeneOffset][ii] > 0) && (iGeneOffset != ii))
	}//for (int ii = 0; ii < i_prob_size; ii++)

}//void  CDarkGA_DSM::vDarkGrayMapDependentGenes(int  iGeneOffset, int  *piMask)



void  CDarkGA_DSM::vUpdateDSM(CDarkGrayGAPxMask  *pcMask)
{
	CString  s_buf;

	int  i_ffe_start, i_ffe_end;
	double  d_time_spent;

	CTimeCounter  c_timer_local;
	i_ffe_start = pc_parent->pcGetProblem()->pcGetEvaluation()->iGetFFE();
	c_timer_local.vSetStartNow();

	int  *pi_dled_extraction_mask;
	pi_dled_extraction_mask = new int[i_prob_size];

	for (int ii = 0; ii < i_prob_size; ii++)
		pi_dled_extraction_mask[ii] = 2;//2->the context gene to check

	for (int i_mask_off = 0; i_mask_off < pcMask->v_mask.size(); i_mask_off++)
		pi_dled_extraction_mask[pcMask->v_mask.at(i_mask_off)] = 1;//1->the gene from the mask (block gene)

	for (int ii = 0; ii < i_prob_size; ii++)
	{
		if  (pcMask->pc_parent_0->piGetGenotype()[ii] == pcMask->pc_parent_1->piGetGenotype()[ii])  pi_dled_extraction_mask[ii] = -1;
	}//for (int ii = 0; ii < i_prob_size; ii++)

	
	int  i_new_pairs_detected = 0;
	for (int i_gene_context = 0; i_gene_context < i_prob_size; i_gene_context++)
	{
		for (int i_gene_block = 0; i_gene_block < i_prob_size; i_gene_block++)
		{
			if ((pi_dled_extraction_mask[i_gene_context] == 2) && (pi_dled_extraction_mask[i_gene_block] == 1))
			{
				v_extract_dled_for_gene_pair(i_gene_block, i_gene_context, pi_dled_extraction_mask, pcMask->pc_parent_0, &i_new_pairs_detected);
				v_extract_dled_for_gene_pair(i_gene_block, i_gene_context, pi_dled_extraction_mask, pcMask->pc_parent_1, &i_new_pairs_detected);
			}//if ((pi_dled_extraction_mask[i_gene_context] == 2) && (pi_dled_extraction_mask[i_gene_block] == 1))
		}//for (int i_gene_block = 0; i_gene_block < i_prob_size; i_gene_block++)
	}//for (int i_context_gene = 0; i_context_gene < i_prob_size; i_context_gene++)

	i_ffe_end = pc_parent->pcGetProblem()->pcGetEvaluation()->iGetFFE();
	d_time_spent = c_timer_local.dGetTimePassed();

	d_cost_time += d_time_spent;
	i_cost_ffe += (i_ffe_end - i_ffe_start);

	delete  pi_dled_extraction_mask;

	//bSave("zzz_dsm_afeter.txt");
	//::Tools::vShow("zzz_dsm_afeter.txt");


	CString  s_dled_cost_report;
	s_dled_cost_report.Format("DSM update info: newConnections:%d cost: %.16lfs(Total: %.16lf) %dffe(Total: %d)", i_new_pairs_detected, d_time_spent, d_cost_time, (i_ffe_end - i_ffe_start), i_cost_ffe);
	//pc_parent->pcGetLog()->vPrintLine(s_dled_cost_report, true);
	
}//void  CDarkGA_DSM::vUpdateDSM(CDarkGrayGAPxMask  *pcMask)



bool  CDarkGA_DSM::b_check_if_true_linkage(int iGeneBlock, int  iGeneContext)
{
	vector<vector <int>>  v_dependent_genes;
	pc_parent->pc_problem->vGetTrueGeneDependencies(&v_dependent_genes);

	for (int i_other_gene_off = 0; i_other_gene_off < v_dependent_genes.at(iGeneBlock).size(); i_other_gene_off++)
	{
		if (v_dependent_genes.at(iGeneBlock).at(i_other_gene_off) == iGeneContext)  return(true);
	}//for (int i_other_gene_off = 0; i_other_gene_off < v_dependent_genes.at(iGeneBlock).size(); i_other_gene_off++)

	return(false);
}//bool  CDarkGA_DSM::b_check_if_true_linkage(int iGeneBlock, int  iGeneContext)



void  CDarkGA_DSM::v_extract_dled_for_gene_pair(int iGeneBlock, int  iGeneContext, int  *piDledExtractionMask, CDarkGrayGAIndividual  *pcExtractionIndividual, int *piNewPairsDetected)
{
	if (pi_dsm[iGeneContext][iGeneBlock] > 0)  return;
	if ((piDledExtractionMask[iGeneBlock] < 0) || (piDledExtractionMask[iGeneContext] < 0))  return;

	pcExtractionIndividual->dComputeFitness();

	int  i_gene_block_value_orig, i_gene_block_value_alter;
	int  i_gene_context_value_orig, i_gene_context_value_alter;


	i_gene_block_value_orig = pcExtractionIndividual->pi_genotype[iGeneBlock];
	i_gene_block_value_alter = i_gene_block_value_orig * (-1) + 1;

	i_gene_context_value_orig = pcExtractionIndividual->pi_genotype[iGeneContext];
	i_gene_context_value_alter = i_gene_context_value_orig * (-1) + 1;


	double  d_fitness_bo_co, d_fitness_bo_ca;
	double  d_fitness_ba_co, d_fitness_ba_ca;


	d_fitness_bo_co = pcExtractionIndividual->dComputeFitness();
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co:", true);
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_alter;
	pcExtractionIndividual->b_fitness_actual = false;
	d_fitness_bo_ca = pcExtractionIndividual->dComputeFitness();
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_ca:");
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_alter;
	pcExtractionIndividual->b_fitness_actual = false;
	d_fitness_ba_ca = pcExtractionIndividual->dComputeFitness();
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_ca:");
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_orig;
	pcExtractionIndividual->b_fitness_actual = false;
	d_fitness_ba_co = pcExtractionIndividual->dComputeFitness();
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_co:");
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	//now we only restore the original genotype we do not have to compute fitness, because we know it (it is in d_fitness_bo_co)
	pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_orig;
	pcExtractionIndividual->b_fitness_actual = true;
	pcExtractionIndividual->d_fitnes_buf = d_fitness_bo_co;


	int  i_block_orig_relation, i_block_alter_relation;
	int  i_context_orig_relation, i_context_alter_relation;

	if (d_fitness_bo_co < d_fitness_bo_ca)  i_block_orig_relation = -1;
	if (d_fitness_bo_co == d_fitness_bo_ca)  i_block_orig_relation = 0;
	if (d_fitness_bo_co > d_fitness_bo_ca)  i_block_orig_relation = 1;

	if (d_fitness_ba_co < d_fitness_ba_ca)  i_block_alter_relation = -1;
	if (d_fitness_ba_co == d_fitness_ba_ca)  i_block_alter_relation = 0;
	if (d_fitness_ba_co > d_fitness_ba_ca)  i_block_alter_relation = 1;


	if (d_fitness_bo_co < d_fitness_ba_co)  i_context_orig_relation = -1;
	if (d_fitness_bo_co == d_fitness_ba_co)  i_context_orig_relation = 0;
	if (d_fitness_bo_co > d_fitness_ba_co)  i_context_orig_relation = 1;

	if (d_fitness_bo_ca < d_fitness_ba_ca)  i_context_alter_relation = -1;
	if (d_fitness_bo_ca == d_fitness_ba_ca)  i_context_alter_relation = 0;
	if (d_fitness_bo_ca > d_fitness_ba_ca)  i_context_alter_relation = 1;


	if (
		(i_block_orig_relation != i_block_alter_relation) ||
		(i_context_orig_relation != i_context_alter_relation)
		)
	{
		pi_dsm[iGeneContext][iGeneBlock] = 1;
		pi_dsm[iGeneBlock][iGeneContext] = 1;

		(*piNewPairsDetected)++;

		/*CString  s_buf;
		if (b_check_if_true_linkage(iGeneBlock, iGeneContext) == false)
		{
			pcExtractionIndividual->b_fitness_actual = true;
			d_fitness_bo_co = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co:", true);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_co = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co_AGAIN:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_alter;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_ca = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_ca:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_alter;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_ba_ca = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_ca:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_orig;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_ba_co = pcExtractionIndividual->dComputeFitness();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_co:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			//now we only restore the original genotype we do not have to compute fitness, because we know it (it is in d_fitness_bo_co)
			pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_orig;
			pcExtractionIndividual->b_fitness_actual = true;
			pcExtractionIndividual->d_fitnes_buf = d_fitness_bo_co;



			CString  s_mut_line, s_sing;
			for (int ii = 0; ii < i_prob_size; ii++)
			{
				s_sing = "_";
				if  (ii == iGeneBlock)  s_sing = "b";
				if (ii == iGeneContext)  s_sing = "c";
				s_mut_line += s_sing;
			}//for (int ii = 0; ii < i_prob_size; ii++)
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_mut_line);


			s_buf.Format("d_fitness_bo_co, d_fitness_bo_ca: %.16lf  %.16lf", d_fitness_bo_co, d_fitness_bo_ca);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("d_fitness_ba_co, d_fitness_ba_ca: %.16lf  %.16lf", d_fitness_ba_co, d_fitness_ba_ca);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("i_block_orig_relation, i_block_alter_relation: %d  %d", i_block_orig_relation, i_block_alter_relation);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("i_context_orig_relation, i_context_alter_relation: %d  %d", i_context_orig_relation, i_context_alter_relation);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);








			::Tools::vReportInFile("zzz_dsm_individuals.txt", "DOUBLE fitness \n\n\n\n\n");

			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_co = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_co = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co_AGAIN:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_alter;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_bo_ca = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_ca:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_alter;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_ba_ca = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_ca:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			pcExtractionIndividual->pi_genotype[iGeneContext] = i_gene_context_value_orig;
			pcExtractionIndividual->b_fitness_actual = false;
			d_fitness_ba_co = pcExtractionIndividual->dComputeFitnessDouble();
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_co:");
			::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
			::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

			//now we only restore the original genotype we do not have to compute fitness, because we know it (it is in d_fitness_bo_co)
			pcExtractionIndividual->pi_genotype[iGeneBlock] = i_gene_block_value_orig;
			pcExtractionIndividual->b_fitness_actual = true;
			pcExtractionIndividual->d_fitnes_buf = d_fitness_bo_co;


			if (d_fitness_bo_co < d_fitness_bo_ca)  i_block_orig_relation = -1;
			if (d_fitness_bo_co == d_fitness_bo_ca)  i_block_orig_relation = 0;
			if (d_fitness_bo_co > d_fitness_bo_ca)  i_block_orig_relation = 1;

			if (d_fitness_ba_co < d_fitness_ba_ca)  i_block_alter_relation = -1;
			if (d_fitness_ba_co == d_fitness_ba_ca)  i_block_alter_relation = 0;
			if (d_fitness_ba_co > d_fitness_ba_ca)  i_block_alter_relation = 1;


			if (d_fitness_bo_co < d_fitness_ba_co)  i_context_orig_relation = -1;
			if (d_fitness_bo_co == d_fitness_ba_co)  i_context_orig_relation = 0;
			if (d_fitness_bo_co > d_fitness_ba_co)  i_context_orig_relation = 1;

			if (d_fitness_bo_ca < d_fitness_ba_ca)  i_context_alter_relation = -1;
			if (d_fitness_bo_ca == d_fitness_ba_ca)  i_context_alter_relation = 0;
			if (d_fitness_bo_ca > d_fitness_ba_ca)  i_context_alter_relation = 1;



			for (int ii = 0; ii < i_prob_size; ii++)
			{
				s_sing = "_";
				if (ii == iGeneBlock)  s_sing = "b";
				if (ii == iGeneContext)  s_sing = "c";
				s_mut_line += s_sing;
			}//for (int ii = 0; ii < i_prob_size; ii++)
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_mut_line);


			s_buf.Format("d_fitness_bo_co, d_fitness_bo_ca: %.16lf  %.16lf", d_fitness_bo_co, d_fitness_bo_ca);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("d_fitness_ba_co, d_fitness_ba_ca: %.16lf  %.16lf", d_fitness_ba_co, d_fitness_ba_ca);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("i_block_orig_relation, i_block_alter_relation: %d  %d", i_block_orig_relation, i_block_alter_relation);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
			s_buf.Format("i_context_orig_relation, i_context_alter_relation: %d  %d", i_context_orig_relation, i_context_alter_relation);
			::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

			s_buf.Format("%d NOTdep %d", iGeneBlock, iGeneContext);
			::Tools::vShow(s_buf);
		}//if (b_check_if_true_linkage(iGeneBlock, iGeneContext) == true)*/

		//CString  s_buf;
		//s_buf.Format("%d/%d", iGeneBlock, iGeneContext);
		//::Tools::vReportInFile("zzzzz_missing_linkage.txt", s_buf);
	}//if  (

	/*CString  s_mut_line, s_sing;
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		s_sing = "_";
		if  (ii == iGeneBlock)  s_sing = "b";
		if (ii == iGeneContext)  s_sing = "c";
		s_mut_line += s_sing;
	}//for (int ii = 0; ii < i_prob_size; ii++)
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_mut_line);

	CString  s_buf;
	s_buf.Format("d_fitness_bo_co, d_fitness_bo_ca: %.2lf  %.2lf", d_fitness_bo_co, d_fitness_bo_ca);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
	s_buf.Format("d_fitness_ba_co, d_fitness_ba_ca: %.2lf  %.2lf", d_fitness_ba_co, d_fitness_ba_ca);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

	s_buf.Format("i_block_orig_relation, i_block_alter_relation: %d  %d", i_block_orig_relation, i_block_alter_relation);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

	s_buf.Format("i_context_orig_relation, i_context_alter_relation: %d  %d", i_context_orig_relation, i_context_alter_relation);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vShow("CDarkGA_DSM::v_extract_dled_for_gene_pair");*/



}//void  CDarkGA_DSM::v_extract_dled_for_gene_pair(int  iGeneContext, int iGeneBlock, CDarkGrayGAIndividual  *pcExtractionIndividual)



//---------------------------------------------CDarkGrayGAPxMaskManager()-------------------------------------------------------
CDarkGrayGAPxMaskManager::CDarkGrayGAPxMaskManager()
{

}//CDarkGrayGAPxMaskManager::CDarkGrayGAPxMaskManager()


CDarkGrayGAPxMaskManager::~CDarkGrayGAPxMaskManager()
{
	for (int ii = 0; ii < v_masks.size(); ii++)
		delete  v_masks.at(ii);
	for (int ii = 0; ii < v_masks_buffered.size(); ii++)
		delete  v_masks_buffered.at(ii);
}//CDarkGrayGAPxMaskManager::~CDarkGrayGAPxMaskManager()


void  CDarkGrayGAPxMaskManager::vShuffle()
{
	vector<CDarkGrayGAPxMask *>  v_masks_shuffled;

	int  i_offset;
	while (v_masks.size() > 0)
	{
		i_offset = ::RandUtils::iRandNumber(0, v_masks.size() - 1);
		v_masks_shuffled.push_back(v_masks.at(i_offset));
		v_masks.erase(v_masks.begin() + i_offset);
	}//while (v_masks.size() > 0)

	v_masks = v_masks_shuffled;
}//void  CDarkGrayGAPxMaskManager::vShuffle()


void  CDarkGrayGAPxMaskManager::vSortByLength()
{
	std::sort(v_masks.begin(), v_masks.end(), [](const CDarkGrayGAPxMask *pcVal0, const CDarkGrayGAPxMask *pcVal1) -> bool { return(pcVal0->v_mask.size() < pcVal1->v_mask.size()); });
}//void  CDarkGrayGAPxMaskManager::vSortByLength()


void  CDarkGrayGAPxMaskManager::vClear()
{
	for (int ii = 0; ii < v_masks.size(); ii++)
		v_masks_buffered.push_back(v_masks.at(ii));
	v_masks.clear();
}//void  CDarkGrayGAPxMaskManager::vClear()

CDarkGrayGAPxMask*  CDarkGrayGAPxMaskManager::pcGetNewPxMask()
{
	CDarkGrayGAPxMask*  pc_new_mask;

	if (v_masks_buffered.size() > 0)
	{
		pc_new_mask = v_masks_buffered.back();
		v_masks_buffered.pop_back();
	}//if (i_masks_size < v_masks.size())
	else
		pc_new_mask = new CDarkGrayGAPxMask();

	v_masks.push_back(pc_new_mask);
		
	pc_new_mask->vClear();
	return(pc_new_mask);
}//CDarkGrayGAPxMask*  CDarkGrayGAPxMaskManager::pcGetNewPxMask()


CDarkGrayGAPxMask* CDarkGrayGAPxMaskManager::pcGetAt(int iOffset)
{
	if (iOffset < v_masks.size())  return(v_masks.at(iOffset)); 
	return(NULL);
}//CDarkGrayGAPxMask* CDarkGrayGAPxMaskManager::pcGetAt(int iOffset)


void  CDarkGrayGAPxMaskManager::vReport(CString  sDest)
{
	FILE  *pf_dest;
	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;
	vReport(pf_dest);
	fclose(pf_dest);
	::Tools::vShow(12345);//*/
}//void  CDarkGrayGAPxMask::vReport(CString  sDest)



void  CDarkGrayGAPxMaskManager::vReport(FILE  *pfDest)
{
	fprintf(pfDest, "MASKS: %d\n\n\n\n\n", v_masks.size());
	
	for (int ii = 0; ii < v_masks.size(); ii++)
		v_masks.at(ii)->vReport(pfDest);
}//void  CDarkGrayGAPxMask::vReportTest()



bool  CDarkGrayGAPxMask::bDoICContain(CDarkGrayGAIndividual  *pcOtherThanThisOne)
{
	if (pc_parent_0 == pcOtherThanThisOne)  return(true);
	if (pc_parent_1 == pcOtherThanThisOne)  return(true);
	return(false);
}//bool  CDarkGrayGAPxMask::bDoICContain(CDarkGrayGAIndividual  *pcOtherThanThisOne)



CDarkGrayGAIndividual  *CDarkGrayGAPxMask::pcGetOtherInd(CDarkGrayGAIndividual  *pcOtherThanThisOne)
{
	if (pc_parent_0 != pcOtherThanThisOne)  return(pc_parent_0);
	if (pc_parent_1 != pcOtherThanThisOne)  return(pc_parent_1);
	return(NULL);
}//CDarkGrayGAIndividual  *CDarkGrayGAPxMask::pcGetOtherInd(CDarkGrayGAIndividual  *pcOtherThanThisOne)



void  CDarkGrayGAPxMask::vReport(CString  sDest)
{
	FILE  *pf_dest;
	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;
	vReport(pf_dest);
	fclose(pf_dest);
}//void  CDarkGrayGAPxMask::vReport(CString  sDest)



void  CDarkGrayGAPxMask::vReport(FILE  *pfDest)
{
	fprintf(pfDest, "%s\n", pc_parent_0->sToStr());
	fprintf(pfDest, "%s\n", pc_parent_1->sToStr());

	int  *pi_tool = new int[pc_parent_0->i_templ_length];

	for (int ii = 0; ii < pc_parent_0->i_templ_length; ii++)
		pi_tool[ii] = 0;

	for (int i_off = 0; i_off < v_mask.size(); i_off++)
		pi_tool[v_mask.at(i_off)] = 1;


	CString  s_line, s_buf;
	for (int ii = 0; ii < pc_parent_0->i_templ_length; ii++)
	{
		if (pi_tool[ii] == 0)  s_buf = "_";
		if (pi_tool[ii] == 1)  s_buf = "1";
		s_line += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)
	fprintf(pfDest, "%s\n", s_line);

	s_line.Format("size: [%d]:", v_mask.size());
	for (int i_off = 0; i_off < v_mask.size(); i_off++)
	{
		s_buf.Format("%d,", v_mask.at(i_off));
		s_line += s_buf;
	}//for (int i_off = 0; i_off < v_mask.size(); i_off++)

	fprintf(pfDest, "%s\n", s_line);


	delete  pi_tool;

	//::Tools::vShow(12345);//*/
}//void  CDarkGrayGAPxMask::vReportTest()



CString  CDarkGrayGAPxMask::sToStr()
{
	CString  s_result;

	int  *pi_tool = new int[pc_parent_0->i_templ_length];

	for (int ii = 0; ii < pc_parent_0->i_templ_length; ii++)
		pi_tool[ii] = 0;

	for (int i_off = 0; i_off < v_mask.size(); i_off++)
		pi_tool[v_mask.at(i_off)] = 1;


	CString  s_buf;
	for (int ii = 0; ii < pc_parent_0->i_templ_length; ii++)
	{
		if (pi_tool[ii] == 0)  s_buf = "_";
		if (pi_tool[ii] == 1)  s_buf = "1";
		s_result += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)


	delete  pi_tool;


	return(s_result);
}//CString  CDarkGrayGAPxMask::sToStr()



//---------------------------------------------CDarkGrayGAIndividual-------------------------------------------------------
CDarkGrayGAIndividual::CDarkGrayGAIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CDarkGrayGASinglePop  *pcParent)
{
	i_templ_length = iTemplLength;
	pc_parent = pcParent;

	pi_genotype = new int[i_templ_length];
	pi_epx_mask = new int[i_templ_length];

	pc_problem = pcProblem;

	d_fitnes_buf = -1;
	b_fitness_actual = false;


	vRandomizeGenotype();
}//CDarkGrayGAIndividual::CDarkGrayGAIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CDarkGrayGA  *pcParent)


CDarkGrayGAIndividual::CDarkGrayGAIndividual(CDarkGrayGAIndividual &pcOther)
{
	::Tools::vShow("No implementation: CDarkGrayGAIndividual::CDarkGrayGAIndividual(CDarkGrayGAIndividual &pcOther) ");
};//CDarkGrayGAIndividual::CDarkGrayGAIndividual(CDarkGrayGAIndividual &pcOther)


CDarkGrayGAIndividual::~CDarkGrayGAIndividual()
{
	delete  pi_genotype;
	delete  pi_epx_mask;
};//CDarkGrayGAIndividual::~CDarkGrayGAIndividual()


void  CDarkGrayGAIndividual::vCopyFrom(CDarkGrayGAIndividual  *pcOther)
{
	this->pc_parent = pcOther->pc_parent;
	this->i_templ_length = pcOther->i_templ_length;
	this->v_opt_order = pcOther->v_opt_order;
	this->d_fitnes_buf = pcOther->d_fitnes_buf;
	this->b_fitness_actual = pcOther->b_fitness_actual;
	this->pc_problem = pcOther->pc_problem;


	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = pcOther->pi_genotype[ii];

}//void  CDarkGrayGAIndividual::vCopyFrom(CDarkGrayGAIndividual  *pcOther)



bool  CDarkGrayGAIndividual::b_get_all_epx_masks(int  *piMasksManager, int  *piMasksNum, CDarkGrayGAIndividual  *pcDonor) 
{
	//first get next uncovered different gene
	int  i_next_seed_gene = -1;

	for (int ii = 0; (ii < i_templ_length) && (i_next_seed_gene == -1); ii++)
	{
		if (piMasksManager[ii] == -1)  i_next_seed_gene = ii;
	}//for (int ii = 0; (ii < i_templ_length)&&(i_init_gene == -1); ii++)

	if (i_next_seed_gene == -1)  return(false);

	pcDonor->vEpxMaskCompute(i_next_seed_gene, this);
	(*piMasksNum)++;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pcDonor->pi_epx_mask[ii] > 0)
		{
			if (piMasksManager[ii] > -1)  ::Tools::vShow("IMPOSISBILITY ALARM: bool  CDarkGrayGAIndividual::b_get_all_epx_masks");
			pi_epx_mask[ii] = (*piMasksNum);
		}//if (pcDonor->pi_epx_mask[ii] > 0)
	}//for (int ii = 0; ii < i_templ_length; ii++)

	return(true);
}//bool  CDarkGrayGAIndividual::b_get_all_epx_masks(int  *piMasksManager, int  *piMasksNum, CDarkGrayGAIndividual  *pcDonor) 





int   CDarkGrayGAIndividual::iMixing_ePX_ByDonor(CDarkGrayGAIndividual *pcDonor, CDarkGrayGAIndividual  *pcResult)
{
	int i_init_gene = -1;
	for (int ii = 0; (ii < i_templ_length)&&(i_init_gene == -1); ii++)
	{
		if (pi_genotype[ii] != pcDonor->pi_genotype[ii])  i_init_gene = ii;
	}//for (int ii = 0; (ii < i_templ_length)&&(i_init_gene == -1); ii++)

	if (i_init_gene == -1)  return(-1);

	bool  b_slided = false;

	pcDonor->vEpxMaskCompute(i_init_gene, this);
	if (pcDonor->bEpxMaskCanICross() == true)
	{
		//first get all epx masks
		int  i_masks_num = 1;

		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pcDonor->pi_epx_mask[ii] > 0)
				pi_epx_mask[ii] = i_masks_num;
			else
			{
				pi_epx_mask[ii] = pcDonor->pi_epx_mask[ii];//0 or -1 -> we ignore 0, but we try to generate next masks for '-1's
			}//else  if (pcDonor->pi_epx_mask[ii] > 0)
		}//for (int ii = 0; ii < i_templ_length; ii++)

		while (b_get_all_epx_masks(pi_epx_mask, &i_masks_num, pcDonor) == true);

		vector<int>  v_masks_ids;
		for (int ii = 0; ii < i_masks_num; ii++)
			v_masks_ids.push_back(ii+1);

		/*FILE  *pf_test;
		pf_test = fopen("zzzz_epx_by_donor_masks_test.txt", "w+");
		fprintf(pf_test, "%s\n", sToStr());
		fprintf(pf_test, "%s\n", pcDonor->sToStr());
		fprintf(pf_test, "%s\n", sEpxToStr());

		fclose(pf_test);
		::Tools::vShow(12345);//*/
		
		int  i_offset, i_mask_to_cross;
		int  i_epx_donate_result;
		int  i_epx_exchanged_length, i_epx_differing_length;
		while (v_masks_ids.size() > 0)
		{
			i_offset = RandUtils::iRandNumber(0, v_masks_ids.size() - 1);
			i_mask_to_cross = v_masks_ids.at(i_offset);
			v_masks_ids.erase(v_masks_ids.begin() + i_offset);

			i_epx_exchanged_length = 0;
			i_epx_differing_length = 0;
			for (int ii = 0; ii < i_templ_length; ii++)
			{
				if (pi_epx_mask[ii] == i_mask_to_cross)
				{
					i_epx_exchanged_length++;
					pcDonor->pi_epx_mask[ii] = 1;
				}//if (pi_epx_mask[ii] == i_mask_to_cross)
				else
				{
					if  (pi_genotype[ii] ==  pcDonor->pi_genotype[ii])
						pcDonor->pi_epx_mask[ii] = 0;
					else
					{
						pcDonor->pi_epx_mask[ii] = -1;
						i_epx_differing_length++;
					}//else  if (pi_genotype[ii] == pcDonor->pi_genotype[ii])
				}//else  if (pi_epx_mask[ii] == i_mask_to_cross)
			}//for (int ii = 0; ii < i_templ_length; ii++)

			pcDonor->i_epx_mask_positions_exchanged = i_epx_exchanged_length;
			pcDonor->i_epx_mask_positions_remain_differing = i_epx_differing_length;
			i_epx_donate_result = pcDonor->iEpxDonateByMask(this, pcResult);

			if (i_epx_donate_result > 0)
			{
				if  (i_epx_donate_result == 2)  (pc_parent->i_uniform_donations)++;
				return(i_epx_donate_result);
			}//if (i_epx_donate_result > 0)

			//SLIDE			
			if (i_epx_donate_result == 0)
			{
				if (pc_parent->pc_individual_buffer == NULL)  pc_parent->pc_individual_buffer = new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_parent);
				pc_parent->pc_individual_buffer->vCopyFrom(pcResult);
				b_slided = true;
			}//if (i_epx_donate_result == 0)

		}//while (v_masks_ids.size() > 0)
	}//if (pcDonor->bEpxMaskCanICross() == true)





	if (b_slided == true)
	{
		if (pc_parent->pc_individual_buffer == NULL)  pc_parent->pc_individual_buffer = new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_parent);
		pcResult->vCopyFrom(pc_parent->pc_individual_buffer);
		(pc_parent->i_slide_number)++;
		return(0);
	}//if (b_slided == true)

	//do floating
	return(-1);
}//int   CDarkGrayGAIndividual::iMixing_ePX_ByDonor(CDarkGrayGAIndividual *pcDonor, CDarkGrayGAIndividual  *pcResult)





int   CDarkGrayGAIndividual::iMixing_ePX_ByDonor(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult)
{
	int  i_gene_to_cross, i_offset;
	vector<CDarkGrayGAIndividual *> v_crossable_individuals;



	int  i_epx_donate_result_equal = 0;
	int  i_epx_donate_result_worse = 0;

	CString  s_first_result_buf;
	int  i_cand_offset;
	CDarkGrayGAIndividual  *pc_donor_candidate;


	for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)
	{
		if (this != pvPop->at(i_ind))
		{
			if (this->bIsTheSame(pvPop->at(i_ind)) == false)  v_crossable_individuals.push_back(pvPop->at(i_ind));
		}//if (this != pvPop->at(i_ind))
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)


	int  i_epx_by_donor_result;
	while (v_crossable_individuals.size() > 0)
	{
		i_cand_offset = RandUtils::iRandNumber(0, v_crossable_individuals.size() - 1);
		pc_donor_candidate = v_crossable_individuals.at(i_cand_offset);
		v_crossable_individuals.erase(v_crossable_individuals.begin() + i_cand_offset);

		i_epx_by_donor_result = iMixing_ePX_ByDonor(pc_donor_candidate, pcResult);

		if (i_epx_by_donor_result > 0)
		{
			/*FILE  *pf_test;
			pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
			fprintf(pf_test, "%s\n", sToStr());
			fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

			CString  s_line, s_buf;
			for (int ii = 0; ii < i_templ_length; ii++)
			{
				s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
				if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
				if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
				s_line += s_buf;
			}//for (int ii = 0; ii < i_templ_length; ii++)
			fprintf(pf_test, "%s\n", s_line);
			fprintf(pf_test, "%s\n", pcResult->sToStr());

			fclose(pf_test);
			::Tools::vShow(12345);//*/

			CString  s_epx_report;
			s_epx_report.Format("exchnaged: %d; remained different: %d", pc_donor_candidate->iEpxMaskPositionsExchanged(), pc_donor_candidate->iEpxMaskPositionsRemainDiffering());
			//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

			return(pc_donor_candidate->iEpxMaskPositionsExchanged());
		}//if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)
		
	}//while (v_crossable_individuals.size() > 0)


	pcResult->vCopyFrom(this);

	CString  s_epx_report;
	s_epx_report.Format("epx equal: %d    epx worse: %d", i_epx_donate_result_equal, i_epx_donate_result_worse);
	//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

	return(0);
}//int   CDarkGrayGAIndividual::iMixing_ePX_ByDonor(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult)



void  CDarkGrayGAIndividual::vGetPxMasks(CDarkGrayGAIndividual  *pcOther, CDarkGrayGAPxMaskManager  *pcMasksManager)
{
	int i_init_gene = -1;
	for (int ii = 0; (ii < i_templ_length) && (i_init_gene == -1); ii++)
	{
		if (pi_genotype[ii] != pcOther->pi_genotype[ii])  i_init_gene = ii;
	}//for (int ii = 0; (ii < i_templ_length)&&(i_init_gene == -1); ii++)

	if (i_init_gene == -1)  return;

	pcOther->vEpxMaskCompute(i_init_gene, this);
	if (pcOther->bEpxMaskCanICross() == true)
	{
		//first get all epx masks
		int  i_masks_num = 1;

		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pcOther->pi_epx_mask[ii] > 0)
				pi_epx_mask[ii] = i_masks_num;
			else
			{
				pi_epx_mask[ii] = pcOther->pi_epx_mask[ii];//0 or -1 -> we ignore 0, but we try to generate next masks for '-1's
			}//else  if (pcDonor->pi_epx_mask[ii] > 0)
		}//for (int ii = 0; ii < i_templ_length; ii++)

		while (b_get_all_epx_masks(pi_epx_mask, &i_masks_num, pcOther) == true);


		CDarkGrayGAPxMask  *pc_new_px_mask;
		for (int i_mask = 1; i_mask <= i_masks_num; i_mask++)
		{
			pc_new_px_mask = pcMasksManager->pcGetNewPxMask();

			for (int i_gene = 0; i_gene < i_templ_length; i_gene++)
			{
				if (pi_epx_mask[i_gene] == i_mask)  pc_new_px_mask->v_mask.push_back(i_gene);
			}//for (int ii = 0; ii < i_templ_length; ii++)

			pc_new_px_mask->pc_parent_0 = this;
			pc_new_px_mask->pc_parent_1 = pcOther;

			//pc_new_px_mask->vReportTest();
		}//for (int ii = 0; ii < i_masks_num; ii++)
	}//if (pcOther->bEpxMaskCanICross() == true)

}//void  CDarkGrayGAIndividual::vGetPxMasks(CDarkGrayGAIndividual  *pcOther, CDarkGrayGAPxMaskManager  *pcMasksManager)


int   CDarkGrayGAIndividual::iMixing_PX_ByMask(CDarkGrayGAPxMask *pcMask, CDarkGrayGAIndividual  *pcResult)
{
	CDarkGrayGAIndividual  *pc_donor_candidate;

	pc_donor_candidate = pcMask->pcGetOtherInd(this);
	
	for (int ii = 0; ii < i_templ_length; ii++)
		pcResult->pi_genotype[ii] = pi_genotype[ii];

	for (int i_offset = 0; i_offset < pcMask->v_mask.size(); i_offset++)
		pcResult->pi_genotype[pcMask->v_mask.at(i_offset)] = pc_donor_candidate->pi_genotype[pcMask->v_mask.at(i_offset)];

	double  d_fitness_result;
	pcResult->b_fitness_actual = false;
	d_fitness_result = pcResult->dComputeFitness();

	//::Tools::vReportInFile("zzzzzz_mix_px_log.txt", sToStr());
	//::Tools::vReportInFile("zzzzzz_mix_px_log.txt", pcResult->sToStr());
	//::Tools::vReportInFile("zzzzzz_mix_px_log.txt", "\n");

	if (dComputeFitness() < d_fitness_result)  return(1);
	if (dComputeFitness() == d_fitness_result)  return(0);

	return(-1);
}//int   CDarkGrayGAIndividual::iMixing_ePX_ByDonor(CDarkGrayGAIndividual *pcDonor, CDarkGrayGAIndividual  *pcResult)



int   CDarkGrayGAIndividual::iUniformCrossoverByMask(CDarkGrayGAPxMask *pcMask, CDarkGrayGAIndividual  *pcResult)
{
	CDarkGrayGAIndividual  *pc_donor_candidate;


	int  *pi_modified_map, *pi_dummy;

	pc_parent->vGetGenotypeBufferTools(&pi_modified_map, &pi_dummy);
	for (int ii = 0; ii < i_templ_length; ii++)
		pi_modified_map[ii] = 0;

	int  i_genes_exchanged;

	pc_donor_candidate = pcMask->pcGetOtherInd(this);

	i_genes_exchanged = 0;
	for (int ii = 0; ii < i_templ_length; ii++)
		pcResult->pi_genotype[ii] = pi_genotype[ii];

	for (int i_offset = 0; i_offset < pcMask->v_mask.size(); i_offset++)
	{
		if (::RandUtils::dRandNumber(0, 1) < 0.5)
		{
			pcResult->pi_genotype[pcMask->v_mask.at(i_offset)] = pc_donor_candidate->pi_genotype[pcMask->v_mask.at(i_offset)];
			pi_modified_map[pcMask->v_mask.at(i_offset)] = 1;
			i_genes_exchanged++;
		}//if  (::RandUtils::dRandNumber(0,1) < 0.5)
	}//for (int i_offset = 0; i_offset < pcMask->v_mask.size(); i_offset++)


	double  d_fit_start, d_fit_uniform, d_fit_uniform_opt;
	d_fit_start = dComputeFitness();

	pcResult->b_fitness_actual = false;
	d_fit_uniform = pcResult->dComputeFitness();

	pcResult->b_fitness_actual = false;
	d_fit_uniform_opt = pcResult->dComputeFitnessOptimize(NULL, true, pi_modified_map);

	if (d_fit_start < d_fit_uniform_opt)
	{
		CString  s_buf;
		s_buf.Format("UNIFORM+OPT (%d/%d): %.8lf -> %.8lf -> %.8lf", i_genes_exchanged, pcMask->v_mask.size(), d_fit_start, d_fit_uniform, d_fit_uniform_opt);
		pc_parent->pcGetLog()->vPrintLine(s_buf, true);

		return(2);
	}//if (d_fitness_start < d_fitness_end)

	return(-1);
}//int   CDarkGrayGAIndividual::iUniformCrossoverByMask(CDarkGrayGAPxMask *pcMask, CDarkGrayGAIndividual  *pcResult)




int  CDarkGrayGAIndividual::iGetPopLevel()
{
	int  i_pop_level;
	i_pop_level = pc_parent->pc_parent->iGetPopLevel(pc_parent);
	return(i_pop_level);
}//int  CDarkGrayGAIndividual::iGetPopLevel()



int   CDarkGrayGAIndividual::iMixing_ePX_ByMaskLen(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult)
{
	CString  s_buf;

	int  i_gene_to_cross, i_offset;
	vector<CDarkGrayGAIndividual *> v_crossable_individuals;
	


	int  i_epx_donate_result_equal = 0;
	int  i_epx_donate_result_worse = 0;

	CString  s_first_result_buf;
	int  i_cand_offset;
	

	for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)
	{
		if (this != pvPop->at(i_ind))
		{
			if (this->bIsTheSame(pvPop->at(i_ind)) == false)  v_crossable_individuals.push_back(pvPop->at(i_ind));
		}//if (this != pvPop->at(i_ind))
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)


	pc_parent->pcGetPxMasksManager()->vClear();
	for (int i_ind = 0; i_ind < v_crossable_individuals.size(); i_ind++)
	{
		v_crossable_individuals.at(i_ind)->vGetPxMasks(this, pc_parent->pcGetPxMasksManager());
	}//for (int i_ind = 0; i_ind < v_crossable_individuals.size(); i_ind++)

	pc_parent->pcGetPxMasksManager()->vShuffle();
	pc_parent->pcGetPxMasksManager()->vSortByLength();
	//pc_parent->pcGetPxMasksManager()->vReport("zzzzzz_manager_masks_test.txt");


	vector  <CDarkGrayGAPxMask*> v_sliding_masks;
	CDarkGrayGAPxMask  *pc_mask;
	int  i_epx_by_donor_result;
	CString  s_donor_modified, s_this_modified;
	//if (pc_parent->pc_individual_buffer == NULL)  pc_parent->pc_individual_buffer = new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_parent);
	//pc_parent->pc_individual_buffer->vCopyFrom(this);

	for (int i_mask = 0; i_mask < pc_parent->pcGetPxMasksManager()->iGetSize(); i_mask++)
	{
		pc_mask = pc_parent->pcGetPxMasksManager()->pcGetAt(i_mask);
		if (pc_mask != NULL)
		{
			i_epx_by_donor_result = iMixing_PX_ByMask(pc_mask, pcResult);

			if (i_epx_by_donor_result > 0)
			{
				//this->vCopyFrom(pc_parent->pc_individual_buffer);
				return(pc_mask->v_mask.size());
			}//if (i_epx_by_donor_result > 0)

			if (i_epx_by_donor_result == 0)  v_sliding_masks.push_back(pc_mask);


			if (i_epx_by_donor_result < 0)
			{
				s_this_modified = pcResult->sToStr();
				int  i_epx_switched_result;
				CDarkGrayGAIndividual  *pc_other_ind;
				pc_other_ind = pc_mask->pcGetOtherInd(this);
				i_epx_switched_result = pc_other_ind->iMixing_PX_ByMask(pc_mask, pcResult);

				if (i_epx_switched_result > 0)
				{
					if (pc_parent->pc_parent->i_sett_donor_improvement == 1)
					{
						if (pc_parent->pc_parent->b_p3_the_same_exists(pcResult) == false)
						{
							CDarkGrayGASinglePop  *pc_parent_preserved;
							pc_parent_preserved = pc_other_ind->pc_parent;
							pc_other_ind->vCopyFrom(pcResult);
							pc_other_ind->pc_parent = pc_parent_preserved;
						}//if (pc_parent->pc_parent->b_p3_the_same_exists(pcResult) == false)
					}//if (this->pc_parent->pc_parent->i_donor_improvement == 1)
					
					//s_buf.Format("Improving donor");
					//::Tools::vShow(s_buf);

					/*CDarkGrayGAIndividual  *pc_donor_improved_copy;
					pc_donor_improved_copy = new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_parent);
					pc_donor_improved_copy->vCopyFrom(pcResult);

					int  i_donor_pyramid_level;
					i_donor_pyramid_level = pc_other_ind->iGetPopLevel();

					if (pc_other_ind->pc_parent->pc_parent->b_p3_add_to_level(i_donor_pyramid_level + 1, pc_donor_improved_copy) == false)  delete  pc_donor_improved_copy;
					s_buf.Format("donor push: %d->%d", i_donor_pyramid_level, i_donor_pyramid_level+1);
					pc_other_ind->pc_parent->pc_parent->pc_log->vPrintLine(s_buf, true);*/
				}//if (i_epx_switched_result > 0)
				else
				{
					/*s_donor_modified = pcResult->sToStr();

					s_buf.Format("FAILED: %d\n", i_epx_switched_result);
					::Tools::vReportInFile("zzzz_switchedEpx.txt", s_buf);
					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->pc_parent_0->sToStr());
					pc_mask->pc_parent_0->b_fitness_actual = false;
					pc_mask->pc_parent_0->dComputeFitness();
					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->pc_parent_0->sToStr());

					::Tools::vReportInFile("zzzz_switchedEpx.txt", "");


					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->pc_parent_1->sToStr());
					pc_mask->pc_parent_1->b_fitness_actual = false;
					pc_mask->pc_parent_1->dComputeFitness();
					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->pc_parent_1->sToStr());

					::Tools::vReportInFile("zzzz_switchedEpx.txt", "\n\n");
					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->sToStr());
					::Tools::vReportInFile("zzzz_switchedEpx.txt", s_this_modified);
					::Tools::vReportInFile("zzzz_switchedEpx.txt", s_donor_modified);//*/
					pc_parent->pc_dsm->vUpdateDSM(pc_mask);

					//::Tools::vShow("SwitchedEPX FAILED!!!");
				}//else  if (i_epx_switched_result > 0)
			}//if (i_epx_by_donor_result < 0)

		}//if (pc_mask != NULL)				
	}//for (int i_mask = 0; i_mask < pc_parent->pcGetPxMasksManager()->iGetSize(); i_mask++)


	if (v_sliding_masks.size() > 0)
	{
		int i_offset;
		i_offset = ::RandUtils::iRandNumber(0, v_sliding_masks.size()-1);


		if (pc_parent->pc_parent->i_sett_uniform_crossover_for_slide == 1)
		{
			int  i_uniform_crossover_result;
			i_uniform_crossover_result = iUniformCrossoverByMask(v_sliding_masks.at(i_offset), pcResult);

			if (i_uniform_crossover_result > 0)
			{
				pc_parent->i_uniform_donations++;
				return(1);
			}//if (i_uniform_crossover_result > 0)
		}//if  (pc_parent->pc_parent->i_uniform_crossover_for_slide == 1)


		iMixing_PX_ByMask(v_sliding_masks.at(i_offset), pcResult);
		return(0);
	}//if (v_sliding_masks.size() > 0)

	
	pcResult->vCopyFrom(this);

	return(-1);
}//int   CDarkGrayGAIndividual::iMixing_ePX_ByMaskLen(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult)





int  CDarkGrayGAIndividual::iMixing_ePX_Brutal(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult)
{
	int  i_gene_to_cross, i_offset;
	vector<CDarkGrayGAIndividual *> v_crossable_individuals;


	int  i_epx_donate_result;
	
	int  i_epx_donate_result_equal = 0;
	int  i_epx_donate_result_worse = 0;

	CString  s_first_result_buf;
	int  i_cand_offset;
	CDarkGrayGAIndividual  *pc_donor_candidate;

	vector<int>  v_available_positions;
	for (int ii = 0; ii < i_templ_length; ii++)
		v_available_positions.push_back(ii);



	while (v_available_positions.size() > 0)
	{
		i_offset = RandUtils::iRandNumber(0, v_available_positions.size() - 1);
		i_gene_to_cross = v_available_positions.at(i_offset);
		v_available_positions.erase(v_available_positions.begin() + i_offset);



		
		//fprintf(pf_test, "%s\n\n", sToStr());

		v_crossable_individuals.clear();
		for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)
		{
			if (this != pvPop->at(i_ind))
			{
				if (pi_genotype[i_gene_to_cross] != pvPop->at(i_ind)->pi_genotype[i_gene_to_cross])
				{
					pvPop->at(i_ind)->vEpxMaskCompute(i_gene_to_cross, this);
					if (pvPop->at(i_ind)->bEpxMaskCanICross() == true)  
						v_crossable_individuals.push_back(pvPop->at(i_ind));
					/*else
					{
						CString  s_line, s_buf;

						s_line = "";
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", pvPop->at(i_ind)->pi_epx_mask[ii]);
							if (pvPop->at(i_ind)->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (pvPop->at(i_ind)->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);

					}//else  if (pvPop->at(i_ind)->bEpxMaskCanICross() == true)  */
				}//if (pi_genotype[i_gene_to_cross] != pvPop->at(i_ind)->pi_genotype[i_gene_to_cross])
			}//if (this != pvPop->at(i_ind))
		}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)


		if (v_crossable_individuals.size() > 0)
		{
			/*FILE  *pf_test;
			pf_test = fopen("zzzz_epx_mask_LIST_test.txt", "w+");
			fprintf(pf_test, "\n\n\n\nCROSSABLE:\n\n\n");

			CDarkGrayGAIndividual  *pc_buf = new CDarkGrayGAIndividual(i_templ_length, pc_problem, pc_parent);

			CString  s_line, s_buf;
			for (int i_ind = 0; i_ind < v_crossable_individuals.size(); i_ind++)
			{
				fprintf(pf_test, "%s\n\n", v_crossable_individuals.at(i_ind)->sEpxToStr());
				pc_buf->vCopyFrom(v_crossable_individuals.at(i_ind));

				for (int i_gene_dffering = 0; i_gene_dffering < i_templ_length; i_gene_dffering++)
				{
					if (v_crossable_individuals.at(i_ind)->pi_epx_mask[i_gene_dffering] == -1)
					{
						pc_buf->vEpxMaskCompute(i_gene_dffering, this);
						fprintf(pf_test, "%s\n", pc_buf->sEpxToStr());
					}//if (v_crossable_individuals.at(i_ind)->pi_epx_mask[i_gene_dffering] == -1)
				}//for (int ii = 0; ii < i_templ_length; ii++)

				fprintf(pf_test, "\n\n");

			}//for (int ii = 0; ii < v_crossable_individuals.size(); ii++)
			fclose(pf_test);
			::Tools::vShow(v_crossable_individuals.size());//*/
					   			 		  		  		 	   		
			
			pc_donor_candidate = v_crossable_individuals.at(0);

			i_epx_donate_result = pc_donor_candidate->iEpxDonateByMask(this, pcResult);

			if (i_epx_donate_result == 1)
			{
				/*FILE  *pf_test;
				pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
				fprintf(pf_test, "%s\n", sToStr());
				fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

				CString  s_line, s_buf;
				for (int ii = 0; ii < i_templ_length; ii++)
				{
					s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
					if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
					if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
					s_line += s_buf;
				}//for (int ii = 0; ii < i_templ_length; ii++)
				fprintf(pf_test, "%s\n", s_line);
				fprintf(pf_test, "%s\n", pcResult->sToStr());

				fclose(pf_test);
				::Tools::vShow(12345);//*/

				CString  s_epx_report;
				s_epx_report.Format("exchnaged: %d; remained different: %d", pc_donor_candidate->iEpxMaskPositionsExchanged(), pc_donor_candidate->iEpxMaskPositionsRemainDiffering());
				//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

				return(pc_donor_candidate->iEpxMaskPositionsExchanged());
			}//if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)


			if (i_epx_donate_result == 0)
			{
				i_epx_donate_result_equal++;
			}//if (i_epx_donate_result == 0)

			if (i_epx_donate_result == -1)
			{
				/*::Tools::vShow("Worse");
				s_first_result_buf = pcResult->sToStr();

				//REVERT CROSSING
				i_epx_donate_result = -2;
				this->vEpxMaskCompute(i_gene_to_cross, pc_donor_candidate);
				if (this->bEpxMaskCanICross() == true)
				{
					i_epx_donate_result = this->iEpxDonateByMask(pc_donor_candidate, pcResult);
				}//if (this->bEpxMaskCanICross() == true)

				if (i_epx_donate_result != 1)
				{
					FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", s_first_result_buf);

					fprintf(pf_test, "\n====================\n");


					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());
					fprintf(pf_test, "%s\n", sToStr());
					s_line = "";
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", this->pi_epx_mask[ii]);
						if (this->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (this->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());




					fclose(pf_test);
					::Tools::vShow("NIEMOZLIWE");
				}//if (i_epx_donate_result != 1)*/


				i_epx_donate_result_worse++;
			}//if (i_epx_donate_result == -1)
		}//if  (v_crossable_individuals.size() > 0)
		

	}//while (v_available_positions.size() > 0)

	pcResult->vCopyFrom(this);

	CString  s_epx_report;
	s_epx_report.Format("epx equal: %d    epx worse: %d", i_epx_donate_result_equal, i_epx_donate_result_worse);
	//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

	return(0);




	while (v_crossable_individuals.size() > 0)
	{
		i_cand_offset = RandUtils::iRandNumber(0, v_crossable_individuals.size() - 1);
		pc_donor_candidate = v_crossable_individuals.at(i_cand_offset);
		v_crossable_individuals.erase(v_crossable_individuals.begin() + i_cand_offset);

		

		v_available_positions.clear();
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pi_genotype[ii] != pc_donor_candidate->pi_genotype[ii])  v_available_positions.push_back(ii);
		}//for (int ii = 0; ii < i_templ_length; ii++)


		if (v_available_positions.size() > 0)
		{
			i_offset = RandUtils::iRandNumber(0, v_available_positions.size() - 1);
			i_gene_to_cross = v_available_positions.at(i_offset);

			pc_donor_candidate->vEpxMaskCompute(i_gene_to_cross, this);
			if (pc_donor_candidate->bEpxMaskCanICross() == true)
			{
				i_epx_donate_result = pc_donor_candidate->iEpxDonateByMask(this, pcResult);

				if (i_epx_donate_result == 1)
				{
					/*FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());

					fclose(pf_test);
					::Tools::vShow(12345);//*/

					CString  s_epx_report;
					s_epx_report.Format("exchnaged: %d; remained different: %d", pc_donor_candidate->iEpxMaskPositionsExchanged(), pc_donor_candidate->iEpxMaskPositionsRemainDiffering());
					//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

					return(pc_donor_candidate->iEpxMaskPositionsExchanged());
				}//if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)
				

				if (i_epx_donate_result == 0)  i_epx_donate_result_equal++;
				
				if (i_epx_donate_result == -1)  
				{
					s_first_result_buf = pcResult->sToStr();

					//REVERT CROSSING
					i_epx_donate_result = -2;
					this->vEpxMaskCompute(i_gene_to_cross, pc_donor_candidate);
					if (this->bEpxMaskCanICross() == true)
					{
						i_epx_donate_result = this->iEpxDonateByMask(pc_donor_candidate, pcResult);
					}//if (this->bEpxMaskCanICross() == true)

					if (i_epx_donate_result != 1)
					{
						FILE  *pf_test;
						pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
						fprintf(pf_test, "%s\n", sToStr());
						fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

						CString  s_line, s_buf;
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
							if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);



						fprintf(pf_test, "%s\n", s_first_result_buf);

						fprintf(pf_test, "\n====================\n");


						fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());
						fprintf(pf_test, "%s\n", sToStr());
						s_line = "";
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", this->pi_epx_mask[ii]);
							if (this->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (this->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);
						fprintf(pf_test, "%s\n", pcResult->sToStr());


						

						fclose(pf_test);
						::Tools::vShow("NIEMOZLIWE");
					}//if (i_epx_donate_result != 1)


					i_epx_donate_result_worse++;

					/*FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());

					fclose(pf_test);
					::Tools::vShow(-8);//*/
				}//else  if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)
			}//if (pc_donor_candidate->bEpxMaskCanICross() == true)
		}//if (v_available_positions.size() > 0)
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)	


	pcResult->vCopyFrom(this);

	//CString  s_epx_report;
	s_epx_report.Format("epx equal: %d    epx worse: %d", i_epx_donate_result_equal, i_epx_donate_result_worse);
	//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

	return(0);
}//bool  CDarkGrayGAIndividual::bMixing_ePX(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcDest)


int  CDarkGrayGAIndividual::iMixing_ePX(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcResult)
{
	int  i_gene_to_cross, i_offset;
	vector<CDarkGrayGAIndividual *> v_crossable_individuals;


	for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)
	{
		if (this != pvPop->at(i_ind))
		{
			if (this->bIsTheSame(pvPop->at(i_ind)) == false)  v_crossable_individuals.push_back(pvPop->at(i_ind));
		}//if (this != pvPop->at(i_ind))
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)


	int  i_epx_donate_result_equal = 0;
	int  i_epx_donate_result_worse = 0;

	CString  s_first_result_buf;
	int  i_cand_offset;
	CDarkGrayGAIndividual  *pc_donor_candidate;
	vector<int>  v_available_positions;
	while (v_crossable_individuals.size() > 0)
	{
		i_cand_offset = RandUtils::iRandNumber(0, v_crossable_individuals.size() - 1);
		pc_donor_candidate = v_crossable_individuals.at(i_cand_offset);
		v_crossable_individuals.erase(v_crossable_individuals.begin() + i_cand_offset);


		v_available_positions.clear();
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pi_genotype[ii] != pc_donor_candidate->pi_genotype[ii])  v_available_positions.push_back(ii);
		}//for (int ii = 0; ii < i_templ_length; ii++)


		int  i_epx_donate_result;
		if (v_available_positions.size() > 0)
		{
			i_offset = RandUtils::iRandNumber(0, v_available_positions.size() - 1);
			i_gene_to_cross = v_available_positions.at(i_offset);

			pc_donor_candidate->vEpxMaskCompute(i_gene_to_cross, this);
			if (pc_donor_candidate->bEpxMaskCanICross() == true)
			{
				i_epx_donate_result = pc_donor_candidate->iEpxDonateByMask(this, pcResult);

				if (i_epx_donate_result == 1)
				{
					/*FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());

					fclose(pf_test);
					::Tools::vShow(12345);//*/

					CString  s_epx_report;
					s_epx_report.Format("exchnaged: %d; remained different: %d", pc_donor_candidate->iEpxMaskPositionsExchanged(), pc_donor_candidate->iEpxMaskPositionsRemainDiffering());
					//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

					return(pc_donor_candidate->iEpxMaskPositionsExchanged());
				}//if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)


				if (i_epx_donate_result == 0)  i_epx_donate_result_equal++;

				if (i_epx_donate_result == -1)
				{
					s_first_result_buf = pcResult->sToStr();

					//REVERT CROSSING
					i_epx_donate_result = -2;
					this->vEpxMaskCompute(i_gene_to_cross, pc_donor_candidate);
					if (this->bEpxMaskCanICross() == true)
					{
						i_epx_donate_result = this->iEpxDonateByMask(pc_donor_candidate, pcResult);
					}//if (this->bEpxMaskCanICross() == true)

					if (i_epx_donate_result != 1)
					{
						FILE  *pf_test;
						pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
						fprintf(pf_test, "%s\n", sToStr());
						fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

						CString  s_line, s_buf;
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
							if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);
						fprintf(pf_test, "%s\n", s_first_result_buf);

						fprintf(pf_test, "\n====================\n");


						fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());
						fprintf(pf_test, "%s\n", sToStr());
						s_line = "";
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", this->pi_epx_mask[ii]);
							if (this->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (this->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);
						fprintf(pf_test, "%s\n", pcResult->sToStr());




						fclose(pf_test);
						::Tools::vShow("IMPOSSIBLE");
					}//if (i_epx_donate_result != 1)


					i_epx_donate_result_worse++;

					/*FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());

					fclose(pf_test);
					::Tools::vShow(-8);//*/
				}//else  if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)
			}//if (pc_donor_candidate->bEpxMaskCanICross() == true)
		}//if (v_available_positions.size() > 0)
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)	


	pcResult->vCopyFrom(this);

	CString  s_epx_report;
	s_epx_report.Format("epx equal: %d    epx worse: %d", i_epx_donate_result_equal, i_epx_donate_result_worse);
	//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

	return(0);
}//bool  CDarkGrayGAIndividual::bMixing_ePX(vector<CDarkGrayGAIndividual *> *pvPop, CDarkGrayGAIndividual  *pcDest)



int  CDarkGrayGAIndividual::iEpxDonateByMask(CDarkGrayGAIndividual *pcReceiver, CDarkGrayGAIndividual *pcResult)
{
	double  d_fitness_start, d_fitness_end;


	d_fitness_start = pcReceiver->dComputeFitness();

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if ((pi_epx_mask[ii] == -1) || (pi_epx_mask[ii] == 0))
			pcResult->pi_genotype[ii] = pcReceiver->pi_genotype[ii];
		else
			pcResult->pi_genotype[ii] = pi_genotype[ii];
	}//for (int ii = 0; ii < i_templ_length; ii++)

	pcResult->b_fitness_actual = false;
	d_fitness_end = pcResult->dComputeFitness();

	if (d_fitness_start < d_fitness_end)  return(1);



	bool  b_return_slide = false;
	double  d_fitness_slide = -1;
	if (d_fitness_start == d_fitness_end)
	{
		b_return_slide = true;
		d_fitness_slide = d_fitness_end;
	}//if (d_fitness_start == d_fitness_end)



	//uniform crossover
	bool  b_uniform_crossover = false;
	if (b_uniform_crossover == true)
	{
		int  *pi_modified_map, *pi_dummy;

		pc_parent->vGetGenotypeBufferTools(&pi_modified_map, &pi_dummy);
		for (int ii = 0; ii < i_templ_length; ii++)
			pi_modified_map[ii] = 0;

		int  i_original_epx_mask_positions_exchanged = i_epx_mask_positions_exchanged;

		i_epx_mask_positions_exchanged = 0;
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if ((pi_epx_mask[ii] == -1) || (pi_epx_mask[ii] == 0))
				pcResult->pi_genotype[ii] = pcReceiver->pi_genotype[ii];
			else
			{
				if (::RandUtils::dRandNumber(0, 1) < 0.5)
				{
					pcResult->pi_genotype[ii] = pi_genotype[ii];
					pi_modified_map[ii] = 1;
					i_epx_mask_positions_exchanged++;
				}//if  (::RandUtils::dRandNumber(0,1) < 0.5)
				else
					pcResult->pi_genotype[ii] = pcReceiver->pi_genotype[ii];
			}//else  if ((pi_epx_mask[ii] == -1) || (pi_epx_mask[ii] == 0))
		}//for (int ii = 0; ii < i_templ_length; ii++)


		pcResult->b_fitness_actual = false;
		d_fitness_end = pcResult->dComputeFitnessOptimize(NULL, true, pi_modified_map);

		if (d_fitness_start < d_fitness_end)
		{
			//CString  s_buf;
			//s_buf.Format("UNIFORM+OPT: %.8lf -> %.8lf", d_fitness_start, d_fitness_end);
			//pc_parent->pcGetLog()->vPrintLine(s_buf, true);

			return(2);
		}//if (d_fitness_start < d_fitness_end)

		if (d_fitness_start == d_fitness_end)  return(0);

		i_epx_mask_positions_exchanged = i_original_epx_mask_positions_exchanged;
	}//if (b_uniform_crossover == true)



	if (b_return_slide == true)
	{
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if ((pi_epx_mask[ii] == -1) || (pi_epx_mask[ii] == 0))
				pcResult->pi_genotype[ii] = pcReceiver->pi_genotype[ii];
			else
				pcResult->pi_genotype[ii] = pi_genotype[ii];
		}//for (int ii = 0; ii < i_templ_length; ii++)

		pcResult->d_fitnes_buf = d_fitness_slide;
		pcResult->b_fitness_actual = true;

		return(0);
	}//if (b_return_slide == true)

	return(-1);
}//int  CDarkGrayGAIndividual::iEpxDonateByMask(CDarkGrayGAIndividual *pcReceiver, CDarkGrayGAIndividual *pcResult)




void  CDarkGrayGAIndividual::v_epx_mask_extend_at_level(int  iLevelToExplode, CDarkGrayGAIndividual *pcReceiver)
{
	bool  b_extended = false;

	for (int i_gene_this = 0; i_gene_this < i_templ_length; i_gene_this++)
	{
		if (pi_epx_mask[i_gene_this] == iLevelToExplode)
		{
			for (int i_gene_other = 0; i_gene_other < i_templ_length; i_gene_other++)
			{
				if (pi_epx_mask[i_gene_other] == -1)
				{
					if (pc_parent->pcGetDSM()->piGetDSM()[i_gene_this][i_gene_other] > 0)
					{
						pi_epx_mask[i_gene_other] = iLevelToExplode + 1;
						b_extended = true;
					}//if (pc_parent->pcGetDSM()->piGetDSM()[i_gene_this][i_gene_other] > 0)
				}//if  (pi_epx_mask[i_gene_other]  == -1)

			}//for (int i_gene_other = 0; i_gene_other < i_templ_length; i_gene_other++)
		}//if (pi_epx_mask[i_gene] == iLevelToExplode)			
	}//for (int i_gene_this = 0; i_gene_this < i_templ_length; i_gene_this++)

	if (b_extended == true)  v_epx_mask_extend_at_level(iLevelToExplode + 1, pcReceiver);
}//bool  CDarkGrayGAIndividual::b_epx_mask_extend_at_level(int  iLevelToExplode, CDarkGrayGAIndividual *pcReceiver)



void  CDarkGrayGAIndividual::vEpxMaskCompute(int  iGeneToCross, CDarkGrayGAIndividual *pcReceiver)
{
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] == pcReceiver->pi_genotype[ii])
			pi_epx_mask[ii] = 0;
		else
			pi_epx_mask[ii] = -1;
	}//for (int ii = 0; ii < i_templ_length; ii++)

	b_epx_mask_can_cross = false;

	if (pi_genotype[iGeneToCross] != pcReceiver->pi_genotype[iGeneToCross])
		pi_epx_mask[iGeneToCross] = 1;
	else
		return;

	v_epx_mask_extend_at_level(1, pcReceiver);

	i_epx_mask_positions_exchanged = 0;
	i_epx_mask_positions_remain_differing = 0;
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		//we have at least one different (iGeneToCross differs), so we need to have at least one that is not marked by the crossing mark (otherwise, we will exchange all differeing genes)
		if (pi_epx_mask[ii] == -1)
		{
			//b_epx_mask_can_cross = true;
			i_epx_mask_positions_remain_differing++;
			//return;
		}//if (pi_epx_mask[ii] == -1)

		if (pi_epx_mask[ii] > 0)   i_epx_mask_positions_exchanged++;
	}//for (int ii = 0; ii < i_templ_length; ii++)

	if  ( (i_epx_mask_positions_remain_differing > 0)&&(i_epx_mask_positions_exchanged > 0) )  b_epx_mask_can_cross = true;
}//void  CDarkGrayGAIndividual::vEpxMaskCompute(int  iGeneToCross, CDarkGrayGAIndividual *pcDonor)



bool  CDarkGrayGAIndividual::bEpxMaskCanICross()
{
	return(b_epx_mask_can_cross);
}//bool  CDarkGrayGAIndividual::bEpxMaskCanICross()


CString  CDarkGrayGAIndividual::sEpxToStr()
{
	CString  s_res, s_buf;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		s_buf.Format("%d", pi_epx_mask[ii]);
		if (pi_epx_mask[ii] == 0)  s_buf = "_";
		if (pi_epx_mask[ii] < 0)  s_buf = "*";
		s_res += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)


	s_buf.Format("   Exchnage: %d  Differing:%d", i_epx_mask_positions_exchanged, i_epx_mask_positions_remain_differing);
	s_res += s_buf;

	return(s_res);
}//CString  CDarkGrayGAIndividual::sEpxToStr()


CString  CDarkGrayGAIndividual::sToStr()
{
	CString  s_res, s_buf;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		s_buf.Format("%d", pi_genotype[ii]);
		s_res += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)

	s_buf.Format("  %.8lf", dComputeFitness());
	s_res += s_buf;

	return(s_res);
}//CString  CDarkGrayGAIndividual::sToStr()


bool  CDarkGrayGAIndividual::bIsTheSame(CDarkGrayGAIndividual  *pcOther)
{
	if ((pi_genotype == NULL))  return(false);
	if ((pcOther->pi_genotype == NULL))  return(false);

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] != pcOther->pi_genotype[ii])  return(false);
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(true);
}//bool  CDarkGrayGAIndividual::bIsTheSame(CDarkGrayGAIndividual  *pcOther)


double  CDarkGrayGAIndividual::dGetSimilarity(CDarkGrayGAIndividual  *pcOther, int  *piGenesTheSame)
{
	int  i_genes_the_same;
	if (piGenesTheSame == NULL)  piGenesTheSame = &i_genes_the_same;
	*piGenesTheSame = 0;

	if ((pi_genotype == NULL))  return(0);
	if ((pcOther->pi_genotype == NULL))  return(0);


	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] == pcOther->pi_genotype[ii])  (*piGenesTheSame)++;
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	double  d_res;
	d_res = *piGenesTheSame;
	d_res = d_res / i_templ_length;

	return(d_res);
}//double  CDarkGrayGAIndividual::dGetSimilarity(CDarkGrayGAIndividual  *pcOther, int  *piGenesTheSame)




void  CDarkGrayGAIndividual::vRandomizeGenotype()
{
	d_fitnes_buf = -1;
	b_fitness_actual = false;

	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = RandUtils::iRandNumber(0, 1);

};//void  CDarkGrayGAIndividual::vRandomizeGenotype()


double  CDarkGrayGAIndividual::dComputeFitness()
{
	if (b_fitness_actual == true)  return(d_fitnes_buf);

	d_fitnes_buf = pc_parent->dComputeFitness(pi_genotype);
	b_fitness_actual = true;

	return(d_fitnes_buf);
};//double  CDarkGrayGAIndividual::dComputeFitness()


double  CDarkGrayGAIndividual::dComputeFitnessDouble()
{
	if (b_fitness_actual == true)  return(d_fitnes_buf);

	d_fitnes_buf = pc_parent->dComputeFitnessDouble(pi_genotype);
	b_fitness_actual = true;

	return(d_fitnes_buf);
};//double  CDarkGrayGAIndividual::dComputeFitness()



void  CDarkGrayGAIndividual::v_create_opt_order(vector<int>  *pvOrder)
{
	vector<int>  v_temp;

	pvOrder->clear();

	for (int ii = 0; ii < i_templ_length; ii++)
		v_temp.push_back(ii);

	int  i_pos;
	while (v_temp.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_temp.size() - 1);
		pvOrder->push_back(v_temp.at(i_pos));
		v_temp.erase(v_temp.begin() + i_pos);
	}//while  (v_temp.size() > 0)
}//void  CDarkGrayGAIndividual::v_create_opt_order(vector<int>  *pvOrder)




double  CDarkGrayGAIndividual::d_optimize_single_gene(int  iOptGene)
{
	double  d_fitness_current, d_fit_new;
	d_fitness_current = dComputeFitness();

	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;

	b_fitness_actual = false;
	d_fit_new = dComputeFitness();

	if (d_fit_new > d_fitness_current)  return(d_fit_new);


	//flip back...
	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;
	b_fitness_actual = true;
	this->d_fitnes_buf = d_fitness_current;

	return(this->d_fitnes_buf);
}//double  CDarkGrayGAIndividual::d_optimize_single_gene(int  iOptGene)



double  CDarkGrayGAIndividual::dComputeFitnessOptimize(vector<int>  *pvOrder /*= NULL*/, bool  bDarkGray /*= false*/, int  *piDarkGrayModifiedGenes /*= NULL*/)
{
	
	CString  s_buf;

	if (pvOrder == NULL)  pvOrder = &v_opt_order;
	if (pvOrder->size() != i_templ_length)  v_create_opt_order(pvOrder);

	
		

	if (pc_parent == NULL)
	{
		::MessageBox(NULL, "if (pc_parent == NULL)    double  CDarkGrayGAIndividual::dComputeFitnessOptimizeDarkGray(vector<int>  *pvOrder = NULL)", "if (pc_parent == NULL)  double  CDarkGrayGAIndividual::dComputeFitnessOptimizeDarkGray(vector<int>  *pvOrder = NULL)", MB_OK);
		return(-1);
	}//if (pc_parent == NULL)

	int  *pi_genes_to_check_current, *pi_genes_changed;

	
	if (bDarkGray == true)
	{
		pc_parent->vGetGenotypeBufferTools(&pi_genes_to_check_current, &pi_genes_changed);

		if (piDarkGrayModifiedGenes != NULL)
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_changed[ii] = piDarkGrayModifiedGenes[ii];
		}//if (piDarkGrayModifiedGenes != NULL)
		else
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_changed[ii] = 1;
		}//else  if (piDarkGrayModifiedGenes != NULL)
	}//if (bDarkGray == true)
	else
	{
		pi_genes_to_check_current = NULL;
		pi_genes_changed = NULL;
	}//else  if (bDarkGray == true)

	
	int  i_opt_gene;
	int  i_orig_gene_val;
	bool  b_changed;

	b_changed = true;

	//::Tools::vShow("IN");


	bool  b_gene_consider;
	int  i_opt_counter = 0;
	while (b_changed == true)
	{
		//double  d_start, d_end;
		//d_start = dComputeFitness();
		//int i_ffe_start, i_ffe_end;
		//i_ffe_start = pc_problem->pcGetEvaluation()->iGetFFE();



		i_opt_counter++;
		b_changed = false;

		if (bDarkGray == true)
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_to_check_current[ii] = 0;

			for (int ii = 0; ii < i_templ_length; ii++)
			{
				if  (pi_genes_changed[ii] == 1)  pc_parent->pcGetDSM()->vDarkGrayMapDependentGenes(ii, pi_genes_to_check_current);
			}//for (int ii = 0; ii < i_templ_length; ii++)

			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_changed[ii] = 0;
		}//if (bDarkGray == true)

		
		for (int ii = 0; ii < pvOrder->size(); ii++)
		{
			i_opt_gene = pvOrder->at(ii);

			b_gene_consider = false;
			if (bDarkGray == true)
			{
				if  (pi_genes_to_check_current[ii] == 1)  b_gene_consider = true;
			}//if (bDarkGray == true)
			else
				b_gene_consider = true;


			if (b_gene_consider == true)
			{
				i_orig_gene_val = pi_genotype[i_opt_gene];
				d_optimize_single_gene(i_opt_gene);

				if (i_orig_gene_val != pi_genotype[i_opt_gene])
				{
					//if  (b_changed == false)  ::Tools::vShow("b_changed = true;");
					b_changed = true;
					if  (pi_genes_changed  != NULL)  pi_genes_changed[i_opt_gene] = 1;
				}//if (i_orig_gene_val != pi_genotype[i_opt_gene])
			}//if  (b_gene_consider == true)
		}//for  (int  i_opt_traj = 0; i_opt_traj < i_number_of_pairs; i_opt_traj++)


		//d_end = dComputeFitness();
		//s_buf.Format("%.8lf -> %.8lf", d_start, d_end);
		//::Tools::vShow(s_buf);

		/*i_ffe_end = pc_problem->pcGetEvaluation()->iGetFFE();
		s_buf.Format("%d\n%d\n%d\n", i_ffe_start, i_ffe_end, i_ffe_end - i_ffe_start);

		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", s_buf);
		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", sToStr());*/


	}//while (b_changed == true)
	
	
	return(dComputeFitness());
};//double  CDarkGrayGAIndividual::dComputeFitnessOptimize()




