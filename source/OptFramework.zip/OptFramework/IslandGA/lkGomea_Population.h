#pragma once

#include <cmath>
#include <iostream> 
#include <vector>
using namespace std;

#include "lkGomea_Individual.h"
#include "lkGomea_Config.h"
#include "lkGomea_shared.h"
#include "lkGomea_problems.h"
#include "lkGomea_FOS.h"
#include "lkGomea_PopulationGeneral.h"

class C_lkGomea_Population: public C_lkGomea_PopulationGeneral
{
public:

	C_lkGomea_Population(C_lkGomea_Config *config_, C_lkGomea_Problem *problemInstance_, C_lkGomea_sharedInformation *sharedInformationPointer_, size_t populationIndex_, size_t populationSize_):
		C_lkGomea_PopulationGeneral(config_, problemInstance_, sharedInformationPointer_, populationIndex_, populationSize_){};
	
	~C_lkGomea_Population();

	bool b_makeOffspring();
	bool  b_generateOffspring();
	bool GOM(size_t offspringIndex, C_lkGomea_Individual *backup, bool  *pbTimeLimitOK);
	bool conditionalGOM(size_t offspringIndex, C_lkGomea_Individual *backup, vector<vector<int> > &neighbors, bool  *pbTimeLimitOK);
};