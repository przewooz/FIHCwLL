#ifndef C_CGOMEA_OPTIMIZER_H
#define C_CGOMEA_OPTIMIZER_H


#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "CommandParam.h"
#include "Error.h"
#include "Log.h"
#include "MathUtils.h"
#include "Optimizer.h"
#include "Problem.h"
#include  "util\timer.h"
#include  "util\tools.h"

#include "cGomea_Config.h"
#include "cGomea_gomeaP3_MI.h"



#include <istream>
#include <algorithm>





namespace nC_Gomea
{
	class C_CGomea : public CBinaryOptimizer
	{
	public:
		static uint32_t iERROR_PARENT_C_CGomea;
		static uint32_t iERROR_CODE_C_CGomea_GENOTYPE_LEN_BELOW_0;


		C_CGomea(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
		C_CGomea(C_CGomea *pcOther);
		~C_CGomea();

		void  vCopyFrom(C_CGomea *pcOther);

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new C_CGomea(this); };
		virtual bool bRunIteration(uint32_t iIterationNumber);

		virtual CError eConfigure(istream *psSettings);
		virtual void vInitialize();

		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo();

		double dComputeFitness(int32_t *piBits);
		

	private:
		void  v_get_best_genotype(vector<char>  *pvGenotype);//asdasd

		double  d_time_last_time;
		int  i_templ_length;


		C_CGomea_Config  *pc_gomea_config;
		C_CGomea_gomeaP3_MI  *pc_cgomea_best_p3;

		int32_t *pi_bits;
	};//class C_CGomea : public CBinaryOptimizer	

}//namespace nC_Gomea

#endif//C_CGOMEA_OPTIMIZER_H