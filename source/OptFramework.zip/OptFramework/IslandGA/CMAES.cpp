#include "CMAES.h"

template <class TESOStrategy>
CCMAES<TESOStrategy>::CCMAES(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: COptimizer<CRealCoding, CRealCoding>(pcProblem, pcLog, iRandomSeed)
{
	v_init();
}//CCMAES<TESOStrategy>::CCMAES(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

template <class TESOStrategy>
CCMAES<TESOStrategy>::CCMAES(CCMAES<TESOStrategy> *pcOther)
	: COptimizer<CRealCoding, CRealCoding>(pcOther)
{
	v_init();

	f_sigma = pcOther->f_sigma;
	b_is_sep = pcOther->b_is_sep;
	b_is_vd = pcOther->b_is_vd;
}//CCMAES<TESOStrategy>::CCMAES(CCMAES<TESOStrategy> *pcOther)

template <class TESOStrategy>
CCMAES<TESOStrategy>::~CCMAES()
{
	v_clear_cmaes();
	delete pc_candidate_individual;
}//CCMAES<TESOStrategy>::~CCMAES()

template <class TESOStrategy>
CError CCMAES<TESOStrategy>::eConfigure(istream *psSettings)
{
	CError c_error = COptimizer<CRealCoding, CRealCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		CFloatCommandParam p_sigma(CMAES_ARGUMENT_SIGMA, 0, FLT_MAX);
		f_sigma = p_sigma.fGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CBoolCommandParam p_is_sep(CMAES_ARGUMENT_IS_SEP);
		b_is_sep = p_is_sep.bGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CBoolCommandParam p_is_vd(CMAES_ARGUMENT_IS_VD);
		b_is_vd = p_is_vd.bGetValue(psSettings, &c_error);
	}//if (!c_error)

	return c_error;
}//CError CCMAES<TESOStrategy>::eConfigure(istream *psSettings)

template <class TESOStrategy>
void CCMAES<TESOStrategy>::vInitialize(time_t tStartTime)
{
	v_clear_cmaes();
	v_create_cmaes();

	pc_cmaes->init();
}//void CCMAES<TESOStrategy>::vInitialize(time_t tStartTime)

template <class TESOStrategy>
bool CCMAES<TESOStrategy>::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)
{
	pc_cmaes->run_iteration();

	bool b_updated = b_update_best_individual(iIterationNumber, tStartTime);

	CString s_log_message;

	s_log_message.Format
	(
		"iteration: %u; time: %u; ffe: %u; best: %f",
		iIterationNumber,
		(uint32_t)(time(nullptr) - tStartTime),
		pc_problem->pcGetEvaluation()->iGetFFE(),
		pc_best_individual->dGetFitnessValue()
	);//s_log_message.Format

	pc_log->vPrintLine(s_log_message, true);

	return b_updated;
}//bool CCMAES<TESOStrategy>::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

template <class TESOStrategy>
void CCMAES<TESOStrategy>::v_init()
{
	pc_cmaes = nullptr;

	CRealCoding *pc_candidate_genotype = pc_problem->pcGetEvaluation()->pcCreateSampleFenotype();
	pc_candidate_genotype->vSetValues(new double[pc_candidate_genotype->iGetNumberOfDimensions()], true);

	pc_candidate_individual = new CIndividual<CRealCoding, CRealCoding>(pc_candidate_genotype, pc_problem);
}//void CCMAES<TESOStrategy>::v_init()

template <class TESOStrategy>
void CCMAES<TESOStrategy>::v_create_cmaes()
{
	CRealCoding *pc_sample_genotype = pc_problem->pcGetEvaluation()->pcCreateSampleFenotype();

	CRealRandomGeneration c_random_generation(pc_sample_genotype);
	CRealCoding *pc_random_genotype = c_random_generation.pcGenerate();

	GenoPheno<pwqBoundStrategy> c_geno_pheno
	(
		pc_random_genotype->pdGetMinValues(), 
		pc_random_genotype->pdGetMaxValues(), 
		pc_random_genotype->iGetNumberOfDimensions()
	);//GenoPheno<pwqBoundStrategy> c_geno_pheno

	double d_sigma = (double)f_sigma;

	CMAParameters<GenoPheno<pwqBoundStrategy>> c_parameters
	(
		pc_random_genotype->iGetNumberOfDimensions(),
		pc_random_genotype->pdGetValues(),
		f_sigma, -1, i_random_seed, c_geno_pheno
	);//CMAParameters<GenoPheno< pwqBoundStrategy>> c_parameters

	c_parameters.set_logger(pc_log);

	c_parameters.set_max_fevals(INT_MAX);
	c_parameters.set_max_iter(INT_MAX);

	if (b_is_sep)
	{
		c_parameters.set_sep();
	}//if (b_is_sep)

	if (b_is_vd)
	{
		c_parameters.set_algo(VD_CMAES);
		c_parameters.set_vd();
	}//if (b_is_vd)

	FitFunc f_fitness = [&](const double *pdValues, const int iNumberOfDimensions)
	{
		CRealCoding *pc_candidate_genotype = pc_candidate_individual->pcGetGenotype();

		for (int i = 0; i < iNumberOfDimensions; i++)
		{
			*(pc_candidate_genotype->pdGetValues() + i) = *(pdValues + i);
		}//for (int i = 0; i < iNumberOfDimensions; i++)

		return -pc_problem->pcGetEvaluation()->dEvaluate(pc_candidate_genotype);
	};//FitFunc f_fitness = [&](const double *pdValues, const int iNumberOfDimensions)

	pc_cmaes = new ESOptimizer<TESOStrategy, CMAParameters<GenoPheno<pwqBoundStrategy>>>(f_fitness, c_parameters);

	delete pc_sample_genotype;
	delete pc_random_genotype;
}//void CCMAES<TESOStrategy>::v_create_cmaes()

template <class TESOStrategy>
void CCMAES<TESOStrategy>::v_clear_cmaes()
{
	delete pc_cmaes;
}//void CCMAES<TESOStrategy>::v_clear_cmaes()

template <class TESOStrategy>
bool CCMAES<TESOStrategy>::b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime)
{
	CMASolutions &c_best_solution = pc_cmaes->get_solutions();

	for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	{
		*(pc_candidate_individual->pcGetGenotype()->pdGetValues() + i) = *(c_best_solution.best_candidate().get_x_ptr() + i);
	}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)

	pc_candidate_individual->vSetFitnessValue(-c_best_solution.best_candidate().get_fvalue());

	return b_update_best_individual(iIterationNumber, tStartTime, pc_candidate_individual);
}//bool CCMAES<TESOStrategy>::b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime)

template class CCMAES<CMAStrategy<CovarianceUpdate, GenoPheno<pwqBoundStrategy>>>;
template class CCMAES<IPOPCMAStrategy<CovarianceUpdate, GenoPheno<pwqBoundStrategy>>>;
template class CCMAES<BIPOPCMAStrategy<CovarianceUpdate, GenoPheno<pwqBoundStrategy>>>;
template class CCMAES<CMAStrategy<ACovarianceUpdate, GenoPheno<pwqBoundStrategy>>>;
template class CCMAES<IPOPCMAStrategy<ACovarianceUpdate, GenoPheno<pwqBoundStrategy>>>;
template class CCMAES<BIPOPCMAStrategy<ACovarianceUpdate, GenoPheno<pwqBoundStrategy>>>;
template class CCMAES<CMAStrategy<VDCMAUpdate, GenoPheno<pwqBoundStrategy>>>;
template class CCMAES<IPOPCMAStrategy<VDCMAUpdate, GenoPheno<pwqBoundStrategy>>>;
template class CCMAES<BIPOPCMAStrategy<VDCMAUpdate, GenoPheno<pwqBoundStrategy>>>;