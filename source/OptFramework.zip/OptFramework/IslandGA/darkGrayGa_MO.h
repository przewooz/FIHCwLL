#ifndef CDARK_GRAY_GA_MO_OPTIMIZER_H
#define CDARK_GRAY_GA_MO_OPTIMIZER_H


#include "MultiObjectiveOptimizer.h"
#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "CommandParam.h"
#include "Error.h"
#include "Log.h"
#include "MathUtils.h"
#include "Optimizer.h"
#include "Problem.h"
#include "Individual.h"
#include  "util\timer.h"
#include  "util\tools.h"
#include "PopulationSizingOptimizer.h"



//#include <istream>
//#include <algorithm>



#define MO_DLED__EPISTASIS__PERCENTAGE			 "{MO_DLED__EPISTASIS__PERCENTAGE}"
#define MO_DLED__EPISTASIS__NUMBER				 "{MO_DLED__EPISTASIS__NUMBER}"

#define MO_DLED__DEP_TYPE__COMPLETE__PERCENTAGE	 "{MO_DLED__DEP_TYPE__COMPLETE__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__COMPLETE__NUMBER		 "{MO_DLED__DEP_TYPE__COMPLETE__NUMBER}"
#define MO_DLED__DEP_TYPE__LEFT__PERCENTAGE		 "{MO_DLED__DEP_TYPE__LEFT__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__LEFT__NUMBER			 "{MO_DLED__DEP_TYPE__LEFT__NUMBER}"
#define MO_DLED__DEP_TYPE__RIGHT__PERCENTAGE	 "{MO_DLED__DEP_TYPE__RIGHT__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__RIGHT__NUMBER		 "{MO_DLED__DEP_TYPE__RIGHT__NUMBER}"
#define MO_DLED__DEP_TYPE__LEFT_RIGHT__PERCENTAGE		 "{MO_DLED__DEP_TYPE__LEFT_RIGHT__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__LEFT_RIGHT__NUMBER			 "{MO_DLED__DEP_TYPE__LEFT_RIGHT__NUMBER}"
#define MO_DLED__DEP_TYPE__MIDDLE__PERCENTAGE	 "{MO_DLED__DEP_TYPE__MIDDLE__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__MIDDLE__NUMBER		 "{MO_DLED__DEP_TYPE__MIDDLE__NUMBER}"

#define MO_DLED__RANGES__1_PERCENTAGE		 "{MO_DLED__RANGES__1_PERCENTAGE}"
#define MO_DLED__RANGES__1_NUMBER			 "{MO_DLED__RANGES__1_NUMBER}"
#define MO_DLED__RANGES__2_PERCENTAGE		 "{MO_DLED__RANGES__2_PERCENTAGE}"
#define MO_DLED__RANGES__2_NUMBER			 "{MO_DLED__RANGES__2_NUMBER}"
#define MO_DLED__RANGES__3_PERCENTAGE		 "{MO_DLED__RANGES__3_PERCENTAGE}"
#define MO_DLED__RANGES__3_NUMBER			 "{MO_DLED__RANGES__3_NUMBER}"
#define MO_DLED__RANGES__4_PERCENTAGE		 "{MO_DLED__RANGES__4_PERCENTAGE}"
#define MO_DLED__RANGES__4_NUMBER			 "{MO_DLED__RANGES__4_NUMBER}"
#define MO_DLED__RANGES__5_PERCENTAGE		 "{MO_DLED__RANGES__5_PERCENTAGE}"
#define MO_DLED__RANGES__5_NUMBER			 "{MO_DLED__RANGES__5_NUMBER}"
#define MO_DLED__RANGES__MORE_PERCENTAGE		 "{MO_DLED__RANGES__MORE_PERCENTAGE}"
#define MO_DLED__RANGES__MORE_NUMBER			 "{MO_DLED__RANGES__MORE_NUMBER}"


#define MO_DLED__COVERAGE__100perc_COVERAGE_NUMBER			 "{MO_DLED__COVERAGE__100perc_COVERAGE_NUMBER}"
#define MO_DLED__COVERAGE__100perc_COVERAGE_PERCENTAGE		 "{MO_DLED__COVERAGE__100perc_COVERAGE_PERCENTAGE}"

#define MO_DLED__COVERAGE__AVR								 "{MO_DLED__COVERAGE__AVR}"
#define MO_DLED__COVERAGE__ST_DEV							 "{MO_DLED__COVERAGE__ST_DEV}"
#define MO_DLED__COVERAGE__MEDIAN						     "{MO_DLED__COVERAGE__MEDIAN}"




namespace nDarkGrayGA_MO
{
	class  CDarkGrayGASinglePop_MO;
	class  CDarkGrayGAIndividual_MO;
	class  CDarkGA_DSM_MO;
	class  CDarkGrayGAPxMaskManager_MO;
	class  CDarkGrayGAPxMask_MO;
	class  CDarkGA_DSM_MO_Dependency_Set;
	class  CDarkGA_DSM_MO_Dependency;
	class  CShiftVectorManager;
	class  CShiftVectorRange;

	#define  s_OPTIMIZER_DARK_GA_MO_POP_SCHEME			"popScheme(0-P3like; 1-GA-like)"
	#define  s_OPTIMIZER_DARK_GA_MO_DONOR_IMPROVEMENT  "DonorImprovement"
	#define  s_OPTIMIZER_DARK_GA_MO_PERFECT_LINKAGE	"PerfectLinkage"
	#define  s_OPTIMIZER_DARK_GA_MO_GLOBAL_BEST_IMPROVEMENT	"GlobalBestImprovement"
	#define  s_OPTIMIZER_DARK_GA_MO_GLOBAL_BEST_LIMIT	"GlobalBestLimit (0=unlimited bestPop size)"
	#define  s_OPTIMIZER_DARK_GA_MO_GLOBAL_BEST_POP_RUN	"GlobalBestPopRun"
	#define  s_OPTIMIZER_DARK_GA_MO_UNIFORM_CROSSOVER_FOR_SLIDE	"UniformCrossoverForSlide"
	#define  s_OPTIMIZER_DARK_GA_MO__MO_DLED			"MO_DLED(0-Off;1-On)"
	#define  s_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY		"VectorChooseStrategy(0-Off;1-On;2-ShiftVectors)"
	#define  s_OPTIMIZER_DARK_GA_MO__IMPROVE_BESTS		"ImproveBests(0-Off;1-On)"
	


	#define  i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__STATIC		0
	#define  i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__RANDOM_VECTORS		1
	#define  i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__SHIFT_VECTORS		2
	class CDarkGrayGA_MO : public CBinaryMultiObjectiveOptimizer  //CBinaryOptimizer
	{
		friend class CDarkGrayGAIndividual_MO;
		friend class CDarkGA_DSM_MO;
	public:
		static uint32_t iERROR_PARENT_CDarkGrayGA_MO;
		static uint32_t iERROR_CODE_DARK_GRAY_GA_MO_GENOTYPE_LEN_BELOW_0;


		CDarkGrayGA_MO(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
		CDarkGrayGA_MO(CDarkGrayGA_MO *pcOther);
		~CDarkGrayGA_MO();

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CDarkGrayGA_MO(this); };
		virtual bool bRunIteration(uint32_t iIterationNumber) override;
		virtual bool bRunIteration_P3(uint32_t iIterationNumber);
		virtual bool bRunIteration_sGA(uint32_t iIterationNumber);

		virtual CError eConfigure(istream *psSettings) override;
		virtual void vInitialize() override;


		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo();
		CString  sLinkageSummaryReport();

		double dComputeFitness(int32_t *piBits);


		CDarkGrayGAIndividual_MO  *pcGetBest();
		void  vInsertToBestPop(CDarkGrayGAIndividual_MO  *pcNewInd);
		void  vInsertToBestPop(CDarkGrayGASinglePop_MO  *pcSinglePop);

		CDarkGA_DSM_MO  *pcGetDSM() { return(pc_dsm); };


		int  iP3GetPyramidIndNumber();
		int  iGetPopLevel(CDarkGrayGASinglePop_MO  *pcPopToCheck);

	private:
		bool  b_p3_add_to_level(int iLevel, CDarkGrayGAIndividual_MO *pcIndToAdd);
		bool b_p3_the_same_exists(CDarkGrayGAIndividual_MO *pcIndToAdd);
		void  v_global_best_improvement();
		void  v_global_best_pop_run();

		CTimeCounter  c_time_counter;
		double  d_time_last_time;

		int  i_sett_pop_scheme;
		int  i_sett_mo_dled;
		int  i_vector_choose_strategy;
		int  i_improve_bests;
		int  i_sett_donor_improvement;
		int  i_sett_perfect_linkage;
		int  i_sett_global_best_improvement;
		int  i_sett_global_number_limit;
		int  i_sett_global_best_pop_run;

		int  i_sett_uniform_crossover_for_slide;

		int  i_next_pop_size;
		vector<CDarkGrayGASinglePop_MO *> v_pyramid;
		vector<CDarkGrayGASinglePop_MO *> v_pop_running, v_pops_obsolete;

		CDarkGrayGASinglePop_MO  *pc_base_pop;
		CDarkGrayGASinglePop_MO  *pc_best_pop;
		CDarkGrayGASinglePop_MO  *pc_best_climbing_pop;
		//CDarkGrayGAIndividual  *pc_best;

		CShiftVectorManager  *pc_shift_vec_manager;
		
		CDarkGA_DSM_MO  *pc_dsm;
		int  i_pop_size;
		int  i_templ_length;
	};//class CDarkGrayGA_MO : public CBinaryOptimizer	*/



	class CDarkGrayGASinglePop_MO : public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>
	{
		friend class CDarkGrayGA_MO;
		friend class CDarkGrayGAIndividual_MO;
	public:
		static uint32_t iERROR_PARENT_CDarkGrayGA_MO_SinglePop;
		static uint32_t iERROR_CODE_DARK_GRAY_GA_MO_GENOTYPE_LEN_BELOW_0;


		CDarkGrayGASinglePop_MO(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed, CDarkGrayGA_MO  *pcParent);
		CDarkGrayGASinglePop_MO(CDarkGrayGASinglePop_MO *pcOther);
		~CDarkGrayGASinglePop_MO();

		void  vCopyFrom(CDarkGrayGASinglePop_MO *pcOther);

		COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() override;
		virtual bool bRunIteration(uint32_t iIterationNumber) override;
		bool bRunIterationForceCross(uint32_t iIterationNumber);
		bool bRunIterationMaskLen(uint32_t iIterationNumber);
		bool bRunIteration_sGA(uint32_t iIterationNumber);

		bool  bDonateToIndividual(CDarkGrayGAIndividual_MO  *pcReceiver);
		int  iDonateToIndividual_PxByLen(CDarkGrayGAIndividual_MO  *pcReceiver, bool bUseDomination = false, vector<CDarkGrayGAIndividual_MO *> *pvPopToBeDifferentFrom = NULL);

		virtual CError eConfigure(istream *psSettings) override;
		virtual void vInitialize() override;

		bool bIsSteadyState() override;
		double dComputeAverageFitnessValue() override;

		uint32_t iGetPopulationSize() override { return i_pop_size; }
		void vSetPopulationSize(uint32_t iPopulationSize) override { i_pop_size = iPopulationSize; };

		void  vGetGenotypeBufferTools(int  **piTool_0, int  **piTool_1);


		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo();


		void  vRecalculateForNewWeights();
		double dComputeFitness(int32_t *piBits);
		double dComputeFitnessDouble(int32_t *piBits);

		void  vExcludeDominated();


		CDarkGrayGAIndividual_MO  *pcGetBest() { return(pc_best); };

		CDarkGA_DSM_MO  *pcGetDSM() { return(pc_dsm); };

		CDarkGrayGAPxMaskManager_MO  *pcGetPxMasksManager() { return(pc_px_masks_manager); }

		void  vSavePopTest();


	private:
		
		double d_evaluate(int32_t *piBits);
		double d_evaluate_double(int32_t *piBits);
		CDarkGrayGAIndividual_MO* pc_get_random_individual();

		CDarkGrayGA_MO  *pc_parent;

		bool  b_steady_state;
		CTimeCounter  c_time_counter;
		double  d_time_last_time;
		CIndividual<CBinaryCoding, CBinaryCoding> *pc_evaluation_individual;
		CDarkGrayGAIndividual_MO *pc_individual_buffer;
		int  *pi_genotope_buffer_tool_0, *pi_genotope_buffer_tool_1;

		int  i_slide_number;
		int  i_uniform_donations;

		vector<CDarkGrayGAIndividual_MO *> v_pop, v_pop_copy;

		CDarkGrayGAPxMaskManager_MO  *pc_px_masks_manager;
		
		CDarkGrayGAIndividual_MO  *pc_best;

		CDarkGA_DSM_MO  *pc_dsm;
		int  i_pop_size;
		int  i_templ_length;
	};//class CDarkGrayGASinglePop : public CBinaryOptimizer	



	#define  i_OPTIMIZER_DARK_GA_MO_DSM__MO_DLED_OFF   0
	#define  i_OPTIMIZER_DARK_GA_MO_DSM__MO_DLED_ON    1
	class  CDarkGA_DSM_MO 
	{
	public:
		CDarkGA_DSM_MO(CDarkGrayGA_MO  *pcParent);
		~CDarkGA_DSM_MO();

		void  vSetMO_Dled(int  iNewMO_Dled);
		int  iGetMO_Dled() { return(i_sett_mo_dled); }

		bool  bSetSize(int  iProbSize);

		CString  sLinkageSummaryReport();
		bool  bGetTrueLinkage(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem);
		void  vDarkGrayMapDependentGenes(int  iGeneOffset, int  *piMask);

		int  iRebuildDSM_ForVectors(double  dVec0, double dVec1);
		void  vUpdateDSM(CDarkGrayGAPxMask_MO  *pcMask);

		int  **piGetDSM() { return(pi_dsm); }

		bool  bSave(CString  sDest);
		bool  bSave(FILE  *pfDest);

		void  vSaveDepRanges(CString  sDest);
		void  vSaveDepRanges(FILE  *pfDest);

		void  vTest();

		CString  sGet_MO_Dled_Stats();

	private:
		void  v_extract_dled_for_gene_pair(int  iGeneContext, int iGeneBlock, int  *piDledExtractionMask, CDarkGrayGAIndividual_MO  *pcExtractionIndividual, int *piNewPairsDetected);
		bool  b_check_if_true_linkage(int iGeneBlock, int  iGeneContext);
		bool  b_new_dep_range_try_add(CDarkGA_DSM_MO_Dependency  *pcNewDependency);
		void  v_zero_dsm();

		CString  s_mo_dled_stats__epistasis();
		CString  s_mo_dled_stats__dep_type();
		CString  s_mo_dled_stats__ranges();
		CString  s_mo_dled_stats__coverage();
				
		int		 i_mo_dled__get_pairs_number();

		int  i_sett_mo_dled;

		int  **pi_dsm;
		int  i_prob_size;
		CDarkGrayGAIndividual_MO  *pc_individual_tool;

		int  i_cost_ffe;
		double  d_cost_time;

		CDarkGrayGA_MO  *pc_parent;

		CDarkGA_DSM_MO_Dependency_Set  ***pc_dependency_sets;
		//vector<CDarkGA_DSM_MO_Dependency *>  v_dependency_ranges;	

		double  d_vec_w0;
		double  d_vec_w1;
	};//class  CDargGA_DSM_MO



	#define   i_VECTOR_MANAGER_STRATEGY__POINT_IN_RANGE		0
	#define   i_VECTOR_MANAGER_STRATEGY__SHRINKING_EDGES	1
	class  CShiftVectorManager
	{
	public:
		CShiftVectorManager() { i_weights_choose_startegy = i_VECTOR_MANAGER_STRATEGY__SHRINKING_EDGES; };

		bool  bGetWeights(double  *pdVec0, double  *pdVec1);
		void  vUpdateAvailableRanges(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1);

		CString  sToStr();

	private: 
		bool  bGetWeights_random_point_in_range(double  *pdVec0, double  *pdVec1);
		bool  bGetWeights_shrinking_edges(double  *pdVec0, double  *pdVec1);

		void  vUpdateAvailableRanges__random_point_in_range(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1);
		void  vUpdateAvailableRanges__shrinking_edges(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1);


		vector<CShiftVectorRange  *>  v_shift_vec_ranges;
		int  i_weights_choose_startegy;
	};//class  CShiftVectorManager


	class  CShiftVectorRange
	{
	public:
		CShiftVectorRange(double dStart, bool bStartIncluded, double dEnd, bool bEndIncluded) { d_start = dStart;  d_end = dEnd; b_start_included = bStartIncluded; b_end_included = bEndIncluded; };
		CShiftVectorRange() { d_start = d_end = 0; b_start_included = b_end_included = false; };

		bool  bInRange(double  dVec0);
		double  dGetValueInRange();

		CString  sToStr();


		bool  b_start_included;
		bool  b_end_included;
		double  d_start;
		double  d_end;	
	};//class  CShiftVectorRange


	#define   i_MO_DEPENDENCY_TYPE__NONE			0
	#define   i_MO_DEPENDENCY_TYPE__COMPLETE		1
	#define   i_MO_DEPENDENCY_TYPE__LEFT			2
	#define   i_MO_DEPENDENCY_TYPE__RIGHT			3
	#define   i_MO_DEPENDENCY_TYPE__LEFT_RIGHT		4
	#define   i_MO_DEPENDENCY_TYPE__MIDDLE			5
	class  CDarkGA_DSM_MO_Dependency_Set
	{
	public:
		CDarkGA_DSM_MO_Dependency_Set(int  iGene0, int iGene1) {i_gene_0 = iGene0; i_gene_1 = iGene1;};
		~CDarkGA_DSM_MO_Dependency_Set();

		bool  bAddNewDependency(CDarkGA_DSM_MO_Dependency *);
		bool  bInRange(double  dVec0, double  dVec1);

		int  iGetMODependencyType();
		double  dCoverage();
		vector<CDarkGA_DSM_MO_Dependency *>  *pvGet_DependencyNumber() { return(&v_dependency_set); };

		CString  sToStr();

	private:
		bool  b_old_dep_contained(CDarkGA_DSM_MO_Dependency *pcNewDep);
		bool  b_new_dep_contained(CDarkGA_DSM_MO_Dependency *pcNewDep);
		bool  b_new_dep_join(CDarkGA_DSM_MO_Dependency *pcNewDep);

				
		vector<CDarkGA_DSM_MO_Dependency *>  v_dependency_set;
		int  i_gene_0;
		int  i_gene_1;
	};//class  CDarkGA_DSM_MO_Dependency_Set



	class  CDarkGA_DSM_MO_Dependency
	{
	public:
		CDarkGA_DSM_MO_Dependency() { d_start = d_end = 0; b_start_included = b_end_included = false; i_gene_0 = i_gene_1 = -1; };

		bool  bExtractRange
			(
				int  iPosStart, int  *piPosEnd,
				vector<double>  *pvZeroPoints,
				double  d_0_bo_c, double  d_0_ba_c, double  d_0_co_b, double  d_0_ca_b,
				double  d_1_bo_c, double  d_1_ba_c, double  d_1_co_b, double  d_1_ca_b
			);

		bool  b_check_dependency
			(
				double  d_w0, double  d_w1,
				double  d_0_bo_c, double  d_0_ba_c, double  d_0_co_b, double  d_0_ca_b,
				double  d_1_bo_c, double  d_1_ba_c, double  d_1_co_b, double  d_1_ca_b
			);

		bool  bInRange(double  dVec0);
		bool  bInRange(double  dVec0, double  dVec1);

		bool  bContained(CDarkGA_DSM_MO_Dependency  *pcOther);
		bool  bContained_RangeStartEnd(double  dRange_StartEnd, bool  bStartEnd_included, bool bStart);

		bool  bJoin(CDarkGA_DSM_MO_Dependency  *pcOther);
		
		double  dCoverage() { return(d_end - d_start); };
		CString  sToStr(bool  bShowGeneNumber = true);


		bool  b_start_included;
		bool  b_end_included;
		double  d_start;
		double  d_end;

		int  i_gene_0;
		int  i_gene_1;			
	};//class  CDarkGA_DSM_MO_Dependency


	class  CDarkGrayGAPxMaskManager_MO
	{
	public:
		CDarkGrayGAPxMaskManager_MO();
		~CDarkGrayGAPxMaskManager_MO();

		void  vClear();

		void  vReport(CString  sDest);
		void  vReport(FILE  *pfDest);
		CDarkGrayGAPxMask_MO  *pcGetNewPxMask();

		void  vShuffle();
		void  vSortByLength();

		int  iGetSize() { return(v_masks.size()); };
		CDarkGrayGAPxMask_MO  *pcGetAt(int iOffset);

	private:
		vector<CDarkGrayGAPxMask_MO *>  v_masks;
		vector<CDarkGrayGAPxMask_MO *>  v_masks_buffered;
		
	};//class  CDarkGrayGAPxMaskManager_MO


	class CDarkGrayGAPxMask_MO
	{
	public:
		CDarkGrayGAPxMask_MO() { };

		void  vClear() { v_mask.clear();  pc_parent_0 = NULL; pc_parent_1 = NULL; }
		void  vReport(CString  sDest);
		void  vReport(FILE  *pfDest);

		CString  sToStr();

		CDarkGrayGAIndividual_MO  *pcGetOtherInd(CDarkGrayGAIndividual_MO  *pcOtherThanThisOne);
		bool  bDoICContain(CDarkGrayGAIndividual_MO  *pcOtherThanThisOne);

		vector<int> v_mask;
		CDarkGrayGAIndividual_MO  *pc_parent_0;
		CDarkGrayGAIndividual_MO  *pc_parent_1;
	};//class CDarkGrayGAPxMask



	class  CDarkGrayGAIndividual_MO : public  CMultiIndividual
	{
		friend class CDarkGrayGA_MO;
		friend class CDarkGrayGASinglePop_MO;
		friend class CDarkGrayGAPxMask_MO;
		friend class CDarkGA_DSM_MO;
	public:
		//CDarkGrayGAIndividual_MO(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CDarkGrayGASinglePop_MO *pcParent);
		CDarkGrayGAIndividual_MO(int  iTemplLength, CBinaryMultiObjectiveProblem *pcProblem, CDarkGrayGASinglePop_MO *pcParent);
		CDarkGrayGAIndividual_MO(CDarkGrayGAIndividual_MO &pcOther);
		~CDarkGrayGAIndividual_MO();

		bool  bIsTheSame(CDarkGrayGAIndividual_MO  *pcOther);
		double  dGetSimilarity(CDarkGrayGAIndividual_MO  *pcOther, int  *piGenesTheSame);
		void  vRandomizeGenotype();
		int*  piGetGenotype() { return(pc_genotype->piGetBits()); }

		int  iGetPopLevel();


		int   iMixing_ePX(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult);
		int   iMixing_ePX_Brutal(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult);

		void  vGetPxMasks(CDarkGrayGAIndividual_MO  *pcOther, CDarkGrayGAPxMaskManager_MO  *pcMasksManager);
		int   iMixing_ePX_ByMaskLen(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult, bool bUseDomination, vector<CDarkGrayGAIndividual_MO *> *pvPopToBeDifferentFrom = NULL);
		int   iMixing_PX_ByMask(CDarkGrayGAPxMask_MO *pcMask, CDarkGrayGAIndividual_MO  *pcResult, bool bUseDomination);
		int   iUniformCrossoverByMask(CDarkGrayGAPxMask_MO *pcMask, CDarkGrayGAIndividual_MO  *pcResult);

		int   iMixing_ePX_ByDonor(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult);
		int   iMixing_ePX_ByDonor(CDarkGrayGAIndividual_MO *pcDonor, CDarkGrayGAIndividual_MO  *pcResult);
		int   iMixing_ePX_Pair(CDarkGrayGAIndividual_MO *pcOther, CDarkGrayGAIndividual_MO  *pcResult);
		void  vEpxMaskCompute(int  iGeneToCross, CDarkGrayGAIndividual_MO *pcReceiver);
		bool  bEpxMaskCanICross();
		int   iEpxMaskPositionsExchanged() { return(i_epx_mask_positions_exchanged); };
		int   iEpxMaskPositionsRemainDiffering() { return(i_epx_mask_positions_remain_differing); };
		int   iEpxDonateByMask(CDarkGrayGAIndividual_MO *pcReceiver, CDarkGrayGAIndividual_MO *pcResult);

		void  vCopyFrom(CDarkGrayGAIndividual_MO  *pcNewInd);

		double  dComputeFitness();
		void  vRecalculateForNewWeights();
		double  dComputeFitnessDouble();
		double  dComputeFitnessOptimize(vector<int>  *pvOrder = NULL, bool  bDarkGray = false, int  *piDarkGrayModifiedGenes = NULL);


		void  vClearOptOrder() { v_opt_order.clear(); }

		virtual CMultiIndividual  *pcClone();
		bool  bCheckTest();

		CString  sToStr();
		CString  sEpxToStr();

	private:
		void  v_epx_mask_extend_at_level(int  iLevelToExplode, CDarkGrayGAIndividual_MO *pcReceiver);

		void  v_create_opt_order(vector<int>  *pvOrder);
		double  d_optimize_single_gene(int  iOptGene);

		bool  b_get_all_epx_masks(int  *piMasksManager, int  *piMasksNum, CDarkGrayGAIndividual_MO  *pcDonor);



		CDarkGrayGASinglePop_MO  *pc_parent;
		int  i_templ_length;
		//int  *pi_genotype;
		vector<int>  v_opt_order;

		int  *pi_epx_mask;
		bool  b_epx_mask_can_cross;
		int   i_epx_mask_positions_exchanged;
		int   i_epx_mask_positions_remain_differing;

		double  d_fitnes_buf;
		bool  b_fitness_actual;

		//CProblem<CBinaryCoding, CBinaryCoding > *pc_problem;
	};//class  CDarkGrayGAIndividual

}//namespace nDarkGrayGA

#endif//CDARK_GRAY_GA_MO_OPTIMIZER_H
