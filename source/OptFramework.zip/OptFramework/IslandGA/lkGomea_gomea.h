#pragma once

#include <string> 
#include <iostream>
using namespace std;

#include "lkGomea_Config.h"
#include "lkGomea_Individual.h"
#include "lkGomea_shared.h"
#include "lkGomea_problems.h"

class C_lkGomea_GOMEA
{
public:
	C_lkGomea_Config *config;
	C_lkGomea_Problem *problemInstance = NULL;
	C_lkGomea_sharedInformation *sharedInformationInstance = NULL;
	
	C_lkGomea_GOMEA(C_lkGomea_Config *config_): config(config_){};
	virtual ~C_lkGomea_GOMEA(){};

	virtual bool b_run() = 0;
	double readVTR();
};