#pragma once
using namespace std;

#include "lkGomea_Config.h"
#include "lkGomea_Individual.h"
#include "lkGomea_shared.h"

//prw added include:
#include "lkGomea_problems.h"

class C_lkGomea_Linkup
{
private:
	C_lkGomea_Config *config;
	C_lkGomea_sharedInformation *info;
	C_lkGomea_Problem *problem;

    // Greedy relinking that changes a bit and takes any distance reduction,
    // as long as it is not a hill -- a solution with worse fitness than both from and to.
    // Distance is defined by hamming distance.
    // If no other choice exists than to traverse a hill, false is returned.
    // Otherwise relinking succeeds and true is returned.
    bool relink_forward_greedy(C_lkGomea_Individual *from, C_lkGomea_Individual *to,  bool  *pbTimeLimitOK);

    // Relinking that traverses the entire bitflip neighborhood and picks the solution with
    // highest fitness.
    // Distance is defined by hamming distance.
    // Progress is made as long as it is not a hill -- a solution with worse fitness than both from and to.
    // If no other choice exists than to traverse a hill, false is returned.
    // Otherwise relinking eventually arrives at to and true is returned.
    bool relink_forward_best(C_lkGomea_Individual *from, C_lkGomea_Individual *to, bool  *pbTimeLimitOK);

public:
	C_lkGomea_Linkup(C_lkGomea_Config *config_, C_lkGomea_sharedInformation *info_, C_lkGomea_Problem *problem_);
    ~C_lkGomea_Linkup();
    bool relink(C_lkGomea_Individual *from, C_lkGomea_Individual *to, bool  *pbTimeLimitOK);

    bool  b_evaluateSolution(C_lkGomea_Individual *new_solution, C_lkGomea_Individual *orig_solution, vector<int> &changedGenes);
    void checkVTR(C_lkGomea_Individual *solution);
	bool b_checkTimeLimit_OK();
    //void checkTimeLimit();
};