#pragma once

#include <vector>
#include <unordered_map>
using namespace std;

#include "lkGomea_utils.h"
//#include "time.hpp"

struct C_lkGomea_sharedInformation
{
	double numberOfEvaluations, numberOfSurrogateEvaluations;
	long long startTimeMilliseconds;
	double elitistSolutionHittingTimeMilliseconds,
	       elitistSolutionHittingTimeEvaluations;

	C_lkGomea_Individual elitist;
	double inherentElitistFitness;
	C_lkGomea_solutionsArchive *evaluatedSolutions;
	C_lkGomea_solutionsArchive *vtrUniqueSolutions;
	bool firstEvaluationEver;
	double percentileThreshold;
	C_lkGomea_Pyramid *pyramid;
	
	C_lkGomea_sharedInformation(int maxArchiveSize)
	{
		numberOfEvaluations = 0;
		//startTimeMilliseconds = getCurrentTimeStampInMilliSeconds();
		startTimeMilliseconds = 0;
		firstEvaluationEver = true;
		inherentElitistFitness = INFINITY;
		evaluatedSolutions = new C_lkGomea_solutionsArchive(maxArchiveSize);
		vtrUniqueSolutions = new C_lkGomea_solutionsArchive(INT_MAX);
		pyramid = new C_lkGomea_Pyramid();
		//all_graphs.resize(1);
	}

	~C_lkGomea_sharedInformation()
	{
		delete evaluatedSolutions;
		delete vtrUniqueSolutions;
		delete pyramid;
	}
};