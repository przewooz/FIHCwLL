#include "IntegralSensorChangeDetector.h"

#include "FloatCommandParam.h"
#include "MathUtils.h"
#include "UIntCommandParam.h"

#include <cmath>

using namespace ChangeDetector;

CIntegralSensorChangeDetector::CIntegralSensorChangeDetector(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: CSensorChangeDetector<CRealCoding, CRealCoding>(pcProblem, pcLog, iRandomSeed)
{
	pd_integral_values = nullptr;
}//CIntegralSensorChangeDetector::CIntegralSensorChangeDetector(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

CIntegralSensorChangeDetector::~CIntegralSensorChangeDetector()
{
	v_clear_integral_values();
}//CIntegralSensorChangeDetector::~CIntegralSensorChangeDetector()

void CIntegralSensorChangeDetector::v_clear_integral_values()
{
	delete pd_integral_values;
	pd_integral_values = nullptr;
}//void CIntegralSensorChangeDetector::v_clear_integral_values()

CError CIntegralSensorChangeDetector::eConfigure(istream *psSettings)
{
	v_clear_integral_values();

	CError c_error = CSensorChangeDetector<CRealCoding, CRealCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_number_of_integral_samples(INTEGRAL_SENSOR_CHANGE_DETECTOR_ARGUMENT_NUMBER_OF_INTEGRAL_SAMPLES, 1, UINT32_MAX);
		i_number_of_integral_samples = p_number_of_integral_samples.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_integral_width(INTEGRAL_SENSOR_CHANGE_DETECTOR_ARGUMENT_INTEGRAL_WIDTH);
		d_integral_width = (double)p_integral_width.fGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_integral_height(INTEGRAL_SENSOR_CHANGE_DETECTOR_ARGUMENT_INTEGRAL_HEIGHT);
		d_integral_height = (double)p_integral_height.fGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_integral_epsilon(INTEGRAL_SENSOR_CHANGE_DETECTOR_ARGUMENT_INTEGRAL_EPSILON);
		d_integral_epsilon = (double)p_integral_epsilon.fGetValue(psSettings, &c_error);
	}//if (!c_error)

	return c_error;
}//CError CIntegralSensorChangeDetector::eConfigure(istream *psSettings)

void CIntegralSensorChangeDetector::vInitialize()
{
	CSensorChangeDetector<CRealCoding, CRealCoding>::vInitialize();

	v_clear_integral_values();

	pd_integral_values = new double[i_number_of_sensors];

	for (uint32_t i = 0; i < i_number_of_sensors; i++)
	{
		*(pd_integral_values + i) = d_calculate_integral(*(ppc_sensors + i));
	}//for (uint32_t i = 0; i < i_number_of_sensors; i++)
}//void CIntegralSensorChangeDetector::vInitialize()

bool CIntegralSensorChangeDetector::b_detect_change()
{
	bool b_change_detected = CSensorChangeDetector<CRealCoding, CRealCoding>::b_detect_change();

	if (b_change_detected)
	{
		cout << "sensor" << endl;
	}//if (b_change_detected)

	CIndividual<CRealCoding, CRealCoding> *pc_sensor;

	double d_previous_integral_value, d_current_integral_value;

	CString s_integral_values;

	for (uint32_t i = 0; i < i_number_of_sensors; i++)
	{
		pc_sensor = *(ppc_sensors + i);

		d_previous_integral_value = *(pd_integral_values + i);
		d_current_integral_value = d_calculate_integral(pc_sensor);
		*(pd_integral_values + i) = d_current_integral_value;

		s_integral_values.AppendFormat("%f\t", d_current_integral_value);

		b_change_detected |= abs(d_current_integral_value - d_previous_integral_value) > d_integral_epsilon;

		if (abs(d_current_integral_value - d_previous_integral_value) > d_integral_epsilon)
		{
			cout << abs(d_current_integral_value - d_previous_integral_value) << endl;
		}
	}//for (uint32_t i = 0; i < i_number_of_sensors; i++)

	pc_log->vPrintLine(s_integral_values);

	return b_change_detected;
}//bool CIntegralSensorChangeDetector::b_detect_change()

double CIntegralSensorChangeDetector::d_calculate_integral(CIndividual<CRealCoding, CRealCoding> *pcSensor)
{
	double d_half_integral_width = d_integral_width / 2;
	double d_half_integral_height = d_integral_height / 2;

	uint16_t i_number_of_dimensions = pcSensor->pcGetFenotype()->iGetNumberOfDimensions();

	double *pd_min_values = new double[i_number_of_dimensions];
	double *pd_max_values = new double[i_number_of_dimensions];

	for (uint16_t i = 0; i < i_number_of_dimensions; i++)
	{
		*(pd_min_values + i) = *(pcSensor->pcGetFenotype()->pdGetValues() + i) - d_half_integral_width;
		*(pd_max_values + i) = *(pcSensor->pcGetFenotype()->pdGetValues() + i) + d_half_integral_width;

		if (*(pd_min_values + i) < *(pcSensor->pcGetFenotype()->pdGetMinValues() + i))
		{
			*(pd_min_values + i) = *(pcSensor->pcGetFenotype()->pdGetMinValues() + i);
		}//if (*(pd_min_values + i) < *(pcSensor->pcGetFenotype()->pdGetMinValues() + i))

		if (*(pd_max_values + i) > *(pcSensor->pcGetFenotype()->pdGetMaxValues() + i))
		{
			*(pd_max_values + i) = *(pcSensor->pcGetFenotype()->pdGetMaxValues() + i);
		}//if (*(pd_max_values + i) > *(pcSensor->pcGetFenotype()->pdGetMaxValues() + i))
	}//for (uint16_t i = 0; i < i_number_of_dimensions; i++)

	double d_sensor_fitness_value = pcSensor->dGetFitnessValue();

	double d_max_considering_fitness_value = d_sensor_fitness_value + d_half_integral_height;
	double d_min_considering_fitness_value = d_sensor_fitness_value - d_half_integral_height;

	CIndividual<CRealCoding, CRealCoding> *pc_integral_sample_individual = new CIndividual<CRealCoding, CRealCoding>(pcSensor);

	//double d_integral_value = MathUtils::dComputeMonteCarloIntegral([&](double *pdValues)
	//{
	//	//TODO: vSetValues in CRealCoding

	//	for (uint16_t i = 0; i < i_number_of_dimensions; i++)
	//	{
	//		*(pc_integral_sample_individual->pcGetGenotype()->pdGetValues() + i) = *(pdValues + i);
	//	}//for (uint16_t i = 0; i < i_number_of_dimensions; i++)

	//	pc_integral_sample_individual->vIsEvaluated(false);
	//	pc_integral_sample_individual->vEvaluate();

	//	//cout << pcSensor->dGetFitnessValue() << " " << pc_integral_sample_individual->dGetFitnessValue() << endl;

	//	return pc_integral_sample_individual->dGetFitnessValue() - d_min_considering_fitness_value;
	//}, d_max_considering_fitness_value - d_min_considering_fitness_value, pd_min_values, pd_max_values, (uint8_t)i_number_of_dimensions, i_number_of_integral_samples);

	//uint64_t i_ffe_before = pc_problem->pcGetEvaluation()->iGetFFE();

	double d_integral_value = MathUtils::dComputeHCubatureIntegral([&](const double *pdValues)
	{
		//TODO: vSetValues in CRealCoding

		for (uint16_t i = 0; i < i_number_of_dimensions; i++)
		{
			*(pc_integral_sample_individual->pcGetGenotype()->pdGetValues() + i) = *(pdValues + i);
		}//for (uint16_t i = 0; i < i_number_of_dimensions; i++)

		pc_integral_sample_individual->vIsEvaluated(false);
		pc_integral_sample_individual->vEvaluate();

		//cout << pcSensor->dGetFitnessValue() << " " << pc_integral_sample_individual->dGetFitnessValue() << endl;

		double d_fitness_value = pc_integral_sample_individual->dGetFitnessValue();

		//cout << d_min_considering_fitness_value << " " << d_max_considering_fitness_value << endl;

		if (d_fitness_value > d_max_considering_fitness_value)
		{
			d_fitness_value = d_max_considering_fitness_value;
		}//if (d_fitness_value > d_max_considering_fitness_value)

		return d_fitness_value - d_min_considering_fitness_value;
	}, pd_min_values, pd_max_values, (uint8_t)i_number_of_dimensions, i_number_of_integral_samples);

	//cout << "ffe: " << (int)(pc_problem->pcGetEvaluation()->iGetFFE() - i_ffe_before) << endl << endl;

	delete pd_min_values;
	delete pd_max_values;

	delete pc_integral_sample_individual;

	return d_integral_value;
}//double CIntegralSensorChangeDetector::d_calculate_integral(CIndividual<CRealCoding, CRealCoding> *pcSensor)