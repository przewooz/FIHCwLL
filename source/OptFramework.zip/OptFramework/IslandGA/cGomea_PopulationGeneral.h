#pragma once

#include <cmath>
#include <iostream> 
#include <vector>
using namespace std;

#include "cGomea_Individual.h"
#include "cGomea_Config.h"
#include "cGomea_shared.h"
#include "cGomea_problems.h"
#include "cGomea_FOS.h"

class C_CGomea_PopulationGeneral
{
public:
	C_CGomea_Config *config;
	C_CGomea_Problem *problemInstance;
	C_CGomea_sharedInformation *sharedInformationPointer;
	size_t GOMEAIndex;
	size_t populationSize;

	vector<C_CGomea_Individual*> population;
	vector<C_CGomea_Individual*> offspringPopulation;
	vector<int> noImprovementStretches;

	C_CGomea_FOS *populationFOS;
	bool terminated;
	double averageFitness=-1e+308;
	size_t numberOfGenerations;
	int improved_restricted = 0;
	C_CGomea_FOS *FOSInstance = NULL;
    vector<vector<double> > matrix;
   	size_t currentPyramidLevel=0;

	C_CGomea_PopulationGeneral(C_CGomea_Config *config_, C_CGomea_Problem *problemInstance_, C_CGomea_sharedInformation *sharedInformationPointer_, size_t GOMEAIndex_, size_t populationSize_);
	virtual ~C_CGomea_PopulationGeneral(){};

	void tournamentSelection(int k, vector<C_CGomea_Individual*> &population, vector<C_CGomea_Individual*> &offspringPopulation);
	void hillClimberSingle(C_CGomea_Individual *solution);
	void hillClimberMultiple(C_CGomea_Individual *solution);

	void calculateAverageFitness();	
	void copyOffspringToPopulation();
	void evaluateSolution(C_CGomea_Individual *solution);
	void evaluateSolution(C_CGomea_Individual *solution, C_CGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
	bool GOM(size_t offspringIndex, C_CGomea_Individual *backup);
	void findNeighbors(vector<vector< int> > &neighbors);
	bool conditionalGOM(size_t offspringIndex, C_CGomea_Individual *backup, vector<vector<int> > &neighbors);
	bool FI(size_t offspringIndex, C_CGomea_Individual *backup);
	bool conditionalFI(size_t offspringIndex, C_CGomea_Individual *backup, vector<vector<int> > &neighbors);
	void updateElitistAndCheckVTR(C_CGomea_Individual *solution);
	void checkTimeLimit();
};

