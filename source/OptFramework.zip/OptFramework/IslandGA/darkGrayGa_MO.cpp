#include "darkGrayGa_MO.h"



using  namespace nDarkGrayGA_MO;



uint32_t CDarkGrayGA_MO::iERROR_PARENT_CDarkGrayGA_MO = CError::iADD_ERROR_PARENT("iERROR_PARENT_CDarkGrayGA_MO");
uint32_t CDarkGrayGA_MO::iERROR_CODE_DARK_GRAY_GA_MO_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_DARK_GRAY_GA_MO_GENOTYPE_LEN_BELOW_0");


uint32_t CDarkGrayGASinglePop_MO::iERROR_PARENT_CDarkGrayGA_MO_SinglePop = CError::iADD_ERROR_PARENT("iERROR_PARENT_CDarkGrayGA_MO_SinglePop");
uint32_t CDarkGrayGASinglePop_MO::iERROR_CODE_DARK_GRAY_GA_MO_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_DARK_GRAY_GA_MO_GENOTYPE_LEN_BELOW_0");



//---------------------------------------------CDarkGrayGA_MO-------------------------------------------------------
CDarkGrayGA_MO::CDarkGrayGA_MO(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryMultiObjectiveOptimizer(pcProblem, pcLog, iRandomSeed)
{
	i_pop_size = 0;
	pc_evaluation_individual = NULL;
	//pc_best = NULL;
	pc_best_pop = NULL;
	pc_best_climbing_pop = NULL;
	pc_dsm = new CDarkGA_DSM_MO(this);
	pc_shift_vec_manager = new CShiftVectorManager();
};//CDarkGrayGA_MO::CDarkGrayGA_MO(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



CDarkGrayGA_MO::CDarkGrayGA_MO(CDarkGrayGA_MO *pcOther) : CBinaryMultiObjectiveOptimizer(pcOther)//CBinaryOptimizer(pcOther)
{
	::Tools::vShow("NO IMPLEMENTATION: CDarkGrayGA_MO::CDarkGrayGA(CDarkGrayGA_MO *pcOther)");
}//CDarkGrayGA_MO::CDarkGrayGA_MO(CDarkGrayGASinglePop *pcOther) : CBinaryOptimizer(pcOther)



CDarkGrayGA_MO::~CDarkGrayGA_MO()
{
	//pc_best_pop->vSavePopTest();
	pc_dsm->vSaveDepRanges(pc_log->sGetLogFile() + "___dep_ranges.txt");

	//if (pc_best != NULL)  delete  pc_best;
	if (pc_best_pop != NULL)  delete  pc_best_pop;
	if (pc_dsm != NULL)  delete  pc_dsm;
	if (pc_base_pop != NULL)  delete  pc_base_pop;
	if (pc_best_climbing_pop != NULL)  delete  pc_best_climbing_pop;
	if (pc_shift_vec_manager != NULL)  delete  pc_shift_vec_manager;
}//CDarkGrayGA_MO::~CDarkGrayGA_MO()


void  CDarkGrayGA_MO::vInitialize()
{
	c_time_counter.vSetStartNow();
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();
	
	i_next_pop_size = 2;

	pc_dsm->bSetSize(i_templ_length);

	if  (i_sett_perfect_linkage == 1)  pc_dsm->bGetTrueLinkage(pc_problem);

	pc_base_pop = new CDarkGrayGASinglePop_MO(pc_problem, pc_log, i_random_seed, this);
	//pc_best = new CDarkGrayGAIndividual_MO(i_templ_length, pc_problem, pc_base_pop);

	pc_best_pop = new CDarkGrayGASinglePop_MO(pc_base_pop);
	pc_best_pop->vSetPopulationSize(1);
	pc_best_pop->vInitialize();
	pc_best_pop->pc_parent = this;


	pc_best_climbing_pop = new CDarkGrayGASinglePop_MO(pc_base_pop);
	pc_best_climbing_pop->vSetPopulationSize(1);
	pc_best_climbing_pop->vInitialize();
	pc_best_climbing_pop->pc_parent = this;

	pc_dsm->vSetMO_Dled(i_sett_mo_dled);

	//pc_dsm->bSave("zzzzz_dsm_test.txt");
	//vSavePopTest();
}//void  CDarkGrayGA_MO::vInitialize(time_t tStartTime)


CDarkGrayGAIndividual_MO  *CDarkGrayGA_MO::pcGetBest()
{
	if  (pc_best_pop == NULL)  return(NULL);
	if (pc_best_pop->v_pop.size() == 0)  return(NULL);

	/*double  d_best_fit;
	d_best_fit = pc_best_pop->v_pop.at(0)->dComputeFitness();

	for (int i_ind = 1; i_ind < pc_best_pop->v_pop.size(); i_ind++)
	{
		if (d_best_fit < pc_best_pop->v_pop.at(i_ind)->dComputeFitness())  d_best_fit = pc_best_pop->v_pop.at(i_ind)->dComputeFitness();
	}//for (int i_ind = 1; i_ind < pc_best_pop->v_pop.size(); i_ind++)*/

	return(pc_best_pop->v_pop.at(0));
}//CDarkGrayGAIndividual_MO  *CDarkGrayGA_MO::pcGetBest()



void  CDarkGrayGA_MO::vInsertToBestPop(CDarkGrayGASinglePop_MO  *pcSinglePop)
{
	double  d_best_fitness;

	//int  i_best_pop_size_start, i_best_pop_size_end;
	
	//i_best_pop_size_start = pc_best_pop->v_pop.size();
	d_best_fitness = pcSinglePop->pcGetBest()->dComputeFitness();

	for (int ii = 0; ii < pcSinglePop->v_pop.size(); ii++)
	{
		if (pcSinglePop->v_pop.at(ii)->dComputeFitness() >= d_best_fitness)
		{
			vInsertToBestPop(pcSinglePop->v_pop.at(ii));
		}//if (pcSinglePop->v_pop.at(ii)->dComputeFitness() == d_best_fitness)
	}//for (int ii = 0; ii < pcSinglePop->v_pop.size(); ii++)

	//i_best_pop_size_end = pc_best_pop->v_pop.size();

}//void  CDarkGrayGA_MO::vInsertToBestPop(CDarkGrayGASinglePop_MO  *pcSinglePop)



void  CDarkGrayGA_MO::vInsertToBestPop(CDarkGrayGAIndividual_MO  *pcNewInd)
{
	if (pc_best_pop->v_pop.at(0)->dComputeFitness() == pcNewInd->dComputeFitness())
	{
		for (int ii = 0; ii < pc_best_pop->v_pop.size(); ii++)
		{
			if (pc_best_pop->v_pop.at(ii)->bIsTheSame(pcNewInd) == true)  return;
		}//for (int ii = 0; ii < pc_best_pop->v_pop.size(); ii++)

		int  i_ind_to_replace_offset;
		if (
			( (i_sett_global_number_limit == 0) &&(pc_best_pop->v_pop.size() < v_pop_running.at(v_pop_running.size() - 1)->v_pop.size()) )
			||
			(pc_best_pop->v_pop.size() < i_sett_global_number_limit)
			)
		{
			pc_best_pop->v_pop.push_back(new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *) pc_problem, pc_best_pop));
			i_ind_to_replace_offset = pc_best_pop->v_pop.size() - 1;
		}//if ((i_sett_global_number_limit < 0) || (pc_best_pop->v_pop.size() < i_sett_global_number_limit))
		else
			i_ind_to_replace_offset = ::RandUtils::iRandNumber(0, pc_best_pop->v_pop.size() - 1);

		pc_best_pop->v_pop.at(i_ind_to_replace_offset)->vCopyFrom(pcNewInd);		
		pc_best_pop->vSetPopulationSize(pc_best_pop->v_pop.size());
	}//if (pc_best_pop->v_pop.at(0)->dComputeFitness() == pcNewInd->dComputeFitness())

	if (pc_best_pop->v_pop.at(0)->dComputeFitness() < pcNewInd->dComputeFitness())
	{
		pc_best_pop->vSetPopulationSize(1);
		pc_best_pop->v_pop.at(0)->vCopyFrom(pcNewInd);

		for (int ii = 1; ii < pc_best_pop->v_pop.size(); ii++)
			delete  pc_best_pop->v_pop.at(ii);
		while (pc_best_pop->v_pop.size() > 1)
			pc_best_pop->v_pop.erase(pc_best_pop->v_pop.begin() + pc_best_pop->v_pop.size() - 1);

		for (int ii = 1; ii < pc_best_pop->v_pop_copy.size(); ii++)
			delete  pc_best_pop->v_pop_copy.at(ii);
		while (pc_best_pop->v_pop_copy.size() > 1)
			pc_best_pop->v_pop_copy.erase(pc_best_pop->v_pop_copy.begin() + pc_best_pop->v_pop_copy.size() - 1);
	}//if (pc_best_pop->v_pop.at(0)->dComputeFitness() < pcNewInd->dComputeFitness())
}//CDarkGrayGA::vInsertToBestPop(CDarkGrayGAIndividual_MO  *pcNewInd)






CError CDarkGrayGA_MO::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA_MO);


	c_err = COptimizer::eConfigure(psSettings);

	CUIntCommandParam p_pop_scheme(s_OPTIMIZER_DARK_GA_MO_POP_SCHEME);
	i_sett_pop_scheme = p_pop_scheme.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);


	CUIntCommandParam p_vector_choose_strategy(s_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY);
	i_vector_choose_strategy = p_vector_choose_strategy.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);


	CUIntCommandParam p_improve_bests(s_OPTIMIZER_DARK_GA_MO__IMPROVE_BESTS);
	i_improve_bests = p_improve_bests.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	
	CUIntCommandParam p_mo_dled(s_OPTIMIZER_DARK_GA_MO__MO_DLED);
	i_sett_mo_dled = p_mo_dled.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);


	

	CUIntCommandParam p_perfect_linkage(s_OPTIMIZER_DARK_GA_MO_PERFECT_LINKAGE);
	i_sett_perfect_linkage = p_perfect_linkage.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_donor_improvement(s_OPTIMIZER_DARK_GA_MO_DONOR_IMPROVEMENT);
	i_sett_donor_improvement = p_donor_improvement.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	CUIntCommandParam p_global_best_improvement(s_OPTIMIZER_DARK_GA_MO_GLOBAL_BEST_IMPROVEMENT);
	i_sett_global_best_improvement = p_global_best_improvement.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	CUIntCommandParam p_global_number_limit(s_OPTIMIZER_DARK_GA_MO_GLOBAL_BEST_LIMIT);
	i_sett_global_number_limit = p_global_number_limit.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_global_best_pop_run(s_OPTIMIZER_DARK_GA_MO_GLOBAL_BEST_POP_RUN);
	i_sett_global_best_pop_run = p_global_best_pop_run.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);
	
	CUIntCommandParam p_uniform_crossover_for_slide(s_OPTIMIZER_DARK_GA_MO_UNIFORM_CROSSOVER_FOR_SLIDE);
	i_sett_uniform_crossover_for_slide = p_uniform_crossover_for_slide.iGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	
	return c_err;
};//CError CDarkGrayGA_MO::eConfigure(istream *psSettings)




bool CDarkGrayGA_MO::bRunIteration(uint32_t iIterationNumber)
{
	if  (i_sett_pop_scheme == 0)  return(bRunIteration_P3(iIterationNumber));
	if (i_sett_pop_scheme == 1)  return(bRunIteration_sGA(iIterationNumber));
	return(false);
	//return(bRunIteration_sGA(iIterationNumber, tStartTime));
}//bool CDarkGrayGA_MO::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



bool CDarkGrayGA_MO::b_p3_the_same_exists(CDarkGrayGAIndividual_MO  *pcIndToAdd)
{
	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
	{
		for (int i_ind = 0; i_ind < v_pyramid.at(i_lev)->v_pop.size(); i_ind++)
		{
			if (v_pyramid.at(i_lev)->v_pop.at(i_ind)->bIsTheSame(pcIndToAdd))  return(false);
		}//for (int i_ind = 0; i_ind < v_pyramid.at(i_lev)->v_pop.size(); i_ind++)
	}//for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
	return(true);
}//bool CDarkGrayGA_MO::b_p3_the_same_exists(CDarkGrayGAIndividual_MO  *pcIndToAdd)

bool CDarkGrayGA_MO::b_p3_add_to_level(int iLevel, CDarkGrayGAIndividual_MO  *pcIndToAdd)
{
	while (v_pyramid.size() <= iLevel)
	{
		CDarkGrayGASinglePop_MO  *pc_new_pop;

		pc_new_pop = new CDarkGrayGASinglePop_MO(pc_base_pop);
		pc_new_pop->vSetPopulationSize(0);
		pc_new_pop->vInitialize();
		pc_new_pop->pc_parent = this;

		v_pyramid.push_back(pc_new_pop);
	}//while (v_pyramid.size() <= iLevel)


	if (b_p3_the_same_exists(pcIndToAdd) == false)  return(false);

	pcIndToAdd->pc_parent = v_pyramid.at(iLevel);
	v_pyramid.at(iLevel)->v_pop.push_back(pcIndToAdd);
	return(true);
}//void CDarkGrayGA_MO::v_p3_add_to_level(int iLevel, CDarkGrayGAIndividual_MO*pcIndToAdd)



int  CDarkGrayGA_MO::iGetPopLevel(CDarkGrayGASinglePop_MO  *pcPopToCheck)
{
	for (int ii = 0; ii < v_pyramid.size(); ii++)
	{
		if (v_pyramid.at(ii) == pcPopToCheck)  return(ii);
	}//for (int ii = 0; ii < v_pyramid.size(); ii++)

	return(-1);
}//int  CDarkGrayGA_MO::iGetPopLevel(CDarkGrayGASinglePop_MO  *pcPopToCheck)


int  CDarkGrayGA_MO::iP3GetPyramidIndNumber()
{
	int  i_result = 0;

	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
		i_result += v_pyramid.at(i_lev)->v_pop.size();

	return(i_result);
}//int  CDarkGrayGA_MO::iP3GetPyramidIndNumber()


bool CDarkGrayGA_MO::bRunIteration_P3(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA_MO);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();

	bool  b_print = false;
	if (iIterationNumber % 100 == 0)  b_print = true;



	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem  *)pc_problem->pcGetEvaluation();

	vector<CMultiObjectiveMeasure*>  *pv_mesaures;
	pv_mesaures = pc_multi_problem->pvGetMeasures();


	if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__STATIC)
	{

	}//if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__STATIC)



	if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__RANDOM_VECTORS)
	{
		//s_buf.Format("0: %.4lf   1:%.4lf", pv_mesaures->at(0)->dWeight, pv_mesaures->at(1)->dWeight);
		//::Tools::vShow(s_buf);

		//get random weights and normalize...
		double  d_weight_summ;
		d_weight_summ = 0;
		for (int ii = 0; ii < pv_mesaures->size(); ii++)
		{
			pv_mesaures->at(ii)->dWeight = RandUtils::dRandNumber(0, 1);
			d_weight_summ += pv_mesaures->at(ii)->dWeight;
		}//for (int ii = 0; ii < pv_mesaures->size(); ii++)

		if (d_weight_summ == 0)
			pv_mesaures->at(0)->dWeight = 1;
		else
		{
			for (int ii = 0; ii < pv_mesaures->size(); ii++)
				pv_mesaures->at(ii)->dWeight = pv_mesaures->at(ii)->dWeight / d_weight_summ;
		}//else  if (d_weight_summ == 0)


		//pv_mesaures->at(0)->dWeight = 0.5;
		//pv_mesaures->at(1)->dWeight = 0.5;

		//s_buf.Format("0: %.4lf   1:%.4lf", pv_mesaures->at(0)->dWeight, pv_mesaures->at(1)->dWeight);
		//::Tools::vShow(s_buf);
	}//if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__RANDOM_VECTORS)



	if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__SHIFT_VECTORS)
	{
		bool  b_weights_obtained;
		b_weights_obtained = pc_shift_vec_manager->bGetWeights(&(pv_mesaures->at(0)->dWeight), &(pv_mesaures->at(1)->dWeight));
		if (b_weights_obtained == false)  ::Tools::vShow("if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__SHIFT_VECTORS)");
		//s_buf.Format("OUT WEIGHTS: %.4lf %.4lf", pv_mesaures->at(0)->dWeight, pv_mesaures->at(1)->dWeight);
		//::Tools::vShow(s_buf);
	}//if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__SHIFT_VECTORS)
	
	

	int  i_dsm_dependencies_applying;
	i_dsm_dependencies_applying = pc_dsm->iRebuildDSM_ForVectors(pv_mesaures->at(0)->dWeight, pv_mesaures->at(1)->dWeight);





	CDarkGrayGAIndividual_MO  *pc_climber, *pc_copy;
	pc_climber = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), pc_base_pop);
	pc_climber->vRandomizeGenotype();
	pc_climber->dComputeFitnessOptimize(NULL);

	/*bool  b_track_ind = false;
	if (pc_climber->bCheckTest() == true)
	{
		::Tools::vReportInFile("zzzz_opt_block.txt", "");
		::Tools::vReportInFile("zzzz_opt_block.txt", pc_climber->sToStr());
		b_track_ind = true;

		pc_dsm->bSave("zzzzz_dsm.txt");
	}//if (pc_climber->bCheckTest() == true)*/

	pc_copy = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), pc_base_pop);
	pc_copy->vCopyFrom(pc_climber);

	//::Tools::vReportInFile("zzzz_inds.txt", "START: " + pc_climber->sToStr());

	b_p3_add_to_level(0, pc_copy);


	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
		v_pyramid.at(i_lev)->vRecalculateForNewWeights();

	pc_best_pop->vRecalculateForNewWeights();

	for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)
	{
		if (v_pyramid.at(i_lev)->iDonateToIndividual_PxByLen(pc_climber) == 1)
		{
			pc_copy = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), pc_base_pop);
			pc_copy->vCopyFrom(pc_climber);

			if (b_p3_add_to_level(i_lev + 1, pc_copy) == false)  delete  pc_copy;
		}//if (v_pyramid.at(i_lev)->bDonateToIndividual_PxByLen(pc_climber) == true)

		//if  (b_track_ind == true)  ::Tools::vReportInFile("zzzz_opt_block.txt", pc_climber->sToStr());
	}//for (int i_lev = 0; i_lev < v_pyramid.size(); i_lev++)


	pc_climber->vRate();
	if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__SHIFT_VECTORS)
	{
		//s_buf.Format("OUT WEIGHTS 2: %.4lf %.4lf", pv_mesaures->at(0)->dWeight, pv_mesaures->at(1)->dWeight);
		//::Tools::vShow(s_buf);
		pc_shift_vec_manager->vUpdateAvailableRanges(pv_mesaures->at(0)->dWeight, pv_mesaures->at(1)->dWeight, pc_climber->v_fitness.at(0), pc_climber->v_fitness.at(1));
	}//if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__SHIFT_VECTORS)


	//::Tools::vReportInFile("zzzz_inds.txt", "CLIMB: " + pc_climber->sToStr());

	if (i_improve_bests == 1)
	{
		CDarkGrayGAIndividual_MO  *pc_dgga_ind;

		/*for (int i_ind = 0; i_ind < pc_best_pop->v_pop.size(); i_ind++)
		{
			pc_dgga_ind = pc_best_pop->v_pop.at(i_ind);

			int  i_domination;
			i_domination = pc_climber->iCheckDomination(pc_dgga_ind);

			if (i_domination <= 0)
			{
				pc_best_climbing_pop->v_pop.at(0)->vCopyFrom(pc_climber);
				if (pc_best_climbing_pop->iDonateToIndividual_PxByLen(pc_dgga_ind, b_print) == 1)
				{
					b_print = true;
					if (b_print)
					{
						s_buf.Format("  Best improved %d", i_ind);
						pc_log->vPrintLine(s_buf, true);
					}//if (b_print)
				}//if (pc_best_climbing_pop->iDonateToIndividual_PxByLen(pc_climber, b_print) == 1)
			}//if (i_domination <= 0)
			else
			{
				pc_best_climbing_pop->v_pop.at(0)->vCopyFrom(pc_dgga_ind);
				if (pc_best_climbing_pop->iDonateToIndividual_PxByLen(pc_climber, b_print) == 1)
				{
					b_print = true;
					if (b_print)
					{
						s_buf.Format("  Climber improved %d", i_ind);
						pc_log->vPrintLine(s_buf, true);
					}//if (b_print)
				}//if (pc_best_climbing_pop->iDonateToIndividual_PxByLen(pc_climber, b_print) == 1)
			}//else  if (i_domination <= 0)
		}//for (int i_ind = 0; i_ind < pc_best_pop->v_pop.size(); i_ind++)*/

		pc_dgga_ind = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), pc_best_pop);
				

		int  i_cross_res;
		int  i_best_pop_size;
		i_best_pop_size = pc_best_pop->v_pop.size();
		for (int i_ind = 0; i_ind < i_best_pop_size; i_ind++)
		{
			pc_dgga_ind->vCopyFrom(pc_best_pop->v_pop.at(i_ind));

			//int  i_domination;
			//i_domination = pc_climber->iCheckDomination(pc_dgga_ind);

			//if (i_domination <= 0)
			{
				pc_best_climbing_pop->v_pop.at(0)->vCopyFrom(pc_climber);
				//if (pc_best_climbing_pop->iDonateToIndividual_PxByLen(pc_dgga_ind, true) == 1)
				i_cross_res = pc_best_climbing_pop->iDonateToIndividual_PxByLen(pc_dgga_ind, true, &(pc_best_pop->v_pop));
				if (i_cross_res >= 0)
				{
					pc_best_pop->v_pop.push_back(pc_dgga_ind);
					pc_dgga_ind = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), pc_best_pop);
					b_print = true;
					if (b_print)
					{
						if  (i_cross_res == 1)  s_buf.Format("  Best improved %d", i_ind);
						if (i_cross_res == 0)  s_buf.Format("  Best slided %d", i_ind);
						pc_log->vPrintLine(s_buf, true);
					}//if (b_print)
				}//if (pc_best_climbing_pop->iDonateToIndividual_PxByLen(pc_climber, b_print) == 1)
			}//if (i_domination <= 0)
		}//for (int i_ind = 0; i_ind < pc_best_pop->v_pop.size(); i_ind++)
		delete  pc_dgga_ind;

		//if (pc_best_pop->iDonateToIndividual_PxByLen(pc_climber, true) == 1)
		if (pc_best_pop->iDonateToIndividual_PxByLen(pc_climber, true, &(pc_best_pop->v_pop)) == 1)
		{
			b_print = true;
			if (b_print)
			{
				s_buf.Format("  Climber improved");
				pc_log->vPrintLine(s_buf, true);
			}//if (b_print)
		}//if (pc_best_climbing_pop->iDonateToIndividual_PxByLen(pc_climber, b_print) == 1)		

		//::Tools::vReportInFile("zzzz_inds.txt", "BESTS: " + pc_climber->sToStr());
		//::Tools::vReportInFile("zzzz_inds.txt", "\n");


		//check domination
		pc_best_pop->v_pop.push_back(new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem, pc_best_pop));
		pc_best_pop->v_pop.at(pc_best_pop->v_pop.size() - 1)->vCopyFrom(pc_climber);

		pc_best_pop->vExcludeDominated();
		
		//pc_climber->dComputeFitness
	}//if  (i_improve_bests == 1)
	else
	{
		if (pcGetBest()->dComputeFitness() < pc_climber->dComputeFitness())
		{
			vInsertToBestPop(pc_climber);
			//pc_best->vCopyFrom(pc_climber);
			b_print = true;
		}//if (pc_best->dComputeFitness() < pc_climber->dComputeFitness())
	}//else  if  (i_improve_bests == 1)
		

	
	/*bool  i_donated = 1;
	while (i_donated > 0)
	{
		i_donated = 0;

		for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)
		{
			if (v_pop_running.at(i_pop)->bDonateToIndividual_PxByLen(pc_best) == true)  i_donated = 2;
		}//for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)

		if (i_donated == 2)
		{
			for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
			{
				if (v_pops_obsolete.at(i_pop_obs)->bDonateToIndividual_PxByLen(pc_best) == true)  i_donated = 2;
			}//for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
		}//if (i_donated == 2)

	}//if (b_donated == true)*/





	bool b_updated = b_update_best_individual(iIterationNumber, pcGetBest()->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pcGetBest()->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"pyramid: %d  PyrInds: %d  best: %.8lf (%d)  DSMdependencies:%d  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf] [%diterations]",
		v_pyramid.size(), iP3GetPyramidIndNumber(), pcGetBest()->dComputeFitness(), pc_best_pop->v_pop.size(),
		i_dsm_dependencies_applying,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE(), iIterationNumber
	);

	if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__SHIFT_VECTORS)
	{
		s_buf += pc_shift_vec_manager->sToStr();
	}//if (i_vector_choose_strategy == i_OPTIMIZER_DARK_GA_MO__VECTOR_CHOOSE_STRATEGY__SHIFT_VECTORS)

	if (b_print)
	{
		pc_log->vPrintLine(s_buf, true);
		pc_log->vPrintLine("", true);
		//pc_dsm->vSaveDepRanges("zzzzz_dep_ranges.txt");
		//pc_dsm->bSave("zzzzz_dsm.txt");
		//pc_best_pop->vSavePopTest();
	}//if (b_print)
	


	return(true);
}//bool CDarkGrayGA_MO::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



void  CDarkGrayGA_MO::v_global_best_pop_run()
{
	CString  s_buf;

	double  d_fit_start, d_fit_end;

	d_fit_start = pc_best_pop->pcGetBest()->dComputeFitness();
	pc_log->vPrintLine("BEST POP run:", true);
	pc_best_pop->bRunIteration_sGA(1);
	d_fit_end = pc_best_pop->pcGetBest()->dComputeFitness();
	   	
	if (d_fit_start < d_fit_end)
	{
		s_buf.Format("BEST POP RUN SUCC: %.8lf -> %.8lf", d_fit_start, d_fit_end);
		pc_log->vPrintLine(s_buf, true);
		pc_log->vPrintLine("", true);

		vInsertToBestPop(pc_best_pop->pcGetBest());
	}//if (d_fit_start < d_fit_end)

}//void  CDarkGrayGA_MO::v_global_best_pop_run()


void CDarkGrayGA_MO::v_global_best_improvement()
{
	CString  s_buf;

	bool  i_donated = 1;
	double  d_best_fit_start, d_best_fit_end;
	int  i_epx_res;
	CDarkGrayGAIndividual_MO *pc_ind_buffer;
	CDarkGrayGAIndividual_MO *pc_best_current;

	while (i_donated > 0)
	{
		i_donated = 0;

		for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)
		{
			for (int i_best_pop_ind = 0; i_best_pop_ind < pc_best_pop->v_pop.size(); i_best_pop_ind++)
			{
				pc_best_current = pc_best_pop->v_pop.at(i_best_pop_ind);

				d_best_fit_start = pc_best_current->dComputeFitness();
				if (v_pop_running.at(i_pop)->pc_individual_buffer == NULL)  v_pop_running.at(i_pop)->pc_individual_buffer = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), v_pop_running.at(i_pop));
				pc_ind_buffer = v_pop_running.at(i_pop)->pc_individual_buffer;
				pc_ind_buffer->vCopyFrom(pc_best_current);

				i_epx_res = pc_best_current->iMixing_ePX_ByMaskLen(&(v_pop_running.at(i_pop)->v_pop), pc_ind_buffer, true);
				if (i_epx_res > 0)
				{
					vInsertToBestPop(pc_ind_buffer);
					d_best_fit_end = pcGetBest()->dComputeFitness();
					i_donated = 1;

					s_buf.Format
					(
						"GLOBAL BEST DONATED %.8lf -> %.8lf  BestPopSize:%d   donatorPopSize: %d",
						d_best_fit_start, d_best_fit_end,
						pc_best_pop->v_pop.size(), 
						v_pop_running.at(i_pop)->v_pop.size()
					);
					pc_log->vPrintLine(s_buf, true);
					pc_log->vPrintLine("", true);
				}//if (i_epx_buf > 0)

				//we slide
				if (i_epx_res == 0)
				{
					vInsertToBestPop(pc_ind_buffer);
					d_best_fit_end = pcGetBest()->dComputeFitness();

					s_buf.Format
					(
						"Global best SLIDED %.8lf -> %.8lf  BestPopSize:%d   donatorPopSize: %d",
						d_best_fit_start, d_best_fit_end,
						pc_best_pop->v_pop.size(),
						v_pop_running.at(i_pop)->v_pop.size()
					);
					pc_log->vPrintLine(s_buf, true);
					pc_log->vPrintLine("", true);

					//::Tools::vShow("Best SLIDE!!!!!");
				}//if (i_epx_buf > 0)
			}//for (int i_best_pop_ind = 0; i_best_pop_ind < pc_best_pop->v_pop.size(); i_best_pop_ind++)
		}//for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)

		//if (i_donated == 2)
		//{
		//	for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
		//	{
		//		if (v_pops_obsolete.at(i_pop_obs)->bDonateToIndividual_PxByLen(pc_best) == true)  i_donated = 2;
		//	}//for (int i_pop_obs = 0; i_pop_obs < v_pops_obsolete.size(); i_pop_obs++)
		//}//if (i_donated == 2)

	}//if (b_donated == true)*/
}//bool CDarkGrayGA_MO::v_global_best_improvement()




bool CDarkGrayGA_MO::bRunIteration_sGA(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA_MO);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();



	if (v_pop_running.size() == 0)
	{
		CDarkGrayGASinglePop_MO  *pc_new_pop;

		pc_new_pop = new CDarkGrayGASinglePop_MO(pc_base_pop);
		pc_new_pop->vSetPopulationSize(i_next_pop_size);
		i_next_pop_size = i_next_pop_size * 2;
		pc_new_pop->vInitialize();
		pc_new_pop->pc_parent = this;

		v_pop_running.push_back(pc_new_pop);
	}//if (v_pop_running.size() == 0)


	
	for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)
	{
		v_pop_running.at(i_pop)->bRunIteration_sGA(iIterationNumber);
		//if (pc_best->dComputeFitness() < v_pop_running.at(i_pop)->pcGetBest()->dComputeFitness())  pc_best->vCopyFrom(v_pop_running.at(i_pop)->pcGetBest());
		if (pcGetBest()->dComputeFitness() < v_pop_running.at(i_pop)->pcGetBest()->dComputeFitness())  vInsertToBestPop(v_pop_running.at(i_pop));

		if (v_pop_running.at(i_pop)->bIsSteadyState() == true)
		{
			v_pops_obsolete.push_back(v_pop_running.at(i_pop));
			v_pop_running.erase(v_pop_running.begin() + i_pop);
		}//if (v_pop_running.at(i_pop)->bIsSteadyState() == true)
	}//for (int i_pop = 0; i_pop < v_pop_running.size(); i_pop++)


	if  (i_sett_global_best_improvement == 1)  v_global_best_improvement();

	if  (i_sett_global_best_pop_run == 1)  v_global_best_pop_run();


	
	bool b_updated = b_update_best_individual(iIterationNumber, pcGetBest()->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pcGetBest()->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"pops: %d  runningPops: %d  best: %.8lf (bestPopSize:%d)  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pops_obsolete.size() + v_pop_running.size(), v_pop_running.size(), pcGetBest()->dComputeFitness(), pc_best_pop->v_pop.size(),
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);
	pc_log->vPrintLine("", true);



	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGA_MO::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



double CDarkGrayGA_MO::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_compute_fitness_value(piBits);
	return(d_fitness_value);
}//double CDarkGrayGA_MO::dComputeFitness(int32_t *piBits)



CString  CDarkGrayGA_MO::sAdditionalSummaryInfo()
{
	CString  s_buf;

	s_buf = pc_dsm->sGet_MO_Dled_Stats();

	return(s_buf);
};//CString  CDarkGrayGA_MO::sAdditionalSummaryInfo() 



CString  CDarkGrayGA_MO::sLinkageSummaryReport()
{
	CString  s_res;
	s_res = pc_dsm->sLinkageSummaryReport();
	return(s_res);
}//CString  CDarkGrayGA_MO::sLinkageSummaryReport()

















//---------------------------------------------CDarkGrayGASinglePop_MO-------------------------------------------------------
CDarkGrayGASinglePop_MO::CDarkGrayGASinglePop_MO(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed, CDarkGrayGA_MO  *pcParent)
	: CPopulationSizingSingleOptimizer(pcProblem, pcLog, iRandomSeed)
{
	i_pop_size = 0;
	pc_evaluation_individual = NULL;
	pc_individual_buffer = NULL;
	pi_genotope_buffer_tool_0 = NULL;
	pi_genotope_buffer_tool_1 = NULL;

	pc_best = NULL;
	b_steady_state = false;

	pc_parent = pcParent;

	if (pc_parent == NULL)
		pc_dsm = new CDarkGA_DSM_MO(pc_parent);
	else
		pc_dsm = pc_parent->pcGetDSM();

	pc_px_masks_manager = new CDarkGrayGAPxMaskManager_MO();
};//CDarkGrayGASinglePop_MO::CDarkGrayGASinglePop_MO(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



CDarkGrayGASinglePop_MO::CDarkGrayGASinglePop_MO(CDarkGrayGASinglePop_MO *pcOther) : CPopulationSizingSingleOptimizer(pcOther)
{
	pc_evaluation_individual = NULL;
	pc_individual_buffer = NULL;
	pi_genotope_buffer_tool_0 = NULL;
	pi_genotope_buffer_tool_1 = NULL;

	pc_best = NULL;
	pc_problem = pcOther->pc_problem;
	pc_log = pcOther->pc_log;
	b_steady_state = false;

	pc_parent = pcOther->pc_parent;
	if (pc_parent == NULL)
		pc_dsm = new CDarkGA_DSM_MO(pc_parent);
	else
		pc_dsm = pc_parent->pcGetDSM();

	pc_px_masks_manager = new CDarkGrayGAPxMaskManager_MO();
}//CDarkGrayGASinglePop_MO::CDarkGrayGASinglePop_MO(CDarkGrayGASinglePop_MO *pcOther) : CBinaryOptimizer(pcOther)



CDarkGrayGASinglePop_MO::~CDarkGrayGASinglePop_MO()
{
	for (int ii = 0; ii < v_pop.size(); ii++)
		delete  v_pop.at(ii);

	for (int ii = 0; ii < v_pop_copy.size(); ii++)
		delete  v_pop_copy.at(ii);

	
	if (pc_evaluation_individual != NULL)  delete  pc_evaluation_individual;

	if (pc_best != NULL)  delete  pc_best;

	if (pi_genotope_buffer_tool_0 != NULL)  delete  pi_genotope_buffer_tool_0;
	if (pi_genotope_buffer_tool_1 != NULL)  delete  pi_genotope_buffer_tool_1;

	if (pc_parent == NULL)
	{
		if (pc_dsm != NULL)  delete  pc_dsm;
	}//if (pc_parent == NULL)

	if (pc_px_masks_manager != NULL)  delete  pc_px_masks_manager;
}//CDarkGrayGASinglePop_MO::~CDarkGrayGASinglePop_MO()


void  CDarkGrayGASinglePop_MO::vInitialize()
{
	c_time_counter.vSetStartNow();
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();



	pc_best = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), this);
	pc_individual_buffer = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), this);
	pi_genotope_buffer_tool_0 = new int[i_templ_length];
	pi_genotope_buffer_tool_1 = new int[i_templ_length];

	i_slide_number = 0;

	//pc_dsm->bSetSize(i_templ_length);
	//pc_dsm->bGetTrueLinkage(pc_problem);
	//pc_dsm->bSave("zzzzz_dsm_test.txt");
	//vSavePopTest();


	CDarkGrayGAIndividual_MO  *pc_indiv_new;
	while  (v_pop.size() < i_pop_size)
	{
		//int i_ffe_start, i_ffe_end;
		//i_ffe_start = pc_problem->pcGetEvaluation()->iGetFFE();

		pc_indiv_new = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), this);
		pc_indiv_new->vRandomizeGenotype();
		
		/*::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", "START: \n");
		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", pc_indiv_new->sToStr());
		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", "\n\n\n\n");*/

		//pc_indiv_new->dComputeFitness();
		pc_indiv_new->dComputeFitnessOptimize(NULL);
		//pc_indiv_new->dComputeFitnessOptimize(NULL, true);

		/*i_ffe_end = pc_problem->pcGetEvaluation()->iGetFFE();

		CString  s_buf;
		s_buf.Format("\n\n\n%d\n%d\n%d\n", i_ffe_start, i_ffe_end, i_ffe_end - i_ffe_start);

		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", s_buf);
		::Tools::vReportInFile("zzzzz_ind_opt_summ.txt", pc_indiv_new->sToStr());
		::Tools::vShow("zzzzz_ind_opt_darkGr.txt");//*/

		v_pop.push_back(pc_indiv_new);
	}//while  (v_pop.size() < i_pop_size)


	

	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();



	CString  s_buf;

	s_buf.Format
	(
		"INIT size: %d  best: %.8lf avr: %.8lf  [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	//pc_log->vPrintLine(s_buf, true);
}//void  CDarkGrayGASinglePop_MO::vInitialize(time_t tStartTime)


void  CDarkGrayGASinglePop_MO::vSavePopTest()
{
	FILE  *pf_dest;
	pf_dest = fopen("zzz_test_pop.txt", "w+");

	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		fprintf(pf_dest, "%s\n", v_pop.at(ii)->sToStr());
	}//for (int ii = 0; ii < i_pop_size; ii++)

	fclose(pf_dest);

	//::Tools::vShow("void  CDarkGrayGA::vSavePopTest()");
}//void  CDarkGrayGASinglePop_MO::vSavePopTest()



void  CDarkGrayGASinglePop_MO::vCopyFrom(CDarkGrayGASinglePop_MO *pcOther)
{
	i_pop_size = pcOther->i_pop_size;
	i_templ_length = pcOther->i_templ_length;

	v_pop.clear();
	for (size_t ii = 0; ii < pcOther->v_pop.size(); ii++)
	{
		if (pcOther->v_pop[ii] != nullptr)
		{
			v_pop.push_back(new CDarkGrayGAIndividual_MO(*(pcOther->v_pop[ii])));
		}//if (pcOther->v_population[ii] != nullptr)
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void  CDarkGrayGASinglePop_MO::vCopyForm(CDarkGrayGASinglePop_MO *pcOther)



COptimizer<CBinaryCoding, CBinaryCoding> *CDarkGrayGASinglePop_MO::pcCopy()
{
	CDarkGrayGASinglePop_MO  *pc_res = new CDarkGrayGASinglePop_MO(this);

	pc_res->vCopyFrom(this);

	return(pc_res);
}//COptimizer<CBinaryCoding, CBinaryCoding> *CDarkGrayGASinglePop_MO::pcCopy()


bool CDarkGrayGASinglePop_MO::bIsSteadyState()
{
	return(b_steady_state);
	//return(false);
}//bool CDarkGrayGASinglePop_MO::bIsSteadyState()


double CDarkGrayGASinglePop_MO::dComputeAverageFitnessValue()
{
	double  d_avr = 0;
	for (size_t ii = 0; ii < v_pop.size(); ii++)
	{
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (size_t ii = 0; ii < v_population.size(); ii++)

	return(d_avr / v_pop.size());
}//double CDarkGrayGASinglePop_MO::dComputeAverageFitnessValue()



CError CDarkGrayGASinglePop_MO::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA_MO_SinglePop);


	c_err = COptimizer::eConfigure(psSettings);


	CUIntCommandParam p_pop_size(OPTIMIZER_ARGUMENT_POP_SIZE);
	i_pop_size = p_pop_size.iGetValue(psSettings, &c_err);
	if (p_pop_size.bHasValue() == false)  i_pop_size = 0;
	if (c_err)  return(c_err);

	return c_err;
};//CError CDarkGrayGASinglePop_MO::eConfigure(istream *psSettings)



bool CDarkGrayGASinglePop_MO::bRunIterationForceCross(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA_MO_SinglePop);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();


	//save current individuals
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (v_pop_copy.size() <= ii)
			v_pop_copy.push_back(new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem*) pc_problem, this));

		v_pop_copy.at(ii)->vCopyFrom(v_pop.at(ii));
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	i_uniform_donations = 0;

	for (int ii = 0; ii < v_pop.size(); ii++)//it must be v_pop.size() here because we assured that v_pop_next is at least of the size of v_pop
	{
		i_epx_buf = v_pop_copy.at(ii)->iMixing_ePX_ByDonor(&v_pop_copy, v_pop.at(ii));

		if (i_epx_buf > 0)
		{
			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();




	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	if (i_epx_succ == 0)  b_steady_state = true;//asdasd

	s_buf.Format
	(
		"size: %d  best: %.8lf avr: %.8lf  epx[SUCC/min/max]: %d/%d/%d  Uniform Donations: %d Slides:%d iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		i_epx_succ, i_epx_min, i_epx_max, i_uniform_donations, i_slide_number,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	if (b_steady_state == true)  s_buf += "   STEADY STATE";
	pc_log->vPrintLine(s_buf, true);

	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGASinglePop_MO::bRunIterationForceCross(uint32_t iIterationNumber, time_t tStartTime)





bool CDarkGrayGASinglePop_MO::bRunIteration_sGA(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA_MO_SinglePop);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();


	//save current individuals
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (v_pop_copy.size() <= ii)
			v_pop_copy.push_back(new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem*) pc_problem, this));

		v_pop_copy.at(ii)->vCopyFrom(v_pop.at(ii));
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	i_uniform_donations = 0;

	for (int ii = 0; ii < v_pop.size(); ii++)//it must be v_pop.size() here because we assured that v_pop_next is at least of the size of v_pop
	{
		//i_epx_buf = v_pop_copy.at(ii)->iMixing_ePX_ByMaskLen(&v_pop_copy, v_pop.at(ii));
		i_epx_buf = iDonateToIndividual_PxByLen(v_pop_copy.at(ii));

		if (i_epx_buf > 0)
		{
			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	for (int ii = 0; ii < v_pop.size(); ii++)
		v_pop.at(ii)->vCopyFrom(v_pop_copy.at(ii));


	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();




	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	if (i_epx_succ == 0)  b_steady_state = true;//asdasd

	s_buf.Format
	(
		"size: %d  best: %.8lf avr: %.8lf  epx[SUCC/min/max]: %d/%d/%d  Uniform Donations: %d Slides:%d iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		i_epx_succ, i_epx_min, i_epx_max, i_uniform_donations, i_slide_number,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	if (b_steady_state == true)  s_buf += "   STEADY STATE";
	pc_log->vPrintLine(s_buf, true);

	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGASinglePop_MO::bRunIteration_sGA(uint32_t iIterationNumber)





bool CDarkGrayGASinglePop_MO::bRunIterationMaskLen(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CDarkGrayGA_MO_SinglePop);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();


	//save current individuals
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (v_pop_copy.size() <= ii)
			v_pop_copy.push_back(new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), this));

		v_pop_copy.at(ii)->vCopyFrom(v_pop.at(ii));
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	i_uniform_donations = 0;

	for (int ii = 0; ii < v_pop.size(); ii++)//it must be v_pop.size() here because we assured that v_pop_next is at least of the size of v_pop
	{
		i_epx_buf = v_pop_copy.at(ii)->iMixing_ePX_ByMaskLen(&v_pop_copy, v_pop.at(ii), false);

		if (i_epx_buf > 0)
		{
			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();




	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	if (i_epx_succ == 0)  b_steady_state = true;//asdasd

	s_buf.Format
	(
		"size: %d  best: %.8lf avr: %.8lf  epx[SUCC/min/max]: %d/%d/%d  Uniform Donations: %d Slides:%d iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr,
		i_epx_succ, i_epx_min, i_epx_max, i_uniform_donations, i_slide_number,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	if (b_steady_state == true)  s_buf += "   STEADY STATE";
	pc_log->vPrintLine(s_buf, true);

	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGASinglePop_MO::bRunIterationForceCross(uint32_t iIterationNumber, time_t tStartTime)





bool CDarkGrayGASinglePop_MO::bRunIteration(uint32_t iIterationNumber)
{
	return(bRunIterationMaskLen(iIterationNumber));
	return(bRunIterationForceCross(iIterationNumber));

	CError c_err(iERROR_PARENT_CDarkGrayGA_MO_SinglePop);

	CString  s_buf;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();


	//save current individuals
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (v_pop_copy.size() <= ii)
			v_pop_copy.push_back(new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), this));

		v_pop_copy.at(ii)->vCopyFrom(v_pop.at(ii));
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)//it must be v_pop.size() here because we assured that v_pop_next is at least of the size of v_pop
	{
		i_epx_buf = v_pop_copy.at(ii)->iMixing_ePX_ByDonor(&v_pop_copy, v_pop.at(ii));
		
		if (i_epx_buf > 0)
		{
			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
	}//for (int ii = 0; ii < v_pop.size(); ii++)


	double  d_avr = 0;
	for (int ii = 0; ii < v_pop.size(); ii++)
	{
		if (pc_best->dComputeFitness() < v_pop.at(ii)->dComputeFitness())  pc_best->vCopyFrom(v_pop.at(ii));
		d_avr += v_pop.at(ii)->dComputeFitness();
	}//for (int ii = 0; ii < v_pop.size(); ii++)
	d_avr = d_avr / v_pop.size();

	


	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->dComputeFitness(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->piGetGenotype()[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});
	d_time_last_time = c_time_counter.dGetTimePassed();


	if (i_epx_succ == 0)  b_steady_state = true;

	s_buf.Format
	(
		"size: %d  best: %.8lf avr: %.8lf  epx[SUCC/min/max]: %d/%d/%d  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(), pc_best->dComputeFitness(), d_avr, 
		i_epx_succ, i_epx_min, i_epx_max,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	if (b_steady_state == true)  s_buf += "   STEADY STATE";
	pc_log->vPrintLine(s_buf, true); 



	/*double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();


	if (pc_best->dComputeFitness() < pc_new_ind->dComputeFitness())
		pc_best->vCopyFrom(pc_new_ind);

	b_update_best_individual(iIterationNumber, tStartTime, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_time_counter.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf TheSameChecks: %d Ind:%d  Levs:%d, Last:%.8lf->%.8lf LastLev: %d  SuccOms: %d  Nodes[%d]: <%.0lf; %.0lf> Av: %.2lf Med: %.1lf [time: %.8lf] [FFE:%.0lf]",
		pc_best->dComputeFitness(), i_the_same_checks, iGetIndNumber(), v_pop.size(), d_start, pc_new_ind->dComputeFitness(), pc_new_ind->i_level, i_succ_oms,
		c_ltree_global.pvGetNodes()->size(), c_ltree_global.dGetNodeSizeMin(), c_ltree_global.dGetNodeSizeMax(), c_ltree_global.dGetNodeSizeAvr(), c_ltree_global.dGetNodeSizeMedian(),
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);*/


	return(true);
}//bool CDarkGrayGASinglePop_MO::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)




int  CDarkGrayGASinglePop_MO::iDonateToIndividual_PxByLen(CDarkGrayGAIndividual_MO  *pcReceiver, bool bUseDomination, vector<CDarkGrayGAIndividual_MO *> *pvPopToBeDifferentFrom)
{
	double  d_fitness_start, d_fitness_end;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();

	d_fitness_start = pcReceiver->dComputeFitness();


	if (pc_individual_buffer == NULL)  pc_individual_buffer = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), this);


	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;


	i_epx_buf = pcReceiver->iMixing_ePX_ByMaskLen(&v_pop, pc_individual_buffer, bUseDomination, pvPopToBeDifferentFrom);
	if (i_epx_buf > 0)
	{
		pcReceiver->vCopyFrom(pc_individual_buffer);

		i_epx_succ++;
		if (i_epx_min < 0)  i_epx_min = i_epx_buf;
		if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
		if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;

		return(1);
	}//if (i_epx_buf > 0)

	//we slide
	if (i_epx_buf == 0)
	{
		pcReceiver->vCopyFrom(pc_individual_buffer);

		i_slide_number++;
		if (i_epx_min < 0)  i_epx_min = i_epx_buf;
		if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
		if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;

		return(0);
	}//if (i_epx_buf > 0)


	/*d_fitness_end = pcReceiver->dComputeFitness();


	CString  s_buf, s_change;
	if (d_fitness_start < d_fitness_end)  s_change = "CHANGE!!!";


	s_buf.Format
	(
		"Donate toindividual PxByLen: size: %d  %s: %.8lf -> %.8lf      epx[SUCC/min/max]: %d/%d/%d  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(),
		s_change,
		d_fitness_start, d_fitness_end,
		i_epx_succ, i_epx_min, i_epx_max,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);

	if  (bPrint == true)  pc_log->vPrintLine(s_buf, true);*/

	return(-1);
}//bool  CDarkGrayGASinglePop_MO::bDonateToIndividual(CDarkGrayGAIndividual_MO  *pcReceiver)


bool  CDarkGrayGASinglePop_MO::bDonateToIndividual(CDarkGrayGAIndividual_MO  *pcReceiver)
{
	double  d_fitness_start, d_fitness_end;

	double  d_start_time;
	d_start_time = c_time_counter.dGetTimePassed();

	d_fitness_start = pcReceiver->dComputeFitness();


	if (pc_individual_buffer == NULL)  pc_individual_buffer = new CDarkGrayGAIndividual_MO(i_templ_length, (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation(), this);
	

	int  i_epx_min, i_epx_max, i_epx_succ, i_epx_buf;
	i_epx_min = -1;
	i_epx_max = -1;
	i_epx_succ = 0;

	i_epx_buf = 1;
	while  (i_epx_buf > 0)
	{
		i_epx_buf = pcReceiver->iMixing_ePX_ByDonor(&v_pop, pc_individual_buffer);

		if (i_epx_buf > 0)
		{
			pcReceiver->vCopyFrom(pc_individual_buffer);

			i_epx_succ++;
			if (i_epx_min < 0)  i_epx_min = i_epx_buf;
			if (i_epx_max < i_epx_buf)  i_epx_max = i_epx_buf;
			if (i_epx_buf < i_epx_min)  i_epx_min = i_epx_buf;
		}//if (i_epx_buf > 0)
		else
		{

		}//else if (i_epx_buf > 0)
	}//while  (i_epx_succ  == 1)


	d_fitness_end = pcReceiver->dComputeFitness();


	CString  s_buf, s_change;
	if (d_fitness_start < d_fitness_end)  s_change = "CHANGE!!!";

	
	s_buf.Format
	(
		"Donate toindividual: size: %d  %s: %.8lf -> %.8lf      epx[SUCC/min/max]: %d/%d/%d  iterTime: %.8lf [time: %.8lf] [FFE:%.0lf]",
		v_pop.size(),
		s_change,
		d_fitness_start, d_fitness_end,
		i_epx_succ, i_epx_min, i_epx_max,
		d_time_last_time - d_start_time,
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);

	if  (i_epx_succ  > 0)  return(true);

	return(false);
}//bool  CDarkGrayGASinglePop_MO::bDonateToIndividual(CDarkGrayGAIndividual_MO  *pcReceiver)



void  CDarkGrayGASinglePop_MO::vGetGenotypeBufferTools(int  **piTool_0, int  **piTool_1)
{
	if (pi_genotope_buffer_tool_0 == NULL)  pi_genotope_buffer_tool_0 = new int[i_templ_length];
	if (pi_genotope_buffer_tool_1 == NULL)  pi_genotope_buffer_tool_1 = new int[i_templ_length];
	
	*piTool_0 = pi_genotope_buffer_tool_0;
	*piTool_1 = pi_genotope_buffer_tool_1;
}//int  *CDarkGrayGASinglePop_MO::piGetGenotypeBufferTool()


double CDarkGrayGASinglePop_MO::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_evaluate(piBits);
	return(d_fitness_value);
}//double CDarkGrayGASinglePop_MO::dComputeFitness(int32_t *piBits)


double CDarkGrayGASinglePop_MO::dComputeFitnessDouble(int32_t *piBits)
{
	double d_fitness_value = d_evaluate_double(piBits);
	return(d_fitness_value);
}//double CDarkGrayGASinglePop_MO::dComputeFitness(int32_t *piBits)



void  CDarkGrayGASinglePop_MO::vRecalculateForNewWeights()
{
	for (int i_ind = 0; i_ind < v_pop.size(); i_ind++)
		v_pop.at(i_ind)->vRecalculateForNewWeights();
}//void  CDarkGrayGASinglePop_MO::vRecalculateForNewWeights()


void  CDarkGrayGASinglePop_MO::vExcludeDominated()
{
	int  i_domination;
	for (int i_ind_0 = 0; i_ind_0 < v_pop.size(); i_ind_0++)
	{
		for (int i_ind_1 = i_ind_0 + 1; i_ind_1 < v_pop.size(); i_ind_1++)
		{
			if (i_ind_0 < i_ind_1)
			{
				i_domination = v_pop.at(i_ind_0)->iCheckDomination(v_pop.at(i_ind_1));

				if (i_domination == 1)
				{
					delete  v_pop.at(i_ind_1);
					v_pop.erase(v_pop.begin() + i_ind_1);
					i_ind_1--;
				}//if (i_domination == 1)

				if (i_domination == -1)
				{
					delete  v_pop.at(i_ind_0);
					v_pop.erase(v_pop.begin() + i_ind_0);
					//i_ind_0--; we do NOT do it i_ind_0 becomes the next individual
					i_ind_1 = i_ind_0 + 1 - 1; //we reset the next iterator
				}//if (i_domination == 1)

				if (i_domination == 0)
				{
					if (v_pop.at(i_ind_0)->bTheSameObjectives(v_pop.at(i_ind_1)) == true)
					{
						delete  v_pop.at(i_ind_1);
						v_pop.erase(v_pop.begin() + i_ind_1);
						i_ind_1--;
					}//if (
				}//if (i_domination == 0)
			}//if  (i_ind_0 < i_ind_1)
		}//for (int i_ind_1 = 0; i_ind_1 < v_pop.size(); i_ind_1++)
	}//for  (int i_ind_0 = 0; i_ind_0 < v_pop.size(); i_ind_0++)
}//void  CDarkGrayGASinglePop_MO::vExcludeDominated()




double CDarkGrayGASinglePop_MO::d_evaluate(int32_t *piBits)
{
	if (pc_evaluation_individual == NULL)
	{
		pc_evaluation_individual = new CIndividual<CBinaryCoding, CBinaryCoding>(new CBinaryCoding(pc_problem->pcGetEvaluation()->iGetNumberOfElements(), nullptr), pc_problem->pcGetEvaluation(), nullptr, nullptr, pc_problem->pcGetTransformation());
	}//if (pc_evaluation_tool == NULL)
		
	pc_evaluation_individual->pcGetGenotype()->vSetBits(piBits);
	pc_evaluation_individual->vIsEvaluated(false);
	pc_evaluation_individual->vEvaluate();

	return pc_evaluation_individual->dGetFitnessValue();
}//double CDarkGrayGASinglePop_MO::d_evaluate(CBinaryPSOIndividual * pc_individual)



double CDarkGrayGASinglePop_MO::d_evaluate_double(int32_t *piBits)
{
	if (pc_evaluation_individual == NULL)
	{
		pc_evaluation_individual = new CIndividual<CBinaryCoding, CBinaryCoding>(new CBinaryCoding(pc_problem->pcGetEvaluation()->iGetNumberOfElements(), nullptr), pc_problem->pcGetEvaluation(), nullptr, nullptr, pc_problem->pcGetTransformation());
	}//if (pc_evaluation_tool == NULL)

	pc_evaluation_individual->pcGetGenotype()->vSetBits(piBits);
	pc_evaluation_individual->vIsEvaluated(false);
	pc_evaluation_individual->vEvaluateDouble();

	return pc_evaluation_individual->dGetFitnessValue();
}//double CDarkGrayGASinglePop_MO::d_evaluate(CBinaryPSOIndividual * pc_individual)






CString  CDarkGrayGASinglePop_MO::sAdditionalSummaryInfo()
{
	CString  s_buf;

	return(s_buf);
};//CString  CDarkGrayGASinglePop_MO::sAdditionalSummaryInfo() 





//---------------------------------------------CDarkGA_DSM_MO-------------------------------------------------------

CDarkGA_DSM_MO::CDarkGA_DSM_MO(CDarkGrayGA_MO  *pcParent)
{
	pi_dsm = NULL;
	i_prob_size = -1;
	pc_individual_tool = NULL;

	i_cost_ffe = 0;
	d_cost_time = 0;

	pc_parent = pcParent;

	i_sett_mo_dled = 0;

	d_vec_w0 = -1;
	d_vec_w1 = -1;

	pc_dependency_sets = NULL;
}//CDarkGA_DSM_MO::CDarkGA_DSM_MO(CDarkGrayGA_MO  *pcParent, int iSettMoDled)


CDarkGA_DSM_MO::~CDarkGA_DSM_MO()
{
	if (pi_dsm != NULL)
	{
		for (int ii = 0; ii < i_prob_size; ii++)
			delete  pi_dsm[ii];
		delete  pi_dsm;
	}//if (pi_dsm != NULL)

	if (pc_individual_tool != NULL)  delete  pc_individual_tool;

	if (pc_dependency_sets != NULL)
	{
		for (int iy = 0; iy < i_prob_size; iy++)
		{
			for (int ix = 0; ix < i_prob_size; ix++)
				if (pc_dependency_sets[ix][iy] != NULL)  delete  pc_dependency_sets[ix][iy];
		}//for (int iy = 0; iy < i_prob_size; iy++)

		for (int ii = 0; ii < i_prob_size; ii++)
			delete  pc_dependency_sets[ii];
		delete  pc_dependency_sets;
	}//if (pc_dependency_sets != NULL)


	//for (int ii = 0; ii < v_dependency_ranges.size(); ii++)
		//delete  v_dependency_ranges.at(ii);
}//CDarkGA_DSM_MO::CDarkGA_DSM_MO(int  iProblemSize)


void  CDarkGA_DSM_MO::vSetMO_Dled(int  iNewMO_Dled)
{
	i_sett_mo_dled = iNewMO_Dled;
}//void  CDarkGA_DSM_MO::vSetMO_Dled(int  iNewMO_Dled)


bool  CDarkGA_DSM_MO::bSetSize(int  iProbSize)
{
	if (i_prob_size > 0)  return(false);

	i_prob_size = iProbSize;
	pi_dsm = new int*[i_prob_size];
	for (int ii = 0; ii < i_prob_size; ii++)
		pi_dsm[ii] = new int[i_prob_size];

	v_zero_dsm();


	pc_dependency_sets = new CDarkGA_DSM_MO_Dependency_Set**[i_prob_size];
	for (int ii = 0; ii < i_prob_size; ii++)
		pc_dependency_sets[ii] = new CDarkGA_DSM_MO_Dependency_Set*[i_prob_size];

	for (int ix = 0; ix < i_prob_size; ix++)
	{
		for (int iy = 0; iy < i_prob_size; iy++)
			pc_dependency_sets[ix][iy] = NULL;
	}//for (int ix = 0; ix < i_prob_size; ix++)
	
	return(true);
}//bool  CDarkGA_DSM_MO::bSetSize(int  iProbSize)


void  CDarkGA_DSM_MO::v_zero_dsm()
{
	for (int iy = 0; iy < i_prob_size; iy++)
	{
		for (int ix = 0; ix < i_prob_size; ix++)
			pi_dsm[ix][iy] = 0;
	}//for (int iy = 0; iy < i_prob_size; iy++)
}//void  CDarkGA_DSM_MO::v_zero_dsm()



bool  CDarkGA_DSM_MO::bSave(CString  sDest)
{
	FILE  *pf_dest;

	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return(false);
	bSave(pf_dest);
	fclose(pf_dest);

	return(true);
}//bool  CDarkGA_DSM_MO::bSave(CString  sDest)


bool  CDarkGA_DSM_MO::bSave(FILE  *pfDest)
{
	CString  s_line, s_buf;

	s_line = " \t ";
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		s_buf.Format("%d\t", ii);
		s_line += s_buf;
	}//for (int ii = 0; ii < i_prob_size; ii++)
	s_line += "\n";
	fprintf(pfDest, s_line);

	for (int iy = 0; iy < i_prob_size; iy++)
	{
		s_line.Format("%d\t", iy);
		for (int ix = 0; ix < i_prob_size; ix++)
		{
			s_buf.Format("%d\t", pi_dsm[ix][iy]);
			s_line += s_buf;
		}//for (int ix = 0; ix < i_prob_size; ix++)
		s_line += "\n";
		fprintf(pfDest, s_line);
	}//for (int iy = 0; iy < i_prob_size; iy++)
}//bool  CDarkGA_DSM_MO::bSave(FILE  *pfDest)


void  CDarkGA_DSM_MO::vSaveDepRanges(CString  sDest)
{
	FILE  *pf_dest;

	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;
	vSaveDepRanges(pf_dest);
	fclose(pf_dest);
}//void  CDarkGA_DSM_MO::vSaveDepRanges(CString  sDest)


void  CDarkGA_DSM_MO::vSaveDepRanges(FILE  *pfDest)
{
	CString  s_buf;

	int  i_counter;

	if (pc_dependency_sets != NULL)
	{
		i_counter = 0;

		s_buf.Format("\n\nRANGES:\n");
		fprintf(pfDest, s_buf);

		for (int ix = 0; ix < i_prob_size; ix++)
		{
			for (int iy = 0; iy < i_prob_size; iy++)
			{
				if (pc_dependency_sets[ix][iy] != NULL)
				{
					s_buf = pc_dependency_sets[ix][iy]->sToStr();
					s_buf += "\n";
					fprintf(pfDest, s_buf);
				}//if (pc_dependency_sets[ix][iy] != NULL)
			}//for (int ix = 0; ix < i_prob_size; ix++)
		}//for (int iy = 0; iy < i_prob_size; iy++)

	}//if (pc_dependency_sets != NULL)
	else
		fprintf(pfDest, "<NO RANGES>");

	/*s_buf.Format("\n\nRANGES[%d]:\n", v_dependency_ranges.size());
	fprintf(pfDest, s_buf);

	for (int ii = 0; ii < v_dependency_ranges.size(); ii++)
	{
		s_buf = v_dependency_ranges.at(ii)->sToStr();
		s_buf += "\n";
		fprintf(pfDest, s_buf);
	}//for (int ii = 0; ii < v_dependency_ranges.size(); ii++)*/
}//void  CDarkGA_DSM_MO::vSaveDepRanges(FILE  *pfDest)



/*
#define MO_DLED__EPISTASIS__PERCENTAGE			 "{MO_DLED__EPISTASIS__PERCENTAGE}"
#define MO_DLED__EPISTASIS__NUMBER				 "{MO_DLED__EPISTASIS__NUMBER}"

#define MO_DLED__DEP_TYPE__COMPLETE__PERCENTAGE	 "{MO_DLED__DEP_TYPE__COMPLETE__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__COMPLETE__NUMBER		 "{MO_DLED__DEP_TYPE__COMPLETE__NUMBER}"
#define MO_DLED__DEP_TYPE__LEFT__PERCENTAGE		 "{MO_DLED__DEP_TYPE__LEFT__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__LEFT__NUMBER			 "{MO_DLED__DEP_TYPE__LEFT__NUMBER}"
#define MO_DLED__DEP_TYPE__RIGHT__PERCENTAGE	 "{MO_DLED__DEP_TYPE__RIGHT__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__RIGHT__NUMBER		 "{MO_DLED__DEP_TYPE__RIGHT__NUMBER}"
#define MO_DLED__DEP_TYPE__LEFT_RIGHT__PERCENTAGE		 "{MO_DLED__DEP_TYPE__LEFT_RIGHT__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__LEFT_RIGHT__NUMBER			 "{MO_DLED__DEP_TYPE__LEFT_RIGHT__NUMBER}"
#define MO_DLED__DEP_TYPE__MIDDLE__PERCENTAGE	 "{MO_DLED__DEP_TYPE__MIDDLE__PERCENTAGE}"
#define MO_DLED__DEP_TYPE__MIDDLE__NUMBER		 "{MO_DLED__DEP_TYPE__MIDDLE__NUMBER}"

#define MO_DLED__RANGES__1_PERCENTAGE		 "{MO_DLED__RANGES__1_PERCENTAGE}"
#define MO_DLED__RANGES__1_NUMBER			 "{MO_DLED__RANGES__1_NUMBER}"
#define MO_DLED__RANGES__2_PERCENTAGE		 "{MO_DLED__RANGES__2_PERCENTAGE}"
#define MO_DLED__RANGES__2_NUMBER			 "{MO_DLED__RANGES__2_NUMBER}"
#define MO_DLED__RANGES__3_PERCENTAGE		 "{MO_DLED__RANGES__3_PERCENTAGE}"
#define MO_DLED__RANGES__3_NUMBER			 "{MO_DLED__RANGES__3_NUMBER}"
#define MO_DLED__RANGES__4_PERCENTAGE		 "{MO_DLED__RANGES__4_PERCENTAGE}"
#define MO_DLED__RANGES__4_NUMBER			 "{MO_DLED__RANGES__4_NUMBER}"
#define MO_DLED__RANGES__5_PERCENTAGE		 "{MO_DLED__RANGES__5_PERCENTAGE}"
#define MO_DLED__RANGES__5_NUMBER			 "{MO_DLED__RANGES__5_NUMBER}"
#define MO_DLED__RANGES__MORE_PERCENTAGE		 "{MO_DLED__RANGES__MORE_PERCENTAGE}"
#define MO_DLED__RANGES__MORE_NUMBER			 "{MO_DLED__RANGES__MORE_NUMBER}"


#define MO_DLED__COVERAGE__100perc_COVERAGE_NUMBER			 "{MO_DLED__COVERAGE__100perc_COVERAGE_NUMBER}"
#define MO_DLED__COVERAGE__100perc_COVERAGE_PERCENTAGE		 "{MO_DLED__COVERAGE__100perc_COVERAGE_PERCENTAGE}"

#define MO_DLED__COVERAGE__AVR								 "{MO_DLED__COVERAGE__AVR}"
#define MO_DLED__COVERAGE__ST_DEV							 "{MO_DLED__COVERAGE__ST_DEV}"
#define MO_DLED__COVERAGE__MEDIAN						     "{MO_DLED__COVERAGE__MEDIAN}"

*/

double  d_divide(int  iNum, int  iBase)
{
	double  d_result;

	d_result = iNum;
	d_result = d_result / iBase;

	return(d_result);
}//double  d_divide(int  iNum, int  iBase)


CString  CDarkGA_DSM_MO::s_mo_dled_stats__coverage()
{
	CString  s_result, s_buf;
	double  d_coverage_cur;

	vector<double>  v_coverages;


	int  i_pairs_number;
	i_pairs_number = i_mo_dled__get_pairs_number();

	
	int  i_coverage_100perc_num;

	i_coverage_100perc_num = 0;
	for (int iy = 0; iy < i_prob_size; iy++)
	{
		for (int ix = 0; ix < i_prob_size; ix++)
		{
			if (pc_dependency_sets[ix][iy] != NULL)
			{
				d_coverage_cur = pc_dependency_sets[ix][iy]->dCoverage();

				if (d_coverage_cur > 0.9999)  i_coverage_100perc_num++;//rounding inconsistencies!
				v_coverages.push_back(d_coverage_cur);
			}//if (pc_dependency_sets[ix][iy] != NULL)
		}//for (int ix = 0; ix < i_prob_size; ix++)
	}//for (int iy = 0; iy < i_prob_size; iy++)

	double  d_cov_avr, d_cov_st_dev, d_cov_med;
	if (::Tools::bGetMedianAndAvr(&v_coverages, true, &d_cov_med, &d_cov_avr, &d_cov_st_dev) == false)
	{
		s_result = "<error at ::Tools::bGetMedianAndAvr>";
		return(s_result);
	}//if (::Tools::bGetMedianAndAvr(&v_coverages, true, &d_cov_med, &d_cov_avr, &d_cov_st_dev) == false)
	
	double  d_coverage_100perc_perc;
	d_coverage_100perc_perc = d_divide(i_coverage_100perc_num, i_pairs_number);

	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__COVERAGE__100perc_COVERAGE_PERCENTAGE, d_coverage_100perc_perc, MO_DLED__COVERAGE__100perc_COVERAGE_NUMBER, i_coverage_100perc_num);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%lf\t%s\t%lf", MO_DLED__COVERAGE__AVR, d_cov_avr, MO_DLED__COVERAGE__ST_DEV, d_cov_st_dev, MO_DLED__COVERAGE__MEDIAN, d_cov_med);
	s_result += s_buf;

	return(s_result);
}//CString  CDarkGA_DSM_MO::s_mo_dled_stats__coverage()


CString  CDarkGA_DSM_MO::sGet_MO_Dled_Stats()
{
	CString  s_result;
	if (i_sett_mo_dled != i_OPTIMIZER_DARK_GA_MO_DSM__MO_DLED_ON)  return(s_result);

	s_result += s_mo_dled_stats__epistasis();
	s_result += s_mo_dled_stats__dep_type();
	s_result += s_mo_dled_stats__ranges();
	s_result += s_mo_dled_stats__coverage();

	return(s_result);
}//CString  CDarkGA_DSM_MO::sGet_MO_Dled_Stats()



CString  CDarkGA_DSM_MO::s_mo_dled_stats__ranges()
{
	CString  s_result, s_buf;

	int  i_pairs_number;
	i_pairs_number = i_mo_dled__get_pairs_number();

	int  i_range_1, i_range_2, i_range_3, i_range_4, i_range_5, i_range_more;

	i_range_1 = 0;
	i_range_2 = 0;
	i_range_3 = 0;
	i_range_4 = 0;
	i_range_5 = 0;
	i_range_more = 0;

	for (int iy = 0; iy < i_prob_size; iy++)
	{
		for (int ix = 0; ix < i_prob_size; ix++)
		{
			if (pc_dependency_sets[ix][iy] != NULL)
			{
				if (pc_dependency_sets[ix][iy]->pvGet_DependencyNumber()->size() == 1)  i_range_1++;
				if (pc_dependency_sets[ix][iy]->pvGet_DependencyNumber()->size() == 2)  i_range_2++;
				if (pc_dependency_sets[ix][iy]->pvGet_DependencyNumber()->size() == 3)  i_range_3++;
				if (pc_dependency_sets[ix][iy]->pvGet_DependencyNumber()->size() == 4)  i_range_4++;
				if (pc_dependency_sets[ix][iy]->pvGet_DependencyNumber()->size() == 5)  i_range_5++;
				if (pc_dependency_sets[ix][iy]->pvGet_DependencyNumber()->size() > 5)   i_range_more++;
			}//if (pc_dependency_sets[ix][iy] != NULL)
		}//for (int ix = 0; ix < i_prob_size; ix++)
	}//for (int iy = 0; iy < i_prob_size; iy++)


	double  d_range_1_perc, d_range_2_perc, d_range_3_perc, d_range_4_perc, d_range_5_perc, d_range_more_perc;
	d_range_1_perc = d_divide(i_range_1, i_pairs_number);
	d_range_2_perc = d_divide(i_range_2, i_pairs_number);
	d_range_3_perc = d_divide(i_range_3, i_pairs_number);
	d_range_4_perc = d_divide(i_range_4, i_pairs_number);
	d_range_5_perc = d_divide(i_range_5, i_pairs_number);
	d_range_more_perc = d_divide(i_range_more, i_pairs_number);


	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__RANGES__1_PERCENTAGE, d_range_1_perc, MO_DLED__RANGES__1_NUMBER, i_range_1);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__RANGES__2_PERCENTAGE, d_range_2_perc, MO_DLED__RANGES__2_NUMBER, i_range_2);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__RANGES__3_PERCENTAGE, d_range_3_perc, MO_DLED__RANGES__3_NUMBER, i_range_3);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__RANGES__4_PERCENTAGE, d_range_4_perc, MO_DLED__RANGES__4_NUMBER, i_range_4);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__RANGES__5_PERCENTAGE, d_range_5_perc, MO_DLED__RANGES__5_NUMBER, i_range_5);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__RANGES__MORE_PERCENTAGE, d_range_more_perc, MO_DLED__RANGES__MORE_NUMBER, i_range_more);
	s_result += s_buf;


	return(s_result);
}//CString  CDarkGA_DSM_MO::s_mo_dled_stats__ranges()



CString  CDarkGA_DSM_MO::s_mo_dled_stats__dep_type()
{
	CString  s_result, s_buf;

	int  i_pairs_number;
	i_pairs_number = i_mo_dled__get_pairs_number();

	int  i_type;
	int  i_type_complete_num, i_type_left_num, i_type_right_num, i_type_left_right_num, i_type_middle_num;


	i_type_complete_num = 0;
	i_type_left_num = 0;
	i_type_right_num = 0;
	i_type_left_right_num = 0;
	i_type_middle_num = 0;
	for (int iy = 0; iy < i_prob_size; iy++)
	{
		for (int ix = 0; ix < i_prob_size; ix++)
		{
			if (pc_dependency_sets[ix][iy] != NULL)
			{
				i_type = pc_dependency_sets[ix][iy]->iGetMODependencyType();

				if (i_type == i_MO_DEPENDENCY_TYPE__COMPLETE)  i_type_complete_num++;
				if (i_type == i_MO_DEPENDENCY_TYPE__LEFT)  i_type_left_num++;
				if (i_type == i_MO_DEPENDENCY_TYPE__RIGHT)  i_type_right_num++;
				if (i_type == i_MO_DEPENDENCY_TYPE__LEFT_RIGHT)  i_type_left_right_num++;
				if (i_type == i_MO_DEPENDENCY_TYPE__MIDDLE)  i_type_middle_num++;
			}//if (pc_dependency_sets[ix][iy] != NULL)
		}//for (int ix = 0; ix < i_prob_size; ix++)
	}//for (int iy = 0; iy < i_prob_size; iy++)


	double  d_type_complete_perc, d_type_left_perc, d_type_right_perc, d_type_left_right_perc, d_type_middle_perc;
	d_type_complete_perc	= d_divide(i_type_complete_num, i_pairs_number);
	d_type_left_perc		= d_divide(i_type_left_num, i_pairs_number);
	d_type_right_perc		= d_divide(i_type_right_num, i_pairs_number);
	d_type_left_right_perc	= d_divide(i_type_left_right_num, i_pairs_number);
	d_type_middle_perc		= d_divide(i_type_middle_num, i_pairs_number);

	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__DEP_TYPE__COMPLETE__PERCENTAGE, d_type_complete_perc, MO_DLED__DEP_TYPE__COMPLETE__NUMBER, i_type_complete_num);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__DEP_TYPE__LEFT__PERCENTAGE, d_type_left_perc, MO_DLED__DEP_TYPE__LEFT__NUMBER, i_type_left_num);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__DEP_TYPE__RIGHT__PERCENTAGE, d_type_right_perc, MO_DLED__DEP_TYPE__RIGHT__NUMBER, i_type_right_num);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__DEP_TYPE__LEFT_RIGHT__PERCENTAGE, d_type_left_right_perc, MO_DLED__DEP_TYPE__LEFT_RIGHT__NUMBER, i_type_left_right_num);
	s_result += s_buf;
	s_buf.Format("\t%s\t%lf\t%s\t%d", MO_DLED__DEP_TYPE__MIDDLE__PERCENTAGE, d_type_middle_perc, MO_DLED__DEP_TYPE__MIDDLE__NUMBER, i_type_middle_num);
	s_result += s_buf;

	return(s_result);
}//CString  CDarkGA_DSM_MO::s_mo_dled_stats__dep_type()


CString  CDarkGA_DSM_MO::s_mo_dled_stats__epistasis()
{
	CString  s_result;

	int  i_pairs_max, i_pairs_number;
	i_pairs_max = (i_prob_size * (i_prob_size - 1)) / 2;
	i_pairs_number = i_mo_dled__get_pairs_number();

	double  d_pairs_perc;
	d_pairs_perc = d_divide(i_pairs_number, i_pairs_max);
	s_result.Format("\t%s\t%lf\t%s\t%d", MO_DLED__EPISTASIS__PERCENTAGE, d_pairs_perc, MO_DLED__EPISTASIS__NUMBER, i_pairs_number);

	return(s_result);
}//CString  CDarkGA_DSM_MO::s_mo_dled_stats__epistasis()


int  CDarkGA_DSM_MO::i_mo_dled__get_pairs_number()
{
	int  i_counter;

	i_counter = 0;
	for (int iy = 0; iy < i_prob_size; iy++)
	{
		for (int ix = 0; ix < i_prob_size; ix++)
		{
			if (pc_dependency_sets[ix][iy] != NULL)  i_counter++;
		}//for (int ix = 0; ix < i_prob_size; ix++)
	}//for (int iy = 0; iy < i_prob_size; iy++)

	return(i_counter);
}//int  CDarkGA_DSM_MO::i_mo_dled__get_pairs_number()



bool  CDarkGA_DSM_MO::bGetTrueLinkage(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem)
{
	vector<vector <int>>  v_dependent_genes;
	pcProblem->vGetTrueGeneDependencies(&v_dependent_genes);


	CString  s_line, s_buf;
	FILE  *pf_test;
	/*pf_test = fopen("zzzz_trueLink.txt", "w+");
	for (int i_set = 0; i_set < v_dependent_genes.size(); i_set++)
	{
		s_line.Format("[%d]:", i_set);
		for (int i_off = 0; i_off < v_dependent_genes.at(i_set).size(); i_off++)
		{
			s_buf.Format("%d, ", v_dependent_genes.at(i_set).at(i_off));
			s_line += s_buf;
		}//for (int i_off = 0; i_off < v_dependent_genes.at(i_set).size(); i_off++)

		s_line += "\n";
		fprintf(pf_test, s_line);
	}//for (int ii = 0; ii < v_dependent_genes.size(); ii++)
	fclose(pf_test);//*/


	for (int i_gene_this = 0; i_gene_this < v_dependent_genes.size(); i_gene_this++)
	{
		for (int i_gene_other_offset = 0; i_gene_other_offset < v_dependent_genes.at(i_gene_this).size(); i_gene_other_offset++)
		{
			pi_dsm[i_gene_this][v_dependent_genes.at(i_gene_this).at(i_gene_other_offset)] = 1;
		}//for (int i_gene_other = 0; i_gene_other < v_dependent_genes.at(i_gene_this).size(); i_gene_other++)
	}//for (int i_gene = 0; i_gene < v_dependent_genes.size(); i_gene++)

	//bSave("zzzz_true_dsm.txt");
	//::Tools::vShow("trueLink");

		

	return(true);
}//bool  CDarkGA_DSM_MO::bGetTrueLinkage(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem)


CString  CDarkGA_DSM_MO::sLinkageSummaryReport()
{
	CString  s_res;

	vector<vector <int>>  v_dependent_genes;
	pc_parent->pc_problem->vGetTrueGeneDependencies(&v_dependent_genes);
	if (v_dependent_genes.size() == 0)
	{
		s_res.Format
		(
			"\%s\t%.2lf\t%s\t%d",
			OPT_LINK_COST_TIME, d_cost_time, OPT_LINK_COST_FFE, i_cost_ffe
		);
		return(s_res);
	}//if (v_dependent_genes.size() == 0)

	int  i_cur_fill;
	double  d_fill_perc_cur, d_fill_perc_min, d_fill_perc_max, d_fill_perc_avr;
	int  i_true_dependent_genes;
	for (int i_gene = 0; i_gene < i_prob_size; i_gene++)
	{
		i_cur_fill = 0;
		
		for (int i_other = 0; i_other < i_prob_size; i_other++)
		{
			if (i_gene != i_other)
			{
				if (pi_dsm[i_gene][i_other] > 0)  i_cur_fill++;
			}//if (i_gene != i_other)
		}//for (int i_other = 0; i_other < i_prob_size; i_other++)

		i_true_dependent_genes = 0;
		for (int ii = 0; ii < v_dependent_genes.at(i_gene).size(); ii++)
		{
			if (v_dependent_genes.at(i_gene).at(ii) != i_gene)  i_true_dependent_genes++;
		}//for (int ii = 0; ii < v_dependent_genes.at(i_gene).size(); ii++)


		

		d_fill_perc_cur = i_cur_fill;
		if (v_dependent_genes.at(i_gene).size() > 0)
			d_fill_perc_cur = d_fill_perc_cur / i_true_dependent_genes;
		else
			d_fill_perc_cur = 1;

		if (i_gene == 0)
		{
			d_fill_perc_min = d_fill_perc_cur;
			d_fill_perc_max = d_fill_perc_cur;
			d_fill_perc_avr = d_fill_perc_cur;
		}//if (i_gene == 0)
		else
		{
			if (d_fill_perc_cur < d_fill_perc_min)  d_fill_perc_min = d_fill_perc_cur;
			if (d_fill_perc_cur > d_fill_perc_max)  d_fill_perc_max = d_fill_perc_cur;
			d_fill_perc_avr += d_fill_perc_cur;
		}//else  if (i_gene == 0)
	}//for (int i_gene = 0; i_gene < i_prob_size; i_gene++)

	d_fill_perc_avr = d_fill_perc_avr / i_prob_size;

	
	s_res.Format
		(
			"\t%s\t%.8lf\t%s\t%.8lf\t%s\t%.8lf\t%s\t%.2lf\t%s\t%d", 
			OPT_LINK_QUALITY_FILL_MIN, d_fill_perc_min, OPT_LINK_QUALITY_FILL_MAX, d_fill_perc_max, OPT_LINK_QUALITY_FILL_AVR, d_fill_perc_avr, 
			OPT_LINK_COST_TIME, d_cost_time, OPT_LINK_COST_FFE, i_cost_ffe
		);
	return(s_res);
}//CString  CDarkGA_DSM_MO::sLinkageSummaryReport()



void  CDarkGA_DSM_MO::vDarkGrayMapDependentGenes(int  iGeneOffset, int  *piMask)
{
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		if ((pi_dsm[iGeneOffset][ii] > 0) && (iGeneOffset != ii))
		{
			piMask[ii] = 1;
		}//if ((pi_dsm[iGeneOffset][ii] > 0) && (iGeneOffset != ii))
	}//for (int ii = 0; ii < i_prob_size; ii++)

}//void  CDarkGA_DSM_MO::vDarkGrayMapDependentGenes(int  iGeneOffset, int  *piMask)


int  CDarkGA_DSM_MO::iRebuildDSM_ForVectors(double  dVec0, double dVec1)
{
	d_vec_w0 = dVec0;
	d_vec_w1 = dVec1;


	int  i_dep_applying;

	i_dep_applying = 0;
	if (i_sett_mo_dled == i_OPTIMIZER_DARK_GA_MO_DSM__MO_DLED_ON)
	{
		v_zero_dsm();

		for (int ix = 0; ix < i_prob_size; ix++)
		{
			for (int iy = ix+1; iy < i_prob_size; iy++)
			{
				if (pc_dependency_sets[ix][iy] != NULL)
				{
					if (pc_dependency_sets[ix][iy]->bInRange(d_vec_w0, d_vec_w1) == true)
					{
						if (pi_dsm[ix][iy] == 0)
						{
							pi_dsm[ix][iy] = 1;
							pi_dsm[iy][ix] = 1;

							i_dep_applying += 2;
						}//if (pi_dsm[v_dependency_ranges.at(i_dep)->i_gene_0][v_dependency_ranges.at(i_dep)->i_gene_1] == 0)

					}//if (v_dependency_ranges.at(i_dep)->bInRange(d_vec_w0, d_vec_w1) == true)
				}//if (pc_dependency_sets[ix][iy] != NULL)
			}//for (int ix = 0; ix < i_prob_size; ix++)
		}//for (int iy = 0; iy < i_prob_size; iy++)

		/*for (int i_dep = 0; i_dep < v_dependency_ranges.size(); i_dep++)
		{
			if (v_dependency_ranges.at(i_dep)->bInRange(d_vec_w0, d_vec_w1) == true)
			{
				if (pi_dsm[v_dependency_ranges.at(i_dep)->i_gene_0][v_dependency_ranges.at(i_dep)->i_gene_1] == 0)
				{
					pi_dsm[v_dependency_ranges.at(i_dep)->i_gene_0][v_dependency_ranges.at(i_dep)->i_gene_1] = 1;
					pi_dsm[v_dependency_ranges.at(i_dep)->i_gene_1][v_dependency_ranges.at(i_dep)->i_gene_0] = 1;

					i_dep_applying += 2;
				}//if (pi_dsm[v_dependency_ranges.at(i_dep)->i_gene_0][v_dependency_ranges.at(i_dep)->i_gene_1] == 0)
				
			}//if (v_dependency_ranges.at(i_dep)->bInRange(d_vec_w0, d_vec_w1) == true)
		}//for (int i_dep = 0; i_dep < v_dependency_ranges.size(); i_dep++)*/

	}//if (i_sett_mo_dled == i_OPTIMIZER_DARK_GA_MO_DSM__MO_DLED_ON)

	return(i_dep_applying);
}//int  CDarkGA_DSM_MO::iRebuildDSM_ForVectors(double  dVec0, double dVec1)


void  CDarkGA_DSM_MO::vUpdateDSM(CDarkGrayGAPxMask_MO  *pcMask)
{
	CString  s_buf;

	int  i_ffe_start, i_ffe_end;
	double  d_time_spent;

	CTimeCounter  c_timer_local;
	i_ffe_start = pc_parent->pcGetProblem()->pcGetEvaluation()->iGetFFE();
	c_timer_local.vSetStartNow();

	int  *pi_dled_extraction_mask;
	pi_dled_extraction_mask = new int[i_prob_size];

	for (int ii = 0; ii < i_prob_size; ii++)
		pi_dled_extraction_mask[ii] = 2;//2->the context gene to check

	for (int i_mask_off = 0; i_mask_off < pcMask->v_mask.size(); i_mask_off++)
		pi_dled_extraction_mask[pcMask->v_mask.at(i_mask_off)] = 1;//1->the gene from the mask (block gene)

	for (int ii = 0; ii < i_prob_size; ii++)
	{
		if  (pcMask->pc_parent_0->piGetGenotype()[ii] == pcMask->pc_parent_1->piGetGenotype()[ii])  pi_dled_extraction_mask[ii] = -1;
	}//for (int ii = 0; ii < i_prob_size; ii++)

	
	int  i_new_pairs_detected = 0;
	for (int i_gene_context = 0; i_gene_context < i_prob_size; i_gene_context++)
	{
		for (int i_gene_block = 0; i_gene_block < i_prob_size; i_gene_block++)
		{
			if ((pi_dled_extraction_mask[i_gene_context] == 2) && (pi_dled_extraction_mask[i_gene_block] == 1))
			{
				v_extract_dled_for_gene_pair(i_gene_block, i_gene_context, pi_dled_extraction_mask, pcMask->pc_parent_0, &i_new_pairs_detected);
				v_extract_dled_for_gene_pair(i_gene_block, i_gene_context, pi_dled_extraction_mask, pcMask->pc_parent_1, &i_new_pairs_detected);
			}//if ((pi_dled_extraction_mask[i_gene_context] == 2) && (pi_dled_extraction_mask[i_gene_block] == 1))
		}//for (int i_gene_block = 0; i_gene_block < i_prob_size; i_gene_block++)
	}//for (int i_context_gene = 0; i_context_gene < i_prob_size; i_context_gene++)

	i_ffe_end = pc_parent->pcGetProblem()->pcGetEvaluation()->iGetFFE();
	d_time_spent = c_timer_local.dGetTimePassed();

	d_cost_time += d_time_spent;
	i_cost_ffe += (i_ffe_end - i_ffe_start);

	delete  pi_dled_extraction_mask;

	//bSave("zzz_dsm_afeter.txt");
	//::Tools::vShow("zzz_dsm_afeter.txt");

	//this is unnecessary! it is updated on-the-run in: v_extract_dled_for_gene_pair
	//iRebuildDSM_ForVectors(d_vec_w0, d_vec_w1);


	//CString  s_dled_cost_report;
	//s_dled_cost_report.Format("DSM update info: newConnections:%d cost: %.16lfs(Total: %.16lf) %dffe(Total: %d)", i_new_pairs_detected, d_time_spent, d_cost_time, (i_ffe_end - i_ffe_start), i_cost_ffe);
	//pc_parent->pcGetLog()->vPrintLine(s_dled_cost_report, true);
	
}//void  CDarkGA_DSM_MO::vUpdateDSM(CDarkGrayGAPxMask_MO  *pcMask)



bool  CDarkGA_DSM_MO::b_check_if_true_linkage(int iGeneBlock, int  iGeneContext)
{
	vector<vector <int>>  v_dependent_genes;
	pc_parent->pc_problem->vGetTrueGeneDependencies(&v_dependent_genes);

	for (int i_other_gene_off = 0; i_other_gene_off < v_dependent_genes.at(iGeneBlock).size(); i_other_gene_off++)
	{
		if (v_dependent_genes.at(iGeneBlock).at(i_other_gene_off) == iGeneContext)  return(true);
	}//for (int i_other_gene_off = 0; i_other_gene_off < v_dependent_genes.at(iGeneBlock).size(); i_other_gene_off++)

	return(false);
}//bool  CDarkGA_DSM_MO::b_check_if_true_linkage(int iGeneBlock, int  iGeneContext)




bool  CDarkGA_DSM_MO::b_new_dep_range_try_add(CDarkGA_DSM_MO_Dependency  *pcNewDependency)
{
	if (pc_dependency_sets == NULL)  ::Tools::vShow("bool  CDarkGA_DSM_MO::b_new_dep_range_try_add(CDarkGA_DSM_MO_Dependency  *pcNewDependency)");

	int  i_buf;
	int  i_x, i_y;
	i_x = pcNewDependency->i_gene_0;
	i_y = pcNewDependency->i_gene_1;
	if (i_x > i_y)
	{
		i_buf = i_x;
		i_x = i_y;
		i_y = i_buf;
	}//if (i_x > i_y)

	if (pc_dependency_sets[i_x][i_y] == NULL)  pc_dependency_sets[i_x][i_y] = new CDarkGA_DSM_MO_Dependency_Set(i_x, i_y);

	if (pc_dependency_sets[i_x][i_y]->bAddNewDependency(pcNewDependency) == true)  return(true);

	return(false);
}//bool  CDarkGA_DSM_MO::b_new_dep_range_try_add(CDarkGA_DSM_MO_Dependency  *pcNewDependency)


void  CDarkGA_DSM_MO::vTest()
{
	CString  s_buf;


	double  d_0_bo_c, d_0_ba_c;
	double  d_0_co_b, d_0_ca_b;
	double  d_1_bo_c, d_1_ba_c;
	double  d_1_co_b, d_1_ca_b;

	d_0_bo_c = -22.0000;
	d_0_ba_c = -28.0000;
	d_0_co_b = -15.0000;
	d_0_ca_b = -21.0000;
	d_1_bo_c =  33.0000; 
	d_1_ba_c =  23.0000;
	d_1_co_b =  24.0000;  
	d_1_ca_b =  14.0000;


	vector<double>  v_zero_points;
	double  d_zero_point_temp;

	d_zero_point_temp = ::Tools::dGetZeroPoint(d_0_bo_c, d_1_bo_c);
	if (0 <= d_zero_point_temp)  v_zero_points.push_back(d_zero_point_temp);
	d_zero_point_temp = ::Tools::dGetZeroPoint(d_0_ba_c, d_1_ba_c);
	if (0 <= d_zero_point_temp)  v_zero_points.push_back(d_zero_point_temp);
	d_zero_point_temp = ::Tools::dGetZeroPoint(d_0_co_b, d_1_co_b);
	if (0 <= d_zero_point_temp)  v_zero_points.push_back(d_zero_point_temp);
	d_zero_point_temp = ::Tools::dGetZeroPoint(d_0_ca_b, d_1_ca_b);
	if (0 <= d_zero_point_temp)  v_zero_points.push_back(d_zero_point_temp);

	std::sort(v_zero_points.begin(), v_zero_points.end(), [](const double dVal0, const double dVal1) -> bool { return(dVal0 < dVal1); });

	if (v_zero_points.at(0) != 0)  v_zero_points.insert(v_zero_points.begin(), 0);
	if (v_zero_points.at(v_zero_points.size() - 1) != 1)  v_zero_points.push_back(1);

	s_buf = ::Tools::sFormatVector(&v_zero_points);
	::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
	s_buf.Format("d_0_bo_c: %.4lf  d_0_ba_c: %.4lf  d_0_co_b: %.4lf  d_0_ca_b: %.4lf", d_0_bo_c, d_0_ba_c, d_0_co_b, d_0_ca_b);
	::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
	s_buf.Format("d_1_bo_c: %.4lf  d_1_ba_c: %.4lf  d_1_co_b: %.4lf  d_1_ca_b: %.4lf", d_1_bo_c, d_1_ba_c, d_1_co_b, d_1_ca_b);
	::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
	::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", "");

	CDarkGA_DSM_MO_Dependency  *pc_new_dep_with_range;
	int i_pos = 0;
	bool  b_dep_found = true;
	while (b_dep_found == true)
	{
		pc_new_dep_with_range = new CDarkGA_DSM_MO_Dependency();
		pc_new_dep_with_range->i_gene_0 = 85;
		pc_new_dep_with_range->i_gene_1 = 3;

		b_dep_found = pc_new_dep_with_range->bExtractRange
		(
			i_pos, &i_pos,
			&v_zero_points,
			d_0_bo_c, d_0_ba_c, d_0_co_b, d_0_ca_b,
			d_1_bo_c, d_1_ba_c, d_1_co_b, d_1_ca_b
		);
		if (b_dep_found == true)
			b_new_dep_range_try_add(pc_new_dep_with_range);
			//v_dependency_ranges.push_back(pc_new_dep_with_range);
		else
			delete  pc_new_dep_with_range;
	}//while (b_dep_found == true)


	vSaveDepRanges("zzzz_mo_dled_vectors.txt");
	/*::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", "\n\nRANGES:\n");
	for (int ii = 0; ii < v_dependency_ranges.size(); ii++)
	{
		s_buf = v_dependency_ranges.at(ii)->sToStr();
		::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
	}//for (int ii = 0; ii < v_dependency_ranges.size(); ii++)

	::Tools::vShow("DONE");*/


}//void  CDarkGA_DSM_MO::vTest()


void  CDarkGA_DSM_MO::v_extract_dled_for_gene_pair(int iGeneBlock, int  iGeneContext, int  *piDledExtractionMask, CDarkGrayGAIndividual_MO  *pcExtractionIndividual, int *piNewPairsDetected)
{
	//vTest();

	CString  s_buf;

	if (pi_dsm[iGeneContext][iGeneBlock] > 0)  return;
	if ((piDledExtractionMask[iGeneBlock] < 0) || (piDledExtractionMask[iGeneContext] < 0))  return;

	pcExtractionIndividual->dComputeFitness();

	int  i_gene_block_value_orig, i_gene_block_value_alter;
	int  i_gene_context_value_orig, i_gene_context_value_alter;


	i_gene_block_value_orig = pcExtractionIndividual->pc_genotype->piGetBits()[iGeneBlock];
	i_gene_block_value_alter = i_gene_block_value_orig * (-1) + 1;

	i_gene_context_value_orig = pcExtractionIndividual->pc_genotype->piGetBits()[iGeneContext];
	i_gene_context_value_alter = i_gene_context_value_orig * (-1) + 1;


	double  d_fitness_bo_co_0, d_fitness_bo_ca_0;
	double  d_fitness_ba_co_0, d_fitness_ba_ca_0;
	double  d_fitness_bo_co_1, d_fitness_bo_ca_1;
	double  d_fitness_ba_co_1, d_fitness_ba_ca_1;


	pcExtractionIndividual->dComputeFitness();
	d_fitness_bo_co_0 = pcExtractionIndividual->v_fitness.at(0);
	d_fitness_bo_co_1 = pcExtractionIndividual->v_fitness.at(1);
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_co:", true);
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	pcExtractionIndividual->pc_genotype->piGetBits()[iGeneContext] = i_gene_context_value_alter;
	pcExtractionIndividual->b_fitness_actual = false;
	pcExtractionIndividual->dComputeFitness();
	d_fitness_bo_ca_0 = pcExtractionIndividual->v_fitness.at(0);
	d_fitness_bo_ca_1 = pcExtractionIndividual->v_fitness.at(1);
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_bo_ca:");
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	pcExtractionIndividual->pc_genotype->piGetBits()[iGeneBlock] = i_gene_block_value_alter;
	pcExtractionIndividual->b_fitness_actual = false;
	pcExtractionIndividual->dComputeFitness();
	d_fitness_ba_ca_0 = pcExtractionIndividual->v_fitness.at(0);
	d_fitness_ba_ca_1 = pcExtractionIndividual->v_fitness.at(1);
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_ca:");
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	pcExtractionIndividual->pc_genotype->piGetBits()[iGeneContext] = i_gene_context_value_orig;
	pcExtractionIndividual->b_fitness_actual = false;
	pcExtractionIndividual->dComputeFitness();
	d_fitness_ba_co_0 = pcExtractionIndividual->v_fitness.at(0);
	d_fitness_ba_co_1 = pcExtractionIndividual->v_fitness.at(1);
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "d_fitness_ba_co:");
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", pcExtractionIndividual->sToStr());
	//::Tools::vReportInFile("zzz_dsm_individuals.txt", "");

	//now we only restore the original genotype we do not have to compute fitness, because we know it (it is in d_fitness_bo_co)
	pcExtractionIndividual->pc_genotype->piGetBits()[iGeneBlock] = i_gene_block_value_orig;
	pcExtractionIndividual->b_fitness_actual = true;
	pcExtractionIndividual->v_fitness.at(0) = d_fitness_bo_co_0;
	pcExtractionIndividual->v_fitness.at(1) = d_fitness_bo_co_1;
	pcExtractionIndividual->vRecalculateForNewWeights();


	if (i_sett_mo_dled == i_OPTIMIZER_DARK_GA_MO_DSM__MO_DLED_OFF)
	{
		int  i_block_orig_relation_0, i_block_alter_relation_0;
		int  i_context_orig_relation_0, i_context_alter_relation_0;
		int  i_block_orig_relation_1, i_block_alter_relation_1;
		int  i_context_orig_relation_1, i_context_alter_relation_1;

		if (d_fitness_bo_co_0 < d_fitness_bo_ca_0)  i_block_orig_relation_0 = -1;
		if (d_fitness_bo_co_0 == d_fitness_bo_ca_0)  i_block_orig_relation_0 = 0;
		if (d_fitness_bo_co_0 > d_fitness_bo_ca_0)  i_block_orig_relation_0 = 1;

		if (d_fitness_bo_co_1 < d_fitness_bo_ca_1)  i_block_orig_relation_1 = -1;
		if (d_fitness_bo_co_1 == d_fitness_bo_ca_1)  i_block_orig_relation_1 = 0;
		if (d_fitness_bo_co_1 > d_fitness_bo_ca_1)  i_block_orig_relation_1 = 1;


		if (d_fitness_ba_co_0 < d_fitness_ba_ca_0)  i_block_alter_relation_0 = -1;
		if (d_fitness_ba_co_0 == d_fitness_ba_ca_0)  i_block_alter_relation_0 = 0;
		if (d_fitness_ba_co_0 > d_fitness_ba_ca_0)  i_block_alter_relation_0 = 1;

		if (d_fitness_ba_co_1 < d_fitness_ba_ca_1)  i_block_alter_relation_1 = -1;
		if (d_fitness_ba_co_1 == d_fitness_ba_ca_1)  i_block_alter_relation_1 = 0;
		if (d_fitness_ba_co_1 > d_fitness_ba_ca_1)  i_block_alter_relation_1 = 1;


		if (d_fitness_bo_co_0 < d_fitness_ba_co_0)  i_context_orig_relation_0 = -1;
		if (d_fitness_bo_co_0 == d_fitness_ba_co_0)  i_context_orig_relation_0 = 0;
		if (d_fitness_bo_co_0 > d_fitness_ba_co_0)  i_context_orig_relation_0 = 1;

		if (d_fitness_bo_co_1 < d_fitness_ba_co_1)  i_context_orig_relation_1 = -1;
		if (d_fitness_bo_co_1 == d_fitness_ba_co_1)  i_context_orig_relation_1 = 0;
		if (d_fitness_bo_co_1 > d_fitness_ba_co_1)  i_context_orig_relation_1 = 1;


		if (d_fitness_bo_ca_0 < d_fitness_ba_ca_0)  i_context_alter_relation_0 = -1;
		if (d_fitness_bo_ca_0 == d_fitness_ba_ca_0)  i_context_alter_relation_0 = 0;
		if (d_fitness_bo_ca_0 > d_fitness_ba_ca_0)  i_context_alter_relation_0 = 1;

		if (d_fitness_bo_ca_1 < d_fitness_ba_ca_1)  i_context_alter_relation_1 = -1;
		if (d_fitness_bo_ca_1 == d_fitness_ba_ca_1)  i_context_alter_relation_1 = 0;
		if (d_fitness_bo_ca_1 > d_fitness_ba_ca_1)  i_context_alter_relation_1 = 1;


		if (
			(i_block_orig_relation_0 != i_block_alter_relation_0) ||
			(i_context_orig_relation_0 != i_context_alter_relation_0) ||
			(i_block_orig_relation_1 != i_block_alter_relation_1) ||
			(i_context_orig_relation_1 != i_context_alter_relation_1)
			)
		{
			pi_dsm[iGeneContext][iGeneBlock] = 1;
			pi_dsm[iGeneBlock][iGeneContext] = 1;

			(*piNewPairsDetected)++;
		}//if  (
	}//if (i_sett_mo_dled == 0)
	

	
	if (i_sett_mo_dled == i_OPTIMIZER_DARK_GA_MO_DSM__MO_DLED_ON)
	{
		double  d_0_bo_c, d_0_ba_c;
		double  d_0_co_b, d_0_ca_b;
		double  d_1_bo_c, d_1_ba_c;
		double  d_1_co_b, d_1_ca_b;

		d_0_bo_c = d_fitness_bo_co_0 - d_fitness_bo_ca_0;
		d_0_ba_c = d_fitness_ba_co_0 - d_fitness_ba_ca_0;
		d_0_co_b = d_fitness_bo_co_0 - d_fitness_ba_co_0;
		d_0_ca_b = d_fitness_bo_ca_0 - d_fitness_ba_ca_0;

		d_1_bo_c = d_fitness_bo_co_1 - d_fitness_bo_ca_1;
		d_1_ba_c = d_fitness_ba_co_1 - d_fitness_ba_ca_1;
		d_1_co_b = d_fitness_bo_co_1 - d_fitness_ba_co_1;
		d_1_ca_b = d_fitness_bo_ca_1 - d_fitness_ba_ca_1;


		vector<double>  v_zero_points;
		double  d_zero_point_temp;

		d_zero_point_temp = ::Tools::dGetZeroPoint(d_0_bo_c, d_1_bo_c);
		if (0 <= d_zero_point_temp)  v_zero_points.push_back(d_zero_point_temp);
		d_zero_point_temp = ::Tools::dGetZeroPoint(d_0_ba_c, d_1_ba_c);
		if (0 <= d_zero_point_temp)  v_zero_points.push_back(d_zero_point_temp);
		d_zero_point_temp = ::Tools::dGetZeroPoint(d_0_co_b, d_1_co_b);
		if (0 <= d_zero_point_temp)  v_zero_points.push_back(d_zero_point_temp);
		d_zero_point_temp = ::Tools::dGetZeroPoint(d_0_ca_b, d_1_ca_b);
		if (0 <= d_zero_point_temp)  v_zero_points.push_back(d_zero_point_temp);

		std::sort(v_zero_points.begin(), v_zero_points.end(), [](const double dVal0, const double dVal1) -> bool { return(dVal0 < dVal1); });

				

		CDarkGA_DSM_MO_Dependency  *pc_new_dep_with_range;
		if (v_zero_points.size() == 0)
		{
			double  d_weighted_bo_c, d_weighted_ba_c;
			double  d_weighted_co_b, d_weighted_ca_b;

			int  i_block_orig_relation, i_block_alter_relation;
			int  i_context_orig_relation, i_context_alter_relation;


			double  d_w0, d_w1;

			d_w0 = 0.5;
			d_w1 = 0.5;

			d_weighted_bo_c = d_w0 * d_0_bo_c + d_w1 * d_1_bo_c;
			d_weighted_ba_c = d_w0 * d_0_ba_c + d_w1 * d_1_ba_c;
			d_weighted_co_b = d_w0 * d_0_co_b + d_w1 * d_1_co_b;
			d_weighted_ba_c = d_w0 * d_0_ca_b + d_w1 * d_1_ca_b;

			if (d_weighted_bo_c < 0)  i_block_orig_relation = -1;
			if (d_weighted_bo_c == 0)  i_block_orig_relation = 0;
			if (d_weighted_bo_c > 0)  i_block_orig_relation = 1;

			if (d_weighted_ba_c < 0)  i_block_alter_relation = -1;
			if (d_weighted_ba_c == 0)  i_block_alter_relation = 0;
			if (d_weighted_ba_c > 0)  i_block_alter_relation = 1;

			if (d_weighted_co_b < 0)  i_context_orig_relation = -1;
			if (d_weighted_co_b == 0)  i_context_orig_relation = 0;
			if (d_weighted_co_b > 0)  i_context_orig_relation = 1;

			if (d_weighted_ba_c < 0)  i_context_alter_relation = -1;
			if (d_weighted_ba_c == 0)  i_context_alter_relation = 0;
			if (d_weighted_ba_c > 0)  i_context_alter_relation = 1;


			if (
				(i_block_orig_relation != i_block_alter_relation) ||
				(i_context_orig_relation != i_context_alter_relation)
				)
			{
				pc_new_dep_with_range = new CDarkGA_DSM_MO_Dependency();
				pc_new_dep_with_range->d_start = 0;
				pc_new_dep_with_range->b_start_included = true;
				pc_new_dep_with_range->d_end = 1;
				pc_new_dep_with_range->b_end_included = true;
				pc_new_dep_with_range->i_gene_0 = iGeneBlock;
				pc_new_dep_with_range->i_gene_1 = iGeneContext;

				if (b_new_dep_range_try_add(pc_new_dep_with_range) == false)  delete  pc_new_dep_with_range;
				//v_dependency_ranges.push_back(pc_new_dep_with_range);
			}//if (
		}//if (v_zero_points.size() == 0)
		else
		{
			if (v_zero_points.at(0) != 0)  v_zero_points.insert(v_zero_points.begin(), 0);
			if (v_zero_points.at(v_zero_points.size() - 1) != 1)  v_zero_points.push_back(1);


			int i_pos = 0;
			bool  b_dep_found = true;
			while (b_dep_found == true)
			{
				pc_new_dep_with_range = new CDarkGA_DSM_MO_Dependency();
				pc_new_dep_with_range->i_gene_0 = iGeneBlock;
				pc_new_dep_with_range->i_gene_1 = iGeneContext;

				b_dep_found = pc_new_dep_with_range->bExtractRange
					(
						i_pos, &i_pos,
						&v_zero_points,
						d_0_bo_c, d_0_ba_c, d_0_co_b, d_0_ca_b,
						d_1_bo_c, d_1_ba_c,	d_1_co_b, d_1_ca_b
					);
				if (b_dep_found == true)
				{
					if (b_new_dep_range_try_add(pc_new_dep_with_range) == false)  delete  pc_new_dep_with_range;
					//v_dependency_ranges.push_back(pc_new_dep_with_range);

					/*if (
						((pc_new_dep_with_range->i_gene_0 == 1) && (pc_new_dep_with_range->i_gene_1 == 0)) ||
						((pc_new_dep_with_range->i_gene_0 == 0) && (pc_new_dep_with_range->i_gene_1 == 1))
						)
					{
						s_buf.Format("\nGENES %d * %d = ", iGeneBlock, iGeneContext);
						::Tools::vReportInFile("zzzzz_dependencies.txt", s_buf);
						s_buf = ::Tools::sFormatVector(&v_zero_points);
						::Tools::vReportInFile("zzzzz_dependencies.txt", s_buf);
						s_buf = pc_dependency_sets[0][1]->sToStr();
						::Tools::vReportInFile("zzzzz_dependencies.txt", s_buf);
						::Tools::vReportInFile("zzzzz_dependencies.txt", "\n\n\n\n");
					}//if (*/

					if (pc_new_dep_with_range->bInRange(d_vec_w0, d_vec_w1) == true)
					{
						
						/*s_buf.Format("\n\n\nGENES %d * %d = ", iGeneBlock, iGeneContext);
						::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
						s_buf = ::Tools::sFormatVector(&v_zero_points);
						::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
						s_buf = this->
			/*::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", "\nFITNESS:");
			s_buf.Format("d_fitness_bo_co_0: %.4lf  d_fitness_bo_ca_0: %.4lf  d_fitness_ba_co_0: %.4lf  d_fitness_ba_ca_0: %.4lf", d_fitness_bo_co_0, d_fitness_bo_ca_0, d_fitness_ba_co_0, d_fitness_ba_ca_0);
			::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
			s_buf.Format("d_fitness_bo_co_1: %.4lf  d_fitness_bo_ca_1: %.4lf  d_fitness_ba_co_1: %.4lf  d_fitness_ba_ca_1: %.4lf", d_fitness_bo_co_1, d_fitness_bo_ca_1, d_fitness_ba_co_1, d_fitness_ba_ca_1);
			::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);

			s_buf.Format("d_0_bo_c: %.4lf  d_0_ba_c: %.4lf  d_0_co_b: %.4lf  d_0_ca_b: %.4lf", d_0_bo_c, d_0_ba_c, d_0_co_b, d_0_ca_b);
			::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
			s_buf.Format("d_1_bo_c: %.4lf  d_1_ba_c: %.4lf  d_1_co_b: %.4lf  d_1_ca_b: %.4lf", d_1_bo_c, d_1_ba_c, d_1_co_b, d_1_ca_b);
			::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
			::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", "");//*/


						pi_dsm[iGeneContext][iGeneBlock] = 1;
						pi_dsm[iGeneBlock][iGeneContext] = 1;
					}//if (pc_new_dep_with_range->bInRange(d_vec_w0, d_vec_w1) == true)
				}//if (b_dep_found == true)
				else
					delete  pc_new_dep_with_range;
			}//while (b_dep_found == true)


			/*::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", "\n\nRANGES:\n");
			for (int ii = 0; ii < v_dependency_ranges.size(); ii++)
			{
				s_buf = v_dependency_ranges.at(ii)->sToStr();
				::Tools::vReportInFile("zzzz_mo_dled_vectors.txt", s_buf);
			}//for (int ii = 0; ii < v_dependency_ranges.size(); ii++)*/

			//::Tools::vShow("DONE_OK");

			


		}//else  if (v_zero_points.size() == 0)

		

		
		//::Tools::dGetZeroPoint(d_0_bo_c, d_1_bo_c);
		//::Tools::vProducePermutation


	}//if (i_sett_mo_dled == 1)


	/*CString  s_mut_line, s_sing;
	for (int ii = 0; ii < i_prob_size; ii++)
	{
		s_sing = "_";
		if  (ii == iGeneBlock)  s_sing = "b";
		if (ii == iGeneContext)  s_sing = "c";
		s_mut_line += s_sing;
	}//for (int ii = 0; ii < i_prob_size; ii++)
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_mut_line);

	CString  s_buf;
	s_buf.Format("d_fitness_bo_co, d_fitness_bo_ca: %.2lf  %.2lf", d_fitness_bo_co, d_fitness_bo_ca);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);
	s_buf.Format("d_fitness_ba_co, d_fitness_ba_ca: %.2lf  %.2lf", d_fitness_ba_co, d_fitness_ba_ca);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

	s_buf.Format("i_block_orig_relation, i_block_alter_relation: %d  %d", i_block_orig_relation, i_block_alter_relation);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

	s_buf.Format("i_context_orig_relation, i_context_alter_relation: %d  %d", i_context_orig_relation, i_context_alter_relation);
	::Tools::vReportInFile("zzz_dsm_individuals.txt", s_buf);

	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vReportInFile("zzz_dsm_individuals.txt", "");
	::Tools::vShow("CDarkGA_DSM_MO::v_extract_dled_for_gene_pair");*/



}//void  CDarkGA_DSM_MO::v_extract_dled_for_gene_pair(int  iGeneContext, int iGeneBlock, CDarkGrayGAIndividual_MO  *pcExtractionIndividual)



//---------------------------------------------CDarkGA_DSM_MO_Dependency_Set-------------------------------------------------------
CDarkGA_DSM_MO_Dependency_Set::~CDarkGA_DSM_MO_Dependency_Set()
{
	for (int ii = 0; ii < v_dependency_set.size(); ii++)
		delete  v_dependency_set.at(ii);
}//CDarkGA_DSM_MO_Dependency_Set::~CDarkGA_DSM_MO_Dependency_Set()



bool  CDarkGA_DSM_MO_Dependency_Set::b_new_dep_contained(CDarkGA_DSM_MO_Dependency *pcNewDep)
{
	for (int ii = 0; ii < v_dependency_set.size(); ii++)
	{
		if (v_dependency_set.at(ii)->bContained(pcNewDep) == true)  return(true);
	}//for (int ii = 0; ii < v_dependency_set.size(); ii++)


	return(false);
}//bool  CDarkGA_DSM_MO_Dependency_Set::b_new_dep_contained(CDarkGA_DSM_MO_Dependency *pcNewDep)


bool  CDarkGA_DSM_MO_Dependency_Set::b_old_dep_contained(CDarkGA_DSM_MO_Dependency *pcNewDep)
{
	bool  b_contained;
	b_contained = false;

	for (int ii = 0; ii < v_dependency_set.size(); ii++)
	{
		if (pcNewDep->bContained(v_dependency_set.at(ii)) == true)
		{
			delete  v_dependency_set.at(ii);
			v_dependency_set.erase(v_dependency_set.begin() + ii);
			ii--;
			b_contained = true;
		}//if (pcNewDep->bContained(v_dependency_set.at(ii)) == true)
	}//for (int ii = 0; ii < v_dependency_set.size(); ii++)


	return(b_contained);
}//bool  CDarkGA_DSM_MO_Dependency_Set::b_old_dep_contained(CDarkGA_DSM_MO_Dependency *pcNewDep)




bool  CDarkGA_DSM_MO_Dependency_Set::b_new_dep_join(CDarkGA_DSM_MO_Dependency *pcNewDep)
{
	/*if (
		((pcNewDep->i_gene_0 == 20) && (pcNewDep->i_gene_1 == 27)) ||
		((pcNewDep->i_gene_0 == 27) && (pcNewDep->i_gene_1 == 20))
		)
	{
		::Tools::vShow(pcNewDep->sToStr());
	}//if (*/

	bool  b_joined;

	b_joined = false;
	for (int i_joined = 0; i_joined < v_dependency_set.size(); i_joined++)
	{
		if (pcNewDep->bJoin(v_dependency_set.at(i_joined)) == true)
		{
			delete  v_dependency_set.at(i_joined);
			v_dependency_set.erase(v_dependency_set.begin() + i_joined);
			i_joined--;
			b_joined = true;
		}//if (pcNewDep->bJoin(v_dependency_set.at(i_joined)) == true)
	}//for (int ii = 0; ii < v_dependency_set.size(); ii++)


	return(b_joined);
}//bool  CDarkGA_DSM_MO_Dependency_Set::b_new_dep_join(CDarkGA_DSM_MO_Dependency *pcNewDep)



bool  CDarkGA_DSM_MO_Dependency_Set::bAddNewDependency(CDarkGA_DSM_MO_Dependency *pcNewDep)
{
	bool  b_result;

	b_result = false;
	if (b_new_dep_contained(pcNewDep) == true)  return(false);

	bool  b_joined = true;

	while (b_joined == true)
	{
		b_old_dep_contained(pcNewDep); //after joining, some other may be contained
		b_joined = b_new_dep_join(pcNewDep);
	}//while (b_joined == true)
	
	v_dependency_set.push_back(pcNewDep);

	std::sort(v_dependency_set.begin(), v_dependency_set.end(), [](const CDarkGA_DSM_MO_Dependency *pcDep0, const CDarkGA_DSM_MO_Dependency *pcDep1) -> bool { return(pcDep0->d_start < pcDep1->d_start); });
		
	return(true);
}//bool  CDarkGA_DSM_MO_Dependency_Set::bAddNewDependency(CDarkGA_DSM_MO_Dependency *)


bool  CDarkGA_DSM_MO_Dependency_Set::bInRange(double  dVec0, double  dVec1)
{
	for (int ii = 0; ii < v_dependency_set.size(); ii++)
	{
		if (v_dependency_set.at(ii)->bInRange(dVec0, dVec1) == true)  return(true);
	}//for (int ii = 0; ii < v_dependency_set.size(); ii++)

	return(false);
}//bool  CDarkGA_DSM_MO_Dependency_Set::bInRange(double  dVec0, double  dVec1)



double  CDarkGA_DSM_MO_Dependency_Set::dCoverage()
{
	double  d_coverage;

	d_coverage = 0;
	for (int ii = 0; ii < v_dependency_set.size(); ii++)
		d_coverage += v_dependency_set.at(ii)->dCoverage();

	return(d_coverage);
}//double  CDarkGA_DSM_MO_Dependency_Set::dCoverage()

int  CDarkGA_DSM_MO_Dependency_Set::iGetMODependencyType()
{
	/*if ((i_gene_0 == 1) && (i_gene_1 == 4))
	{
		if (v_dependency_set.at(v_dependency_set.size() - 1)->d_end == 1)
			::Tools::vShow("ok:   if (v_dependency_set.at(v_dependency_set.size() - 1)->d_end == 1)");
		else
			::Tools::vShow("NOK:   if (v_dependency_set.at(v_dependency_set.size() - 1)->d_end == 1)");


		if (v_dependency_set.at(v_dependency_set.size() - 1)->b_start_included == true)
			::Tools::vShow("ok:   if (v_dependency_set.at(v_dependency_set.size() - 1)->b_start_included == true)");
		else
			::Tools::vShow("NOK:   if (v_dependency_set.at(v_dependency_set.size() - 1)->b_start_included == true)");


		if (v_dependency_set.at(0)->d_start > 0)
			::Tools::vShow("true:   if (v_dependency_set.at(0)->d_start > 0)");
		else
			::Tools::vShow("FALSE:   if (v_dependency_set.at(0)->d_start > 0)");


		if (v_dependency_set.at(0)->b_end_included == false)
			::Tools::vShow("true:   (v_dependency_set.at(0)->b_end_included == false)");
		else
			::Tools::vShow("FALSE:   (v_dependency_set.at(0)->b_end_included == false)");


		::Tools::vShow("asdasd");
	}//if ((i_gene_0 == 1) && (i_gene_1 == 4))*/


	if (v_dependency_set.size() == 0)  return(i_MO_DEPENDENCY_TYPE__NONE);

	if (v_dependency_set.size() == 1)
	{
		if (
			(v_dependency_set.at(0)->d_start == 0) && (v_dependency_set.at(0)->b_start_included == true) &&
			(v_dependency_set.at(0)->d_end == 1) && (v_dependency_set.at(0)->b_end_included == true)
			)
		{
			return(i_MO_DEPENDENCY_TYPE__COMPLETE);
		}//if (
	}//if (v_dependency_set.size() == 1)

	if (
		(v_dependency_set.at(0)->d_start == 0) && (v_dependency_set.at(0)->b_start_included == true) &&
		((v_dependency_set.at(v_dependency_set.size() - 1)->d_end < 1) || (v_dependency_set.at(v_dependency_set.size() - 1)->b_end_included == false))
		)
		return(i_MO_DEPENDENCY_TYPE__LEFT);


	if (
		(v_dependency_set.at(v_dependency_set.size() - 1)->d_end == 1) && (v_dependency_set.at(v_dependency_set.size() - 1)->b_end_included == true) &&
		((v_dependency_set.at(0)->d_start > 0) || (v_dependency_set.at(0)->b_start_included == false))
		)
		return(i_MO_DEPENDENCY_TYPE__RIGHT);


	if (
		(v_dependency_set.at(0)->d_start == 0) && (v_dependency_set.at(0)->b_start_included == true) &&
		(v_dependency_set.at(v_dependency_set.size() - 1)->d_end == 1) && (v_dependency_set.at(v_dependency_set.size() - 1)->b_end_included == true)
		)
		return(i_MO_DEPENDENCY_TYPE__LEFT_RIGHT);


	if (
		((v_dependency_set.at(0)->d_start > 0) || (v_dependency_set.at(0)->b_start_included == false))&&
		((v_dependency_set.at(v_dependency_set.size() - 1)->d_end < 1) || (v_dependency_set.at(v_dependency_set.size() - 1)->b_end_included == false))
		)
		return(i_MO_DEPENDENCY_TYPE__MIDDLE);
	

	return(-1);
}//int  CDarkGA_DSM_MO_Dependency_Set::iGetMODependencyType()


CString  CDarkGA_DSM_MO_Dependency_Set::sToStr()
{
	CString  s_result, s_buf;

	s_result.Format("%d * %d = ", i_gene_0, i_gene_1);

	for (int ii = 0; ii < v_dependency_set.size(); ii++)
	{
		s_buf = v_dependency_set.at(ii)->sToStr(false);
		s_result += " " + s_buf;
	}//for (int ii = 0; ii < v_dependency_set.size(); ii++)

	for (int ii = v_dependency_set.size(); ii < 3; ii++)
	{
		s_result += "                                         ";
	}//for (int ii = v_dependency_set.size(); ii < 5; ii++)


	int  i_type;
	i_type = iGetMODependencyType();

	s_buf = "XXXXXXXXXXXXXX";
	if (i_type == i_MO_DEPENDENCY_TYPE__COMPLETE)  s_buf = "COMPLETE";
	if (i_type == i_MO_DEPENDENCY_TYPE__LEFT)  s_buf = "LEFT";
	if (i_type == i_MO_DEPENDENCY_TYPE__RIGHT)  s_buf = "RIGHT";
	if (i_type == i_MO_DEPENDENCY_TYPE__LEFT_RIGHT)  s_buf = "LEFT_RIGHT";
	if (i_type == i_MO_DEPENDENCY_TYPE__MIDDLE)  s_buf = "MIDDLE";

	s_result += s_buf;
	s_result += "   ";

	double  d_coverage;
	d_coverage = dCoverage();

	if  (d_coverage > 0.9999)  s_result += "100percCoverage    ";

	s_buf.Format("   Coverage: %.8lf", d_coverage);
	s_result += s_buf;
	


	return(s_result);
}//CString  CDarkGA_DSM_MO_Dependency_Set::sToStr()


//---------------------------------------------CDarkGA_DSM_MO_Dependency-------------------------------------------------------
bool  CDarkGA_DSM_MO_Dependency::bExtractRange
(
	int  iPosStart, int  *piPosEnd,
	vector<double>  *pvZeroPoints,
	double  d_0_bo_c, double  d_0_ba_c, double  d_0_co_b, double  d_0_ca_b,
	double  d_1_bo_c, double  d_1_ba_c, double  d_1_co_b, double  d_1_ca_b
)
{
	if (iPosStart >= pvZeroPoints->size())  return(false);

	CString  s_buf;
	double  d_w0, d_w1;
	bool  b_dep_found, b_weights_dependent;
	bool  b_go_on;
	int  i_pos_cur;
	int  i_start_orig;
	i_start_orig = iPosStart;

	i_pos_cur = iPosStart;
	b_dep_found = false;
	b_go_on = true;
	while (b_go_on == true)
	{
		d_w0 = pvZeroPoints->at(i_pos_cur);
		d_w1 = 1;
		d_w1 = d_w1 - d_w0;

		b_weights_dependent = b_check_dependency
			(
				d_w0, d_w1,
				d_0_bo_c, d_0_ba_c, d_0_co_b, d_0_ca_b,
				d_1_bo_c, d_1_ba_c, d_1_co_b, d_1_ca_b
			);


		if (b_weights_dependent == true)
		{
			if (b_dep_found == true)
			{
				d_end = pvZeroPoints->at(i_pos_cur);
				b_end_included = true;
			}//if (b_dep_found == true)
			else
			{
				d_start = pvZeroPoints->at(i_pos_cur);
				d_end = pvZeroPoints->at(i_pos_cur);
				b_start_included = true;
				b_end_included = true;

				b_dep_found = true;
			}//else if (b_dep_found == true)
		}//if (b_weights_dependent == true)
		else
		{
			if (b_dep_found == true)
			{
				d_end = pvZeroPoints->at(i_pos_cur);
				b_end_included = false;
				b_go_on = false;
				*piPosEnd = i_pos_cur;
			}//if (b_dep_found == true)
			else
			{
				//we do nothing, we keep on searching...
			}//else if (b_dep_found == true)
		}//else  if (b_weights_dependent == true)

		/*s_buf.Format("status0: b_dep_found: %s   b_weights_dependent: %s  i_pos_cur: %d  w0: %.4lf w1: %.4lf   %s", 
			::Tools::sFormatBool(b_dep_found), ::Tools::sFormatBool(b_weights_dependent), i_pos_cur,
			d_w0, d_w1,
			sToStr()
			);
		::Tools::vReportInFile("zzzz_bExtractRange.txt", s_buf);//*/

		//middle point
		if ( (b_go_on == true)&&(i_pos_cur < pvZeroPoints->size() - 1) )
		{
			d_w0 = pvZeroPoints->at(i_pos_cur) + pvZeroPoints->at(i_pos_cur + 1);
			d_w0 = d_w0 / 2;
			d_w1 = 1;
			d_w1 = d_w1 - d_w0;

			b_weights_dependent = b_check_dependency
			(
				d_w0, d_w1,
				d_0_bo_c, d_0_ba_c, d_0_co_b, d_0_ca_b,
				d_1_bo_c, d_1_ba_c, d_1_co_b, d_1_ca_b
			);


			if (b_weights_dependent == true)
			{
				if (b_dep_found == true)
				{
					d_end = pvZeroPoints->at(i_pos_cur + 1);
					b_end_included = false;
				}//if (b_dep_found == true)
				else
				{
					d_start = pvZeroPoints->at(i_pos_cur);
					d_end = pvZeroPoints->at(i_pos_cur + 1);
					b_start_included = false;
					b_end_included = false;

					b_dep_found = true;
				}//else if (b_dep_found == true)
			}//if (b_weights_dependent == true)
			else
			{
				if (b_dep_found == true)
				{
					d_end = pvZeroPoints->at(i_pos_cur);
					b_end_included = false;
					b_go_on = false;
					*piPosEnd = i_pos_cur + 1;
				}//if (b_dep_found == true)
				else
				{
					//we do nothing, we keep on searching...
				}//else if (b_dep_found == true)
			}//else  if (b_weights_dependent == true)

			/*s_buf.Format("status1: b_dep_found: %s   b_weights_dependent: %s  i_pos_cur: %d  w0: %.4lf w1: %.4lf   %s",
				::Tools::sFormatBool(b_dep_found), ::Tools::sFormatBool(b_weights_dependent), i_pos_cur,
				d_w0, d_w1,
				sToStr()
				);
			::Tools::vReportInFile("zzzz_bExtractRange.txt", s_buf);//*/

		}//if ( (b_go_on == true)&&(i_pos_cur < pvZeroPoints->size() - 1) )


		if (i_pos_cur >= pvZeroPoints->size() - 1)
		{
			b_go_on = false;
		}//if (i_pos_cur >= pvZeroPoints->size() - 1)
		else
			i_pos_cur++;
	}//while (b_go_on == true)

	if (*piPosEnd <= i_start_orig)  *piPosEnd = i_start_orig + 1;
	
	return(b_dep_found);
}//bool  CDarkGA_DSM_MO_Dependency::bExtractRange



bool  CDarkGA_DSM_MO_Dependency::b_check_dependency
(
	double  d_w0, double  d_w1,
	double  d_0_bo_c, double  d_0_ba_c, double  d_0_co_b, double  d_0_ca_b,
	double  d_1_bo_c, double  d_1_ba_c, double  d_1_co_b, double  d_1_ca_b
)
{
	double  d_weighted_bo_c, d_weighted_ba_c;
	double  d_weighted_co_b, d_weighted_ca_b;

	int  i_block_orig_relation, i_block_alter_relation;
	int  i_context_orig_relation, i_context_alter_relation;


	d_weighted_bo_c = d_w0 * d_0_bo_c + d_w1 * d_1_bo_c;
	d_weighted_ba_c = d_w0 * d_0_ba_c + d_w1 * d_1_ba_c;
	d_weighted_co_b = d_w0 * d_0_co_b + d_w1 * d_1_co_b;
	d_weighted_ca_b = d_w0 * d_0_ca_b + d_w1 * d_1_ca_b;

	if (d_weighted_bo_c < 0)  i_block_orig_relation = -1;
	if (d_weighted_bo_c == 0)  i_block_orig_relation = 0;
	if (d_weighted_bo_c > 0)  i_block_orig_relation = 1;

	if (d_weighted_ba_c < 0)  i_block_alter_relation = -1;
	if (d_weighted_ba_c == 0)  i_block_alter_relation = 0;
	if (d_weighted_ba_c > 0)  i_block_alter_relation = 1;

	if (d_weighted_co_b < 0)  i_context_orig_relation = -1;
	if (d_weighted_co_b == 0)  i_context_orig_relation = 0;
	if (d_weighted_co_b > 0)  i_context_orig_relation = 1;

	if (d_weighted_ca_b < 0)  i_context_alter_relation = -1;
	if (d_weighted_ca_b == 0)  i_context_alter_relation = 0;
	if (d_weighted_ca_b > 0)  i_context_alter_relation = 1;

	/*if (
		((i_gene_0 == 1) && (i_gene_1 == 0)) ||
		((i_gene_0 == 0) && (i_gene_1 == 1))
		)
	{
		CString  s_line, s_buf;
		s_line.Format("GENES %d*%d  WEIGHTS: %.4lf  %.4lf", i_gene_0, i_gene_1, d_w0, d_w1);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);

		s_line.Format("  d_0_bo_c=%.4lf  d_0_ba_c=%.4lf  d_0_co_b=%.4lf  d_0_ca_b=%.4lf", d_0_bo_c, d_0_ba_c, d_0_co_b, d_0_ca_b);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
		s_line.Format("  d_1_bo_c=%.4lf  d_1_ba_c=%.4lf  d_1_co_b=%.4lf  d_1_ca_b=%.4lf", d_1_bo_c, d_1_ba_c, d_1_co_b, d_1_ca_b);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
		s_line.Format("  d_w_bo_c=%.4lf  d_w_ba_c=%.4lf  d_w_co_b=%.4lf  d_w_ca_b=%.4lf", d_weighted_bo_c, d_weighted_ba_c, d_weighted_co_b, d_weighted_ca_b);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
		s_line.Format("  rel_bo_c=%d     rel_ba_c=%d     rel_co_b=%d     rel_ca_b=%d", i_block_orig_relation, i_block_alter_relation, i_context_orig_relation, i_context_alter_relation);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
	}//if (*/


	if (
		(i_block_orig_relation != i_block_alter_relation) ||
		(i_context_orig_relation != i_context_alter_relation)
		)
	{
		/*if (
			((i_gene_0 == 1) && (i_gene_1 == 0)) ||
			((i_gene_0 == 0) && (i_gene_1 == 1))
			)
		{
			CString  s_line, s_buf;
			s_line.Format("GENES %d*%d  WEIGHTS: %.4lf  %.4lf", i_gene_0, i_gene_1, d_w0, d_w1);
			::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);

			s_line.Format("  d_0_bo_c=%.4lf  d_0_ba_c=%.4lf  d_0_co_b=%.4lf  d_0_ca_b=%.4lf", d_0_bo_c, d_0_ba_c, d_0_co_b, d_0_ca_b);
			::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
			s_line.Format("  d_1_bo_c=%.4lf  d_1_ba_c=%.4lf  d_1_co_b=%.4lf  d_1_ca_b=%.4lf", d_1_bo_c, d_1_ba_c, d_1_co_b, d_1_ca_b);
			::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
			s_line.Format("  d_w_bo_c=%.4lf  d_w_ba_c=%.4lf  d_w_co_b=%.4lf  d_w_ca_b=%.4lf", d_weighted_bo_c, d_weighted_ba_c, d_weighted_co_b, d_weighted_ca_b);
			::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
			s_line.Format("  rel_bo_c=%d     rel_ba_c=%d     rel_co_b=%d     rel_ca_b=%d", i_block_orig_relation, i_block_alter_relation, i_context_orig_relation, i_context_alter_relation);
			::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);

			::Tools::vReportInFile("zzzzz_dependencies.txt", "   DEPENDENT!!!\n");
		}//if (*/

		return(true);
	}//if  (


	/*if (
		((i_gene_0 == 1) && (i_gene_1 == 0)) ||
		((i_gene_0 == 0) && (i_gene_1 == 1))
		)
	{
		CString  s_line, s_buf;
		s_line.Format("GENES %d*%d  WEIGHTS: %.4lf  %.4lf", i_gene_0, i_gene_1, d_w0, d_w1);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);

		s_line.Format("  d_0_bo_c=%.4lf  d_0_ba_c=%.4lf  d_0_co_b=%.4lf  d_0_ca_b=%.4lf", d_0_bo_c, d_0_ba_c, d_0_co_b, d_0_ca_b);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
		s_line.Format("  d_1_bo_c=%.4lf  d_1_ba_c=%.4lf  d_1_co_b=%.4lf  d_1_ca_b=%.4lf", d_1_bo_c, d_1_ba_c, d_1_co_b, d_1_ca_b);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
		s_line.Format("  d_w_bo_c=%.4lf  d_w_ba_c=%.4lf  d_w_co_b=%.4lf  d_w_ca_b=%.4lf", d_weighted_bo_c, d_weighted_ba_c, d_weighted_co_b, d_weighted_ca_b);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);
		s_line.Format("  rel_bo_c=%d     rel_ba_c=%d     rel_co_b=%d     rel_ca_b=%d", i_block_orig_relation, i_block_alter_relation, i_context_orig_relation, i_context_alter_relation);
		::Tools::vReportInFile("zzzzz_dependencies.txt", s_line);

		::Tools::vReportInFile("zzzzz_dependencies.txt", "   no dependency found\n");
	}//if (*/


	return(false);
}//bool  CDarkGA_DSM_MO_Dependency::b_check_dependency


bool  CDarkGA_DSM_MO_Dependency::bInRange(double  dVec0)
{
	bool  b_res;

	b_res = bInRange(dVec0, 1.0-dVec0);

	return(b_res);
}//bool  CDarkGA_DSM_MO_Dependency::bInRange(double  dVec0)


bool  CDarkGA_DSM_MO_Dependency::bInRange(double  dVec0, double  dVec1)
{
	if ((d_start < dVec0) && (dVec0 < d_end))  return(true);

	if ((b_start_included == true) && (dVec0 == d_start))  return(true);
	if ((b_end_included == true) && (dVec0 == d_end))  return(true);

	return(false);
}//bool  CDarkGA_DSM_MO_Dependency::bInRange(double  dVec0, double  dVec1)



bool  CDarkGA_DSM_MO_Dependency::bContained_RangeStartEnd(double  dRange_StartEnd, bool  bStartEnd_included, bool bStart)
{

	if ((d_start < dRange_StartEnd) && (dRange_StartEnd < d_end))  return(true);

	if ((b_start_included == true) && (dRange_StartEnd == d_start))  return(true);
	if ((b_end_included == true) && (dRange_StartEnd == d_end))  return(true);

	if (bStart == true)
	{
		if ((b_start_included == bStartEnd_included) && (dRange_StartEnd == d_start))  return(true);
	}//if (bStart == true)
	else
	{
		if ((b_end_included == bStartEnd_included) && (dRange_StartEnd == d_end))  return(true);
	}//else if (bStart == true)*/

	return(false);
}//bool  CDarkGA_DSM_MO_Dependency::bContainedStart(CDarkGA_DSM_MO_Dependency  *pcOther)



bool  CDarkGA_DSM_MO_Dependency::bContained(CDarkGA_DSM_MO_Dependency  *pcOther)
{

	if (
		(bContained_RangeStartEnd(pcOther->d_start, pcOther->b_start_included, true) == true)&&
		(bContained_RangeStartEnd(pcOther->d_end, pcOther->b_end_included, false) == true) 
		)  return(true);


	return(false);
}//bool  CDarkGA_DSM_MO_Dependency::bContained(CDarkGA_DSM_MO_Dependency  *pcOther)



bool  CDarkGA_DSM_MO_Dependency::bJoin(CDarkGA_DSM_MO_Dependency  *pcOther)
{

	if (
		(bContained_RangeStartEnd(pcOther->d_start, pcOther->b_start_included, true) == true) ||
		(bContained_RangeStartEnd(pcOther->d_end, pcOther->b_end_included, false) == true)||
		(pcOther->bContained_RangeStartEnd(d_start, b_start_included, true) == true) ||
		(pcOther->bContained_RangeStartEnd(d_end, b_end_included, false) == true) ||
		(
			(d_end == pcOther->d_start) &&
			((b_end_included == true) || (pcOther->b_start_included == true))
		)||
		(
			(d_start == pcOther->d_end) &&
			((pcOther->b_end_included == true) || (b_start_included == true))
		)
		)
	{
		if (d_start == pcOther->d_start)
		{
			if (pcOther->b_start_included == true)  b_start_included = true;
		}//if (d_start == pcOther->d_start)

		if (d_start > pcOther->d_start)
		{
			d_start = pcOther->d_start;
			b_start_included = pcOther->b_start_included;
		}//if (d_start > pcOther->d_start)


		if (d_end == pcOther->d_end)
		{
			if (pcOther->b_end_included == true)  b_end_included = true;
		}//if (d_start == pcOther->d_start)

		if (d_end < pcOther->d_end)
		{
			d_end = pcOther->d_end;
			b_end_included = pcOther->b_end_included;
		}//if (d_start > pcOther->d_start)

		
		return(true);
	}//if (

	//glueing
	
	return(false);
}//bool  CDarkGA_DSM_MO_Dependency::bContained(CDarkGA_DSM_MO_Dependency  *pcOther)



CString  CDarkGA_DSM_MO_Dependency::sToStr(bool  bShowGeneNumber)
{
	CString  s_result, s_buf;

	if  (bShowGeneNumber == true)  s_result.Format("%d * %d = ", i_gene_0, i_gene_1);

	if (b_start_included == true)
		s_buf = "<";
	else
		s_buf = "(";
	s_result += s_buf;

	s_buf.Format("%.16lf; %.16lf", d_start, d_end);
	s_result += s_buf;

	if (b_end_included == true)
		s_buf = ">";
	else
		s_buf = ")";
	s_result += s_buf;

	return(s_result);
}//CString  CDarkGA_DSM_MO_Dependency::sToStr()


//---------------------------------------------CShiftVectorManager-------------------------------------------------------
bool  CShiftVectorManager::bGetWeights(double  *pdVec0, double  *pdVec1)
{
	bool  b_res;

	b_res = false;
	if (i_weights_choose_startegy == i_VECTOR_MANAGER_STRATEGY__POINT_IN_RANGE) b_res = bGetWeights_random_point_in_range(pdVec0, pdVec1);
	if (i_weights_choose_startegy == i_VECTOR_MANAGER_STRATEGY__SHRINKING_EDGES) b_res = bGetWeights_shrinking_edges(pdVec0, pdVec1);

	return(b_res);
}//bool  CShiftVectorManager::bGetWeights(double  *pdVec0, double  *pdVec1)


bool  CShiftVectorManager::bGetWeights_random_point_in_range(double  *pdVec0, double  *pdVec1)
{
	CShiftVectorRange  *pc_new_range;

	if (v_shift_vec_ranges.size() == 0)
	{
		pc_new_range = new CShiftVectorRange(0, true, 1, true);
		v_shift_vec_ranges.push_back(pc_new_range);
	}//if (v_shift_vec_ranges.size() == 0)


	//check (0,1) and (1,0) availability
	for (int ii = 0; ii < v_shift_vec_ranges.size(); ii++)
	{
		if (v_shift_vec_ranges.at(ii)->bInRange(0) == true)
		{
			*pdVec0 = 0;
			*pdVec1 = 1;
			return(true);
		}//if (v_shift_vec_ranges.at(ii)->bInRange(0) == true)

		if (v_shift_vec_ranges.at(ii)->bInRange(1) == true)
		{
			*pdVec0 = 1;
			*pdVec1 = 0;
			return(true);
		}//if (v_shift_vec_ranges.at(ii)->bInRange(0) == true)
	}//for (int ii = 0; ii < v_shift_vec_ranges.size(); ii++)


	int  i_chosen_range;
	i_chosen_range = ::RandUtils::iRandNumber(0, v_shift_vec_ranges.size() - 1);

	double  d_weight_0;
	d_weight_0 = v_shift_vec_ranges.at(i_chosen_range)->dGetValueInRange();
	*pdVec0 = d_weight_0;
	*pdVec1 = 1;
	*pdVec1 = *pdVec1 - *pdVec0;

	return(true);


	return(false);
}//bool  CShiftVectorManager::bGetWeights_random_point_in_range(double  *pdVec0, double  *pdVec1)



bool  CShiftVectorManager::bGetWeights_shrinking_edges(double  *pdVec0, double  *pdVec1)
{
	
	if (v_shift_vec_ranges.size() == 0)
	{
		CShiftVectorRange  *pc_new_range;
		pc_new_range = new CShiftVectorRange(0, true, 1, true);
		v_shift_vec_ranges.push_back(pc_new_range);
	}//if (v_shift_vec_ranges.size() == 0)


	
	int  i_chosen_edge;
	i_chosen_edge = ::RandUtils::iRandNumber(0, 1);

	double  d_weight_0;

	if (i_chosen_edge == 0)
		d_weight_0 = v_shift_vec_ranges.at(0)->d_start;
	else
		d_weight_0 = v_shift_vec_ranges.at(0)->d_end;

	*pdVec0 = d_weight_0;
	*pdVec1 = 1;
	*pdVec1 = *pdVec1 - *pdVec0;

	//CString  s_buf;
	//s_buf.Format("WEIGHTS: %.4lf %.4lf", *pdVec0, *pdVec1);
	//::Tools::vShow(s_buf);

	return(true);


	return(false);
}//bool  CShiftVectorManager::bGetWeights_shrinking_edges(double  *pdVec0, double  *pdVec1)



void  CShiftVectorManager::vUpdateAvailableRanges(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1)
{
	//CString  s_buf;
	//s_buf.Format("vUpdateAvailableRanges WEIGHTS: %.4lf %.4lf", dDestinationWeight0, dDestinationWeight1);
	//::Tools::vShow(s_buf);

	if (i_weights_choose_startegy == i_VECTOR_MANAGER_STRATEGY__POINT_IN_RANGE) vUpdateAvailableRanges__random_point_in_range(dDestinationWeight0, dDestinationWeight1, dObj0, dObj1);
	if (i_weights_choose_startegy == i_VECTOR_MANAGER_STRATEGY__SHRINKING_EDGES) vUpdateAvailableRanges__shrinking_edges(dDestinationWeight0, dDestinationWeight1, dObj0, dObj1);
}//void  CShiftVectorManager::vUpdateAvailableRanges(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1)

void  CShiftVectorManager::vUpdateAvailableRanges__random_point_in_range(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1)
{

}//void  CShiftVectorManager::vUpdateAvailableRanges__random_point_in_range(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1)


void  CShiftVectorManager::vUpdateAvailableRanges__shrinking_edges(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1)
{
	CString  s_buf;

	double  d_sol_weight_0, d_sol_weight_1;
	double  d_obj_sum;


	d_obj_sum = dObj0 + dObj1;
	d_sol_weight_0 = dObj0 / d_obj_sum;
	d_sol_weight_1 = dObj1 / d_obj_sum;


	int  i_dest_edge = -1;
	if (v_shift_vec_ranges.at(0)->d_start == dDestinationWeight0)  i_dest_edge = 0;
	if (v_shift_vec_ranges.at(0)->d_end   == dDestinationWeight0)  i_dest_edge = 1;

	if (i_dest_edge == -1)
	{
		s_buf.Format("void  CShiftVectorManager::vUpdateAvailableRanges__shrinking_edges(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1)\ndDestinationWeight0: %.16lf, dDestinationWeight1: %.16lf, range0: %.16lf  range1: %.16lf", dDestinationWeight0, dDestinationWeight1, v_shift_vec_ranges.at(0)->d_start, v_shift_vec_ranges.at(0)->d_end);
		::Tools::vShow(s_buf);
	}//if (i_dest_edge == -1)

	if (i_dest_edge == 0)
	{
		if  (v_shift_vec_ranges.at(0)->d_start < d_sol_weight_0)  v_shift_vec_ranges.at(0)->d_start = d_sol_weight_0;
	}//if (i_dest_edge == 0)

	if (i_dest_edge == 1)
	{
		if (v_shift_vec_ranges.at(0)->d_end > d_sol_weight_0)  v_shift_vec_ranges.at(0)->d_end = d_sol_weight_0;
	}//if (i_dest_edge == 1)  

	if (v_shift_vec_ranges.at(0)->d_start > v_shift_vec_ranges.at(0)->d_end)
	{
		delete  v_shift_vec_ranges.at(0);
		v_shift_vec_ranges.clear();
	}//if (v_shift_vec_ranges.at(0)->d_start > v_shift_vec_ranges.at(0)->d_end)

}//void  CShiftVectorManager::vUpdateAvailableRanges__shrinking_edges(double  dDestinationWeight0, double  dDestinationWeight1, double  dObj0, double  dObj1)


CString  CShiftVectorManager::sToStr()
{
	CString  s_result, s_buf;

	s_result.Format("   CShiftVectorManager[%d]:  ", v_shift_vec_ranges.size());
	
	for (int ii = 0; ii < v_shift_vec_ranges.size(); ii++)
	{
		s_buf = v_shift_vec_ranges.at(ii)->sToStr();
		s_result += s_buf;
	}//for (int ii = 0; ii < v_shift_vec_ranges.size(); ii++)


	return(s_result);
}//CString  CShiftVectorManager::sToStr()


//---------------------------------------------CShiftVectorRange-------------------------------------------------------
CString  CShiftVectorRange::sToStr()
{
	CString  s_result, s_buf;


	if (b_start_included == true)
		s_buf = "<";
	else
		s_buf = "(";
	s_result += s_buf;

	s_buf.Format("%.4lf; %.4lf", d_start, d_end);
	s_result += s_buf;

	if (b_start_included == true)
		s_buf = ">";
	else
		s_buf = ")";
	s_result += s_buf;

	return(s_result);
}//CString  CShiftVectorRange::sToStr()


double  CShiftVectorRange::dGetValueInRange()
{
	double  d_res;
	d_res = ::RandUtils::dRandNumber(d_start, d_end);
	return(d_res);
}//double  CShiftVectorRange::dGetValueInRange()


bool  CShiftVectorRange::bInRange(double  dVec0)
{
	if ((d_start < dVec0) && (dVec0 < d_end))  return(true);

	if ((b_start_included == true) && (dVec0 == d_start))  return(true);
	if ((b_end_included == true) && (dVec0 == d_end))  return(true);

	return(false);
}//bool  CShiftVectorRange::bInRange(double  dVec0, double  dVec1)




//---------------------------------------------CDarkGrayGAPxMaskManager_MO-------------------------------------------------------
CDarkGrayGAPxMaskManager_MO::CDarkGrayGAPxMaskManager_MO()
{

}//CDarkGrayGAPxMaskManager_MO::CDarkGrayGAPxMaskManager_MO()


CDarkGrayGAPxMaskManager_MO::~CDarkGrayGAPxMaskManager_MO()
{
	for (int ii = 0; ii < v_masks.size(); ii++)
		delete  v_masks.at(ii);
	for (int ii = 0; ii < v_masks_buffered.size(); ii++)
		delete  v_masks_buffered.at(ii);
}//CDarkGrayGAPxMaskManager_MO::~CDarkGrayGAPxMaskManager_MO()


void  CDarkGrayGAPxMaskManager_MO::vShuffle()
{
	vector<CDarkGrayGAPxMask_MO *>  v_masks_shuffled;

	int  i_offset;
	while (v_masks.size() > 0)
	{
		i_offset = ::RandUtils::iRandNumber(0, v_masks.size() - 1);
		v_masks_shuffled.push_back(v_masks.at(i_offset));
		v_masks.erase(v_masks.begin() + i_offset);
	}//while (v_masks.size() > 0)

	v_masks = v_masks_shuffled;
}//void  CDarkGrayGAPxMaskManager_MO::vShuffle()


void  CDarkGrayGAPxMaskManager_MO::vSortByLength()
{
	std::sort(v_masks.begin(), v_masks.end(), [](const CDarkGrayGAPxMask_MO *pcVal0, const CDarkGrayGAPxMask_MO *pcVal1) -> bool { return(pcVal0->v_mask.size() < pcVal1->v_mask.size()); });
}//void  CDarkGrayGAPxMaskManager_MO::vSortByLength()


void  CDarkGrayGAPxMaskManager_MO::vClear()
{
	for (int ii = 0; ii < v_masks.size(); ii++)
		v_masks_buffered.push_back(v_masks.at(ii));
	v_masks.clear();
}//void  CDarkGrayGAPxMaskManager_MO::vClear()

CDarkGrayGAPxMask_MO*  CDarkGrayGAPxMaskManager_MO::pcGetNewPxMask()
{
	CDarkGrayGAPxMask_MO*  pc_new_mask;

	if (v_masks_buffered.size() > 0)
	{
		pc_new_mask = v_masks_buffered.back();
		v_masks_buffered.pop_back();
	}//if (i_masks_size < v_masks.size())
	else
		pc_new_mask = new CDarkGrayGAPxMask_MO();

	v_masks.push_back(pc_new_mask);
		
	pc_new_mask->vClear();
	return(pc_new_mask);
}//CDarkGrayGAPxMask_MO*  CDarkGrayGAPxMaskManager_MO::pcGetNewPxMask()


CDarkGrayGAPxMask_MO* CDarkGrayGAPxMaskManager_MO::pcGetAt(int iOffset)
{
	if (iOffset < v_masks.size())  return(v_masks.at(iOffset)); 
	return(NULL);
}//CDarkGrayGAPxMask_MO* CDarkGrayGAPxMaskManager_MO::pcGetAt(int iOffset)


void  CDarkGrayGAPxMaskManager_MO::vReport(CString  sDest)
{
	FILE  *pf_dest;
	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;
	vReport(pf_dest);
	fclose(pf_dest);
	::Tools::vShow(12345);//*/
}//void  CDarkGrayGAPxMask::vReport(CString  sDest)



void  CDarkGrayGAPxMaskManager_MO::vReport(FILE  *pfDest)
{
	fprintf(pfDest, "MASKS: %d\n\n\n\n\n", v_masks.size());
	
	for (int ii = 0; ii < v_masks.size(); ii++)
		v_masks.at(ii)->vReport(pfDest);
}//void  CDarkGrayGAPxMask_MO::vReportTest()



bool  CDarkGrayGAPxMask_MO::bDoICContain(CDarkGrayGAIndividual_MO  *pcOtherThanThisOne)
{
	if (pc_parent_0 == pcOtherThanThisOne)  return(true);
	if (pc_parent_1 == pcOtherThanThisOne)  return(true);
	return(false);
}//bool  CDarkGrayGAPxMask_MO::bDoICContain(CDarkGrayGAIndividual_MO  *pcOtherThanThisOne)



CDarkGrayGAIndividual_MO  *CDarkGrayGAPxMask_MO::pcGetOtherInd(CDarkGrayGAIndividual_MO  *pcOtherThanThisOne)
{
	if (pc_parent_0 != pcOtherThanThisOne)  return(pc_parent_0);
	if (pc_parent_1 != pcOtherThanThisOne)  return(pc_parent_1);
	return(NULL);
}//CDarkGrayGAIndividual_MO  *CDarkGrayGAPxMask_MO::pcGetOtherInd(CDarkGrayGAIndividual_MO  *pcOtherThanThisOne)



void  CDarkGrayGAPxMask_MO::vReport(CString  sDest)
{
	FILE  *pf_dest;
	pf_dest = fopen(sDest, "w+");
	if (pf_dest == NULL)  return;
	vReport(pf_dest);
	fclose(pf_dest);
}//void  CDarkGrayGAPxMask_MO::vReport(CString  sDest)



void  CDarkGrayGAPxMask_MO::vReport(FILE  *pfDest)
{
	fprintf(pfDest, "%s\n", pc_parent_0->sToStr());
	fprintf(pfDest, "%s\n", pc_parent_1->sToStr());

	int  *pi_tool = new int[pc_parent_0->i_templ_length];

	for (int ii = 0; ii < pc_parent_0->i_templ_length; ii++)
		pi_tool[ii] = 0;

	for (int i_off = 0; i_off < v_mask.size(); i_off++)
		pi_tool[v_mask.at(i_off)] = 1;


	CString  s_line, s_buf;
	for (int ii = 0; ii < pc_parent_0->i_templ_length; ii++)
	{
		if (pi_tool[ii] == 0)  s_buf = "_";
		if (pi_tool[ii] == 1)  s_buf = "1";
		s_line += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)
	fprintf(pfDest, "%s\n", s_line);

	s_line.Format("size: [%d]:", v_mask.size());
	for (int i_off = 0; i_off < v_mask.size(); i_off++)
	{
		s_buf.Format("%d,", v_mask.at(i_off));
		s_line += s_buf;
	}//for (int i_off = 0; i_off < v_mask.size(); i_off++)

	fprintf(pfDest, "%s\n", s_line);


	delete  pi_tool;

	//::Tools::vShow(12345);//*/
}//void  CDarkGrayGAPxMask_MO::vReportTest()



CString  CDarkGrayGAPxMask_MO::sToStr()
{
	CString  s_result;

	int  *pi_tool = new int[pc_parent_0->i_templ_length];

	for (int ii = 0; ii < pc_parent_0->i_templ_length; ii++)
		pi_tool[ii] = 0;

	for (int i_off = 0; i_off < v_mask.size(); i_off++)
		pi_tool[v_mask.at(i_off)] = 1;


	CString  s_buf;
	for (int ii = 0; ii < pc_parent_0->i_templ_length; ii++)
	{
		if (pi_tool[ii] == 0)  s_buf = "_";
		if (pi_tool[ii] == 1)  s_buf = "1";
		s_result += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)


	delete  pi_tool;


	return(s_result);
}//CString  CDarkGrayGAPxMask_MO::sToStr()



//---------------------------------------------CDarkGrayGAIndividual_MO-------------------------------------------------------
CDarkGrayGAIndividual_MO::CDarkGrayGAIndividual_MO(int  iTemplLength, CBinaryMultiObjectiveProblem *pcProblem, CDarkGrayGASinglePop_MO  *pcParent) : CMultiIndividual()
{
	i_templ_length = iTemplLength;
	pc_parent = pcParent;

	pc_genotype = new CBinaryCoding(i_templ_length);
	//pi_genotype = new int[i_templ_length];
	pi_epx_mask = new int[i_templ_length];

	pc_problem = pcProblem;

	d_fitnes_buf = -1;
	b_fitness_actual = false;


	vRandomizeGenotype();
}//CDarkGrayGAIndividual_MO::CDarkGrayGAIndividual_MO(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CDarkGrayGA  *pcParent)


CDarkGrayGAIndividual_MO::CDarkGrayGAIndividual_MO(CDarkGrayGAIndividual_MO &pcOther)
{
	::Tools::vShow("No implementation: CDarkGrayGAIndividual_MO::CDarkGrayGAIndividual_MO(CDarkGrayGAIndividual_MO &pcOther) ");
};//CDarkGrayGAIndividual_MO::CDarkGrayGAIndividual_MO(CDarkGrayGAIndividual_MO &pcOther)


CDarkGrayGAIndividual_MO::~CDarkGrayGAIndividual_MO()
{
	//delete  pc_genotype; deleted by CMultiIndividual
	delete  pi_epx_mask;
};//CDarkGrayGAIndividual_MO::~CDarkGrayGAIndividual_MO()


void  CDarkGrayGAIndividual_MO::vCopyFrom(CDarkGrayGAIndividual_MO  *pcOther)
{
	this->pc_parent = pcOther->pc_parent;
	this->i_templ_length = pcOther->i_templ_length;
	this->v_opt_order = pcOther->v_opt_order;
	this->d_fitnes_buf = pcOther->d_fitnes_buf;
	this->b_fitness_actual = pcOther->b_fitness_actual;
	this->pc_problem = pcOther->pc_problem;


	for (int ii = 0; ii < i_templ_length; ii++)
		pc_genotype->piGetBits()[ii] = pcOther->pc_genotype->piGetBits()[ii];


	this->v_fitness = pcOther->v_fitness;
	this->b_rated = pcOther->b_rated;

}//void  CDarkGrayGAIndividual_MO::vCopyFrom(CDarkGrayGAIndividual_MO  *pcOther)



bool  CDarkGrayGAIndividual_MO::b_get_all_epx_masks(int  *piMasksManager, int  *piMasksNum, CDarkGrayGAIndividual_MO  *pcDonor) 
{
	//first get next uncovered different gene
	int  i_next_seed_gene = -1;

	for (int ii = 0; (ii < i_templ_length) && (i_next_seed_gene == -1); ii++)
	{
		if (piMasksManager[ii] == -1)  i_next_seed_gene = ii;
	}//for (int ii = 0; (ii < i_templ_length)&&(i_init_gene == -1); ii++)

	if (i_next_seed_gene == -1)  return(false);

	pcDonor->vEpxMaskCompute(i_next_seed_gene, this);
	(*piMasksNum)++;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pcDonor->pi_epx_mask[ii] > 0)
		{
			if (piMasksManager[ii] > -1)  ::Tools::vShow("IMPOSISBILITY ALARM: bool  CDarkGrayGAIndividual_MO::b_get_all_epx_masks");
			pi_epx_mask[ii] = (*piMasksNum);
		}//if (pcDonor->pi_epx_mask[ii] > 0)
	}//for (int ii = 0; ii < i_templ_length; ii++)

	return(true);
}//bool  CDarkGrayGAIndividual_MO::b_get_all_epx_masks(int  *piMasksManager, int  *piMasksNum, CDarkGrayGAIndividual_MO  *pcDonor) 





int   CDarkGrayGAIndividual_MO::iMixing_ePX_ByDonor(CDarkGrayGAIndividual_MO *pcDonor, CDarkGrayGAIndividual_MO  *pcResult)
{
	int i_init_gene = -1;
	for (int ii = 0; (ii < i_templ_length)&&(i_init_gene == -1); ii++)
	{
		if (pc_genotype->piGetBits()[ii] != pcDonor->pc_genotype->piGetBits()[ii])  i_init_gene = ii;
	}//for (int ii = 0; (ii < i_templ_length)&&(i_init_gene == -1); ii++)

	if (i_init_gene == -1)  return(-1);

	bool  b_slided = false;

	pcDonor->vEpxMaskCompute(i_init_gene, this);
	if (pcDonor->bEpxMaskCanICross() == true)
	{
		//first get all epx masks
		int  i_masks_num = 1;

		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pcDonor->pi_epx_mask[ii] > 0)
				pi_epx_mask[ii] = i_masks_num;
			else
			{
				pi_epx_mask[ii] = pcDonor->pi_epx_mask[ii];//0 or -1 -> we ignore 0, but we try to generate next masks for '-1's
			}//else  if (pcDonor->pi_epx_mask[ii] > 0)
		}//for (int ii = 0; ii < i_templ_length; ii++)

		while (b_get_all_epx_masks(pi_epx_mask, &i_masks_num, pcDonor) == true);

		vector<int>  v_masks_ids;
		for (int ii = 0; ii < i_masks_num; ii++)
			v_masks_ids.push_back(ii+1);

		/*FILE  *pf_test;
		pf_test = fopen("zzzz_epx_by_donor_masks_test.txt", "w+");
		fprintf(pf_test, "%s\n", sToStr());
		fprintf(pf_test, "%s\n", pcDonor->sToStr());
		fprintf(pf_test, "%s\n", sEpxToStr());

		fclose(pf_test);
		::Tools::vShow(12345);//*/
		
		int  i_offset, i_mask_to_cross;
		int  i_epx_donate_result;
		int  i_epx_exchanged_length, i_epx_differing_length;
		while (v_masks_ids.size() > 0)
		{
			i_offset = RandUtils::iRandNumber(0, v_masks_ids.size() - 1);
			i_mask_to_cross = v_masks_ids.at(i_offset);
			v_masks_ids.erase(v_masks_ids.begin() + i_offset);

			i_epx_exchanged_length = 0;
			i_epx_differing_length = 0;
			for (int ii = 0; ii < i_templ_length; ii++)
			{
				if (pi_epx_mask[ii] == i_mask_to_cross)
				{
					i_epx_exchanged_length++;
					pcDonor->pi_epx_mask[ii] = 1;
				}//if (pi_epx_mask[ii] == i_mask_to_cross)
				else
				{
					if  (pc_genotype->piGetBits()[ii] ==  pcDonor->pc_genotype->piGetBits()[ii])
						pcDonor->pi_epx_mask[ii] = 0;
					else
					{
						pcDonor->pi_epx_mask[ii] = -1;
						i_epx_differing_length++;
					}//else  if (pi_genotype[ii] == pcDonor->pi_genotype[ii])
				}//else  if (pi_epx_mask[ii] == i_mask_to_cross)
			}//for (int ii = 0; ii < i_templ_length; ii++)

			pcDonor->i_epx_mask_positions_exchanged = i_epx_exchanged_length;
			pcDonor->i_epx_mask_positions_remain_differing = i_epx_differing_length;
			i_epx_donate_result = pcDonor->iEpxDonateByMask(this, pcResult);

			if (i_epx_donate_result > 0)
			{
				if  (i_epx_donate_result == 2)  (pc_parent->i_uniform_donations)++;
				return(i_epx_donate_result);
			}//if (i_epx_donate_result > 0)

			//SLIDE			
			if (i_epx_donate_result == 0)
			{
				if (pc_parent->pc_individual_buffer == NULL)  pc_parent->pc_individual_buffer = new CDarkGrayGAIndividual_MO(i_templ_length, pc_problem, pc_parent);
				pc_parent->pc_individual_buffer->vCopyFrom(pcResult);
				b_slided = true;
			}//if (i_epx_donate_result == 0)

		}//while (v_masks_ids.size() > 0)
	}//if (pcDonor->bEpxMaskCanICross() == true)





	if (b_slided == true)
	{
		if (pc_parent->pc_individual_buffer == NULL)  pc_parent->pc_individual_buffer = new CDarkGrayGAIndividual_MO(i_templ_length, pc_problem, pc_parent);
		pcResult->vCopyFrom(pc_parent->pc_individual_buffer);
		(pc_parent->i_slide_number)++;
		return(0);
	}//if (b_slided == true)

	//do floating
	return(-1);
}//int   CDarkGrayGAIndividual_MO::iMixing_ePX_ByDonor(CDarkGrayGAIndividual_MO *pcDonor, CDarkGrayGAIndividual_MO  *pcResult)





int   CDarkGrayGAIndividual_MO::iMixing_ePX_ByDonor(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult)
{
	int  i_gene_to_cross, i_offset;
	vector<CDarkGrayGAIndividual_MO *> v_crossable_individuals;



	int  i_epx_donate_result_equal = 0;
	int  i_epx_donate_result_worse = 0;

	CString  s_first_result_buf;
	int  i_cand_offset;
	CDarkGrayGAIndividual_MO  *pc_donor_candidate;


	for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)
	{
		if (this != pvPop->at(i_ind))
		{
			if (this->bIsTheSame(pvPop->at(i_ind)) == false)  v_crossable_individuals.push_back(pvPop->at(i_ind));
		}//if (this != pvPop->at(i_ind))
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)


	int  i_epx_by_donor_result;
	while (v_crossable_individuals.size() > 0)
	{
		i_cand_offset = RandUtils::iRandNumber(0, v_crossable_individuals.size() - 1);
		pc_donor_candidate = v_crossable_individuals.at(i_cand_offset);
		v_crossable_individuals.erase(v_crossable_individuals.begin() + i_cand_offset);

		i_epx_by_donor_result = iMixing_ePX_ByDonor(pc_donor_candidate, pcResult);

		if (i_epx_by_donor_result > 0)
		{
			/*FILE  *pf_test;
			pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
			fprintf(pf_test, "%s\n", sToStr());
			fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

			CString  s_line, s_buf;
			for (int ii = 0; ii < i_templ_length; ii++)
			{
				s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
				if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
				if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
				s_line += s_buf;
			}//for (int ii = 0; ii < i_templ_length; ii++)
			fprintf(pf_test, "%s\n", s_line);
			fprintf(pf_test, "%s\n", pcResult->sToStr());

			fclose(pf_test);
			::Tools::vShow(12345);//*/

			CString  s_epx_report;
			s_epx_report.Format("exchnaged: %d; remained different: %d", pc_donor_candidate->iEpxMaskPositionsExchanged(), pc_donor_candidate->iEpxMaskPositionsRemainDiffering());
			//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

			return(pc_donor_candidate->iEpxMaskPositionsExchanged());
		}//if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)
		
	}//while (v_crossable_individuals.size() > 0)


	pcResult->vCopyFrom(this);

	CString  s_epx_report;
	s_epx_report.Format("epx equal: %d    epx worse: %d", i_epx_donate_result_equal, i_epx_donate_result_worse);
	//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

	return(0);
}//int   CDarkGrayGAIndividual_MO::iMixing_ePX_ByDonor(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult)



void  CDarkGrayGAIndividual_MO::vGetPxMasks(CDarkGrayGAIndividual_MO  *pcOther, CDarkGrayGAPxMaskManager_MO  *pcMasksManager)
{
	int i_init_gene = -1;
	for (int ii = 0; (ii < i_templ_length) && (i_init_gene == -1); ii++)
	{
		if (pc_genotype->piGetBits()[ii] != pcOther->pc_genotype->piGetBits()[ii])  i_init_gene = ii;
	}//for (int ii = 0; (ii < i_templ_length)&&(i_init_gene == -1); ii++)

	if (i_init_gene == -1)  return;

	pcOther->vEpxMaskCompute(i_init_gene, this);
	if (pcOther->bEpxMaskCanICross() == true)
	{
		//first get all epx masks
		int  i_masks_num = 1;

		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pcOther->pi_epx_mask[ii] > 0)
				pi_epx_mask[ii] = i_masks_num;
			else
			{
				pi_epx_mask[ii] = pcOther->pi_epx_mask[ii];//0 or -1 -> we ignore 0, but we try to generate next masks for '-1's
			}//else  if (pcDonor->pi_epx_mask[ii] > 0)
		}//for (int ii = 0; ii < i_templ_length; ii++)

		while (b_get_all_epx_masks(pi_epx_mask, &i_masks_num, pcOther) == true);


		CDarkGrayGAPxMask_MO  *pc_new_px_mask;
		for (int i_mask = 1; i_mask <= i_masks_num; i_mask++)
		{
			pc_new_px_mask = pcMasksManager->pcGetNewPxMask();

			for (int i_gene = 0; i_gene < i_templ_length; i_gene++)
			{
				if (pi_epx_mask[i_gene] == i_mask)  pc_new_px_mask->v_mask.push_back(i_gene);
			}//for (int ii = 0; ii < i_templ_length; ii++)

			pc_new_px_mask->pc_parent_0 = this;
			pc_new_px_mask->pc_parent_1 = pcOther;

			//pc_new_px_mask->vReportTest();
		}//for (int ii = 0; ii < i_masks_num; ii++)
	}//if (pcOther->bEpxMaskCanICross() == true)

}//void  CDarkGrayGAIndividual_MO::vGetPxMasks(CDarkGrayGAIndividual_MO  *pcOther, CDarkGrayGAPxMaskManager_MO  *pcMasksManager)


int   CDarkGrayGAIndividual_MO::iMixing_PX_ByMask(CDarkGrayGAPxMask_MO *pcMask, CDarkGrayGAIndividual_MO  *pcResult, bool bUseDomination)
{
	CDarkGrayGAIndividual_MO  *pc_donor_candidate;

	pc_donor_candidate = pcMask->pcGetOtherInd(this);
	
	for (int ii = 0; ii < i_templ_length; ii++)
		pcResult->pc_genotype->piGetBits()[ii] = pc_genotype->piGetBits()[ii];

	for (int i_offset = 0; i_offset < pcMask->v_mask.size(); i_offset++)
		pcResult->pc_genotype->piGetBits()[pcMask->v_mask.at(i_offset)] = pc_donor_candidate->pc_genotype->piGetBits()[pcMask->v_mask.at(i_offset)];

	double  d_fitness_result;
	pcResult->b_fitness_actual = false;
	d_fitness_result = pcResult->dComputeFitness();

	//::Tools::vReportInFile("zzzzzz_mix_px_log.txt", sToStr());
	//::Tools::vReportInFile("zzzzzz_mix_px_log.txt", pcResult->sToStr());
	//::Tools::vReportInFile("zzzzzz_mix_px_log.txt", "\n");

	if (bUseDomination == true)
	{
		int  i_domination;
		i_domination = this->iCheckDomination(pcResult);
		if  (i_domination  <  0)  return(1);//pcResult is better
		if (i_domination == 0)  return(0);//*/
	}//if (bUseDomination == true)
	else
	{
		if (dComputeFitness() < d_fitness_result)  return(1);
		if (dComputeFitness() == d_fitness_result)  return(0);
	}//else if (bUseDomination == true)


	

	return(-1);
}//int   CDarkGrayGAIndividual_MO::iMixing_ePX_ByDonor(CDarkGrayGAIndividual_MO *pcDonor, CDarkGrayGAIndividual_MO  *pcResult)



int   CDarkGrayGAIndividual_MO::iUniformCrossoverByMask(CDarkGrayGAPxMask_MO *pcMask, CDarkGrayGAIndividual_MO  *pcResult)
{
	CDarkGrayGAIndividual_MO  *pc_donor_candidate;


	int  *pi_modified_map, *pi_dummy;

	pc_parent->vGetGenotypeBufferTools(&pi_modified_map, &pi_dummy);
	for (int ii = 0; ii < i_templ_length; ii++)
		pi_modified_map[ii] = 0;

	int  i_genes_exchanged;

	pc_donor_candidate = pcMask->pcGetOtherInd(this);

	i_genes_exchanged = 0;
	for (int ii = 0; ii < i_templ_length; ii++)
		pcResult->pc_genotype->piGetBits()[ii] = pc_genotype->piGetBits()[ii];

	for (int i_offset = 0; i_offset < pcMask->v_mask.size(); i_offset++)
	{
		if (::RandUtils::dRandNumber(0, 1) < 0.5)
		{
			pcResult->pc_genotype->piGetBits()[pcMask->v_mask.at(i_offset)] = pc_donor_candidate->pc_genotype->piGetBits()[pcMask->v_mask.at(i_offset)];
			pi_modified_map[pcMask->v_mask.at(i_offset)] = 1;
			i_genes_exchanged++;
		}//if  (::RandUtils::dRandNumber(0,1) < 0.5)
	}//for (int i_offset = 0; i_offset < pcMask->v_mask.size(); i_offset++)


	double  d_fit_start, d_fit_uniform, d_fit_uniform_opt;
	d_fit_start = dComputeFitness();

	pcResult->b_fitness_actual = false;
	d_fit_uniform = pcResult->dComputeFitness();

	pcResult->b_fitness_actual = false;
	d_fit_uniform_opt = pcResult->dComputeFitnessOptimize(NULL, true, pi_modified_map);

	if (d_fit_start < d_fit_uniform_opt)
	{
		CString  s_buf;
		s_buf.Format("UNIFORM+OPT (%d/%d): %.8lf -> %.8lf -> %.8lf", i_genes_exchanged, pcMask->v_mask.size(), d_fit_start, d_fit_uniform, d_fit_uniform_opt);
		pc_parent->pcGetLog()->vPrintLine(s_buf, true);

		return(2);
	}//if (d_fitness_start < d_fitness_end)

	return(-1);
}//int   CDarkGrayGAIndividual_MO::iUniformCrossoverByMask(CDarkGrayGAPxMask_MO *pcMask, CDarkGrayGAIndividual_MO  *pcResult)




int  CDarkGrayGAIndividual_MO::iGetPopLevel()
{
	int  i_pop_level;
	i_pop_level = pc_parent->pc_parent->iGetPopLevel(pc_parent);
	return(i_pop_level);
}//int  CDarkGrayGAIndividual_MO::iGetPopLevel()



int   CDarkGrayGAIndividual_MO::iMixing_ePX_ByMaskLen(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult, bool bUseDomination, vector<CDarkGrayGAIndividual_MO *> *pvPopToBeDifferentFrom)
{
	CString  s_buf;

	int  i_gene_to_cross, i_offset;
	vector<CDarkGrayGAIndividual_MO *> v_crossable_individuals;
	


	int  i_epx_donate_result_equal = 0;
	int  i_epx_donate_result_worse = 0;

	CString  s_first_result_buf;
	int  i_cand_offset;
	

	for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)
	{
		if (this != pvPop->at(i_ind))
		{
			if (this->bIsTheSame(pvPop->at(i_ind)) == false)  v_crossable_individuals.push_back(pvPop->at(i_ind));
		}//if (this != pvPop->at(i_ind))
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)


	pc_parent->pcGetPxMasksManager()->vClear();
	for (int i_ind = 0; i_ind < v_crossable_individuals.size(); i_ind++)
	{
		v_crossable_individuals.at(i_ind)->vGetPxMasks(this, pc_parent->pcGetPxMasksManager());
	}//for (int i_ind = 0; i_ind < v_crossable_individuals.size(); i_ind++)

	pc_parent->pcGetPxMasksManager()->vShuffle();
	pc_parent->pcGetPxMasksManager()->vSortByLength();
	//pc_parent->pcGetPxMasksManager()->vReport("zzzzzz_manager_masks_test.txt");


	int  i_final_result;
	vector  <CDarkGrayGAPxMask_MO*> v_sliding_masks;
	CDarkGrayGAPxMask_MO  *pc_mask;
	int  i_epx_by_donor_result;
	CString  s_donor_modified, s_this_modified;
	//if (pc_parent->pc_individual_buffer == NULL)  pc_parent->pc_individual_buffer = new CDarkGrayGAIndividual_MO(i_templ_length, pc_problem, pc_parent);
	//pc_parent->pc_individual_buffer->vCopyFrom(this);

	for (int i_mask = 0; i_mask < pc_parent->pcGetPxMasksManager()->iGetSize(); i_mask++)
	{
		pc_mask = pc_parent->pcGetPxMasksManager()->pcGetAt(i_mask);
		if (pc_mask != NULL)
		{
			i_epx_by_donor_result = iMixing_PX_ByMask(pc_mask, pcResult, bUseDomination);

			if (i_epx_by_donor_result > 0)
			{
				//i_final_result = i_epx_by_donor_result;
				//this->vCopyFrom(pcResult);
				return(pc_mask->v_mask.size());
			}//if (i_epx_by_donor_result > 0)

			if (i_epx_by_donor_result == 0)
			{
				if (pvPopToBeDifferentFrom != NULL)
				{
					bool  b_the_same_obj = false;
					for (int ii = 0; (ii < pvPopToBeDifferentFrom->size())&&(b_the_same_obj == false); ii++)
					{
						if  (pcResult->bTheSameObjectives(pvPopToBeDifferentFrom->at(ii)) == true)  b_the_same_obj = true;
					}//for (int ii = 0; (ii < pvPopToBeDifferentFrom->size())&&(b_the_same_obj == false); ii++)

					if (b_the_same_obj == false)
					{
						v_sliding_masks.push_back(pc_mask);
					}//if (b_the_same_obj == false)
				}//if (pvPopToBeDifferentFrom != NULL)
				else
					v_sliding_masks.push_back(pc_mask);//*/
				//this->vCopyFrom(pcResult);
				//if (i_final_result < 0)  i_final_result = 0;
			}//if (i_epx_by_donor_result == 0)


			if (i_epx_by_donor_result < 0)
			{
				s_this_modified = pcResult->sToStr();
				int  i_epx_switched_result;
				CDarkGrayGAIndividual_MO  *pc_other_ind;
				pc_other_ind = pc_mask->pcGetOtherInd(this);
				i_epx_switched_result = pc_other_ind->iMixing_PX_ByMask(pc_mask, pcResult, bUseDomination);

				if (i_epx_switched_result > 0)
				{
					if (pc_parent->pc_parent->i_sett_donor_improvement == 1)
					{
						if (pc_parent->pc_parent->b_p3_the_same_exists(pcResult) == false)
						{
							CDarkGrayGASinglePop_MO  *pc_parent_preserved;
							pc_parent_preserved = pc_other_ind->pc_parent;
							pc_other_ind->vCopyFrom(pcResult);
							pc_other_ind->pc_parent = pc_parent_preserved;
						}//if (pc_parent->pc_parent->b_p3_the_same_exists(pcResult) == false)
					}//if (this->pc_parent->pc_parent->i_donor_improvement == 1)
					
					//s_buf.Format("Improving donor");
					//::Tools::vShow(s_buf);

					/*CDarkGrayGAIndividual_MO  *pc_donor_improved_copy;
					pc_donor_improved_copy = new CDarkGrayGAIndividual_MO(i_templ_length, pc_problem, pc_parent);
					pc_donor_improved_copy->vCopyFrom(pcResult);

					int  i_donor_pyramid_level;
					i_donor_pyramid_level = pc_other_ind->iGetPopLevel();

					if (pc_other_ind->pc_parent->pc_parent->b_p3_add_to_level(i_donor_pyramid_level + 1, pc_donor_improved_copy) == false)  delete  pc_donor_improved_copy;
					s_buf.Format("donor push: %d->%d", i_donor_pyramid_level, i_donor_pyramid_level+1);
					pc_other_ind->pc_parent->pc_parent->pc_log->vPrintLine(s_buf, true);*/
				}//if (i_epx_switched_result > 0)
				else
				{
					/*s_donor_modified = pcResult->sToStr();

					s_buf.Format("FAILED: %d\n", i_epx_switched_result);
					::Tools::vReportInFile("zzzz_switchedEpx.txt", s_buf);
					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->pc_parent_0->sToStr());
					pc_mask->pc_parent_0->b_fitness_actual = false;
					pc_mask->pc_parent_0->dComputeFitness();
					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->pc_parent_0->sToStr());

					::Tools::vReportInFile("zzzz_switchedEpx.txt", "");


					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->pc_parent_1->sToStr());
					pc_mask->pc_parent_1->b_fitness_actual = false;
					pc_mask->pc_parent_1->dComputeFitness();
					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->pc_parent_1->sToStr());

					::Tools::vReportInFile("zzzz_switchedEpx.txt", "\n\n");
					::Tools::vReportInFile("zzzz_switchedEpx.txt", pc_mask->sToStr());
					::Tools::vReportInFile("zzzz_switchedEpx.txt", s_this_modified);
					::Tools::vReportInFile("zzzz_switchedEpx.txt", s_donor_modified);//*/
					pc_parent->pc_dsm->vUpdateDSM(pc_mask);

					//::Tools::vShow("SwitchedEPX FAILED!!!");
				}//else  if (i_epx_switched_result > 0)
			}//if (i_epx_by_donor_result < 0)

		}//if (pc_mask != NULL)				
	}//for (int i_mask = 0; i_mask < pc_parent->pcGetPxMasksManager()->iGetSize(); i_mask++)


	if (v_sliding_masks.size() > 0)
	{
		int i_offset;
		i_offset = ::RandUtils::iRandNumber(0, v_sliding_masks.size()-1);


		if (pc_parent->pc_parent->i_sett_uniform_crossover_for_slide == 1)
		{
			int  i_uniform_crossover_result;
			i_uniform_crossover_result = iUniformCrossoverByMask(v_sliding_masks.at(i_offset), pcResult);

			if (i_uniform_crossover_result > 0)
			{
				pc_parent->i_uniform_donations++;
				return(1);
			}//if (i_uniform_crossover_result > 0)
		}//if  (pc_parent->pc_parent->i_uniform_crossover_for_slide == 1)


		iMixing_PX_ByMask(v_sliding_masks.at(i_offset), pcResult, bUseDomination);
		return(0);
	}//if (v_sliding_masks.size() > 0)*/

	
	pcResult->vCopyFrom(this);
	//return(i_final_result);

	return(-1);
}//int   CDarkGrayGAIndividual_MO::iMixing_ePX_ByMaskLen(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult)





int  CDarkGrayGAIndividual_MO::iMixing_ePX_Brutal(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult)
{
	int  i_gene_to_cross, i_offset;
	vector<CDarkGrayGAIndividual_MO *> v_crossable_individuals;


	int  i_epx_donate_result;
	
	int  i_epx_donate_result_equal = 0;
	int  i_epx_donate_result_worse = 0;

	CString  s_first_result_buf;
	int  i_cand_offset;
	CDarkGrayGAIndividual_MO  *pc_donor_candidate;

	vector<int>  v_available_positions;
	for (int ii = 0; ii < i_templ_length; ii++)
		v_available_positions.push_back(ii);



	while (v_available_positions.size() > 0)
	{
		i_offset = RandUtils::iRandNumber(0, v_available_positions.size() - 1);
		i_gene_to_cross = v_available_positions.at(i_offset);
		v_available_positions.erase(v_available_positions.begin() + i_offset);



		
		//fprintf(pf_test, "%s\n\n", sToStr());

		v_crossable_individuals.clear();
		for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)
		{
			if (this != pvPop->at(i_ind))
			{
				if (pc_genotype->piGetBits()[i_gene_to_cross] != pvPop->at(i_ind)->pc_genotype->piGetBits()[i_gene_to_cross])
				{
					pvPop->at(i_ind)->vEpxMaskCompute(i_gene_to_cross, this);
					if (pvPop->at(i_ind)->bEpxMaskCanICross() == true)  
						v_crossable_individuals.push_back(pvPop->at(i_ind));
					/*else
					{
						CString  s_line, s_buf;

						s_line = "";
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", pvPop->at(i_ind)->pi_epx_mask[ii]);
							if (pvPop->at(i_ind)->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (pvPop->at(i_ind)->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);

					}//else  if (pvPop->at(i_ind)->bEpxMaskCanICross() == true)  */
				}//if (pi_genotype[i_gene_to_cross] != pvPop->at(i_ind)->pi_genotype[i_gene_to_cross])
			}//if (this != pvPop->at(i_ind))
		}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)


		if (v_crossable_individuals.size() > 0)
		{
			/*FILE  *pf_test;
			pf_test = fopen("zzzz_epx_mask_LIST_test.txt", "w+");
			fprintf(pf_test, "\n\n\n\nCROSSABLE:\n\n\n");

			CDarkGrayGAIndividual_MO  *pc_buf = new CDarkGrayGAIndividual_MO(i_templ_length, pc_problem, pc_parent);

			CString  s_line, s_buf;
			for (int i_ind = 0; i_ind < v_crossable_individuals.size(); i_ind++)
			{
				fprintf(pf_test, "%s\n\n", v_crossable_individuals.at(i_ind)->sEpxToStr());
				pc_buf->vCopyFrom(v_crossable_individuals.at(i_ind));

				for (int i_gene_dffering = 0; i_gene_dffering < i_templ_length; i_gene_dffering++)
				{
					if (v_crossable_individuals.at(i_ind)->pi_epx_mask[i_gene_dffering] == -1)
					{
						pc_buf->vEpxMaskCompute(i_gene_dffering, this);
						fprintf(pf_test, "%s\n", pc_buf->sEpxToStr());
					}//if (v_crossable_individuals.at(i_ind)->pi_epx_mask[i_gene_dffering] == -1)
				}//for (int ii = 0; ii < i_templ_length; ii++)

				fprintf(pf_test, "\n\n");

			}//for (int ii = 0; ii < v_crossable_individuals.size(); ii++)
			fclose(pf_test);
			::Tools::vShow(v_crossable_individuals.size());//*/
					   			 		  		  		 	   		
			
			pc_donor_candidate = v_crossable_individuals.at(0);

			i_epx_donate_result = pc_donor_candidate->iEpxDonateByMask(this, pcResult);

			if (i_epx_donate_result == 1)
			{
				/*FILE  *pf_test;
				pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
				fprintf(pf_test, "%s\n", sToStr());
				fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

				CString  s_line, s_buf;
				for (int ii = 0; ii < i_templ_length; ii++)
				{
					s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
					if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
					if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
					s_line += s_buf;
				}//for (int ii = 0; ii < i_templ_length; ii++)
				fprintf(pf_test, "%s\n", s_line);
				fprintf(pf_test, "%s\n", pcResult->sToStr());

				fclose(pf_test);
				::Tools::vShow(12345);//*/

				CString  s_epx_report;
				s_epx_report.Format("exchnaged: %d; remained different: %d", pc_donor_candidate->iEpxMaskPositionsExchanged(), pc_donor_candidate->iEpxMaskPositionsRemainDiffering());
				//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

				return(pc_donor_candidate->iEpxMaskPositionsExchanged());
			}//if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)


			if (i_epx_donate_result == 0)
			{
				i_epx_donate_result_equal++;
			}//if (i_epx_donate_result == 0)

			if (i_epx_donate_result == -1)
			{
				/*::Tools::vShow("Worse");
				s_first_result_buf = pcResult->sToStr();

				//REVERT CROSSING
				i_epx_donate_result = -2;
				this->vEpxMaskCompute(i_gene_to_cross, pc_donor_candidate);
				if (this->bEpxMaskCanICross() == true)
				{
					i_epx_donate_result = this->iEpxDonateByMask(pc_donor_candidate, pcResult);
				}//if (this->bEpxMaskCanICross() == true)

				if (i_epx_donate_result != 1)
				{
					FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", s_first_result_buf);

					fprintf(pf_test, "\n====================\n");


					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());
					fprintf(pf_test, "%s\n", sToStr());
					s_line = "";
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", this->pi_epx_mask[ii]);
						if (this->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (this->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());




					fclose(pf_test);
					::Tools::vShow("NIEMOZLIWE");
				}//if (i_epx_donate_result != 1)*/


				i_epx_donate_result_worse++;
			}//if (i_epx_donate_result == -1)
		}//if  (v_crossable_individuals.size() > 0)
		

	}//while (v_available_positions.size() > 0)

	pcResult->vCopyFrom(this);

	CString  s_epx_report;
	s_epx_report.Format("epx equal: %d    epx worse: %d", i_epx_donate_result_equal, i_epx_donate_result_worse);
	//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

	return(0);




	while (v_crossable_individuals.size() > 0)
	{
		i_cand_offset = RandUtils::iRandNumber(0, v_crossable_individuals.size() - 1);
		pc_donor_candidate = v_crossable_individuals.at(i_cand_offset);
		v_crossable_individuals.erase(v_crossable_individuals.begin() + i_cand_offset);

		

		v_available_positions.clear();
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pc_genotype->piGetBits()[ii] != pc_donor_candidate->pc_genotype->piGetBits()[ii])  v_available_positions.push_back(ii);
		}//for (int ii = 0; ii < i_templ_length; ii++)


		if (v_available_positions.size() > 0)
		{
			i_offset = RandUtils::iRandNumber(0, v_available_positions.size() - 1);
			i_gene_to_cross = v_available_positions.at(i_offset);

			pc_donor_candidate->vEpxMaskCompute(i_gene_to_cross, this);
			if (pc_donor_candidate->bEpxMaskCanICross() == true)
			{
				i_epx_donate_result = pc_donor_candidate->iEpxDonateByMask(this, pcResult);

				if (i_epx_donate_result == 1)
				{
					/*FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());

					fclose(pf_test);
					::Tools::vShow(12345);//*/

					CString  s_epx_report;
					s_epx_report.Format("exchnaged: %d; remained different: %d", pc_donor_candidate->iEpxMaskPositionsExchanged(), pc_donor_candidate->iEpxMaskPositionsRemainDiffering());
					//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

					return(pc_donor_candidate->iEpxMaskPositionsExchanged());
				}//if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)
				

				if (i_epx_donate_result == 0)  i_epx_donate_result_equal++;
				
				if (i_epx_donate_result == -1)  
				{
					s_first_result_buf = pcResult->sToStr();

					//REVERT CROSSING
					i_epx_donate_result = -2;
					this->vEpxMaskCompute(i_gene_to_cross, pc_donor_candidate);
					if (this->bEpxMaskCanICross() == true)
					{
						i_epx_donate_result = this->iEpxDonateByMask(pc_donor_candidate, pcResult);
					}//if (this->bEpxMaskCanICross() == true)

					if (i_epx_donate_result != 1)
					{
						FILE  *pf_test;
						pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
						fprintf(pf_test, "%s\n", sToStr());
						fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

						CString  s_line, s_buf;
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
							if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);



						fprintf(pf_test, "%s\n", s_first_result_buf);

						fprintf(pf_test, "\n====================\n");


						fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());
						fprintf(pf_test, "%s\n", sToStr());
						s_line = "";
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", this->pi_epx_mask[ii]);
							if (this->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (this->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);
						fprintf(pf_test, "%s\n", pcResult->sToStr());


						

						fclose(pf_test);
						::Tools::vShow("NIEMOZLIWE");
					}//if (i_epx_donate_result != 1)


					i_epx_donate_result_worse++;

					/*FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());

					fclose(pf_test);
					::Tools::vShow(-8);//*/
				}//else  if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)
			}//if (pc_donor_candidate->bEpxMaskCanICross() == true)
		}//if (v_available_positions.size() > 0)
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)	


	pcResult->vCopyFrom(this);

	//CString  s_epx_report;
	s_epx_report.Format("epx equal: %d    epx worse: %d", i_epx_donate_result_equal, i_epx_donate_result_worse);
	//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

	return(0);
}//bool  CDarkGrayGAIndividual_MO::bMixing_ePX(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcDest)


int  CDarkGrayGAIndividual_MO::iMixing_ePX(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcResult)
{
	int  i_gene_to_cross, i_offset;
	vector<CDarkGrayGAIndividual_MO *> v_crossable_individuals;


	for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)
	{
		if (this != pvPop->at(i_ind))
		{
			if (this->bIsTheSame(pvPop->at(i_ind)) == false)  v_crossable_individuals.push_back(pvPop->at(i_ind));
		}//if (this != pvPop->at(i_ind))
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)


	int  i_epx_donate_result_equal = 0;
	int  i_epx_donate_result_worse = 0;

	CString  s_first_result_buf;
	int  i_cand_offset;
	CDarkGrayGAIndividual_MO  *pc_donor_candidate;
	vector<int>  v_available_positions;
	while (v_crossable_individuals.size() > 0)
	{
		i_cand_offset = RandUtils::iRandNumber(0, v_crossable_individuals.size() - 1);
		pc_donor_candidate = v_crossable_individuals.at(i_cand_offset);
		v_crossable_individuals.erase(v_crossable_individuals.begin() + i_cand_offset);


		v_available_positions.clear();
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pc_genotype->piGetBits()[ii] != pc_donor_candidate->pc_genotype->piGetBits()[ii])  v_available_positions.push_back(ii);
		}//for (int ii = 0; ii < i_templ_length; ii++)


		int  i_epx_donate_result;
		if (v_available_positions.size() > 0)
		{
			i_offset = RandUtils::iRandNumber(0, v_available_positions.size() - 1);
			i_gene_to_cross = v_available_positions.at(i_offset);

			pc_donor_candidate->vEpxMaskCompute(i_gene_to_cross, this);
			if (pc_donor_candidate->bEpxMaskCanICross() == true)
			{
				i_epx_donate_result = pc_donor_candidate->iEpxDonateByMask(this, pcResult);

				if (i_epx_donate_result == 1)
				{
					/*FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());

					fclose(pf_test);
					::Tools::vShow(12345);//*/

					CString  s_epx_report;
					s_epx_report.Format("exchnaged: %d; remained different: %d", pc_donor_candidate->iEpxMaskPositionsExchanged(), pc_donor_candidate->iEpxMaskPositionsRemainDiffering());
					//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

					return(pc_donor_candidate->iEpxMaskPositionsExchanged());
				}//if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)


				if (i_epx_donate_result == 0)  i_epx_donate_result_equal++;

				if (i_epx_donate_result == -1)
				{
					s_first_result_buf = pcResult->sToStr();

					//REVERT CROSSING
					i_epx_donate_result = -2;
					this->vEpxMaskCompute(i_gene_to_cross, pc_donor_candidate);
					if (this->bEpxMaskCanICross() == true)
					{
						i_epx_donate_result = this->iEpxDonateByMask(pc_donor_candidate, pcResult);
					}//if (this->bEpxMaskCanICross() == true)

					if (i_epx_donate_result != 1)
					{
						FILE  *pf_test;
						pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
						fprintf(pf_test, "%s\n", sToStr());
						fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

						CString  s_line, s_buf;
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
							if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);
						fprintf(pf_test, "%s\n", s_first_result_buf);

						fprintf(pf_test, "\n====================\n");


						fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());
						fprintf(pf_test, "%s\n", sToStr());
						s_line = "";
						for (int ii = 0; ii < i_templ_length; ii++)
						{
							s_buf.Format("%d", this->pi_epx_mask[ii]);
							if (this->pi_epx_mask[ii] == 0)  s_buf = "_";
							if (this->pi_epx_mask[ii] < 0)  s_buf = "*";
							s_line += s_buf;
						}//for (int ii = 0; ii < i_templ_length; ii++)
						fprintf(pf_test, "%s\n", s_line);
						fprintf(pf_test, "%s\n", pcResult->sToStr());




						fclose(pf_test);
						::Tools::vShow("IMPOSSIBLE");
					}//if (i_epx_donate_result != 1)


					i_epx_donate_result_worse++;

					/*FILE  *pf_test;
					pf_test = fopen("zzzz_epx_mask_test.txt", "w+");
					fprintf(pf_test, "%s\n", sToStr());
					fprintf(pf_test, "%s\n", pc_donor_candidate->sToStr());

					CString  s_line, s_buf;
					for (int ii = 0; ii < i_templ_length; ii++)
					{
						s_buf.Format("%d", pc_donor_candidate->pi_epx_mask[ii]);
						if (pc_donor_candidate->pi_epx_mask[ii] == 0)  s_buf = "_";
						if (pc_donor_candidate->pi_epx_mask[ii] < 0)  s_buf = "*";
						s_line += s_buf;
					}//for (int ii = 0; ii < i_templ_length; ii++)
					fprintf(pf_test, "%s\n", s_line);
					fprintf(pf_test, "%s\n", pcResult->sToStr());

					fclose(pf_test);
					::Tools::vShow(-8);//*/
				}//else  if (pc_donor_candidate->bEpxDonateByMask(this, pcResult) == true)
			}//if (pc_donor_candidate->bEpxMaskCanICross() == true)
		}//if (v_available_positions.size() > 0)
	}//for (int i_ind = 0; i_ind < pvPop->size(); i_ind++)	


	pcResult->vCopyFrom(this);

	CString  s_epx_report;
	s_epx_report.Format("epx equal: %d    epx worse: %d", i_epx_donate_result_equal, i_epx_donate_result_worse);
	//pc_parent->pcGetLog()->vPrintLine(s_epx_report, true);

	return(0);
}//bool  CDarkGrayGAIndividual_MO::bMixing_ePX(vector<CDarkGrayGAIndividual_MO *> *pvPop, CDarkGrayGAIndividual_MO  *pcDest)



int  CDarkGrayGAIndividual_MO::iEpxDonateByMask(CDarkGrayGAIndividual_MO *pcReceiver, CDarkGrayGAIndividual_MO *pcResult)
{
	double  d_fitness_start, d_fitness_end;


	d_fitness_start = pcReceiver->dComputeFitness();

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if ((pi_epx_mask[ii] == -1) || (pi_epx_mask[ii] == 0))
			pcResult->pc_genotype->piGetBits()[ii] = pcReceiver->pc_genotype->piGetBits()[ii];
		else
			pcResult->pc_genotype->piGetBits()[ii] = pc_genotype->piGetBits()[ii];
	}//for (int ii = 0; ii < i_templ_length; ii++)

	pcResult->b_fitness_actual = false;
	d_fitness_end = pcResult->dComputeFitness();

	if (d_fitness_start < d_fitness_end)  return(1);



	bool  b_return_slide = false;
	double  d_fitness_slide = -1;
	if (d_fitness_start == d_fitness_end)
	{
		b_return_slide = true;
		d_fitness_slide = d_fitness_end;
	}//if (d_fitness_start == d_fitness_end)



	//uniform crossover
	bool  b_uniform_crossover = false;
	if (b_uniform_crossover == true)
	{
		int  *pi_modified_map, *pi_dummy;

		pc_parent->vGetGenotypeBufferTools(&pi_modified_map, &pi_dummy);
		for (int ii = 0; ii < i_templ_length; ii++)
			pi_modified_map[ii] = 0;

		int  i_original_epx_mask_positions_exchanged = i_epx_mask_positions_exchanged;

		i_epx_mask_positions_exchanged = 0;
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if ((pi_epx_mask[ii] == -1) || (pi_epx_mask[ii] == 0))
				pcResult->pc_genotype->piGetBits()[ii] = pcReceiver->pc_genotype->piGetBits()[ii];
			else
			{
				if (::RandUtils::dRandNumber(0, 1) < 0.5)
				{
					pcResult->pc_genotype->piGetBits()[ii] = pc_genotype->piGetBits()[ii];
					pi_modified_map[ii] = 1;
					i_epx_mask_positions_exchanged++;
				}//if  (::RandUtils::dRandNumber(0,1) < 0.5)
				else
					pcResult->pc_genotype->piGetBits()[ii] = pcReceiver->pc_genotype->piGetBits()[ii];
			}//else  if ((pi_epx_mask[ii] == -1) || (pi_epx_mask[ii] == 0))
		}//for (int ii = 0; ii < i_templ_length; ii++)


		pcResult->b_fitness_actual = false;
		d_fitness_end = pcResult->dComputeFitnessOptimize(NULL, true, pi_modified_map);

		if (d_fitness_start < d_fitness_end)
		{
			//CString  s_buf;
			//s_buf.Format("UNIFORM+OPT: %.8lf -> %.8lf", d_fitness_start, d_fitness_end);
			//pc_parent->pcGetLog()->vPrintLine(s_buf, true);

			return(2);
		}//if (d_fitness_start < d_fitness_end)

		if (d_fitness_start == d_fitness_end)  return(0);

		i_epx_mask_positions_exchanged = i_original_epx_mask_positions_exchanged;
	}//if (b_uniform_crossover == true)



	if (b_return_slide == true)
	{
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if ((pi_epx_mask[ii] == -1) || (pi_epx_mask[ii] == 0))
				pcResult->pc_genotype->piGetBits()[ii] = pcReceiver->pc_genotype->piGetBits()[ii];
			else
				pcResult->pc_genotype->piGetBits()[ii] = pc_genotype->piGetBits()[ii];
		}//for (int ii = 0; ii < i_templ_length; ii++)

		pcResult->d_fitnes_buf = d_fitness_slide;
		pcResult->b_fitness_actual = true;

		return(0);
	}//if (b_return_slide == true)

	return(-1);
}//int  CDarkGrayGAIndividual_MO::iEpxDonateByMask(CDarkGrayGAIndividual_MO *pcReceiver, CDarkGrayGAIndividual_MO *pcResult)




void  CDarkGrayGAIndividual_MO::v_epx_mask_extend_at_level(int  iLevelToExplode, CDarkGrayGAIndividual_MO *pcReceiver)
{
	bool  b_extended = false;

	for (int i_gene_this = 0; i_gene_this < i_templ_length; i_gene_this++)
	{
		if (pi_epx_mask[i_gene_this] == iLevelToExplode)
		{
			for (int i_gene_other = 0; i_gene_other < i_templ_length; i_gene_other++)
			{
				if (pi_epx_mask[i_gene_other] == -1)
				{
					if (pc_parent->pcGetDSM()->piGetDSM()[i_gene_this][i_gene_other] > 0)
					{
						pi_epx_mask[i_gene_other] = iLevelToExplode + 1;
						b_extended = true;
					}//if (pc_parent->pcGetDSM()->piGetDSM()[i_gene_this][i_gene_other] > 0)
				}//if  (pi_epx_mask[i_gene_other]  == -1)

			}//for (int i_gene_other = 0; i_gene_other < i_templ_length; i_gene_other++)
		}//if (pi_epx_mask[i_gene] == iLevelToExplode)			
	}//for (int i_gene_this = 0; i_gene_this < i_templ_length; i_gene_this++)

	if (b_extended == true)  v_epx_mask_extend_at_level(iLevelToExplode + 1, pcReceiver);
}//bool  CDarkGrayGAIndividual_MO::b_epx_mask_extend_at_level(int  iLevelToExplode, CDarkGrayGAIndividual_MO *pcReceiver)



void  CDarkGrayGAIndividual_MO::vEpxMaskCompute(int  iGeneToCross, CDarkGrayGAIndividual_MO *pcReceiver)
{
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pc_genotype->piGetBits()[ii] == pcReceiver->pc_genotype->piGetBits()[ii])
			pi_epx_mask[ii] = 0;
		else
			pi_epx_mask[ii] = -1;
	}//for (int ii = 0; ii < i_templ_length; ii++)

	b_epx_mask_can_cross = false;

	if (pc_genotype->piGetBits()[iGeneToCross] != pcReceiver->pc_genotype->piGetBits()[iGeneToCross])
		pi_epx_mask[iGeneToCross] = 1;
	else
		return;

	v_epx_mask_extend_at_level(1, pcReceiver);

	i_epx_mask_positions_exchanged = 0;
	i_epx_mask_positions_remain_differing = 0;
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		//we have at least one different (iGeneToCross differs), so we need to have at least one that is not marked by the crossing mark (otherwise, we will exchange all differeing genes)
		if (pi_epx_mask[ii] == -1)
		{
			//b_epx_mask_can_cross = true;
			i_epx_mask_positions_remain_differing++;
			//return;
		}//if (pi_epx_mask[ii] == -1)

		if (pi_epx_mask[ii] > 0)   i_epx_mask_positions_exchanged++;
	}//for (int ii = 0; ii < i_templ_length; ii++)

	if  ( (i_epx_mask_positions_remain_differing > 0)&&(i_epx_mask_positions_exchanged > 0) )  b_epx_mask_can_cross = true;
}//void  CDarkGrayGAIndividual_MO::vEpxMaskCompute(int  iGeneToCross, CDarkGrayGAIndividual_MO *pcDonor)



bool  CDarkGrayGAIndividual_MO::bEpxMaskCanICross()
{
	return(b_epx_mask_can_cross);
}//bool  CDarkGrayGAIndividual_MO::bEpxMaskCanICross()


CString  CDarkGrayGAIndividual_MO::sEpxToStr()
{
	CString  s_res, s_buf;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		s_buf.Format("%d", pi_epx_mask[ii]);
		if (pi_epx_mask[ii] == 0)  s_buf = "_";
		if (pi_epx_mask[ii] < 0)  s_buf = "*";
		s_res += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)


	s_buf.Format("   Exchnage: %d  Differing:%d", i_epx_mask_positions_exchanged, i_epx_mask_positions_remain_differing);
	s_res += s_buf;

	return(s_res);
}//CString  CDarkGrayGAIndividual_MO::sEpxToStr()


CString  CDarkGrayGAIndividual_MO::sToStr()
{
	CString  s_res, s_buf;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (ii % 10 == 0)  s_res += " ";
		s_buf.Format("%d", pc_genotype->piGetBits()[ii]);
		s_res += s_buf;
	}//for (int ii = 0; ii < i_templ_length; ii++)

	s_buf.Format("  %.8lf (%.8lf/%.8lf)", dComputeFitness(), v_fitness.at(0), v_fitness.at(1));
	s_res += s_buf;

	return(s_res);
}//CString  CDarkGrayGAIndividual_MO::sToStr()


bool  CDarkGrayGAIndividual_MO::bIsTheSame(CDarkGrayGAIndividual_MO  *pcOther)
{
	if ((pc_genotype == NULL))  return(false);
	if ((pcOther->pc_genotype == NULL))  return(false);

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pc_genotype->piGetBits()[ii] != pcOther->pc_genotype->piGetBits()[ii])  return(false);
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(true);
}//bool  CDarkGrayGAIndividual_MO::bIsTheSame(CDarkGrayGAIndividual_MO  *pcOther)


double  CDarkGrayGAIndividual_MO::dGetSimilarity(CDarkGrayGAIndividual_MO  *pcOther, int  *piGenesTheSame)
{
	int  i_genes_the_same;
	if (piGenesTheSame == NULL)  piGenesTheSame = &i_genes_the_same;
	*piGenesTheSame = 0;

	if ((pc_genotype == NULL))  return(0);
	if ((pcOther->pc_genotype == NULL))  return(0);


	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pc_genotype->piGetBits()[ii] == pcOther->pc_genotype->piGetBits()[ii])  (*piGenesTheSame)++;
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	double  d_res;
	d_res = *piGenesTheSame;
	d_res = d_res / i_templ_length;

	return(d_res);
}//double  CDarkGrayGAIndividual_MO::dGetSimilarity(CDarkGrayGAIndividual_MO  *pcOther, int  *piGenesTheSame)




void  CDarkGrayGAIndividual_MO::vRandomizeGenotype()
{
	d_fitnes_buf = -1;
	b_fitness_actual = false;

	for (int ii = 0; ii < i_templ_length; ii++)
		pc_genotype->piGetBits()[ii] = RandUtils::iRandNumber(0, 1);

};//void  CDarkGrayGAIndividual_MO::vRandomizeGenotype()


double  CDarkGrayGAIndividual_MO::dComputeFitness()
{
	if (b_fitness_actual == true)  return(d_fitnes_buf);

	//pc_genotype = new CBinaryCoding(i_templ_length);
	//for (int ii = 0; ii < i_templ_length; ii++)
		//pc_genotype->piGetBits()[ii] = pi_genotype[ii];

	if (b_fitness_actual == false)
	{
		b_rated = false;
		vRate();
	}//if (b_fitness_actual == false)

	
	d_fitnes_buf = 0;
	for (int ii = 0; ii < pc_problem->pvGetMeasures()->size(); ii++)
		d_fitnes_buf += pc_problem->pvGetMeasures()->at(ii)->dWeight * v_fitness.at(ii);

	b_fitness_actual = true;
	d_fitnes_buf = ::Tools::dRound(d_fitnes_buf, 5);

	return(d_fitnes_buf);
};//double  CDarkGrayGAIndividual_MO::dComputeFitness()


void  CDarkGrayGAIndividual_MO::vRecalculateForNewWeights()
{
	if (b_fitness_actual == false)  return;

	d_fitnes_buf = 0;
	for (int ii = 0; ii < pc_problem->pvGetMeasures()->size(); ii++)
		d_fitnes_buf += pc_problem->pvGetMeasures()->at(ii)->dWeight * v_fitness.at(ii);

	d_fitnes_buf = ::Tools::dRound(d_fitnes_buf, 5);
}//double  CDarkGrayGAIndividual_MO::vRecalculateForNewWeights()


double  CDarkGrayGAIndividual_MO::dComputeFitnessDouble()
{
	if (b_fitness_actual == true)  return(d_fitnes_buf);

	d_fitnes_buf = pc_parent->dComputeFitnessDouble(pc_genotype->piGetBits());
	b_fitness_actual = true;

	return(d_fitnes_buf);
};//double  CDarkGrayGAIndividual_MO::dComputeFitness()



void  CDarkGrayGAIndividual_MO::v_create_opt_order(vector<int>  *pvOrder)
{
	vector<int>  v_temp;

	pvOrder->clear();

	for (int ii = 0; ii < i_templ_length; ii++)
		v_temp.push_back(ii);

	int  i_pos;
	while (v_temp.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_temp.size() - 1);
		pvOrder->push_back(v_temp.at(i_pos));
		v_temp.erase(v_temp.begin() + i_pos);
	}//while  (v_temp.size() > 0)
}//void  CDarkGrayGAIndividual_MO::v_create_opt_order(vector<int>  *pvOrder)




double  CDarkGrayGAIndividual_MO::d_optimize_single_gene(int  iOptGene)
{
	double  d_fitness_current, d_fit_new;
	vector<double>  v_fit_buf;
	d_fitness_current = dComputeFitness();
	v_fit_buf = v_fitness;

	if (pc_genotype->piGetBits()[iOptGene] == 1)
		pc_genotype->piGetBits()[iOptGene] = 0;
	else
		pc_genotype->piGetBits()[iOptGene] = 1;

	b_fitness_actual = false;
	d_fit_new = dComputeFitness();

	if (d_fit_new > d_fitness_current)  return(d_fit_new);


	//flip back...
	if (pc_genotype->piGetBits()[iOptGene] == 1)
		pc_genotype->piGetBits()[iOptGene] = 0;
	else
		pc_genotype->piGetBits()[iOptGene] = 1;
	b_fitness_actual = true;
	this->d_fitnes_buf = d_fitness_current;
	v_fitness = v_fit_buf;

	return(this->d_fitnes_buf);
}//double  CDarkGrayGAIndividual_MO::d_optimize_single_gene(int  iOptGene)



double  CDarkGrayGAIndividual_MO::dComputeFitnessOptimize(vector<int>  *pvOrder /*= NULL*/, bool  bDarkGray /*= false*/, int  *piDarkGrayModifiedGenes /*= NULL*/)
{
	
	CString  s_buf;

	if (pvOrder == NULL)  pvOrder = &v_opt_order;
	if (pvOrder->size() != i_templ_length)  v_create_opt_order(pvOrder);

	
		

	if (pc_parent == NULL)
	{
		::MessageBox(NULL, "if (pc_parent == NULL)    double  CDarkGrayGAIndividual_MO::dComputeFitnessOptimizeDarkGray(vector<int>  *pvOrder = NULL)", "if (pc_parent == NULL)  double  CDarkGrayGAIndividual_MO::dComputeFitnessOptimizeDarkGray(vector<int>  *pvOrder = NULL)", MB_OK);
		return(-1);
	}//if (pc_parent == NULL)

	int  *pi_genes_to_check_current, *pi_genes_changed;

	
	if (bDarkGray == true)
	{
		pc_parent->vGetGenotypeBufferTools(&pi_genes_to_check_current, &pi_genes_changed);

		if (piDarkGrayModifiedGenes != NULL)
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_changed[ii] = piDarkGrayModifiedGenes[ii];
		}//if (piDarkGrayModifiedGenes != NULL)
		else
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_changed[ii] = 1;
		}//else  if (piDarkGrayModifiedGenes != NULL)
	}//if (bDarkGray == true)
	else
	{
		pi_genes_to_check_current = NULL;
		pi_genes_changed = NULL;
	}//else  if (bDarkGray == true)

	
	int  i_opt_gene;
	int  i_orig_gene_val;
	bool  b_changed;

	b_changed = true;

	//::Tools::vShow("IN");


	bool  b_gene_consider;
	int  i_opt_counter = 0;
	while (b_changed == true)
	{
		//double  d_start, d_end;
		//d_start = dComputeFitness();
		//int i_ffe_start, i_ffe_end;
		//i_ffe_start = pc_problem->pcGetEvaluation()->iGetFFE();



		i_opt_counter++;
		b_changed = false;

		if (bDarkGray == true)
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_to_check_current[ii] = 0;

			for (int ii = 0; ii < i_templ_length; ii++)
			{
				if  (pi_genes_changed[ii] == 1)  pc_parent->pcGetDSM()->vDarkGrayMapDependentGenes(ii, pi_genes_to_check_current);
			}//for (int ii = 0; ii < i_templ_length; ii++)

			for (int ii = 0; ii < i_templ_length; ii++)
				pi_genes_changed[ii] = 0;
		}//if (bDarkGray == true)

		
		for (int ii = 0; ii < pvOrder->size(); ii++)
		{
			i_opt_gene = pvOrder->at(ii);

			b_gene_consider = false;
			if (bDarkGray == true)
			{
				if  (pi_genes_to_check_current[ii] == 1)  b_gene_consider = true;
			}//if (bDarkGray == true)
			else
				b_gene_consider = true;


			if (b_gene_consider == true)
			{
				i_orig_gene_val = pc_genotype->piGetBits()[i_opt_gene];
				d_optimize_single_gene(i_opt_gene);

				if (i_orig_gene_val != pc_genotype->piGetBits()[i_opt_gene])
				{
					//if  (b_changed == false)  ::Tools::vShow("b_changed = true;");
					b_changed = true;
					if  (pi_genes_changed  != NULL)  pi_genes_changed[i_opt_gene] = 1;
				}//if (i_orig_gene_val != pi_genotype[i_opt_gene])
			}//if  (b_gene_consider == true)
		}//for  (int  i_opt_traj = 0; i_opt_traj < i_number_of_pairs; i_opt_traj++)


		//d_end = dComputeFitness();
		//s_buf.Format("%.8lf -> %.8lf", d_start, d_end);
		//::Tools::vShow(s_buf);

		/*i_ffe_end = pc_problem->pcGetEvaluation()->iGetFFE();
		s_buf.Format("%d\n%d\n%d\n", i_ffe_start, i_ffe_end, i_ffe_end - i_ffe_start);

		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", s_buf);
		::Tools::vReportInFile("zzzzz_ind_opt_darkGr.txt", sToStr());*/


	}//while (b_changed == true)
	
	
	return(dComputeFitness());
};//double  CDarkGrayGAIndividual_MO::dComputeFitnessOptimize()


bool  CDarkGrayGAIndividual_MO::bCheckTest()
{
	bool  b_ok;
	for (int is = 0; is < i_templ_length; is+=10)
	{
		b_ok = true;
		for (int ii = 1; (ii < 10) && (b_ok == true); ii++)
		{
			if (pc_genotype->piGetBits()[is + ii - 1] != pc_genotype->piGetBits()[is + ii])  b_ok = false;
		}//for (int ii = 1; (ii < 10) && (b_ok == true); ii++)
		if (b_ok == true)  return(true);
	}//for (int ii = 0; ii < i_templ_length; ii++)

	return(false);
}//bool  CDarkGrayGAIndividual_MO::bCheckTest()


CMultiIndividual  *CDarkGrayGAIndividual_MO::pcClone()
{
	CDarkGrayGAIndividual_MO  *pc_clone;
	
	pc_clone = new CDarkGrayGAIndividual_MO(i_templ_length, pc_problem, pc_parent);
	pc_clone->vCopyFrom(this);

	return(pc_clone);
};//CMultiIndividual  *CDarkGrayGAIndividual_MO::pcClone()



