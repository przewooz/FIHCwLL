#pragma once

#include <cmath>
#include <iostream> 
#include <vector>
using namespace std;

#include "lkGomea_Individual.h"
#include "lkGomea_Config.h"
#include "lkGomea_shared.h"
#include "lkGomea_problems.h"
#include "lkGomea_FOS.h"

class C_lkGomea_PopulationGeneral
{
public:
	C_lkGomea_Config *config;
	C_lkGomea_Problem *problemInstance;
	C_lkGomea_sharedInformation *sharedInformationPointer;
	size_t populationIndex;
	size_t populationSize;

	vector<C_lkGomea_Individual*> population;
	vector<C_lkGomea_Individual*> offspringPopulation;
	vector<int> noImprovementStretches;

	C_lkGomea_FOS *populationFOS;
	bool terminated;
	double averageFitness;
	size_t numberOfGenerations;
	C_lkGomea_FOS *FOSInstance = NULL;
	vector<vector<double> > matrix;

	C_lkGomea_PopulationGeneral(C_lkGomea_Config *config_, C_lkGomea_Problem *problemInstance_, C_lkGomea_sharedInformation *sharedInformationPointer_, size_t populationIndex_, size_t populationSize_);
	virtual ~C_lkGomea_PopulationGeneral(){};

	void tournamentSelection(int k, vector<C_lkGomea_Individual*> &population, vector<C_lkGomea_Individual*> &offspringPopulation);
	bool b_hillClimberSingle(C_lkGomea_Individual *solution);
	bool b_hillClimberMultiple(C_lkGomea_Individual *solution);

	void calculateAverageFitness();	
	void copyOffspringToPopulation();
	bool b_evaluateSolution(C_lkGomea_Individual *solution);
	bool GOM(size_t offspringIndex, C_lkGomea_Individual *backup);
	void findNeighbors(vector<vector< int> > &neighbors);
	bool conditionalGOM(size_t offspringIndex, C_lkGomea_Individual *backup, vector<vector<int> > &neighbors);
	bool FI(size_t offspringIndex, C_lkGomea_Individual *backup,  bool  *pbTimeLimitOK);
	bool conditionalFI(size_t offspringIndex, C_lkGomea_Individual *backup, vector<vector<int> > &neighbors, bool  *pbTimeLimitOK);
	void updateElitistAndCheckVTR(C_lkGomea_Individual *solution);
	bool b_checkTimeLimit_OK();
	//void checkTimeLimit();
	int compareSolutions(C_lkGomea_Individual *x, C_lkGomea_Individual*y);
};

