#include "DSMGA2PopulationSizing.h"

#include "DSMGA2.h"

CDSMGA2PopulationSizing::CDSMGA2PopulationSizing(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: CPopulationSizingOptimizer<CBinaryCoding, CBinaryCoding>(pcProblem, pcLog, iRandomSeed)
{

}//CDSMGA2PopulationSizing::CDSMGA2PopulationSizing(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

CDSMGA2PopulationSizing::CDSMGA2PopulationSizing(CDSMGA2PopulationSizing *pcOther)
	: CPopulationSizingOptimizer<CBinaryCoding, CBinaryCoding>(pcOther)
{

}//CDSMGA2PopulationSizing::CDSMGA2PopulationSizing(CDSMGA2PopulationSizing *pcOther)

CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding> * CDSMGA2PopulationSizing::pc_get_params_optimizer(istream *psSettings, CError *pcError)
{
	CDSMGA2 *pc_dsmga = new CDSMGA2(pc_problem, pc_log, i_random_seed);
	*pcError = pc_dsmga->eConfigure(psSettings);

	return pc_dsmga;
}//CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding> * CDSMGA2PopulationSizing::pc_get_params_optimizer(istream *psSettings, CError *pcError)

bool CDSMGA2PopulationSizing::b_run_proper_optimizer_iteration(CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding> *pcProperOptimizer, uint32_t iIterationNumber)
{
	CDSMGA2 *pc_proper_dsmga2 = (CDSMGA2*)pcProperOptimizer;
	return pc_proper_dsmga2->bRunIteration(iIterationNumber, pc_best_individual);
}//bool CDSMGA2PopulationSizing::b_run_proper_optimizer_iteration(CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding> *pcProperOptimizer, uint32_t iIterationNumber, time_t tStartTime)


bool CDSMGA2PopulationSizing::b_run_proper_optimizer_iteration_sep_link(CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding> *pcProperOptimizer, uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage)
{
	CDSMGA2 *pc_proper_dsmga2 = (CDSMGA2*)pcProperOptimizer;
	return pc_proper_dsmga2->bRunIterationSeparateLinkage(iIterationNumber, pcSeparateLinkage);
}//bool CDSMGA2PopulationSizing::b_run_proper_optimizer_iteration_sep_link(CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding> *pcProperOptimizer, uint32_t iIterationNumber, time_t tStartTime, CLinkageAnalyzer  *pcSeparateLinkage)



bool CDSMGA2PopulationSizing::b_run_proper_optimizer_iteration_sep_link(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage)
{
	size_t i_proper_optimizer_index = (size_t)c_population_sizing_counter.iGetLastMostSignificantChangeIndex();
	CDSMGA2 *pc_proper_optimizer = (CDSMGA2 *) v_optimizers.at(i_proper_optimizer_index);

	bool b_updated = b_run_proper_optimizer_iteration_sep_link(pc_proper_optimizer, iIterationNumber, pcSeparateLinkage);
	v_optimizers_average_fitnesses.at(i_proper_optimizer_index) = pc_proper_optimizer->dComputeAverageFitnessValue();

	return b_updated;
}//bool CDSMGA2PopulationSizing::b_run_proper_optimizer_iteration(uint32_t iIterationNumber, time_t tStartTime)





bool CDSMGA2PopulationSizing::bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage)
{
	if (pcSeparateLinkage->dGetOutsideLinkageQuality() >= 0)
	{
		if (c_population_sizing_counter.iIncrement(iGetNextPopSize()) == (uint32_t)v_optimizers.size())
		{
			v_add_new_optimizer(iIterationNumber);
		}//if (c_population_sizing_counter.iIncrement() == (uint32_t)v_ltgas.size())
	}//if (pcSeparateLinkage->dGetOutsideLinkageQuality() >= 0)

	/*if (c_population_sizing_counter.iIncrement() == (uint32_t)v_optimizers.size())
	{
		v_add_new_optimizer(iIterationNumber, tStartTime);
	}//if (c_population_sizing_counter.iIncrement() == (uint32_t)v_optimizers.size())*/


	bool b_updated = false;

	if (b_run_proper_optimizer_iteration_sep_link(iIterationNumber, pcSeparateLinkage))
	{
		b_updated = b_update_best_individual(iIterationNumber);
	}//if (b_run_optimizers_iteration(iIterationNumber, tStartTime))


	CString s_log;

	s_log.Format("iteration: %d (SeparateLinkage); time: %.2lf; number of optimizers: %d; best: %f", iIterationNumber, c_optimizer_timer.dGetTimePassed(),
		v_optimizers.size(), pc_best_individual->dGetFitnessValue());

	pc_log->vPrintLine(s_log, true);
	pc_log->vPrintEmptyLine(true);


	v_delete_optimizers();


	return b_updated;
}//bool CPopulationSizingOptimizer<TGenotype, TFenotype>::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)






void  CDSMGA2PopulationSizing::vExecuteBeforeEnd()
{
	vReportLinkage();
}//void  CLTGAOriginalPopulationSizing::vExecuteBeforeEnd()


bool CDSMGA2PopulationSizing::bReportLinkage_single_dsmga2_additive(int  iLTGA_Offset)
{
	if (pc_linkage_analyzer != NULL)
	{
		CDSMGA2  *pc_dsmga2_to_report;

		if ((iLTGA_Offset < 0) || (v_optimizers.size() <= iLTGA_Offset))  return(false);
		pc_dsmga2_to_report = (CDSMGA2 *) v_optimizers.at(iLTGA_Offset);


		vector<CLinkageAnalyzerSingleDSM  *>  *pv_dsm_set;
		pv_dsm_set = pc_linkage_analyzer->pvGetDSM_Sets();


		//fit by population
		int  i_dsm_set_for_this_ltga_offset;

		i_dsm_set_for_this_ltga_offset = pv_dsm_set->size();//we initially set it to add a next new dsm set
		for (int ii = 0; (ii < pv_dsm_set->size()) && (i_dsm_set_for_this_ltga_offset == pv_dsm_set->size()); ii++)
		{
			if (pv_dsm_set->at(ii)->iGetPopSize() == pc_dsmga2_to_report->iGetPopulationSize())  i_dsm_set_for_this_ltga_offset = ii;
		}//for (int ii = 0; (ii < pv_dsm_set->size())&&(i_dsm_set_for_this_ltga_offset == pv_dsm_set->size()); ii++)

		pc_linkage_analyzer->vSetDSMGA2_DSM(i_dsm_set_for_this_ltga_offset, pc_dsmga2_to_report->iGetPopulationSize(), pc_dsmga2_to_report->pvGetDSM(), pc_dsmga2_to_report->iGetDSM_Size());


		return(true);
	}//if (pc_linkage_analyzer != NULL)


	return(false);
}//void CDSMGA2PopulationSizing::vReportLinkage_single_Ltga_additive(int  iLTGA_Offset)


void CDSMGA2PopulationSizing::v_delete_optimizers()
{
	unordered_set<size_t> s_optimizers_to_delete_indexes;
	s_optimizers_to_delete_indexes.reserve(v_optimizers.size());

	v_get_optimizers_to_delete(&s_optimizers_to_delete_indexes);

	if (!s_optimizers_to_delete_indexes.empty())
	{
		for (size_t i = v_optimizers.size(); i > 0; i--)
		{
			if (s_optimizers_to_delete_indexes.count(i - 1) > 0)
			{
				bReportLinkage_single_dsmga2_additive(i - 1);

				delete v_optimizers.at(i - 1);
				v_optimizers.erase(v_optimizers.begin() + i - 1);
				v_optimizers_average_fitnesses.erase(v_optimizers_average_fitnesses.begin() + i - 1);
			}//if (s_optimizers_to_delete_indexes.count(i - 1) > 0)
		}//for (size_t i = v_ltgas.size(); i > 0; i--)

		c_population_sizing_counter.vReset();
	}//if (!s_optimizers_to_delete_indexes.empty())
}//void CPopulationSizingOptimizer<TGenotype, TFenotype>::v_delete_optimizers()


void CDSMGA2PopulationSizing::vReportLinkage()
{
	if (pc_linkage_analyzer != NULL)
	{
		double  d_perc;


		for (int ii = 0; ii < v_optimizers.size(); ii++)
		{
			bReportLinkage_single_dsmga2_additive(ii);
		}//for (int ii = 0; ii < pops.size(); ii++)

		pc_linkage_analyzer->vCreatePairsReportAndFlushDependentPairs();


		CString  s_buf, s_report;
		s_buf.Format("pops: %d  ", v_optimizers.size());
		s_report = pc_linkage_analyzer->sGeneralCurrentReport();


		pc_log->vPrintLine("LINKAGE REPORT:" + s_buf + s_report, true);
	}//if (pc_linkage_analyzer != NULL)
}//void CDSMGA2PopulationSizing::vReportLinkage()