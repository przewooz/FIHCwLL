#ifndef CCONDITIONAL_GA_OPTIMIZER_H
#define CCONDITIONAL_GA_OPTIMIZER_H


#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "CommandParam.h"
#include "Error.h"
#include "Log.h"
#include "MathUtils.h"
#include "Optimizer.h"
#include "Problem.h"
#include "Individual.h"
#include  "util\timer.h"
#include  "util\tools.h"
#include "PopulationSizingOptimizer.h"



//#include <istream>
//#include <algorithm>





namespace nConditionalGA
{
	class  CConditionalGASinglePop;
	class  CConditionalGAIndividual;
	class  CConditionalGA_DSM;
	class  CConditionalGA_Mask;
	class  CConditionalGA_ProbingData;

	#define  s_OPTIMIZER_CONDITIONAL_GA_POP_SCHEME			"popScheme(0-P3like; 1-GA-like)"
	#define  s_OPTIMIZER_CONDITIONAL_GA_DONOR_IMPROVEMENT  "DonorImprovement"
	#define  s_OPTIMIZER_CONDITIONAL_GA_PERFECT_LINKAGE	"PerfectLinkage"
	#define  s_OPTIMIZER_CONDITIONAL_GA_CLUSTERS_TYPE	"clustersType (0-random; 1-sll; 2-conditional)"
	#define  s_OPTIMIZER_CONDITIONAL_GA_GLOBAL_BEST_IMPROVEMENT	"GlobalBestImprovement"
	#define  s_OPTIMIZER_CONDITIONAL_GA_GLOBAL_BEST_LIMIT	"GlobalBestLimit (0=unlimited bestPop size)"
	#define  s_OPTIMIZER_CONDITIONAL_GA_GLOBAL_BEST_POP_RUN	"GlobalBestPopRun"
	#define  s_OPTIMIZER_CONDITIONAL_GA_UNIFORM_CROSSOVER_FOR_SLIDE	"UniformCrossoverForSlide"

	#define   i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_RANDOM	0
	#define   i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_SLL		1
	#define   i_CONDITIONAL_GA_LINKAGE_MASKS_TYPE_CONDITIONAL_SLL_DLED	2


	class CConditionalGA : public CBinaryOptimizer
	{
		friend class CConditionalGAIndividual;
		friend class CConditionalGA_DSM;
		friend class CConditionalGA_ProbingData;
	public:
		static uint32_t iERROR_PARENT_CConditionalGA;
		static uint32_t iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0;


		CConditionalGA(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
		CConditionalGA(CConditionalGA *pcOther);
		~CConditionalGA();

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CConditionalGA(this); };
		virtual bool bRunIteration(uint32_t iIterationNumber) override;
		virtual bool bRunIteration_P3(uint32_t iIterationNumber);
		virtual bool bRunIteration_sGA(uint32_t iIterationNumber);

		virtual CError eConfigure(istream *psSettings) override;
		virtual void vInitialize() override;


		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo();
		CString  sLinkageSummaryReport();

		double dComputeFitness(int32_t *piBits);


		CConditionalGAIndividual  *pcGetBest();
		void  vInsertToBestPop_FitnessLevels(CConditionalGAIndividual  *pcNewInd);
		void  vInsertToBestPop_FitnessLevels(CConditionalGASinglePop  *pcSinglePop);

		void  vInsertToBestPop_Simple(CConditionalGAIndividual  *pcNewInd);


		CConditionalGA_DSM  *pcGetDSM() { return(pc_dsm); };


		int  iP3GetPyramidIndNumber();
		int  iGetPopLevel(CConditionalGASinglePop  *pcPopToCheck);


		void  vGetClusters(vector<CConditionalGAIndividual *> *pvPop, CConditionalGAIndividual  *pcIndToOpt, vector<CConditionalGA_Mask *> *pvMasks, bool  bAdd_Sll_Dled);

	private:
		bool  b_p3_add_to_level(int iLevel, CConditionalGAIndividual*pcIndToAdd);
		bool b_p3_the_same_exists(CConditionalGAIndividual  *pcIndToAdd);
		void  v_global_best_improvement();
		void  v_global_best_pop_run();

		void  v_get_clusters_random(vector<CConditionalGA_Mask *> *pvMasks);
		void  v_get_clusters_sll(vector<CConditionalGA_Mask *> *pvMasks, vector<CConditionalGAIndividual *> *pvPop, bool  bAdd_Sll_Dled);

		CTimeCounter  c_time_counter;
		double  d_time_last_time;

		int  i_sett_pop_scheme;
		int  i_sett_donor_improvement;
		int  i_sett_perfect_linkage;
		int  i_sett_global_best_improvement;
		int  i_sett_global_number_limit;
		int  i_sett_global_best_pop_run;
		int  i_sett_uniform_crossover_for_slide;

		int  i_sett_clusters; //0-random; 1-sll; 2-conditional sll

		int  i_next_pop_size;
		vector<CConditionalGASinglePop *> v_pyramid;
		vector<CConditionalGASinglePop *> v_pop_running, v_pops_obsolete;
		vector<CConditionalGAIndividual  *> v_dled_inds;

		CConditionalGASinglePop  *pc_base_pop;
		CConditionalGASinglePop  *pc_best_pop;
		
		CConditionalGAIndividual  *pc_tool_ind;

		CLinkageAnalyzer  *pc_sll_computation;//to compute SLL
		CLinkageInformationPack  *pc_linkage_pack;
		CBinaryCoding *pc_evaluation_individual;

		CConditionalGA_DSM  *pc_dsm;
		int  i_pop_size;
		int  i_templ_length;
	};//class CConditionalGA : public CBinaryOptimizer	*/



	class CConditionalGASinglePop : public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>
	{
		friend class CConditionalGA;
		friend class CConditionalGAIndividual;
	public:
		static uint32_t iERROR_PARENT_CConditionalGASinglePop;
		static uint32_t iERROR_CODE_DARK_GRAY_GA_GENOTYPE_LEN_BELOW_0;


		CConditionalGASinglePop(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed, CConditionalGA  *pcParent);
		CConditionalGASinglePop(CConditionalGASinglePop *pcOther);
		~CConditionalGASinglePop();

		void  vCopyFrom(CConditionalGASinglePop *pcOther);

		COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() override;
		virtual bool bRunIteration(uint32_t iIterationNumber) override;
		bool bRunIteration_sGA(uint32_t iIterationNumber);

		bool  bDonateToIndividual(CConditionalGAIndividual  *pcReceiver);
		int  iDonateToIndividual_PxByLen(CConditionalGAIndividual  *pcReceiver, CConditionalGA_ProbingData  *pcProbData, vector<CConditionalGA_Mask *> *pvLastSuccessfulMasks = NULL, bool bPrint = true);

		virtual CError eConfigure(istream *psSettings) override;
		virtual void vInitialize() override;

		bool bIsSteadyState() override;
		double dComputeAverageFitnessValue() override;

		uint32_t iGetPopulationSize() override { return i_pop_size; }
		void vSetPopulationSize(uint32_t iPopulationSize) override { i_pop_size = iPopulationSize; };

		void  vGetGenotypeBufferTools(int  **piTool_0, int  **piTool_1);


		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo();

		double dComputeFitness(int32_t *piBits);
		double dComputeFitnessDouble(int32_t *piBits);


		CConditionalGAIndividual  *pcGetBest() { return(pc_best); };

		CConditionalGA_DSM  *pcGetDSM() { return(pc_dsm); };
		void  vGetClusters(vector<CConditionalGAIndividual *> *pvPop, CConditionalGAIndividual  *pcIndToOpt, vector<CConditionalGA_Mask *> *pvMasks, bool  bAdd_Sll_Dled);


		bool  bRemoveIndividual(CConditionalGAIndividual *pcIndToRem);
		void  vSavePopTest();


	private:
		
		double d_evaluate(int32_t *piBits);
		double d_evaluate_double(int32_t *piBits);
		CConditionalGAIndividual* pc_get_random_individual();

		CConditionalGA  *pc_parent;

		bool  b_steady_state;
		CTimeCounter  c_time_counter;
		double  d_time_last_time;
		CIndividual<CBinaryCoding, CBinaryCoding> *pc_evaluation_individual;
		CConditionalGAIndividual *pc_individual_buffer;
		int  *pi_genotope_buffer_tool_0, *pi_genotope_buffer_tool_1;

		int  i_slide_number;
		int  i_uniform_donations;

		vector<CConditionalGAIndividual *> v_pop, v_pop_copy;

		
		CConditionalGAIndividual  *pc_best;

		CConditionalGA_DSM  *pc_dsm;
		int  i_pop_size;
		int  i_templ_length;
	};//class CConditionalGASinglePop : public CBinaryOptimizer	




	class  CConditionalGA_DSM
	{
	public:
		CConditionalGA_DSM(CConditionalGA  *pcParent);
		~CConditionalGA_DSM();


		bool  bSetSize(int  iProbSize);

		CString  sLinkageSummaryReport();
		bool  bGetTrueLinkage(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem);
		void  vDarkGrayMapDependentGenes(int  iGeneOffset, int  *piMask);

		void  vGetDependentGenes(int  iSourceGene, vector<int>  *pvDependentGenes, int iHopNumber);
		void  vGetCommonDirectlyDependentGenes(int  iGeneFirst, int  iGeneSecond, vector<int>  *pvCommonDirectlyDependentGenes);
		void  vUpdateDSM();

		bool  bDLED_forInd(int  iGeneForDecomp, CConditionalGAIndividual *pcSource);
		bool  bDLED_base_forInd(int  iGeneForDecomp, CConditionalGAIndividual *pcSource);
		bool  bDLED(int  iGeneForDecomp, CConditionalGAIndividual *pcSource);
		bool  bDLED_base(int  iGeneForDecomp, CConditionalGAIndividual *pcSource);

		bool  bGetProbingData(CConditionalGAIndividual *pcSource, CConditionalGA_ProbingData *pcProbingData);

		int  **piGetDSM() { return(pi_dsm); }

		bool  bSave(CString  sDest);
		bool  bSave(FILE  *pfDest);

	private:
		void  v_extract_dled_for_gene_pair(int  iGeneContext, int iGeneBlock, int  *piDledExtractionMask, CConditionalGAIndividual  *pcExtractionIndividual, int *piNewPairsDetected);
		bool  b_check_if_true_linkage(int iGeneBlock, int  iGeneContext);
		int  i_mark_dependent_genes(int  *piHopTool, int iHop);
		//int  i_flip_gene(int i_baseVal);

		int  **pi_dsm;
		int  *pi_gene_dep_numbers;
		CConditionalGAIndividual ***pc_source_inds;
		int  i_prob_size;
		CConditionalGAIndividual  *pc_individual_tool;

		vector<int>  v_dled_genes_to_run;
		int  *pi_hop_tool;

		int  i_cost_ffe;
		double  d_cost_time;

		CConditionalGA  *pc_parent;
	
	};//class  CDargGA_DSM


	class  CConditionalGA_ProbingData
	{
	public:
		CConditionalGA_ProbingData(CConditionalGA *pcParent, CConditionalGAIndividual *pcToolInd) { pc_parent = pcParent; i_probing_gene_0 = -1; i_probing_gene_1 = -1; pc_probing_ind = NULL; pc_tool_ind = pcToolInd; };

		bool  bCheckDependencyFor(CConditionalGAIndividual *pcIndToTest);
		bool  bEqual(CConditionalGA_ProbingData  *pcOther);

		int  i_probing_gene_0;
		int  i_probing_gene_1;
		CConditionalGAIndividual  *pc_probing_ind;

	private:
		CConditionalGAIndividual *pc_tool_ind;
		CConditionalGA *pc_parent;
	};//class  CConditionalGA_ProbingData



	class  CConditionalGA_DependentGenesPair
	{
	public:
		CConditionalGA_DependentGenesPair(int  iGene0, int iGene1) {i_probing_gene_0 = iGene0; i_probing_gene_1 = iGene1;};
		bool  bEqual(int  iGene0, int iGene1);

		int  i_probing_gene_0;
		int  i_probing_gene_1;
	};//class  CConditionalGA_DependentGenesPair
	


	class CConditionalGA_Mask
	{
	public:
		CConditionalGA_Mask(int  iProblemSize) { i_problem_size = iProblemSize; };

		void  vClear() { v_mask.clear(); }
		void  vReport(CString  sDest);
		void  vReport(FILE  *pfDest);
		void  vReportShort(FILE  *pfDest);

		bool  bFitsBlock(vector<int>  *pvBlock);

		CString  sToStr();

		vector<int> v_mask;
		int  i_problem_size;
	};//class CDarkGrayGAPxMask





	class  CConditionalGAIndividual
	{
		friend class CConditionalGA;
		friend class CConditionalGASinglePop;
		friend class CConditionalGAPxMask;
		friend class CConditionalGA_DSM;
	public:
		static int  iFlipGene(int i_baseVal);

		CConditionalGAIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CConditionalGASinglePop *pcParent);
		CConditionalGAIndividual(CConditionalGAIndividual &pcOther);
		~CConditionalGAIndividual();

		bool  bIsTheSame(CConditionalGAIndividual  *pcOther);
		double  dGetSimilarity(CConditionalGAIndividual  *pcOther, int  *piGenesTheSame);
		void  vRandomizeGenotype();
		int*  piGetGenotype() { return(pi_genotype); }

		int  iGetPopLevel();


		int   iConditionalMixing(vector<CConditionalGAIndividual *> *pvPop, CConditionalGA_ProbingData  *pcProbData, CConditionalGAIndividual  *pcResult, vector<CConditionalGA_Mask *> *pvLastSuccessfulMasks);
		int   iConditionalMixing_ByMask(CConditionalGAIndividual  *pcDonor, CConditionalGA_Mask *pcMask, CConditionalGAIndividual  *pcResult);

		void  vCopyFrom(CConditionalGAIndividual  *pcNewInd);
		bool  bTheSameFragment(CConditionalGAIndividual  *pcIndOther, vector<int>  *pvMask);

		double  dComputeFitness();
		double  dComputeFitnessDouble();
		double  dComputeFitnessOptimize(vector<int>  *pvOrder = NULL, bool  bDarkGray = false, int  *piDarkGrayModifiedGenes = NULL);


		bool  bCheckGenesDependent(int  iGeneBase, int  iGeneOther);
		bool  bProbingDependenciesConfirmed_Check(CConditionalGA_ProbingData  *pcProbingToCheck);
		bool  bProbingDependenciesConfirmed_Insert(CConditionalGA_ProbingData  *pcProbingToInsert);

		bool  bDependentPair_Insert(int  iGene0, int iGene1);
		bool  bDependentPair_Check(int  iGene0, int iGene1);
		void  vInsertDependentPairIntoDSM(int  **piDSM);
		double  dDepedentPairsMatching(int **piDSM);
		

		void  vClearOptOrder() { v_opt_order.clear(); }

		CString  sToStr();

	private:
		void  v_create_opt_order(vector<int>  *pvOrder);
		double  d_optimize_single_gene(int  iOptGene);
		void  v_clear_masks(vector<CConditionalGA_Mask *> *pvMasks);
		CString s_get_masks_quality(vector<vector<vector<int>>>  *pvDependenciesMultistruct, vector<CConditionalGA_Mask *> *pvMasks);


		vector<CConditionalGA_ProbingData>  v_probing_dependencies_confirmed;
		vector<CConditionalGA_DependentGenesPair>  v_dependent_genes;


		CConditionalGASinglePop  *pc_parent;
		int  i_templ_length;
		int  *pi_genotype;
		vector<int>  v_opt_order;

		double  d_fitnes_buf;
		bool  b_fitness_actual;

		CProblem<CBinaryCoding, CBinaryCoding > *pc_problem;
	};//class  CConditionalGAIndividual

}//namespace nDarkGrayGA

#endif//CCONDITIONAL_GA_OPTIMIZER_H
