#include "lkGomea.h"



using  namespace nLK_Gomea;



uint32_t C_lkGomea::iERROR_PARENT_C_lkGomea = CError::iADD_ERROR_PARENT("iERROR_PARENT_C_lkGomea");
uint32_t C_lkGomea::iERROR_CODE_C_lkGomea_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_C_lkGomea_GENOTYPE_LEN_BELOW_0");
uint32_t C_lkGomea::iERROR_CODE_C_lkGomea_UnknownPopulationMode = CError::iADD_ERROR("iERROR_CODE_C_lkGomea_UnknownPopulationMode");


//---------------------------------------------C_lkGomea-------------------------------------------------------
C_lkGomea::C_lkGomea(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	pc_lk_gomea_config = NULL;
	pc_cgomea_best_p3 = NULL;
	pi_bits = NULL;
};//C_lkGomea::C_lkGomea(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



C_lkGomea::C_lkGomea(C_lkGomea *pcOther) : CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "No implementatuib: C_lkGomea::C_lkGomea(C_lkGomea *pcOther) : CBinaryOptimizer(pcOther)", "MISSING", MB_OK);
}//C_lkGomea::C_lkGomea(C_lkGomea *pcOther) : CBinaryOptimizer(pcOther)


C_lkGomea::~C_lkGomea()
{
	if (pc_lk_gomea_config != NULL)  delete  pc_lk_gomea_config;
	if (pc_cgomea_best_p3 != NULL)  delete  pc_cgomea_best_p3;
	if (pi_bits != NULL)  delete  pi_bits;
}//C_lkGomea::~C_lkGomea()


void  C_lkGomea::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();


	pc_lk_gomea_config = new C_lkGomea_Config();



	pc_lk_gomea_config->donorSearch = 1;

	if  (i_population_topology == s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY_ASYMETRIC)  pc_lk_gomea_config->populationTopology = 6;//asymetric
	if (i_population_topology == s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY_SYMETRIC)  pc_lk_gomea_config->populationTopology = 7;//symetric
	pc_lk_gomea_config->multiFOS = 1;
	pc_lk_gomea_config->populationScheme = 0;
	pc_lk_gomea_config->topologyMode = -1;



	/*pc_lk_gomea_config->conditionalGOM = 1;
	pc_lk_gomea_config->populationScheme = 2;
	pc_lk_gomea_config->FOSIndex = 4;
	pc_lk_gomea_config->rng.seed(i_random_seed);
	pc_lk_gomea_config->folder = "";

	pc_lk_gomea_config->conditionalGOM = 1; //CGOM
	pc_lk_gomea_config->populationScheme = 2; //P3
	pc_lk_gomea_config->FOSIndex = 4; //Efficient Filtered LTFOS for P3 (without tournament selection)
	pc_lk_gomea_config->hillClimber = 1; //single-iteration HC
	pc_lk_gomea_config->donorSearch = 1; //turns on exhaustive donor search
	pc_lk_gomea_config->orderFOS = 0; //ascending order by element sizes
	pc_lk_gomea_config->similarityMeasure = 1; //NMI instead of MI

	pc_lk_gomea_config->useForcedImprovements = 0; //no FI
	pc_lk_gomea_config->tournamentSelection = 0; //no tournament selection, FOSIndex=4 can be used only when tournament isn't used
	pc_lk_gomea_config->MI_threshold = 0.8; //threshold value for CGOM*/
	   


	pc_lk_gomea_config->problemIndex = 18;
	pc_lk_gomea_config->numberOfVariables = i_templ_length;
	pc_lk_gomea_config->problemInstancePath = "";
	pc_lk_gomea_config->pc_external_problem_computer = pc_problem;
	pc_lk_gomea_config->pc_stop_condition = pc_stop_condition;
	

	for (int ii = 0; ii < i_templ_length; ii++)
		pc_lk_gomea_config->alphabetSize.push_back(2);


	//gomeaInstance = new gomeaLSNoveltyIMS(config);
	pc_cgomea_best_p3 = new C_lkGomea_gomeaLSNoveltyIMS(pc_lk_gomea_config);

	pc_lk_gomea_config->c_opt_timer.vSetStartNow();
}//void  C_lkGomea::vInitialize(time_t tStartTime)




void  C_lkGomea::vCopyFrom(C_lkGomea *pcOther)
{
	i_templ_length = pcOther->i_templ_length;
}//void  C_lkGomea::vCopyFrom(C_lkGomea *pcOther)



CError C_lkGomea::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_C_lkGomea);


	c_err = CBinaryOptimizer::eConfigure(psSettings);


	CUIntCommandParam p_population_topology(s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY);
	i_population_topology = p_population_topology.iGetValue(psSettings, &c_err);
	if (p_population_topology.bHasValue() == false)  i_population_topology = 0;
	if (c_err)  return(c_err);

	if ((i_population_topology != s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY_ASYMETRIC) && (i_population_topology != s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY_SYMETRIC))
	{
		c_err.vSetError(iERROR_CODE_C_lkGomea_UnknownPopulationMode);
		return(c_err);
	}//if ((i_population_topology != s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY_ASYMETRIC) && (i_population_topology != s_OPTIMIZER_LK_GOMEA_POPULATION_TOPOLOGY_SYMETRIC))

	return c_err;
};//CError C_lkGomea::eConfigure(istream *psSettings)




bool C_lkGomea::bRunIteration(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_C_lkGomea);

	CString  s_buf;

	pc_cgomea_best_p3->bRunSingleIteration();

	v_get_best_genotype(&(pc_cgomea_best_p3->pcGetBestInd()->genotype));
	b_update_best_individual(iIterationNumber, pi_bits, pc_cgomea_best_p3->pcGetBestInd()->fitness);
	d_time_last_time = c_optimizer_timer.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf gomeasNum: %d largestGomea: %d [time: %.8lf] [FFE:%.0lf]",
		//pc_cgomea_best_p3->pcGetBestInd()->fitness, pc_cgomea_best_p3->GOMEAs.size(), pc_cgomea_best_p3->GOMEAs.at(pc_cgomea_best_p3->GOMEAs.size() - 1)->population.size(),
		pc_cgomea_best_p3->pcGetBestInd()->fitness, pc_cgomea_best_p3->GOMEAs.size(), pc_cgomea_best_p3->GOMEAs.at(0)->population.size(),

		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);



	return(true);
}//bool C_lkGomea::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)


void  C_lkGomea::v_get_best_genotype(vector<char>  *pvGenotype)
{
	if (pi_bits == NULL)
		pi_bits = new int32_t[i_templ_length];

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pvGenotype->at(ii) == 1)
			pi_bits[ii] = 1;
		else
			pi_bits[ii] = 0;
	}//for (int ii = 0; ii < numberOfVariables; ii++)
}//void  C_lkGomea::v_get_best_genotype(vector<char>  *pvGenotype)




double C_lkGomea::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_compute_fitness_value(piBits);
	return(d_fitness_value);
}//double C_CGomea::dComputeFitness(int32_t *piBits)




CString  C_lkGomea::sAdditionalSummaryInfo()
{
	CString  s_buf;

	return(s_buf);
};//CString  CDarkGrayGA::sAdditionalSummaryInfo() 
