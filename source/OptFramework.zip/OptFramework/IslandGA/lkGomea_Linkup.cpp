#include "lkGomea_Linkup.h";

C_lkGomea_Linkup::C_lkGomea_Linkup(C_lkGomea_Config *config_, C_lkGomea_sharedInformation *info_, C_lkGomea_Problem *problem_) : config(config_), info(info_), problem(problem_)
{
}

C_lkGomea_Linkup::~C_lkGomea_Linkup()
{
}

bool C_lkGomea_Linkup::relink(C_lkGomea_Individual *from, C_lkGomea_Individual *to, bool  *pbTimeLimitOK)
{
    switch (config->solution_relinker)
    {
    case 0:
        return C_lkGomea_Linkup::relink_forward_greedy(from, to, pbTimeLimitOK);
        break;
    case 1:
        return C_lkGomea_Linkup::relink_forward_best(from, to, pbTimeLimitOK);
        break;
    default:
        //throw customException("relinker unknown");
		::Tools::vShow("throw customException(relinker unknown);");
        break;
    }
	::Tools::vShow("throw customException(relinker unknown);");
}

bool C_lkGomea_Linkup::relink_forward_greedy(C_lkGomea_Individual *from, C_lkGomea_Individual *to, bool  *pbTimeLimitOK)
{
	*pbTimeLimitOK = true;

	C_lkGomea_Individual current;
	C_lkGomea_Individual next;
    current = *from;
    next = *from;

    vector<int> changedGenes = {0};
    vector<size_t> indices;
    indices.resize(from->alphabetSize.size());
    iota(indices.begin(), indices.end(), 0);

    while (indices.size() > 0)
    {
        size_t x = 0;
        bool success = false;
        for (size_t p = 0; p < indices.size(); ++p)
        {
            int index = indices[p];
            // Solutions current and next should still be identical at this point.
            assert(current.genotype[index] == next.genotype[index]);

            // Skip over items with identical values.
            if (current.genotype[index] == to->genotype[index])
                continue;

            // Try changing the bit.
            next.genotype[index] = to->genotype[index];
            changedGenes[0] = index;
            // Evaluate the change
			if (b_evaluateSolution(&next, &current, changedGenes) == false)
			{
				*pbTimeLimitOK = false;
				return(false);
			}//if (b_evaluateSolution(&next, &current, changedGenes) == false)

            bool isHill = next.fitness < from->fitness && next.fitness < to->fitness;

            if (!isHill)
            {
                // Step has been performed.
                success = true;
                current = next;
            }
            else
            {
                // Undo change
                next = current;
                // Rewite index to indices (to compact the list of remaining bitflips)
                indices[x] = index;
                // Progress x
                ++x;
            }
        }
        indices.resize(x);
        if (!success && indices.size() != 0)
        {
            return false;
        }
    }

    return true;
}

bool C_lkGomea_Linkup::relink_forward_best(C_lkGomea_Individual *from, C_lkGomea_Individual *to, bool  *pbTimeLimitOK)
{
	*pbTimeLimitOK = true;
	C_lkGomea_Individual current;
	C_lkGomea_Individual next;
	C_lkGomea_Individual next_best;

    current = *from;
    next_best = *from;
    next = *from;

    size_t steps = 0;

    vector<int> changedGenes = {0};
    vector<size_t> indices;
    indices.resize(from->alphabetSize.size());
    iota(indices.begin(), indices.end(), 0);

    while (indices.size() > 0)
    {
        size_t x = 0;
        bool success = false;

        for (size_t p = 0; p < indices.size(); ++p)
        {
            int index = indices[p];
            // Solutions current and next should still be identical at this point.
            assert(current.genotype[index] == next.genotype[index]);

            // Skip over items with identical values.
            if (current.genotype[index] == to->genotype[index])
                continue;

            // Try changing the bit.
            next.genotype[index] = to->genotype[index];
            changedGenes[0] = index;
            // Evaluate the change
			if (b_evaluateSolution(&next, &current, changedGenes) == false)
			{
				*pbTimeLimitOK = false;
				return(false);
			}//if (b_evaluateSolution(&next, &current, changedGenes) == false)

            bool isHill = next.fitness < from->fitness && next.fitness < to->fitness;

            if (!isHill && (!success || next_best.fitness < next.fitness))
            {
                // Not a hill & closer, therefore a potential next step.
                // We want to find the best solution in the (restricted) neighborhood,
                // even taking a worsening step if neccesary to get closer.
                // If success is still false, we haven't done any step yet, so update the next best
                // as well.

                success = true;
                next_best = next;
            }
            // Unlike in the greedy case, we do not know if the change will actually stay.
            // So in any case preserve the index.
            // The one chosen will be removed by continuing over it the next time around.
            // Rewite index to indices (to compact the list of remaining bitflips)
            indices[x] = index;
            // Progress x
            ++x;
            // Undo change
            next = current;
        }
        indices.resize(x);

        steps += 1; 

        // We were unable to perform a change, current is surrounded by hills.
        if (!success && indices.size() != 0)
        {
            return false;
        }
        // Update current solution.
        current = next_best;
        next = next_best;
    }

    return true;
}

/// Copied and modified from PopulationGeneral.cpp

bool C_lkGomea_Linkup::b_evaluateSolution(C_lkGomea_Individual *new_solution, C_lkGomea_Individual *orig_solution, vector<int> &changedGenes)
{
	if (b_checkTimeLimit_OK() == false)  return(false);

	C_lkGomea_archiveRecord searchResult;

    if (config->saveEvaluations)
        info->evaluatedSolutions->checkAlreadyEvaluated(new_solution->genotype, &searchResult);

    if (searchResult.isFound)
    {
        new_solution->fitness = searchResult.value;
    }
    else
    {
        if (orig_solution == NULL)
        {
            problem->calculateFitness(new_solution);
        }
        else
        {
            problem->calculateFitnessPartialEvaluations(new_solution, orig_solution, changedGenes, orig_solution->fitness);
        }

        if (config->problemIndex == 10)
            info->numberOfEvaluations = problem->getEvals();
        else
            info->numberOfEvaluations++;

        if (config->saveEvaluations)
            info->evaluatedSolutions->insertSolution(new_solution->genotype, new_solution->fitness);

        checkVTR(new_solution);

        if (info->numberOfEvaluations >= config->maxEvaluations)
        {
            cout << "Max evals limit reached! Terminating...\n";
            //throw customException("max evals");
			::Tools::vShow("throw customException(max evals);");
        }
    }
	return(true);
}


bool C_lkGomea_Linkup::b_checkTimeLimit_OK()
{
	if (config->pc_stop_condition->bStop(&(config->c_opt_timer), 0, config->pc_external_problem_computer->pcGetEvaluation()->iGetFFE(), NULL) == true)  return(false);
	return(true);
}//bool C_lkGomea_BitflipLS::b_checkTimeLimit_OK()

/*void C_lkGomea_Linkup::checkTimeLimit()
{
    if (getMilliSecondsRunningSinceTimeStamp(info->startTimeMilliseconds) > config->timelimitSeconds * 1000)
    {
        cout << "TIME LIMIT REACHED!" << endl;
        //throw customException("time");
		::Tools::vShow("throw customException(time);");
    }
}*/

void C_lkGomea_Linkup::checkVTR(C_lkGomea_Individual *solution)
{
    /*bool improved = info->firstEvaluationEver || (solution->fitness > info->elitist.fitness);
    bool vtr_hit = (solution->fitness >= config->vtr);
    bool unique_vtr_hit = false;
    if (improved || vtr_hit)
    {
        info->elitistSolutionHittingTimeMilliseconds = getMilliSecondsRunningSinceTimeStamp(info->startTimeMilliseconds);
        info->elitistSolutionHittingTimeEvaluations = info->numberOfEvaluations;

        info->elitist = *solution;

        // Check the VTR 
        if (solution->fitness >= config->vtr)
        {
            archiveRecord rec;
            info->vtrUniqueSolutions->checkAlreadyEvaluated(solution->genotype, &rec);
            if (!rec.isFound)
            {
                info->vtrUniqueSolutions->insertSolution(solution->genotype, solution->fitness);

                // Stop once all unique occurences have been hit.
                if (info->vtrUniqueSolutions->archive.size() >= config->vtr_n_unique)
                {
                    cout << "LAST UNIQUE VTR HIT!" << endl;
                    writeElitistSolutionToFile(config->folder, info->elitistSolutionHittingTimeEvaluations, info->elitistSolutionHittingTimeMilliseconds, solution);
                    throw customException("vtr");
                }
                else
                {
                    unique_vtr_hit = true;
                    cout << "UNIQUE VTR HIT!" << endl;
                }
            }
        }
        if (improved || unique_vtr_hit)
            writeElitistSolutionToFile(config->folder, info->elitistSolutionHittingTimeEvaluations, info->elitistSolutionHittingTimeMilliseconds, solution);
    }*/

    info->firstEvaluationEver = false;
}