#include "DSMCreation.h"

#include "CommandParam.h"
#include "PointerUtils.h"
#include "RandUtils.h"

#include <algorithm>
#include <cmath>
#include <utility>

using namespace Linkage;


template <class TGenotype>
CDSMCreation<TGenotype>::CDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)
{
	i_number_of_elements = iNumberOfElements;
	pc_log = pcLog;
}//CDSMCreation<TGenotype>::CDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)

template <class TGenotype>
CDSMCreation<TGenotype>::~CDSMCreation()
{

}//CDSMCreation<TGenotype>::~CDSMCreation()

template <class TGenotype>
double ** CDSMCreation<TGenotype>::ppdCreateEmptyDSM()
{
	double **ppd_dsm = new double*[i_number_of_elements];

	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		*(ppd_dsm + i) = new double[i_number_of_elements];

		for (uint16_t j = 0; j < i_number_of_elements; j++)
		{
			*(*(ppd_dsm + i) + j) = 0;
		}//for (uint16_t j = 0; j < i_number_of_elements; j++)
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)

	return ppd_dsm;
}//double ** CDSMCreation<TGenotype>::ppdCreateEmptyDSM()

template <class TGenotype>
double ** CDSMCreation<TGenotype>::ppdCreateDSM(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes)
{
	double **ppd_dsm = ppdCreateEmptyDSM();

	vFillDSM(ppcGenotypes, iNumberOfGenotypes, ppd_dsm);

	return ppd_dsm;
}//double ** CDSMCreation<TGenotype>::ppdCreateDSM(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes)

template <class TGenotype>
void CDSMCreation<TGenotype>::vFillDSM(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes, double **ppdDSM)
{
	for (uint16_t i = 0; i + 1 < i_number_of_elements; i++)
	{
		*(*(ppdDSM + i) + i) = 0;

		for (uint16_t j = i + 1; j < i_number_of_elements; j++)
		{
			*(*(ppdDSM + i) + j) = d_calculate_dependency(ppcGenotypes, iNumberOfGenotypes, i, j);
			*(*(ppdDSM + j) + i) = *(*(ppdDSM + i) + j);
		}//for (uint16_t j = i + 1; j < i_number_of_elements; j++)
	}//for (uint16_t i = 0; i + 1 < i_number_of_elements; i++)

	*(*(ppdDSM + i_number_of_elements - 1) + i_number_of_elements - 1) = 0;
}//void CDSMCreation<TGenotype>::vFillDSM(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes, double **ppdDSM)


CBucketDSMCreation::CBucketDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)
	: CDSMCreation<CRealCoding>(iNumberOfElements, pcLog)
{

}//CBucketDSMCreation::CBucketDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)

CError CBucketDSMCreation::eConfigure(istream *psSettings)
{
	CError c_error = CDSMCreation<CRealCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		CBoolCommandParam p_dynamic_min_max(SURFACE_AREA_DSM_CREATION_ARGUMENT_DYNAMIC_MIN_MAX);
		b_dynamic_min_max = p_dynamic_min_max.bGetValue(psSettings, &c_error);
	}//if (!c_error)

	return c_error;
}//CError CBucketDSMCreation::eConfigure(istream *psSettings)

void CBucketDSMCreation::vFillDSM(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, double **ppdDSM)
{
	i_number_of_buckets_per_element = (uint32_t)round(sqrt(iNumberOfGenotypes));

	pi_buckets_indexes = new uint32_t[iNumberOfGenotypes];

	CDSMCreation<CRealCoding>::vFillDSM(ppcGenotypes, iNumberOfGenotypes, ppdDSM);

	delete pi_buckets_indexes;
}//void CBucketDSMCreation::vFillDSM(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, double **ppdDSM)

void CBucketDSMCreation::v_fill_bucket_indexes(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)
{
	double d_min_0, d_min_1;
	double d_step_0, d_step_1;

	v_calculate_min_and_step(ppcGenotypes, iNumberOfGenotypes, iIndex0, &d_min_0, &d_step_0);
	v_calculate_min_and_step(ppcGenotypes, iNumberOfGenotypes, iIndex1, &d_min_1, &d_step_1);

	CRealCoding *pc_genotype;

	double d_value_0, d_value_1;

	for (uint32_t i = 0; i < iNumberOfGenotypes; i++)
	{
		pc_genotype = *(ppcGenotypes + i);

		d_value_0 = d_calculate_value(pc_genotype, iIndex0, d_min_0);
		d_value_1 = d_calculate_value(pc_genotype, iIndex1, d_min_1);

		*(pi_buckets_indexes + i) = i_calculate_bucket_index(d_value_0, d_value_1, d_step_0, d_step_1);
	}//for (uint32_t i = 0; i < iNumberOfGenotypes; i++)
}//void CBucketDSMCreation::v_fill_bucket_indexes(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)

void CBucketDSMCreation::v_calculate_min_and_max(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex, double *pdMin, double *pdMax)
{
	CRealCoding *pc_genotype = *ppcGenotypes;

	double d_value;

	if (b_dynamic_min_max)
	{
		*pdMin = *(pc_genotype->pdGetMaxValues() + iIndex);
		*pdMax = *(pc_genotype->pdGetMinValues() + iIndex);

		for (uint32_t i = 0; i < iNumberOfGenotypes; i++)
		{
			pc_genotype = *(ppcGenotypes + i);
			d_value = *(pc_genotype->pdGetValues() + iIndex);

			if (d_value < *pdMin)
			{
				*pdMin = d_value;
			}//if (d_value < *pdMin)

			if (d_value > *pdMax)
			{
				*pdMax = d_value;
			}//if (d_value > *pdMax)
		}//for (uint32_t i = 0; i < iNumberOfGenotypes; i++)
	}//if (b_dynamic_min_max)
	else
	{
		*pdMin = *(pc_genotype->pdGetMinValues() + iIndex);
		*pdMax = *(pc_genotype->pdGetMaxValues() + iIndex);
	}//else if (b_dynamic_min_max)
}//void CBucketDSMCreation::v_calculate_min_and_max(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex, double *pdMin, double *pdMax)

void CBucketDSMCreation::v_calculate_min_and_step(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex, double *pdMin, double *pdStep)
{
	double d_min, d_max;

	v_calculate_min_and_max(ppcGenotypes, iNumberOfGenotypes, iIndex, &d_min, &d_max);

	*pdMin = d_min;
	*pdStep = (d_max - d_min) / (double)i_number_of_buckets_per_element;
}//void CBucketDSMCreation::v_calculate_min_and_step(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex, double *pdMin, double *pdStep)

double CBucketDSMCreation::d_calculate_value(CRealCoding *pcGenotype, uint16_t iIndex, double dMin)
{
	return *(pcGenotype->pdGetValues() + iIndex) - dMin;
}//double CBucketDSMCreation::d_calculate_value(CRealCoding *pcGenotype, uint16_t iIndex, double dMin)

uint32_t CBucketDSMCreation::i_calculate_bucket_element_index(double dValue, double dStep)
{
	int64_t i_bucket_element_index = (int64_t)floor(dValue / dStep);

	if (i_bucket_element_index < 0)
	{
		i_bucket_element_index = 0;
	}//if (i_bucket_element_index < 0)

	if (i_bucket_element_index + 1 > i_number_of_buckets_per_element)
	{
		i_bucket_element_index = i_number_of_buckets_per_element - 1;
	}//if (i_bucket_element_index + 1 > i_number_of_buckets_per_element)

	return (uint32_t)i_bucket_element_index;
}//uint32_t CBucketDSMCreation::i_calculate_bucket_element_index(double dValue, double dStep)

uint32_t CBucketDSMCreation::i_calculate_bucket_index(double dValue0, double dValue1, double dStep0, double dStep1)
{
	uint32_t i_bucket_element_index_0 = i_calculate_bucket_element_index(dValue0, dStep0);
	uint32_t i_bucket_element_index_1 = i_calculate_bucket_element_index(dValue1, dStep1);

	return i_bucket_element_index_0 * i_number_of_buckets_per_element + i_bucket_element_index_1;
}//uint32_t CBucketDSMCreation::i_calculate_bucket_index(double dValue0, double dValue1, double dStep0, double dStep1)


CSurfaceAreaDSMCreation::CSurfaceAreaDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)
	: CBucketDSMCreation(iNumberOfElements, pcLog)
{

}//CSurfaceAreaDSMCreation::CSurfaceAreaDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)

double CSurfaceAreaDSMCreation::d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)
{
	v_fill_bucket_indexes(ppcGenotypes, iNumberOfGenotypes, iIndex0, iIndex1);

	uint32_t i_number_of_nonempty_buckets_indexes = i_calculate_number_of_nonempty_buckets_indexes(iNumberOfGenotypes);

	return (double)i_number_of_nonempty_buckets_indexes / (double)(i_number_of_buckets_per_element * i_number_of_buckets_per_element);
}//double CSurfaceAreaDSMCreation::d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)

uint32_t CSurfaceAreaDSMCreation::i_calculate_number_of_nonempty_buckets_indexes(uint32_t iNumberOfGenotypes)
{
	uint32_t i_number_of_nonempty_buckets_indexes = 1;

	sort(pi_buckets_indexes + 0, pi_buckets_indexes + iNumberOfGenotypes);

	for (uint32_t i = 0; i + 1 < iNumberOfGenotypes; i++)
	{
		if (*(pi_buckets_indexes + i + 1) != *(pi_buckets_indexes + i))
		{
			i_number_of_nonempty_buckets_indexes++;
		}//if (*(pi_buckets_indexes + i + 1) != *(pi_buckets_indexes + i))
	}//for (uint32_t i = 0; i + 1 < iNumberOfGenotypes; i++)

	return i_number_of_nonempty_buckets_indexes;
}//uint32_t CSurfaceAreaDSMCreation::i_calculate_number_of_nonempty_buckets_indexes(uint32_t iNumberOfGenotypes)


CBiggestBucketDSMCreation::CBiggestBucketDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)
	: CBucketDSMCreation(iNumberOfElements, pcLog)
{

}//CBiggestBucketDSMCreation::CBiggestBucketDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)

double CBiggestBucketDSMCreation::d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)
{
	v_fill_bucket_indexes(ppcGenotypes, iNumberOfGenotypes, iIndex0, iIndex1);

	uint32_t i_size_of_biggest_bucket_index = i_calculate_size_of_biggest_bucket_index(iNumberOfGenotypes);

	return 1.0 - (double)(i_size_of_biggest_bucket_index - 1) / (double)iNumberOfGenotypes;
}//double CBiggestBucketDSMCreation::d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)

uint32_t CBiggestBucketDSMCreation::i_calculate_size_of_biggest_bucket_index(uint32_t iNumberOfGenotypes)
{
	uint32_t i_size_of_biggest_bucket_index = 0;

	sort(pi_buckets_indexes + 0, pi_buckets_indexes + iNumberOfGenotypes);

	uint32_t i_size_of_current_bucket_index = 1;

	for (uint32_t i = 1; i < iNumberOfGenotypes; i++)
	{
		if (*(pi_buckets_indexes + i - 1) == *(pi_buckets_indexes + i))
		{
			i_size_of_current_bucket_index++;
		}//if (*(pi_buckets_indexes + i - 1) == *(pi_buckets_indexes + i))
		else
		{
			if (i_size_of_current_bucket_index > i_size_of_biggest_bucket_index)
			{
				i_size_of_biggest_bucket_index = i_size_of_current_bucket_index;
			}//if (i_size_of_current_bucket_index > i_size_of_biggest_bucket_index)

			i_size_of_current_bucket_index = 1;
		}//else if (*(pi_buckets_indexes + i - 1) == *(pi_buckets_indexes + i))
	}//for (uint32_t i = 1; i < iNumberOfGenotypes; i++)

	if (i_size_of_current_bucket_index > i_size_of_biggest_bucket_index)
	{
		i_size_of_biggest_bucket_index = i_size_of_current_bucket_index;
	}//if (i_size_of_current_bucket_index > i_size_of_biggest_bucket_index)

	return i_size_of_biggest_bucket_index;
}//uint32_t CBiggestBucketDSMCreation::i_calculate_size_of_biggest_bucket_index(uint32_t iNumberOfGenotypes)


CRealMutualInformationDSMCreation::CRealMutualInformationDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)
	: CDSMCreation<CRealCoding>(iNumberOfElements, pcLog)
{

}//CRealMutualInformationDSMCreation::CRealMutualInformationDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)

void CRealMutualInformationDSMCreation::vFillDSM(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, double **ppdDSM)
{
	v_create_covariance_matrix(ppcGenotypes, iNumberOfGenotypes);

	CDSMCreation<CRealCoding>::vFillDSM(ppcGenotypes, iNumberOfGenotypes, ppdDSM);

	PointerUtils::vDelete(ppd_covariance_matrix, (uint32_t)i_number_of_elements);
}//void CRealMutualInformationDSMCreation::vFillDSM(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, double **ppdDSM)

double CRealMutualInformationDSMCreation::d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)
{
	double d_s_0 = sqrt(*(*(ppd_covariance_matrix + iIndex0) + iIndex0));
	double d_s_1 = sqrt(*(*(ppd_covariance_matrix + iIndex1) + iIndex1));
	double d_r = *(*(ppd_covariance_matrix + iIndex0) + iIndex1) / (d_s_0 * d_s_1);

	return -log(sqrt(1.0 / (1.0 - d_r * d_r)));
}//double CRealMutualInformationDSMCreation::d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)

void CRealMutualInformationDSMCreation::v_create_covariance_matrix(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes)
{
	ppd_covariance_matrix = new double*[i_number_of_elements];
	double *pd_means = new double[i_number_of_elements];

	CRealCoding *pc_genotype;

	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		*(ppd_covariance_matrix + i) = new double[i_number_of_elements];

		*(pd_means + i) = 0;

		for (uint32_t j = 0; j < iNumberOfGenotypes; j++)
		{
			pc_genotype = *(ppcGenotypes + j);
			*(pd_means + i) += *(pc_genotype->pdGetValues() + i);
		}//for (uint32_t j = 0; j < iNumberOfGenotypes; j++)

		*(pd_means + i) /= (double)iNumberOfGenotypes;
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)

	double d_cov;

	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		for (uint16_t j = i; j < i_number_of_elements; j++)
		{
			d_cov = 0;

			for (uint32_t k = 0; k < iNumberOfGenotypes; k++)
			{
				pc_genotype = *(ppcGenotypes + k);
				d_cov += (*(pc_genotype->pdGetValues() + i) - *(pd_means + i)) * (*(pc_genotype->pdGetValues() + j) - *(pd_means + j));
			}//for (uint32_t k = 0; k < iNumberOfGenotypes; k++)

			d_cov /= (double)iNumberOfGenotypes;

			*(*(ppd_covariance_matrix + i) + j) = d_cov;
			*(*(ppd_covariance_matrix + j) + i) = d_cov;
		}//for (uint16_t j = i; j < i_number_of_elements; j++)
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)

	delete pd_means;
}//void CRealMutualInformationDSMCreation::v_create_covariance_matrix(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes)


template <class TGenotype>
CRandomDSMCreation<TGenotype>::CRandomDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)
	: CDSMCreation<TGenotype>(iNumberOfElements, pcLog)
{

}//CRandomDSMCreation<TGenotype>::CRandomDSMCreation(uint16_t iNumberOfElements, CLog *pcLog)

template <class TGenotype>
double CRandomDSMCreation<TGenotype>::d_calculate_dependency(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)
{
	return RandUtils::dRandProbability();
}//double CRandomDSMCreation<TGenotype>::d_calculate_dependency(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1)


template <class TGenotype>
CDSMCreation<TGenotype> * DSMCreationUtils::pcGetDSMCreation(istream *psSettings, uint16_t iNumberOfElements, CLog *pcLog, CError *pcError, bool bIsObligatory)
{
	CConstructorCommandParam<CDSMCreation<TGenotype>> p_dsm_creation(DSM_CREATION_TYPE, bIsObligatory);

	size_t i_genotype_type_hash_code = typeid(TGenotype).hash_code();

	p_dsm_creation.vAddConstructor(DSM_CREATION_TYPE_RANDOM, [&]() 
	{ 
		return new CRandomDSMCreation<TGenotype>(iNumberOfElements, pcLog); 
	});//p_dsm_creation.vAddConstructor(DSM_CREATION_TYPE_RANDOM, [&]() 

	if (i_genotype_type_hash_code == typeid(CBinaryCoding).hash_code())
	{

	}//if (i_genotype_type_hash_code == typeid(CBinaryCoding).hash_code())
	else if (i_genotype_type_hash_code == typeid(CRealCoding).hash_code())
	{
		p_dsm_creation.vAddConstructor(DSM_CREATION_TYPE_REAL_SURFACE_AREA, [&]()
		{
			return (CDSMCreation<TGenotype>*)new CSurfaceAreaDSMCreation(iNumberOfElements, pcLog); 
		});//p_dsm_creation.vAddConstructor(DSM_CREATION_TYPE_REAL_SURFACE_AREA, [&]()

		p_dsm_creation.vAddConstructor(DSM_CREATION_TYPE_REAL_MUTUAL_INFORMATION, [&]()
		{
			return (CDSMCreation<TGenotype>*)new CRealMutualInformationDSMCreation(iNumberOfElements, pcLog);
		});//p_dsm_creation.vAddConstructor(DSM_CREATION_TYPE_REAL_MUTUAL_INFORMATION, [&]()
	}//else if (i_genotype_type_hash_code == typeid(CRealCoding).hash_code())

	CDSMCreation<TGenotype> *pc_dsm_creation = p_dsm_creation.pcGetValue(psSettings, pcError);

	if (!*pcError && pc_dsm_creation)
	{
		*pcError = pc_dsm_creation->eConfigure(psSettings);
	}//if (!*pcError && pc_dsm_creation)

	return pc_dsm_creation;
}//CDSMCreation<TGenotype> * DSMCreationUtils::pcGetDSMCreation(istream *psSettings, uint16_t iNumberOfElements, CLog *pcLog, CError *pcError, bool bIsObligatory)


template class CDSMCreation<CBinaryCoding>;
template class CDSMCreation<CRealCoding>;

template class CRandomDSMCreation<CBinaryCoding>;
template class CRandomDSMCreation<CRealCoding>;

template CDSMCreation<CBinaryCoding> * DSMCreationUtils::pcGetDSMCreation(istream*, uint16_t, CLog*, CError*, bool);
template CDSMCreation<CRealCoding> * DSMCreationUtils::pcGetDSMCreation(istream*, uint16_t, CLog*, CError*, bool);