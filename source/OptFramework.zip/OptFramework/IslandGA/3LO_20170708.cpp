#include "3LO.h"



using  namespace ThreeLO;


uint32_t C3LO::iERROR_PARENT_C3LOOptimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_C3LOOptimizer");

uint32_t C3LO::iERROR_CODE_3LO_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_3LO_GENOTYPE_LEN_BELOW_0");



//---------------------------------------------C3LO-------------------------------------------------------
C3LO::C3LO(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog)
	: CBinaryOptimizer(pcProblem, pcLog)
{
	pv_population = new vector  <C3LOIndividual  *>();

	i_random_indiv_adds = 0;

	pc_genotype_root = new  CGenotypeInfoNode();

	pi_best_genotype = NULL;
	pi_genotype_diffr_tool = NULL;
}//C3LO::C3LO(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog)


C3LO::C3LO(C3LO *pcOther)
	: CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "Brak implementacji: C3LO::C3LO(C3LO *pcOther) : CBinaryOptimizer(pcOther)", "BRAK", MB_OK);
}//C3LO::C3LO(C3LO *pcOther)


CError C3LO::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_C3LOOptimizer);

	c_err = CBinaryOptimizer::eConfigure3LO(psSettings);

	return c_err;
}//CError CDummyOptimizer::eConfigure(istream *psSettings)



C3LO::~C3LO()
{
	if (pi_best_genotype != NULL)  delete  pi_best_genotype;
	if (pi_genotype_diffr_tool != NULL)  delete  pi_genotype_diffr_tool;
	
	//v_delete_population(pv_population);
	if (pv_population != NULL)
	{
		for (int ii = 0; ii < (int)pv_population->size(); ii++)
		{
			delete  pv_population->at(ii);
		}//for  (int  ii = 0; ii < (int) pv_population->size(); ii++)
		delete  pv_population;
	}//if  (pvPopulationToDelete  !=  NULL)


	for (int ii = 0; ii < v_new_individuals.size(); ii++)
		delete  v_new_individuals.at(ii);


	//if  (pi_genes_marked_by_linkage != NULL)  delete  pi_genes_marked_by_linkage;

	delete  pc_genotype_root;


	for (int ii = 0; ii < v_genes_marked_by_linkage.size(); ii++)
		delete  v_genes_marked_by_linkage.at(ii);



	//not an owner...
	/*for  (int  ii = 0; ii < v_gene_patterns.size(); ii++)
	delete  v_gene_patterns.at(ii);

	for  (int  ii = 0; ii < v_gene_patterns_parts.size(); ii++)
	delete  v_gene_patterns_parts.at(ii);*/
}//C3LO::~C3LO()




void  C3LO::v_add_order_random(bool  bWithOpposite)
{
	vector <int>  v_genotype_order;
	vector <int>  v_new_order;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		v_genotype_order.push_back(ii);
	}//for  (int ii = 0; ii < i_templ_length; ii++)

	int  i_gene_pos_offset;
	while (v_genotype_order.size() > 0)
	{
		//i_gene_pos_offset = pc_random_gen->Next(0, v_genotype_order.size());
		i_gene_pos_offset = RandUtils::iRandNumber(0, v_genotype_order.size() - 1);
		v_new_order.push_back(v_genotype_order.at(i_gene_pos_offset));

		v_genotype_order.erase(v_genotype_order.begin() + i_gene_pos_offset);
	}//while  (v_genotype_order.size() > 0)

	v_optimization_orders.push_back(v_new_order);


	if (bWithOpposite == true)
	{
		vector <int>  v_opposite_order;

		for (int ii = 0; ii < i_templ_length; ii++)
		{
			v_opposite_order.push_back(v_new_order.at(i_templ_length - ii - 1));
		}//for  (int  ii = 0; ii < i_templ_length; ii++)	

		v_optimization_orders.push_back(v_opposite_order);
	}//if  (bWithOpposite == true)
}//void  C3LO::v_add_order_random()



void  C3LO::v_add_order_by_genotype(bool  bReversed)
{
	vector <int>  v_new_order;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (bReversed == false)
			v_new_order.push_back(ii);
		else
			v_new_order.push_back(i_templ_length - ii - 1);
	}//for  (int ii = 0; ii < i_templ_length; ii++)

	v_optimization_orders.push_back(v_new_order);
}//void  C3LO::v_add_order_by_genotype(bool  bReversed)




void  C3LO::v_initialize_orders()
{
	v_optimization_orders.clear();
	v_add_order_by_genotype(false);
	//v_add_order_by_genotype(true);

	//for  (int  ii = 0; ii < 50; ii++)
	//	v_add_order_random(true);

}//void  C3LO::v_initialize_orders()



void  C3LO::v_insert_gene_pattern_part_level(int  iPatternPartLevel)
{
	if (iPatternPartLevel  <  0)  return;

	while (v_gene_patterns_parts.size() <= iPatternPartLevel)  v_gene_patterns_parts.push_back(vector<C3LOPattern *>());
	while (v_gene_patterns_parts_original.size() <= iPatternPartLevel)  v_gene_patterns_parts_original.push_back(vector<C3LOPattern *>());
	
}//void  C3LO::v_insert_gene_pattern_part_level(int  iPatternPartLevel)



void  C3LO::v_add_gene_pattern_tree(C3LOPattern  *pcTree, int  iPatternLevel)
{
	if (iPatternLevel  <  0)  return;

	while (v_gene_patterns_trees.size() <= iPatternLevel)  v_gene_patterns_trees.push_back(vector<C3LOPattern *>());

	if (pcTree == NULL)  return;
	v_gene_patterns_trees.at(iPatternLevel).push_back(pcTree);
}//void  C3LO::v_add_gene_pattern_tree(C3LOPattern  *pcPattern, int  iPatternLevel)




double  C3LO::d_get_most_similar_pattern_pair_offset(int  *piMostSimlarPairOffset, vector<C3LOPatternPair>  *pvPatternPairs)
{
	double  d_most_similar = 0;
	int  i_most_similar_offset = -1;
	for (int ii = 0; ii < pvPatternPairs->size(); ii++)
	{
		if (pvPatternPairs->at(ii).d_similarity > d_most_similar)
		{
			d_most_similar = pvPatternPairs->at(ii).d_similarity;
			i_most_similar_offset = ii;
		}//if  (v_pattern_pairs.at(ii).d_similarity > d_most_similar)
	}//for  (int ii = 0; ii < v_pattern_pairs.size(); ii++)

	*piMostSimlarPairOffset = i_most_similar_offset;
	return(d_most_similar);
}//double  C3LO::d_get_most_similar_pattern_pair_offset()





void  C3LO::v_remove_pattern_from_buffer(vector<C3LOPattern  *>  *pvPartsBuffer, C3LOPattern  *pcPatternToRemove)
{
	//PRW FINISHED HERE

	for (int ii = 0; ii < pvPartsBuffer->size(); ii++)
	{
		if (pvPartsBuffer->at(ii) == pcPatternToRemove)
		{
			pvPartsBuffer->erase(pvPartsBuffer->begin() + ii);
			return;
		}//if  (pvPartsBuffer->at(ii) == pcPatternToRemove)
	}//for  (int  ii = 0; ii < pvPartsBuffer->size() ii++)*/
}//void  C3LO::v_remove_pattern_from_buffer(vector<C3LOPattern  *>  *pvPartsBuffer, C3LOPattern  *pcPatternToRemove)



void  C3LO::v_remove_pattern_from_pairs_buffer(vector<C3LOPatternPair>  *pvPatternPairsBuffer, C3LOPattern  *pcPatternToRemove)
{
	for (int ii = 0; ii < pvPatternPairsBuffer->size(); ii++)
	{
		if (
			(pvPatternPairsBuffer->at(ii).pc_first == pcPatternToRemove) ||
			(pvPatternPairsBuffer->at(ii).pc_second == pcPatternToRemove)
			)
		{
			pvPatternPairsBuffer->erase(pvPatternPairsBuffer->begin() + ii);
			ii--;
		}//if  (pvPartsBuffer->at(ii) == pcPatternToRemove)
	}//for  (int  ii = 0; ii < pvPartsBuffer->size() ii++)*/	


}//void  C3LO::v_remove_pattern_from_pairs_buffer(vector<C3LOPatternPair>  *pvPatternPairsBuffer, C3LOPattern  *pcPatternToRemove)






bool  C3LO::b_add_higher_level_gene(C3LOPattern  *pcHigherLevelGene, int  iGeneLevel)
{
	if (iGeneLevel  <  0)  return(false);

	while (v_higher_level_trees_genes.size() <= iGeneLevel)  v_higher_level_trees_genes.push_back(vector<C3LOPattern *>());

	if (pcHigherLevelGene == NULL)  return(false);
	if (pcHigherLevelGene->v_pattern.size() == 0)  return(false);

	//check ifit is not contained 
	int  i_common, i_uncommon, i_unmarked;
	for (int ii = 0; ii < v_higher_level_trees_genes.at(iGeneLevel).size(); ii++)
	{
		v_higher_level_trees_genes.at(iGeneLevel).at(ii)->vGetCommonAndUNcommonPositions(pcHigherLevelGene, &i_common, &i_uncommon, &i_unmarked);

		if (i_unmarked == 0)  return(false);
	}//for  (int  ii = 0; ii < this->v_gene_higher_level_trees_genes.at(iGeneLevel).size(); ii++)


	 //now check if it contains...
	for (int ii = 0; ii < v_higher_level_trees_genes.at(iGeneLevel).size(); ii++)
	{
		pcHigherLevelGene->vGetCommonAndUNcommonPositions(v_higher_level_trees_genes.at(iGeneLevel).at(ii), &i_common, &i_uncommon, &i_unmarked);

		if (i_unmarked == 0)
		{
			delete  v_higher_level_trees_genes.at(iGeneLevel).at(ii);
			v_higher_level_trees_genes.at(iGeneLevel).erase(v_higher_level_trees_genes.at(iGeneLevel).begin() + ii);
			ii--;
		}//if  ( (i_uncommon == 0)&&(i_unmarked == 0)  )
	}//for  (int  ii = 0; ii < this->v_gene_higher_level_trees_genes.at(iGeneLevel).size(); ii++)

	v_higher_level_trees_genes.at(iGeneLevel).push_back(pcHigherLevelGene);



	return(true);
}//void  C3LO::v_insert_gene_pattern_part_level(int  iPatternPartLevel)



int  C3LO::i_get_ind_number()
{
	int  i_cur_pop_size;
	i_cur_pop_size = 0;
	for (int i_lvl = 0; i_lvl < v_population_levels.size(); i_lvl++)
	{
		i_cur_pop_size += v_population_levels.at(i_lvl).size();
	}//for  (int i_lvl = 0; i_lvl < v_population_levels.size(); i_lvl++)

	return(i_cur_pop_size);
}//int  C3LO::i_get_ind_number()



void  C3LO::v_count_higher_genes_freq()
{
	for (int i_lvl = 0; i_lvl < v_higher_level_trees_genes.size(); i_lvl++)
	{
		//first compute individual fitness at particular level
		for (int i_ind = 0; i_ind < v_population_levels.at(0).size(); i_ind++)
		{
			v_population_levels.at(0).at(i_ind)->dComputeFitness(i_lvl);
		}//for  (int  i_ind = 0; i_ind < v_population_levels.at(0).size(); i_ind++)


		for (int i_hl_gene = 0; i_hl_gene < v_higher_level_trees_genes.at(i_lvl).size(); i_hl_gene++)
		{
			v_higher_level_trees_genes.at(i_lvl).at(i_hl_gene)->vCountHighLvlGeneFreq(&(v_population_levels.at(0)), i_lvl);
		}//for  (int  i_hl_gene = 0; i_hl_gene < v_higher_level_trees_genes.at(i_lvl).size(); i_hl_gene++)
	}//for  (int  i_lvl = 0; i_lvl < v_higher_level_trees_genes.size(); i_lvl++)
}//void  C3LO::v_count_higher_genes_freq()




void C3LO::vInitialize(time_t tStartTime)
{
	CBinaryOptimizer::vInitialize(tStartTime);

	t_start = tStartTime;

	

	CError  c_err(iERROR_PARENT_C3LOOptimizer);
	CString   s_buf;
	CString   s_levels_info;
	CString   s_tribe_eff_info;


	
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();
	v_initialize_orders();//i_templ_length needed


	if (i_templ_length <= 0)
	{
		c_err.vSetError(C3LO::iERROR_CODE_3LO_GENOTYPE_LEN_BELOW_0);
		return;
	}//if  (i_templ_length  <=  0)


	pi_best_genotype = new int32_t[i_templ_length];
	pi_genotype_diffr_tool = new int32_t[i_templ_length];

	
	pc_log->vPrintLine("Initializing...", true);


	double  d_fit_max_cur;
	C3LOIndividual  *pc_best;


	double  d_buf;
	int  i_max_lvl;



	d_fit_max_cur = 0;
	pc_best = NULL;
	pc_indiv_main = NULL;


	v_insert_gene_pattern_part_level(0);
	v_add_gene_pattern_tree(NULL, 0);

	s_debug = "";

	i_pop_to_add = 1;
	i_upgraded_new_ind_at_last_insert = 0;
	i_upgraded_new_ind = 0;
	i_worse_but_different_used = 0;
	i_worse_but_different_used_at_last_insert = 0;
	b_add_higher_level_gene(NULL, 0);
	i_crossings_with_effect_in_the_pop = 0;
	i_all_crossings = 0;

	i_better_but_cannot_be_added_at_last_insert = 0;
	i_better_but_cannot_be_added = 0;
	i_tribe_effective_in_this_iteration = 0;

	i_brutal_random_search = 0;
	i_brutal_random_search_effective = 0;

	d_fit_max_cur = 0;
	d_unit_max_cur = 0;
	i_cur_gen = 0;

	b_tribe_effective = false;


	c_time_counter.vSetStartNow();
	pc_log->vPrintLine("DONE...", true);

}//void CDummyOptimizer::vInitialize(time_t tStartTime)




C3LOIndividual* C3LO::pc_get_random_individual()
{
	C3LOIndividual  *pc_indiv_result;
	C3LOIndividual  *pc_indiv_new;

	pc_indiv_new = new C3LOIndividual(i_templ_length, pc_problem, &v_optimization_orders, this);
	pc_indiv_new->vRandomInit();
	pc_indiv_new->dComputeFitness(true);//we want the genotype to be optimized

	pc_indiv_result = pc_insert_into_pop(pv_population, pc_indiv_new);
	if (pc_indiv_result != pc_indiv_new)
	{
		delete  pc_indiv_new;
		return(NULL);
	}//if  (b_insert_into_pop(pc_indiv)  ==  false)

	i_random_indiv_adds++;

	return(pc_indiv_result);
}//C3LOIndividual  *pc_get_random_individual()



C3LOIndividual *C3LO::pc_get_individual_with_lvl_tournament(C3LOIndividual *pcDifferentToIndiv /*= NULL*/)
{
	C3LOIndividual *pc_parent_0, *pc_parent_1;

	pc_parent_0 = pc_get_individual_from_lvl(0, pcDifferentToIndiv);
	pc_parent_1 = pc_get_individual_from_lvl(0, pcDifferentToIndiv);

	if (pc_parent_0 == NULL)  return(pc_parent_1);
	if (pc_parent_1 == NULL)  return(pc_parent_0);

	if (pc_parent_0->i_level > pc_parent_1->i_level)
		return(pc_parent_0);
	else
		return(pc_parent_1);

	return(NULL);
}//C3LOIndividual *C3LO::pc_get_individual_from_lvl(int  iEvolutionLvl, C3LOIndividual *pcDifferentToIndiv /*= NULL*/)


C3LOIndividual *C3LO::pc_get_individual_from_lvl(int  iEvolutionLvl, C3LOIndividual *pcDifferentToIndiv /*= NULL*/)
{
	if (iEvolutionLvl < 0)  return(NULL);
	if (v_population_levels.size() <= iEvolutionLvl)  return(NULL);

	if (v_population_levels.at(iEvolutionLvl).size() <  1)  return(NULL);

	int  i_rand_ind;

	int  i_rand_rounds = 0;
	bool  b_rand_again = true;
	while (b_rand_again == true)
	{
		//i_rand_ind = pc_random_gen->Next(0, v_population_levels.at(iEvolutionLvl).size());
		i_rand_ind = RandUtils::iRandNumber(0, v_population_levels.at(iEvolutionLvl).size() -1);
		if (v_population_levels.at(iEvolutionLvl).at(i_rand_ind) != pcDifferentToIndiv)  return(v_population_levels.at(iEvolutionLvl).at(i_rand_ind));

		i_rand_rounds++;

		if (i_rand_rounds >= _3LO_TRIBE_MAX_ROUNDS_NUM)  b_rand_again = false;
	}//while  (b_rand_again == true)


	return(NULL);
}//C3LOIndividual *C3LO::pc_get_individual_from_lvl(int  iEvolutionLvl, C3LOIndividual *pcDifferentToIndiv /*= NULL*/)





C3LOIndividual* C3LO::pc_insert_into_pop(vector  <C3LOIndividual  *>  *pvPopDest, C3LOIndividual  *pcIndToInsert, bool bCheckPhenotype /*= true*/, bool  bCheckGenotype /*= false*/)
{
	double  d_fit;
	d_fit = pcIndToInsert->dComputeFitness(0);//also forces the creation of the genotype


	if (pvPopDest != pv_population)
	{
		for (int ii = 0; ii < pv_population->size(); ii++)
		{
			if (pv_population->at(ii)->dComputeFitness(0) == pcIndToInsert->dComputeFitness(0))
			{
				if (pv_population->at(ii)->bComparePhenotype(pcIndToInsert) == true)
				{
					return(pv_population->at(ii));
				}//if  (pv_population->at(ii)->bComparePhenotype(pcIndToInsert) ==  true)
			}//if  (pv_population->at(ii)->dComputeFitness() == pcIndToInsert->dComputeFitness())
		}//for  (int  ii = 0; ii < pv_population->size(); ii++)
	}//if  (pvPopDest != pv_population)


	for (int ii = 0; ii < pvPopDest->size(); ii++)
	{
		if (pcIndToInsert == pvPopDest->at(ii))  return(pvPopDest->at(ii));
	}//for  (int ii = 0;  ii < pvPopDest->size(); ii++)


	 //find individuals of the same fitness
	for (int ii = pvPopDest->size() - 1; ii >= 0; ii--)
	{
		if (pvPopDest->at(ii)->dComputeFitness(0) > pcIndToInsert->dComputeFitness(0))
		{
			if (ii  <  pvPopDest->size() - 1)
			{
				pvPopDest->insert(pvPopDest->begin() + ii + 1, pcIndToInsert);
				return(pcIndToInsert);
			}//if  (ii  <  pv_population->size() - 1)
			else
			{
				pvPopDest->push_back(pcIndToInsert);
				return(pcIndToInsert);
			}//else  if  (ii  <  pv_population->size() - 1)
		}//if  (pv_population->at(ii)->dComputeFitness() > pc_indiv->dComputeFitness())

		if (pvPopDest->at(ii)->dComputeFitness(0) == pcIndToInsert->dComputeFitness(0))
		{
			if (bCheckPhenotype == true)
			{
				if (pvPopDest->at(ii)->bComparePhenotype(pcIndToInsert) == true)
				{
					return(pvPopDest->at(ii));
				}//if  (pv_population->at(ii)->bComparePhenotype(pcIndToInsert) ==  true)

				if (bCheckGenotype == true)
				{
					if (pvPopDest->at(ii)->bCompareGenotype(pcIndToInsert) == true)
					{
						return(pvPopDest->at(ii));
					}//if  (pv_population->at(ii)->bComparePhenotype(pcIndToInsert) ==  true)
				}//if  (bCheckGenotype == true)
			}//if  (bCheckPhenotype == true)
		}//if  (pv_population->at(ii)->dComputeFitness() == pc_indiv->dComputeFitness())
	}//for  (int  ii = 0; ii < pv_population->size(); ii++)



	 //new best individual...
	pvPopDest->insert(pvPopDest->begin(), pcIndToInsert);
	return(pcIndToInsert);
}//C3LOIndividual* C3LO::pc_insert_into_pop(vector  <C3LOIndividual  *>  *pvPopDest, C3LOIndividual  *pcIndToInsert, bool bCheckPhenotype /*= true*/)






bool  C3LO::b_add_at_level(C3LOIndividual *pcInd, int  iLevel, bool  bComparePhenotypes /*= true*/, bool  bCompareGenotypes /*= false*/)
{
	if (iLevel < 0)  return(false);

	while (v_population_levels.size() <= iLevel)
		v_population_levels.push_back(vector<C3LOIndividual *>());


	for (int ii = 0; ii < v_population_levels.at(iLevel).size(); ii++)
	{
		if (bComparePhenotypes == true)
		{
			if (v_population_levels.at(iLevel).at(ii)->bComparePhenotype(pcInd) == true)  return(false);
		}//if  (bComparePhenotypes == true)

		if (bCompareGenotypes == true)
		{
			if (v_population_levels.at(iLevel).at(ii)->bCompareGenotype(pcInd) == true)  return(false);
		}//if  (bComparePhenotypes == true)	
	}//for  (int ii = 0; ii < v_population_levels.at(iLevel).size(); ii++)


	v_population_levels.at(iLevel).push_back(pcInd);

	return(true);
}//bool  C3LO::b_add_at_level(C3LOIndividual *pcInd, int  iLevel, bool  bComparePhenotypes /*= true*/, bool  bCompareGenotypes /*= false*/)



bool  C3LO::b_ind_on_lvl(C3LOIndividual *pcInd, int  iEvolutionLvl)
{
	if (iEvolutionLvl  <  0)  return(false);
	if (iEvolutionLvl >= v_population_levels.size())  return(false);

	for (int i_ind = 0; i_ind < v_population_levels.at(iEvolutionLvl).size(); i_ind++)
	{
		if (v_population_levels.at(iEvolutionLvl).at(i_ind) == pcInd)  return(true);
	}//for  (int ii = 0; ii < v_population_levels.at(iLevel).size(); ii++)

	return(false);
}//bool  C3LO::b_ind_on_lvl(C3LOIndividual *pcInd, , int  iEvolutionLvl)


bool  C3LO::b_can_ind_be_added_at_any_level(C3LOIndividual *pcInd, bool  bComparePhenotypes /*= true*/, bool  bCompareGenotypes /*= false*/)
{
	for (int i_lvl = 0; i_lvl < v_population_levels.size(); i_lvl++)
	{
		for (int i_ind = 0; i_ind < v_population_levels.at(i_lvl).size(); i_ind++)
		{
			if (bComparePhenotypes == true)
			{
				if (v_population_levels.at(i_lvl).at(i_ind)->bComparePhenotype(pcInd) == true)  return(false);
			}//if  (bComparePhenotypes == true)

			if (bCompareGenotypes == true)
			{
				if (v_population_levels.at(i_lvl).at(i_ind)->bCompareGenotype(pcInd) == true)  return(false);
			}//if  (bComparePhenotypes == true)	
		}//for  (int ii = 0; ii < v_population_levels.at(iLevel).size(); ii++)
	}//for  (int i_lvl = 0; i_lvl < v_population_levels.size(); i_lvl++)

	return(true);
}//bool  C3LO::b_can_ind_be_added_at_any_level(C3LOIndividual *pcInd, bool  bComparePhenotypes /*= true*/, bool  bCompareGenotypes /*= false*/)



double  C3LO::d_get_covering_at_level(int  iLevel)
{
	if (iLevel >= v_genes_marked_by_linkage.size())  return(0);


	double  d_pat_coverage;
	d_pat_coverage = 0;
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (v_genes_marked_by_linkage.at(iLevel)[ii] > 0)  d_pat_coverage++;
	}//for  (int  ii = 0; ii < i_templ_length; ii++)
	d_pat_coverage = d_pat_coverage / i_templ_length;

	return(d_pat_coverage);
}//double  C3LO::d_get_covering_at_level(int  iLevel)


void  C3LO::v_add_linkage_covering_at_level(int  iLevel)
{
	while (v_genes_marked_by_linkage.size() <= iLevel)
	{
		int  *pi_linkage_covering;
		pi_linkage_covering = new int[i_templ_length];

		for (int ii = 0; ii < i_templ_length; ii++)
			pi_linkage_covering[ii] = 0;

		v_genes_marked_by_linkage.push_back(pi_linkage_covering);
	}//while  (v_genes_marked_by_linkage.size() <= iLevel)
}//void  C3LO::v_add_linkage_covering_at_level(int  iLevel)


bool  C3LO::b_produce_new_linkage(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, int  iPatternLevel)
{
	int  *pi_phenotype_main, *pi_phenotype_donator;

	pcInd0->dComputeFitness(iPatternLevel); //force phenotype creation
	pcInd1->dComputeFitness(iPatternLevel); //force phenotype creation

	pi_phenotype_main = pcInd0->piGetPhenotype(0);
	pi_phenotype_donator = pcInd1->piGetPhenotype(0);

	v_add_linkage_covering_at_level(iPatternLevel);

	for (int i_gen_off = 0; i_gen_off < i_templ_length; i_gen_off++)
	{
		if (pi_phenotype_main[i_gen_off] != pi_phenotype_donator[i_gen_off])
		{
			if (v_genes_marked_by_linkage.at(iPatternLevel)[i_gen_off] == 0)  return(true);
			//if  (pi_genes_marked_by_linkage[i_gen_off] == 0)  return(true);
		}//if  (pi_phenotype_0[i_gen_off]  ==  pi_phenotype_1[i_gen_off])
	}//for  (int  ii = 0; ii < i_templ_length; ii++)

	return(false);
}//bool  C3LO::b_produce_new_linkage_high_level(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, int  iLevel)





bool  C3LO::bCanIndBeAddedAtAnyLevel(C3LOIndividual *pcInd, bool  bComparePhenotypes /*= true*/, bool  bCompareGenotypes /*= false*/)
{
	for (int i_lvl = 0; i_lvl < v_population_levels.size(); i_lvl++)
	{
		for (int i_ind = 0; i_ind < v_population_levels.at(i_lvl).size(); i_ind++)
		{
			if (bComparePhenotypes == true)
			{
				if (v_population_levels.at(i_lvl).at(i_ind)->bComparePhenotype(pcInd) == true)  return(false);
			}//if  (bComparePhenotypes == true)

			if (bCompareGenotypes == true)
			{
				if (v_population_levels.at(i_lvl).at(i_ind)->bCompareGenotype(pcInd) == true)  return(false);
			}//if  (bComparePhenotypes == true)	
		}//for  (int ii = 0; ii < v_population_levels.at(iLevel).size(); ii++)
	}//for  (int i_lvl = 0; i_lvl < v_population_levels.size(); i_lvl++)

	return(true);
}//bool  C3LO::b_can_ind_be_added_at_any_level(C3LOIndividual *pcInd, bool  bComparePhenotypes /*= true*/, bool  bCompareGenotypes /*= false*/)






bool  C3LO::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)
{
	CString  s_buf;
	CString  s_levels_info;
	
	//double  d_fit_max, d_fit_max_cur, d_fit_max_pop, d_fit_max_cand;
	//double  d_unit_max_cur, d_unit_max_pop, d_unit_max_cand;
	//	C3LOIndividual  *pc_indiv_main, *pc_indiv_donator, *pc_indiv_offspring;
	//	C3LOIndividual  *pc_buf;

	//s_buf.Format("gen:%d", i_cur_gen);
	//MessageBox(NULL, s_buf, s_buf, MB_OK);


	if (pv_population->size() == 0)
	{
		pc_indiv_main = pc_get_random_individual();
		if (pc_indiv_main != NULL)  b_add_at_level(pc_indiv_main, 0);
	}//if  (pv_population->size() == 0)
	else
	{

		vector<C3LOIndividual  *>  v_added_ind;

		//s_buf.Format("i_pop_to_add:%d", i_pop_to_add);
		//MessageBox(NULL, s_buf, s_buf, MB_OK);

		/*if  (b_tribe_effective == true)
			s_buf.Format("b_tribe_effective:TRUE");
		else
			s_buf.Format("b_tribe_effective:FALSE");*/
		//MessageBox(NULL, s_buf, s_buf, MB_OK);

		if (b_tribe_effective == false)
		{
			//MessageBox(NULL, "if (b_tribe_effective == false)", "if (b_tribe_effective == false)", MB_OK);
			for (int ii = 0; ii < i_pop_to_add; ii++)
			{
				//MessageBox(NULL, "HERE", "HERE", MB_OK);

				pc_indiv_main = pc_get_random_individual();
				pc_indiv_main->vIncrementalBrutalUpdate(&(v_gene_patterns_trees.at(0)), &(v_gene_patterns_parts_original.at(0)), 0);
				if (pc_indiv_main != NULL)
				{
					if (b_add_at_level(pc_indiv_main, 0) == true)  v_added_ind.push_back(pc_indiv_main);
				}//if  (pc_indiv_main != NULL)
			}//for  (int ii = 0; ii < i_pop_to_add; ii++)					

			i_pop_to_add *= 2;
		}//if  (b_tribe_effective == false)

		i_upgraded_new_ind = i_upgraded_new_ind - i_worse_but_different_used_at_last_insert;
		if (i_crossings_with_effect_in_the_pop - (i_upgraded_new_ind/* - i_better_but_cannot_be_added*/) > 0)
		{
			//if  ((i_upgraded_new_ind_at_last_insert - i_better_but_cannot_be_added_at_last_insert) > (i_upgraded_new_ind /*- i_better_but_cannot_be_added*/))
			if ((i_upgraded_new_ind < i_upgraded_new_ind_at_last_insert) || (i_upgraded_new_ind == 0))
			{
				double  d_effect_in_pop_perc;

				d_effect_in_pop_perc = i_crossings_with_effect_in_the_pop - i_upgraded_new_ind;
				d_effect_in_pop_perc = d_effect_in_pop_perc / i_all_crossings;

				int  i_cur_pop_size;
				i_cur_pop_size = i_get_ind_number();

				int  i_new_individuals;
				//i_new_individuals = ::Math::Round(d_effect_in_pop_perc * i_cur_pop_size);
				i_new_individuals = round(d_effect_in_pop_perc * i_cur_pop_size);

				C3LOIndividual  *pc_indiv_new;
				for (int ii = 0; ii < i_new_individuals; ii++)
				{
					pc_indiv_new = pc_get_random_individual();
					if (pc_indiv_new != NULL)
					{
						if (b_add_at_level(pc_indiv_new, 0) == true)  v_added_ind.push_back(pc_indiv_new);
					}//if  (pc_indiv_main != NULL)
				}//for  (int ii = 0; ii < i_pop_to_add; ii++)
			}//if  (i_upgraded_new_ind_at_last_insert > i_upgraded_new_ind)

		}//if  (i_crossings_with_effect_in_the_pop > 0)


		v_count_higher_genes_freq();

		for (int i_new_ind = 0; i_new_ind < v_added_ind.size(); i_new_ind++)
		{
			for (int i_lev = 0; i_lev < v_gene_patterns_trees.size(); i_lev++)
			{
				v_added_ind.at(i_new_ind)->vIncrementalBrutalUpdate(&(v_gene_patterns_trees.at(i_lev)), &(v_gene_patterns_parts_original.at(i_lev)), i_lev);
			}//for  (int  i_lev = 0; i_lev < v_gene_patterns_trees.size(); i_lev++)			
		}//for  (int  i_new_ind = 0; i_new_ind < v_added_ind.size(); i_new_ind++)

		v_added_ind.clear();
	}//else  if  (pv_population->size() == 0)

	i_better_but_cannot_be_added_at_last_insert = i_better_but_cannot_be_added;
	i_upgraded_new_ind_at_last_insert = i_upgraded_new_ind;
	b_tribe_effective = false;
	i_crossings_with_effect_in_the_pop = 0;
	i_better_but_cannot_be_added = 0;
	i_all_crossings = 0;
	i_tribe_effective_in_this_iteration = 0;
	i_upgraded_new_ind = 0;
	i_brutal_random_search = 0;
	i_brutal_random_search_effective = 0;
	i_worse_but_different_used_at_last_insert = i_worse_but_different_used;
	i_worse_but_different_used = 0;


	vector<C3LOIndividual  *>  v_start_lvl_population;
	vector<C3LOIndividual  *>  v_worse_but_different;
	if (v_population_levels.at(0).size() >= 1)
	{
		v_start_lvl_population = v_population_levels.at(0);

		for (int i_indiv = 0; i_indiv < v_start_lvl_population.size(); i_indiv++)
		{
			pc_indiv_main = v_start_lvl_population.at(i_indiv);

			if (b_ind_on_lvl(pc_indiv_main, 0) == true)
			{
				v_worse_but_different.clear();

				if (b_run_flat_pop_for_ind(pc_indiv_main, 0, &v_worse_but_different) == true)
				{
					b_tribe_effective = true;
					i_tribe_effective_in_this_iteration++;
				}//if  (b_run_lvl_for_ind(pc_indiv_main, i_evolution_lvl) == true)

				 //else
				 //{
				if (v_worse_but_different.size() > 0)
				{
					i_worse_but_different_used++;

					int  i_chosen_worse_but_diffr;
					//i_chosen_worse_but_diffr = pc_random_gen->Next(0, v_worse_but_different.size());
					i_chosen_worse_but_diffr = RandUtils::iRandNumber(0, v_worse_but_different.size() - 1);

					if (b_add_at_level(v_worse_but_different.at(i_chosen_worse_but_diffr), 0) == true)
					{

						/*FILE  *pf_test;
						pf_test = fopen("zz_worse_but_diffr.txt", "w+");

						fprintf(pf_test, "BEFORE:\n");
						pc_indiv_main->vSave(pf_test);

						fprintf(pf_test, "\n\n\n\nAFTER:\n");
						v_worse_but_different.at(i_chosen_worse_but_diffr)->vSave(pf_test);

						fclose(pf_test);

						::vShow("test");*/

						v_remove_from_levels(pc_indiv_main);
					}//if  (b_add_at_level(v_worse_but_different.at(i_chosen_worse_but_diffr), 0) == true)

				}//if  (v_worse_but_different.size() > 0)
				 //}//else  if  (b_run_lvl_for_ind(pc_indiv_main, i_evolution_lvl) == true)
			}//if  (b_ind_on_lvl(pc_indiv_main, i_evolution_lvl) == true)
		}//for  (int i_indiv = 0; i_indiv < v_population_levels.at(i_evolution_lvl).size(); i_indiv++)		
	}//if  (v_population_levels.at(i_evolution_lvl).size() > 1)


	if (pv_population->size() > 0)
	{
		d_fit_max_cur = pv_population->at(0)->dComputeFitness(-1);
		d_unit_max_cur = pv_population->at(0)->dUnitation(0);

		pc_best = pv_population->at(0);
	}//if  (pv_population->size() > 0)
	else
	{
		d_fit_max_cur = 0;
		d_unit_max_cur = 0;
	}//else  if  (pv_population->size() > 0)


	for (int ii = 0; ii < v_population_levels.at(0).size(); ii++)
	{
		if (d_fit_max_cur  <  v_population_levels.at(0).at(ii)->dComputeFitness(-1))
		{
			pc_best = v_population_levels.at(0).at(ii);
			d_fit_max_cur = v_population_levels.at(0).at(ii)->dComputeFitness(-1);
			d_unit_max_cur = v_population_levels.at(0).at(ii)->dComputeFitness(-1);

			pc_insert_into_pop(pv_population, v_population_levels.at(0).at(ii));
		}//if  (d_fit_max_cur  <  v_population_levels.at(0).at(ii)->dComputeFitness())

	}//for  (int ii = 0; ii < v_population_levels.at(0).size(); ii++)


	int  *pi_best_phenotype;
	pi_best_phenotype = pc_best->piGetPhenotype(0);
	for (int ii = 0; ii < i_templ_length; ii++)
		pi_best_genotype[ii] = (int32_t) (pi_best_phenotype[ii]);

	b_update_best_individual(iIterationNumber, tStartTime, pi_best_genotype, d_fit_max_cur);



	 //pattern coverage
	CString  s_coverage;
	s_coverage = "";

	for (int ii = 0; ii < v_gene_patterns_trees.size(); ii++)
	{
		s_buf.Format("(%d:%.2lf) ", ii, d_get_covering_at_level(ii));
		s_coverage += s_buf;
	}//for  (int  ii = 0; ii < v_gene_patterns_trees.size(); ii++)



	//c_time_counter.bGetTimePassed(&d_time_passed);
	//d_time_passed = 50;


	int  i_the_same = 0;
	/*for  (int  i_first = 0; i_first < (int) (pv_population->size() - 1); i_first++)
	{
	for  (int  i_sec = i_first + 1; i_sec < pv_population->size(); i_sec++)
	{
	if  (
	pv_population->at(i_first)->bComparePhenotype(pv_population->at(i_sec)) == true
	)
	{
	i_the_same++;
	}//if  (
	}//for  (int  i_sec = i_first + 1; i_sec < pv_population->size(); i_sec++)
	}//for  (int  i_first = 0; i_first < pv_population->size() - 1; i_first++)*/


	/*s_levels_info = "";
	i_max_lvl = 0;
	for  (int  ii = 0; ii < v_population_levels.at(0).size(); ii++)
	{
	if  (i_max_lvl <  v_population_levels.at(0).at(ii)->i_level)  i_max_lvl  =  v_population_levels.at(0).at(ii)->i_level;
	}//for  (int  ii = 0; ii < v_population_levels.size(); ii++)

	vector<int>  v_lvl_info;
	for  (int  ii = 0; ii < i_max_lvl + 1; ii++)  v_lvl_info.push_back(0);

	for  (int  ii = 0; ii < v_population_levels.at(0).size(); ii++)
	v_lvl_info.at(v_population_levels.at(0).at(ii)->i_level)++;

	for  (int  ii = 0; ii < i_max_lvl + 1; ii++)
	{
	s_buf.Format("[%d:%d]", ii, v_lvl_info.at(ii));
	s_levels_info += s_buf;
	}//for  (int  ii = 0; ii < i_max_lvl + 1; ii++)*/



	v_count_higher_genes_freq();


	CString  s_block_info;

	CString  s_phenotype_part;
	int  i_ones, i_zeros, i_other;
	vector <CString>  v_other;

	s_block_info = "";
	
	/*for  (int  i_gene = 0; i_gene < i_templ_length; i_gene+=10)
	{
	i_ones = 0;
	i_zeros = 0;
	i_other = 0;
	v_other.clear();
	for  (int  ii = 0; ii < v_population_levels.at(0).size(); ii++)
	{
	s_phenotype_part = v_population_levels.at(0).at(ii)->sGetPhenotype(0, i_gene, i_gene + 10);

	if  (s_phenotype_part == "1111111111")  i_ones++;
	if  (s_phenotype_part == "0000000000")  i_zeros++;

	if  (
	(s_phenotype_part != "1111111111")&&
	(s_phenotype_part != "0000000000")
	)
	{
	i_other++;

	if (!( std::find(v_other.begin(), v_other.end(), s_phenotype_part) != v_other.end() ))
	v_other.push_back(s_phenotype_part);

	}//if  (

	}//for  (int  ii = 0; ii < v_population_levels.at(0).size(); ii++)

	s_buf.Format("[%d: %d/%d %d/%d] ", i_gene, i_ones, i_zeros, i_other, (int) v_other.size());
	s_block_info += s_buf;
	}//for  (int  i_gene = 0; i_gene < i_templ_length; i_gene++)*/


	/*FILE  *pf_test;
	s_debug.Format("%d_", i_cur_gen);
	s_buf.Format("zzz_pats_%.2d.txt", i_cur_gen);
	v_save_trees_and_patterns(s_buf);//*/



	double  d_time_passed;
	//d_time_passed = (uint32_t)(time(nullptr) - t_start);
	c_time_counter.bGetTimePassed(&d_time_passed);

	s_buf.Format
	(
		"blocked improvements: %d %s Iteration: %d [%d] BrutalRandomSearch: %d (eff:%d) BestFit: %.4lf [u:%.4lf] CheckInd:%d PopSize:%d  CrossResultInThePop: %d/%d NewUpgradedIndividuals: %d WorseButDiffr: %d   RandomIndivAdds: %d Patterns[coverage: %s] FFE:%.0lf FFE_OPTs: %d time passed:%.4lf SAME CONTROL: %d %s  gene patternparts: %d",
		i_better_but_cannot_be_added, s_block_info,
		i_cur_gen, i_tribe_effective_in_this_iteration, i_brutal_random_search,i_brutal_random_search_effective,
		d_fit_max_cur, d_unit_max_cur,
		pv_population->size(), i_get_ind_number(),
		i_crossings_with_effect_in_the_pop, i_all_crossings, i_upgraded_new_ind, i_worse_but_different_used,
		i_random_indiv_adds,
		s_coverage,
		//pc_fitness->dGetFuncEval(),
		(double) pc_problem->pcGetEvaluation()->iGetFFE(),		
		pc_genotype_root->iGetSuccOpt(),
		d_time_passed,
		i_the_same,
		s_levels_info,
		v_gene_patterns_parts_original.at(0).size()
	);


	pc_log->vPrintLine(s_buf, true);


	i_cur_gen++;
	return(true);


	uint16_t i_number_of_bits = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	//osobnik w Twojej konwencji
	//int *pi_bits = nullptr;

	//wyliczenie fitnessu
	//double d_fitness_value = d_compute_fitness_value(pi_bits);

	//bool b_updated = false;

	//aktualizacja najlepszego znalezionego osobnika - w przypadku gdy metoda produkuje tylko jednego osobnika podczas pojedynczej iteracji, 
	//metoda b_update_best_individual zostanie wywolana tylko raz z bitami i fitnessem tego konkretnego osobnika
	//w ponizszym przykladzie for jest tylko po to by pokazac, ze metode b_update_best_individual trzeba wywolac dla kazdego "nowego" osobnika
	//for (int i = 0; i < 10; i++)
	//{
	//	b_updated = b_update_best_individual(iIterationNumber, tStartTime, pi_bits, d_fitness_value) || b_updated;
	//}//for (int i = 0; i < 10; i++)

	//bity najlepszego znalezionego do teraz osobnika
	//pc_best_individual->pcGetGenotype()->piGetBits();

	int *pi_bits = new int[i_number_of_bits];

	for (uint16_t i = 0; i < i_number_of_bits; i++)
	{
		//wywolanie utilsow do liczb pseudolosowych (metoda powinna korzystac jedynie z RandUtils do tego typu rzeczy 
		//- w przeciwnym wypadku podany jako parametr seed nie bedzie uwzgledniony)
		*(pi_bits + i) = RandUtils::iRandNumber(0, 1);
	}//for (uint16_t i = 0; i < i_number_of_bits; i++)

	double d_fitness_value = d_compute_fitness_value(pi_bits);
	bool b_updated = b_update_best_individual(iIterationNumber, tStartTime, pi_bits, d_fitness_value);



	//::MessageBox(NULL, "", "", MB_OK);

	//if ((time(nullptr) - tStartTime) % t_log_frequency == 0)
	{
		CString s_log_message;
		s_log_message.Format("best fitness: %f; best unitation: %f; ffe: %u; time: %u; iteration: %u", pc_best_individual->dGetFitnessValue(),
			pc_best_individual->pcGetGenotype()->dGetUnitation(), pc_problem->pcGetEvaluation()->iGetFFE(), (uint32_t)(time(nullptr) - tStartTime),
			iIterationNumber);

		pc_log->vPrintLine(s_log_message, true);
	}//if ((time(nullptr) - tStartTime) % t_log_frequency == 0)


	return b_updated;
}//bool C3LO::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)






bool  C3LO::b_run_flat_pop_for_ind(C3LOIndividual  *pcIndMain, int iPatternLevel, vector<C3LOIndividual  *>  *pvLevelsOffspringsDifferentToParent)
{
	C3LOIndividual  *pc_indiv_donator, *pc_indiv_offspring, *pc_indiv_reversed_offspring;
	C3LOIndividual  *pc_indiv_new;

	int  i_max_lvl_number;
	i_max_lvl_number = v_population_levels.size() - 1;

	pc_indiv_offspring = NULL;
	pc_indiv_reversed_offspring = NULL;


	//for  (int  i_donator_lvl = i_max_lvl_number; i_donator_lvl >= 0; i_donator_lvl--)
	for (int i_donator_lvl = 0; i_donator_lvl <= i_max_lvl_number; i_donator_lvl++)
	{
		pc_indiv_donator = pc_get_individual_with_lvl_tournament(pcIndMain);

		if (pc_indiv_donator != NULL)
		{
			v_tiny_restricted_evolution(pcIndMain, pc_indiv_donator, &pc_indiv_offspring, &pc_indiv_reversed_offspring, iPatternLevel, 0, 1);
			pc_indiv_reversed_offspring = NULL;
			//pc_indiv_reversed_offspring = NULL;

			/*if  (iPatternLevel  >  0)
			{
			FILE  *pf_test;

			pf_test = fopen("zz_high_lvl_exec.txt", "w+");
			fprintf(pf_test, "\n\nLEVEL:%d\n", iPatternLevel);

			fprintf(pf_test, "\n\nMAIN:\n");
			pcIndMain->vSave(pf_test);

			fprintf(pf_test, "\n\nDONATOR:\n");
			pc_indiv_donator->vSave(pf_test);

			if  (pc_indiv_offspring != NULL)
			{
			fprintf(pf_test, "\n\nOFFSPRING:\n");
			pc_indiv_offspring->vSave(pf_test);
			}//if  (pc_indiv_offspring != NULL)
			else
			fprintf(pf_test, "\n\nNULL OFFSPRING:%d\n");


			fclose(pf_test);

			::vShow("HIGH LVL EXECUTED!");
			}//if  (iPatternLevel  >  0)*/

			if (pc_indiv_offspring != NULL)
			{
				if (pc_indiv_offspring->dComputeFitness(iPatternLevel)  >  pcIndMain->dComputeFitness(iPatternLevel))
				{
					if (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)
					{
						pc_indiv_offspring->i_level = pcIndMain->i_level + 1;

						if (b_add_at_level(pc_indiv_offspring, 0) == true)
						{
							if (pvLevelsOffspringsDifferentToParent != NULL)  pvLevelsOffspringsDifferentToParent->clear();

							v_remove_from_levels(pcIndMain);
							b_run_flat_pop_for_ind(pc_indiv_offspring, iPatternLevel, NULL);
							return(true);
						}//if  (b_add_at_level(pc_indiv_offspring, iEvolutionLvl + 1) == true)
					}//if  (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)
					else
					{
						//if the individual on the current level can only be improved by changing it into already existing individual then lets try to initialize the individual with the higher level genes
						if (v_higher_level_trees_genes.size() > iPatternLevel + 1)
						{
							if (v_higher_level_trees_genes.at(iPatternLevel + 1).size() > 0)
							{
								/*pc_indiv_offspring = NULL;

								pcIndMain->vReInitializeWithHighLevelGenes(&(v_higher_level_trees_genes.at(iPatternLevel + 1)), &pc_indiv_offspring);


								if  (pc_indiv_offspring  !=  NULL)
								{
								if  (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)
								{

								/*FILE  *pf_test;
								pf_test = fopen("zz_reinit_res.txt", "w+");
								fprintf(pf_test, "LEVEL: %d\n\n", iPatternLevel + 1);
								fprintf(pf_test, "PARENT:\n\n");
								pcIndMain->vSave(pf_test);

								fprintf(pf_test, "\nREINIT:\n\n");
								pc_indiv_offspring->vSave(pf_test);

								fprintf(pf_test, "\n\nPATTERNS:\n");
								for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)
								{
								fprintf(pf_test, "\n\nPATTERN LEVEL GENES: %d\n", i_pat_lvl);

								for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
								{
								v_higher_level_trees_genes.at(i_pat_lvl).at(ii)->vSavePattern(pf_test, pc_fitness);
								}//for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
								}//for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)


								for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)
								{
								for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
								{
								v_higher_level_trees_genes.at(i_pat_lvl).at(ii)->vSaveHighLevelGene(pf_test, pc_fitness);
								fprintf(pf_test, "\n");
								}//for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
								}//for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)

								fclose(pf_test);
								::vShow("reinit!");*/


								/*pc_indiv_offspring->i_level = pcIndMain->i_level;

								if  (b_add_at_level(pc_indiv_offspring, 0) == true)
								{
								v_remove_from_levels(pcIndMain);
								b_run_flat_pop_for_ind(pc_indiv_offspring, iPatternLevel + 1);
								//return(true); DO NOT RETURN - IT IS ONLY INDIVIDUAL REPLACE...
								}//if  (b_add_at_level(pc_indiv_offspring, iEvolutionLvl + 1) == true)
								}//if  (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)
								}//if  (pc_indiv_offspring  !=  NULL)*/
							}//if  ((v_higher_level_trees_genes.at(iPatternLevel + 1).size() > 0)


						}//if  (v_higher_level_trees_genes.size() > iPatternLevel)


						i_better_but_cannot_be_added++;
					}//else  if  (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)

				}//if  (pc_indiv_offspring->dComputeFitness()  >  pc_indiv_main->dComputeFitness())
				else
				{
					if (pvLevelsOffspringsDifferentToParent != NULL)  pvLevelsOffspringsDifferentToParent->push_back(pc_indiv_offspring);
					/*if  (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)
					{
					pc_indiv_offspring->i_level = pcIndMain->i_level - 1;
					b_add_at_level(pc_indiv_offspring, 0);
					}//if  (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)*/


					//if the individual can not be updated on this pattern level then lets try on the higher pattern
					if (v_gene_patterns_trees.size() > iPatternLevel + 1)
					{
						b_run_flat_pop_for_ind(pcIndMain, iPatternLevel + 1, pvLevelsOffspringsDifferentToParent);
					}//if  (v_gene_patterns_trees.size() > iPatternLevel + 1)



					 /*if  (pc_indiv_offspring->dComputeFitness()  ==  pcIndMain->dComputeFitness())
					 {
					 if  (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)
					 {
					 pc_indiv_offspring->i_level = pcIndMain->i_level;

					 if  (b_add_at_level(pc_indiv_offspring, 0) == true)
					 {
					 v_remove_from_levels(pcIndMain);
					 //return(true); DO NOT RETURN - IT IS ONLY INDIVIDUAL REPLACE...
					 }//if  (b_add_at_level(pc_indiv_offspring, iEvolutionLvl + 1) == true)
					 }//if  (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)

					 }//if  (pc_indiv_offspring->dComputeFitness()  >  pc_indiv_main->dComputeFitness())*/

				}//else  if  (pc_indiv_offspring->dComputeFitness()  >  pc_indiv_main->dComputeFitness())
			}//if  (pc_indiv_offspring != NULL)


			if (pc_indiv_reversed_offspring != NULL)
			{
				if (pc_indiv_reversed_offspring->dComputeFitness(iPatternLevel)  >  pc_indiv_donator->dComputeFitness(iPatternLevel))
				{
					if (b_can_ind_be_added_at_any_level(pc_indiv_reversed_offspring) == true)
					{
						pc_indiv_reversed_offspring->i_level = pc_indiv_donator->i_level + 1;
						if (b_add_at_level(pc_indiv_reversed_offspring, 0) == true)
						{
							v_remove_from_levels(pc_indiv_donator);
							//b_run_flat_pop_for_ind(pc_indiv_reversed_offspring, iPatternLevel);//it can not be executed. It may cause the execution of b_run_flat_pop_for_ind an enourmous number of times
							return(true);
						}//if  (b_add_at_level(pc_indiv_offspring, iEvolutionLvl + 1) == true)
					}//if  (b_can_ind_be_added_at_any_level(pc_indiv_reversed_offspring) == true)
					else
					{
						//if the individual on the current level can only be improved by changing it into already existing individual then lets try to initialize the individual with the higher level genes
						if (v_higher_level_trees_genes.size() > iPatternLevel + 1)
						{
							//	if  (v_higher_level_trees_genes.at(iPatternLevel + 1).size() > 0)
							//	{
							//		pc_indiv_reversed_offspring = NULL;
							//		pc_indiv_donator->vReInitializeWithHighLevelGenes(&(v_higher_level_trees_genes.at(iPatternLevel + 1)), &pc_indiv_reversed_offspring);

							//		

							//		if  (pc_indiv_reversed_offspring  !=  NULL)
							//		{
							//			if  (b_can_ind_be_added_at_any_level(pc_indiv_reversed_offspring) == true)
							//			{

							//				/*FILE  *pf_test;
							//				pf_test = fopen("zz_reinit_res.txt", "w+");
							//				fprintf(pf_test, "LEVEL: %d\n\n", iPatternLevel + 1);
							//				fprintf(pf_test, "PARENT:\n\n");
							//				pc_indiv_donator->vSave(pf_test);

							//				fprintf(pf_test, "\nREINIT:\n\n");
							//				pc_indiv_reversed_offspring->vSave(pf_test);

							//				fprintf(pf_test, "\n\nPATTERNS:\n");
							//				for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)
							//				{
							//					fprintf(pf_test, "\n\nPATTERN LEVEL GENES: %d\n", i_pat_lvl);

							//					for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
							//					{
							//						v_higher_level_trees_genes.at(i_pat_lvl).at(ii)->vSavePattern(pf_test, pc_fitness);
							//					}//for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
							//				}//for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)


							//				for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)
							//				{
							//					for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
							//					{
							//						v_higher_level_trees_genes.at(i_pat_lvl).at(ii)->vSaveHighLevelGene(pf_test, pc_fitness);
							//						fprintf(pf_test, "\n");
							//					}//for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
							//				}//for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)

							//				fclose(pf_test);
							//				::vShow("reinit donator!");*/


							//				pc_indiv_reversed_offspring->i_level = pc_indiv_donator->i_level;

							//				if  (b_add_at_level(pc_indiv_reversed_offspring, 0) == true)
							//				{
							//					v_remove_from_levels(pc_indiv_donator);
							//					b_run_flat_pop_for_ind(pc_indiv_reversed_offspring, iPatternLevel + 1);
							//					//return(true); DO NOT RETURN - IT IS ONLY INDIVIDUAL REPLACE...
							//				}//if  (b_add_at_level(pc_indiv_offspring, iEvolutionLvl + 1) == true)
							//			}//if  (b_can_ind_be_added_at_any_level(pc_indiv_offspring) == true)
							//		}//if  (pc_indiv_offspring  !=  NULL)
							//	}//if  ((v_higher_level_trees_genes.at(iPatternLevel + 1).size() > 0)
							//	
						}//if  (v_higher_level_trees_genes.size() > iPatternLevel)


						i_better_but_cannot_be_added++;
					}//else  if  (b_can_ind_be_added_at_any_level(pc_indiv_reversed_offspring) == true)

				}//if  (pc_indiv_offspring->dComputeFitness()  >  pc_indiv_main->dComputeFitness())			

			}//if  (pc_indiv_reversed_offspring  !=  NULL)

		}//if  (pc_indiv_donator  != NULL)
	}//for  (int  i_donator_lvl = i_max_lvl_number; i_max_lvl_number >= 0; i_max_lvl_number++)


	 /*C3LOIndividual  *pc_indiv_new;
	 pc_indiv_new = pc_get_random_individual();
	 if  (pc_indiv_new != NULL)  b_add_at_level(pc_indiv_new, 0);*/
	return(false);
}//bool  C3LO::b_run_flat_pop_for_ind(C3LOIndividual  *pcIndMain, int  iEvolutionLvl)







void  C3LO::v_tiny_restricted_evolution(C3LOIndividual  *pcParentMain, C3LOIndividual  *pcParentDonator, C3LOIndividual  **pcOffspring, C3LOIndividual  **pcReversedOffspring, int  iPatternLevel, int  iPopDestLvl, int iRepeatation /*= -1*/)
{
	if (v_gene_patterns_trees.size()  <  iPatternLevel)  return;

	C3LOIndividual  *pc_parent_main;
	C3LOIndividual  *pc_offspring = NULL;
	C3LOIndividual  *pc_reversed_offspring = NULL;

	pc_parent_main = pcParentMain;
	bool  b_continue_tribe = true;
	bool  b_updated_after_linkage_gen;
	vector<C3LOPattern *>  v_allowed_trees;


	*pcOffspring = NULL;

	/*FILE  *pf_test;
	pf_test  = fopen("test.txt", "w+");
	fprintf(pf_test, "MAIN:\n");
	pc_parent_main->vSave(pf_test);
	fprintf(pf_test, "DONATOR:\n");
	pcParentDonator->vSave(pf_test);*/

	int  i_iteration = 0;
	b_updated_after_linkage_gen = false;
	while (b_continue_tribe == true)
	{
		b_continue_tribe = false;

		//pc_parent_main->b_optimized = false;
		//pcParentDonator->b_optimized = false;
		pc_parent_main->dComputeFitness(iPatternLevel); //force phenotype creation
		pcParentDonator->dComputeFitness(iPatternLevel); //force phenotype creation



		if (b_produce_new_linkage(pc_parent_main, pcParentDonator, iPatternLevel) == true)
		{
			if (iPatternLevel > 0)
			{
				int  ig = 0;
				ig++;
			}//if  (iPatternLevel > 0)

			if (s_debug != "")
			{
				CString  s_debug_name;

				s_debug_name.Format("%s_patterns_00_before_level_%d.txt", s_debug, iPatternLevel);
				v_save_trees_and_patterns(s_debug_name);
			}//if  (b_debug  == true)


			v_update_high_lvl_genes_and_trees();
			v_create_trees_from_ind(pc_parent_main, &(v_gene_patterns_trees.at(iPatternLevel)), iPatternLevel);

			if (s_debug != "")
			{
				CString  s_debug_name;

				s_debug_name.Format("%s_patterns_parts_from_ind.txt", s_debug);
				pc_parent_main->vSaveGenePatternParts(s_debug_name);
			}//if  (b_debug  == true)



			if (s_debug != "")
			{
				CString  s_debug_name;

				s_debug_name.Format("%s_patterns_01_after_level_%d.txt", s_debug, iPatternLevel);
				v_save_trees_and_patterns(s_debug_name);
			}//if  (b_debug  == true)


			 /*FILE  *pf_before;
			 pf_before = fopen("zz_before.txt", "w+");
			 fprintf(pf_before, "\n\nPATTERNS:\n");
			 for  (int  ii = 0; ii < v_gene_patterns_trees.size(); ii++)
			 v_gene_patterns_trees.at(0).at(ii)->vSavePattern(pf_before, pc_fitness);
			 fclose(pf_before);//*/



			vector<C3LOPattern *>  v_gene_patterns_trees_buf;
			v_gene_patterns_trees_buf = v_gene_patterns_trees.at(iPatternLevel);
			v_gene_patterns_trees.at(iPatternLevel).clear();

			v_build_pattern_tree(&v_gene_patterns_trees_buf, &(v_gene_patterns_trees.at(iPatternLevel)), iPatternLevel);

			v_update_high_lvl_genes_and_trees();


			if (s_debug != "")
			{
				CString  s_debug_name;

				s_debug_name.Format("%s_patterns_02_built_level_%d.txt", s_debug, iPatternLevel);
				v_save_trees_and_patterns(s_debug_name);
			}//if  (b_debug  == true)


			 /*FILE  *pf_after;
			 pf_after = fopen("zz_after.txt", "w+");
			 fprintf(pf_after, "\n\nPATTERNS:\n");
			 for  (int  ii = 0; ii < v_gene_patterns_trees.at(0).size(); ii++)
			 v_gene_patterns_trees.at(0).at(ii)->vSavePattern(pf_after, pc_fitness);
			 fclose(pf_after);*/


			 //::vShow("patterns!");//*/
		}//if  (b_produce_new_linkage(pc_parent_main, pcParentDonator, i_lvl + 1) == true)


		if (b_produce_new_linkage(pc_parent_main, pcParentDonator, iPatternLevel) == true)
		{
			v_update_high_lvl_genes_and_trees();
			v_create_trees_from_ind(pcParentDonator, &(v_gene_patterns_trees.at(iPatternLevel)), iPatternLevel);

			vector<C3LOPattern *>  v_gene_patterns_trees_buf;
			v_gene_patterns_trees_buf = v_gene_patterns_trees.at(iPatternLevel);
			v_gene_patterns_trees.at(iPatternLevel).clear();

			v_build_pattern_tree(&v_gene_patterns_trees_buf, &(v_gene_patterns_trees.at(iPatternLevel)), iPatternLevel);

			v_update_high_lvl_genes_and_trees();
		}//if  (b_produce_new_linkage(pc_parent_main, pcParentDonator, i_lvl + 1) == true)



		if (v_allowed_trees.size() == 0)
		{
			for (int ii = 0; ii < v_gene_patterns_trees.at(iPatternLevel).size(); ii++)
			{
				if (v_gene_patterns_trees.at(iPatternLevel).at(ii)->bMarkedPhenotypeDifferences(pc_parent_main, pcParentDonator, iPatternLevel) == true)  v_allowed_trees.push_back(v_gene_patterns_trees.at(iPatternLevel).at(ii));
			}//for  (int ii = 0; ii < v_gene_patterns_trees.size(); ii++)
		}//if  (v_allowed_trees.size() == 0)

		if (v_allowed_trees.size() > 0)
		{
			int i_chosen_tree;
			//i_chosen_tree = pc_random_gen->Next(0, v_allowed_trees.size());
			i_chosen_tree = RandUtils::iRandNumber(0, v_allowed_trees.size() - 1);

			//b_cross_individuals_by_tree_branch(pc_parent_main, pcParentDonator, &pc_offspring, &pc_reversed_offspring, v_allowed_trees.at(i_chosen_tree), iPatternLevel);
			//b_cross_individuals_by_tree_branch_longest_reasonable_branch(pc_parent_main, pcParentDonator, &pc_offspring, &pc_reversed_offspring, v_allowed_trees.at(i_chosen_tree), iPatternLevel);
			b_cross_individuals_by_tree_branch_or_part(pc_parent_main, pcParentDonator, &pc_offspring, &pc_reversed_offspring, v_allowed_trees.at(i_chosen_tree), iPatternLevel);
			if (*pcReversedOffspring == NULL)  *pcReversedOffspring = pc_reversed_offspring;

			if (pc_offspring != NULL)
			{
				if (pc_parent_main->dComputeFitness(iPatternLevel) >= pc_offspring->dComputeFitness(iPatternLevel))
				{
					C3LOIndividual  *pc_best_update;
					C3LOIndividual  *pc_best_different_ind;

					pc_best_update = NULL;
					pc_best_different_ind = NULL;
					//i_brutal_random_search++;
					if (pcParentMain->bLinkedGenesBrutalSearch(v_allowed_trees.at(i_chosen_tree), iPatternLevel, &(v_gene_patterns_parts_original.at(iPatternLevel)),  &pc_best_update, &pc_best_different_ind) == true)
					{
						if (pc_best_update != NULL)
						{
							pc_best_update->i_level = pcParentMain->i_level + 1;
							//v_remove_from_levels(pcParentMain);
							//if  (b_add_at_level(pc_best_update, 0)  ==  true)  
							pc_offspring = pc_best_update;
						}//if  (pc_best_update != NULL)
					}//if  (pcParentMain->bLinkedGenesBrutalSearch(v_allowed_trees.at(i_chosen_tree), iPatternLevel, &pc_best_update, &pc_best_different_ind)  ==  true)
					else
					{
						if (pc_best_different_ind != NULL)
						{
							pc_best_different_ind->i_level = pcParentMain->i_level - 1;
							if (iPatternLevel  >  0)
							{
								/*FILE  *pf_test;
								pf_test = fopen("zz_most_different_add.txt", "w+");

								fprintf(pf_test, "\n\nMAIN:\n");
								pcParentMain->vSave(pf_test);

								fprintf(pf_test, "\n\nPATTERN:\n");
								v_allowed_trees.at(i_chosen_tree)->vSavePattern(pf_test, pc_fitness, "", true);

								fprintf(pf_test, "\n\nBEST MOST DIFFERENT:\n");
								pc_best_different_ind->vSave(pf_test);

								for  (int i_lvl = v_population_levels.size() - 1; i_lvl >= 0; i_lvl--)
								{
								fprintf(pf_test, "\n\nPOPULATION LEVEL (%d):\n", i_lvl);

								for  (int i_ind = 0; i_ind < v_population_levels.at(i_lvl).size(); i_ind++)
								{
								v_population_levels.at(i_lvl).at(i_ind)->vSave(pf_test);

								}//for  (int i_ind = 0; i_ind < v_population_levels.at(i_lvl).size(); i_ind++)
								}//for  (int i_lvl = 0; i_lvl < v_population_levels.size(); i_lvl++)


								fclose(pf_test);

								::vShow("best most different");//*/
							}//if  (iPatternLevel  >  0)

							 //v_remove_from_levels(pcParentMain);
							 //if  (b_add_at_level(pc_best_different_ind, 0)  ==  true)  pc_offspring = pc_best_different_ind;
							pc_offspring = pc_best_different_ind;
						}//if  (pc_best_different_ind != NULL)
					}//else  if  (pcParentMain->bLinkedGenesBrutalSearch(v_allowed_trees.at(i_chosen_tree), iPatternLevel, &pc_best_update, &pc_best_different_ind)  ==  true)


					 /*pc_best_different_ind = NULL;
					 pc_best_different_ind = NULL;
					 if  (pcParentDonator->bLinkedGenesBrutalSearch(v_allowed_trees.at(i_chosen_tree), iPatternLevel, &pc_best_different_ind, &pc_best_different_ind)  ==  false)
					 {
					 if  (pc_best_different_ind != NULL)
					 {
					 pc_best_different_ind->i_level = pcParentDonator->i_level;
					 b_add_at_level(pc_best_different_ind, 0);
					 }//if  (pc_best_different_ind != NULL)
					 }//if  (pcParentMain->bLinkedGenesBrutalSearch(v_allowed_trees.at(i_chosen_tree), iPatternLevel, &pc_best_different_ind)  ==  false)*/

				}//if  (pc_parent_main->dComputeFitness()  >=  pc_offspring->dComputeFitness())
			}//if  (pc_offspring  !=  NULL)

			v_allowed_trees.erase(v_allowed_trees.begin() + i_chosen_tree);
			if (v_allowed_trees.size() > 0)  b_continue_tribe = true;
		}//if  (v_allowed_trees.size() > 0)
		else
		{
			if (b_updated_after_linkage_gen == true)
			{
				b_updated_after_linkage_gen = false;
				b_continue_tribe = true;
			}//if  (b_updated_after_linkage_gen  ==  true)
		}//else  if  (v_allowed_trees.size() > 0)

		 //fprintf(pf_test, "\nOFFSPRING:\n");

		if (pc_offspring != NULL)
		{
			//pc_offspring->vSave(pf_test);

			if (pc_parent_main->dComputeFitness(iPatternLevel)  <  pc_offspring->dComputeFitness(iPatternLevel))
			{
				/*v_allowed_trees.clear();
				b_continue_tribe = true;*/
				//pc_parent_main = pc_offspring;
				b_updated_after_linkage_gen = true;
			}//if  (pc_parent_main->dComputeFitness()  <  pc_offspring->dComputeFitness())

			pc_parent_main = pc_offspring;
		}//if  (pc_offspring  !=  NULL)

		i_iteration++;
		if (iRepeatation > 0)
		{
			if (i_iteration >= iRepeatation)  b_continue_tribe = false;
		}//if  (iRepeatation > 0) 
	}//while  (b_continue_tribe == true)

	 /*if  (pc_parent_main->dComputeFitness() > pcParentMain->dComputeFitness()) */
	*pcOffspring = pc_parent_main;
	//fclose(pf_test);
}//void  C3LO::v_tiny_restricted_evolution(C3LOIndividual  *pcParent0, C3LOIndividual  *pcParent1, C3LOIndividual  **pcOffspring)




bool  C3LO::b_cross_individuals_by_tree_branch_longest_reasonable_branch(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOIndividual  **pcOffspring, C3LOIndividual  **pcReversedOffspring, C3LOPattern *pcCrossingTree, int  iPatternLevel)
{
	//C3LOIndividual  *pc_best_acceptable_offspring;
	//pc_best_acceptable_offspring = NULL;

	C3LOPattern  *pc_pattern_to_cross;

	pc_pattern_to_cross = pcCrossingTree->pcGetLongestReasonableBranch(pcInd0, pcInd1, pi_genotype_diffr_tool, iPatternLevel);
	if (pc_pattern_to_cross == NULL) return(false);


	if (pc_pattern_to_cross->bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == true)
	{
		b_cross_infect_individual_by_tree(pcInd0, pcInd1, pcOffspring, pc_pattern_to_cross, iPatternLevel);
		if ((*pcOffspring)->dComputeFitness(iPatternLevel) > pcInd0->dComputeFitness(iPatternLevel))  return(true);



		if (((*pcOffspring)->dComputeFitness(iPatternLevel) < pcInd0->dComputeFitness(iPatternLevel)) && (*pcReversedOffspring == NULL))
		{
			b_cross_infect_individual_by_tree(pcInd1, pcInd0, pcReversedOffspring, pc_pattern_to_cross, iPatternLevel);

			if (pc_pattern_to_cross == pcCrossingTree)//if we are at the top of the tree
			{
				if (
					(
					((*pcOffspring)->dComputeFitness(iPatternLevel) > pcInd0->dComputeFitness(iPatternLevel)) &&
						((*pcReversedOffspring)->dComputeFitness(iPatternLevel) > pcInd1->dComputeFitness(iPatternLevel))
						)
					||
					(
					((*pcOffspring)->dComputeFitness(iPatternLevel) < pcInd0->dComputeFitness(iPatternLevel)) &&
						((*pcReversedOffspring)->dComputeFitness(iPatternLevel) < pcInd1->dComputeFitness(iPatternLevel))
						)
					)
				{
					b_add_higher_level_gene(NULL, pcCrossingTree->iGetPatternLevel() + 1);//create level of high level genes
					v_insert_gene_pattern_part_level(pcCrossingTree->iGetPatternLevel() + 1);
					v_add_gene_pattern_tree(NULL, pcCrossingTree->iGetPatternLevel() + 1);
					v_update_high_lvl_genes_and_trees();
				}//if  (
			}//if  (i_pattern == 0)//if we are at the top of the tree



			if ((*pcReversedOffspring)->dComputeFitness(iPatternLevel) < pcInd1->dComputeFitness(iPatternLevel))  *pcReversedOffspring = NULL;

		}//if (((*pcOffspring)->dComputeFitness(iPatternLevel) < pcInd0->dComputeFitness(iPatternLevel)) && (*pcReversedOffspring == NULL))

	}//if  (pcCrossingTree->bMarkedPhenotypeDifferences(pcInd0, pcInd1) == true)


	return(false);
}//bool  C3LO::b_cross_individuals_by_tree_branch_longest_reasonable_branch(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOIndividual  **pcOffspring, C3LOIndividual  **pcReversedOffspring, C3LOPattern *pcCrossingTree, int  iPatternLevel)





bool  C3LO::b_cross_individuals_by_tree_branch_or_part(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOIndividual  **pcOffspring, C3LOIndividual  **pcReversedOffspring, C3LOPattern *pcCrossingTree, int  iPatternLevel)
{
	C3LOPattern  *pc_chosen_pattern;

	pc_chosen_pattern = NULL;

	if (
		(pcCrossingTree->bUnMarkedPhenotypeDifferences(pcInd0, pcInd1, pi_genotype_diffr_tool, iPatternLevel) == true) &&
		(pcCrossingTree->bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == true)
		)
	{
		pc_chosen_pattern = pcCrossingTree;
	}// if (
	else
	{
		vector<C3LOPattern *>  v_gene_pattern_branch;
		pcCrossingTree->vGetRandomTreeBranch(pcInd0, pcInd1, &v_gene_pattern_branch, iPatternLevel);

		int  i_chosen_branch;
		while ((pc_chosen_pattern == NULL) && (v_gene_pattern_branch.size() > 0))
		{
			i_chosen_branch = RandUtils::iRandNumber(0, v_gene_pattern_branch.size() - 1);

			if (
				(v_gene_pattern_branch.at(i_chosen_branch)->bUnMarkedPhenotypeDifferences(pcInd0, pcInd1, pi_genotype_diffr_tool, iPatternLevel) == true) &&
				(v_gene_pattern_branch.at(i_chosen_branch)->bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == true)
				)
			{
				pc_chosen_pattern = v_gene_pattern_branch.at(i_chosen_branch);
			}// if (

			v_gene_pattern_branch.erase(v_gene_pattern_branch.begin() + i_chosen_branch);		
		}//while ((pc_chosen_pattern == NULL) && (v_gene_pattern_branch.size() > 0))
	
	}//else  if  (

	
	if (pc_chosen_pattern != NULL)
	{
		int  i_effect_already_exists_in_the_pop;

		b_cross_infect_individual_by_tree(pcInd0, pcInd1, pcOffspring, pc_chosen_pattern, iPatternLevel);
		if ((*pcOffspring)->dComputeFitness(iPatternLevel) > pcInd0->dComputeFitness(iPatternLevel))  return(true);



		if (((*pcOffspring)->dComputeFitness(iPatternLevel) < pcInd0->dComputeFitness(iPatternLevel)) && (*pcReversedOffspring == NULL))
		{
			b_cross_infect_individual_by_tree(pcInd1, pcInd0, pcReversedOffspring, pc_chosen_pattern, iPatternLevel);

			if (pc_chosen_pattern == pcCrossingTree)//if we are at the top of the tree
			{
				if (
					(
					((*pcOffspring)->dComputeFitness(iPatternLevel) > pcInd0->dComputeFitness(iPatternLevel)) &&
						((*pcReversedOffspring)->dComputeFitness(iPatternLevel) > pcInd1->dComputeFitness(iPatternLevel))
						)
					||
					(
					((*pcOffspring)->dComputeFitness(iPatternLevel) < pcInd0->dComputeFitness(iPatternLevel)) &&
						((*pcReversedOffspring)->dComputeFitness(iPatternLevel) < pcInd1->dComputeFitness(iPatternLevel))
						)
					)
				{
					b_add_higher_level_gene(NULL, pcCrossingTree->iGetPatternLevel() + 1);//create level of high level genes
					v_insert_gene_pattern_part_level(pcCrossingTree->iGetPatternLevel() + 1);
					v_add_gene_pattern_tree(NULL, pcCrossingTree->iGetPatternLevel() + 1);
					v_update_high_lvl_genes_and_trees();
				}//if  (
			}//if (pc_chosen_pattern == pcCrossingTree)//if we are at the top of the tree

			if ((*pcReversedOffspring)->dComputeFitness(iPatternLevel) < pcInd1->dComputeFitness(iPatternLevel))  *pcReversedOffspring = NULL;

		}//if  ((*pcOffspring)->dComputeFitness() < pcInd0->dComputeFitness())
	
	}//if (pc_chosen_pattern != NULL)


	return(false);
}//bool  C3LO::




bool  C3LO::b_cross_individuals_by_tree_branch(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOIndividual  **pcOffspring, C3LOIndividual  **pcReversedOffspring, C3LOPattern *pcCrossingTree, int  iPatternLevel)
{
	//C3LOIndividual  *pc_best_acceptable_offspring;
	//pc_best_acceptable_offspring = NULL;

	//if (bUnMarkedPhenotypeDifferences(pcInd0, pcInd1, piDifferenceSearchTool, iPatternLevel) == true)  return(this);
	if (pcCrossingTree->bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == true)
	{
		C3LOPattern *pc_best_crossing_node;

		vector<C3LOPattern *>  v_gene_pattern_branch;
		pcCrossingTree->vGetRandomTreeBranch(pcInd0, pcInd1, &v_gene_pattern_branch, iPatternLevel);


		/*int i_chosen_tree;
		i_chosen_tree = pc_random_gen->Next(0, v_allowed_trees.size());*/

		int  i_effect_already_exists_in_the_pop;
		for (int i_pattern = 0; i_pattern < 1;/*v_gene_pattern_branch.size()*/ i_pattern++)
		{
			b_cross_infect_individual_by_tree(pcInd0, pcInd1, pcOffspring, v_gene_pattern_branch.at(i_pattern), iPatternLevel);
			if ((*pcOffspring)->dComputeFitness(iPatternLevel) > pcInd0->dComputeFitness(iPatternLevel))  return(true);



			if (((*pcOffspring)->dComputeFitness(iPatternLevel) < pcInd0->dComputeFitness(iPatternLevel)) && (*pcReversedOffspring == NULL))
			{
				b_cross_infect_individual_by_tree(pcInd1, pcInd0, pcReversedOffspring, v_gene_pattern_branch.at(i_pattern), iPatternLevel);

				if (i_pattern == 0)//if we are at the top of the tree
				{
					if (
						(
						((*pcOffspring)->dComputeFitness(iPatternLevel) > pcInd0->dComputeFitness(iPatternLevel)) &&
							((*pcReversedOffspring)->dComputeFitness(iPatternLevel) > pcInd1->dComputeFitness(iPatternLevel))
							)
						||
						(
						((*pcOffspring)->dComputeFitness(iPatternLevel) < pcInd0->dComputeFitness(iPatternLevel)) &&
							((*pcReversedOffspring)->dComputeFitness(iPatternLevel) < pcInd1->dComputeFitness(iPatternLevel))
							)
						)
					{
						b_add_higher_level_gene(NULL, pcCrossingTree->iGetPatternLevel() + 1);//create level of high level genes
						v_insert_gene_pattern_part_level(pcCrossingTree->iGetPatternLevel() + 1);
						v_add_gene_pattern_tree(NULL, pcCrossingTree->iGetPatternLevel() + 1);
						v_update_high_lvl_genes_and_trees();
					}//if  (
				}//if  (i_pattern == 0)//if we are at the top of the tree

		

				if ((*pcReversedOffspring)->dComputeFitness(iPatternLevel) < pcInd1->dComputeFitness(iPatternLevel))  *pcReversedOffspring = NULL;

			}//if  ((*pcOffspring)->dComputeFitness() < pcInd0->dComputeFitness())
		}//if  (pc_best_crossing_node !=  NULL)*/
	}//if  (pcCrossingTree->bMarkedPhenotypeDifferences(pcInd0, pcInd1) == true)


	return(false);
}//bool  C3LO::




bool  C3LO::b_cross_individuals_by_tree(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOIndividual  **pcOffspring, C3LOPattern *pcCrossingTree, int iPatternLevel)
{
	//first do crossing with current tree node



	if (pcCrossingTree->bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == true)
	{
		C3LOPattern *pc_best_crossing_node;

		pc_best_crossing_node = pcCrossingTree->pcGetBestCrossingNode(iPatternLevel, pcInd0, pcInd1);

		if (pc_best_crossing_node != NULL)
		{
			return(b_cross_infect_individual_by_tree(pcInd0, pcInd1, pcOffspring, pc_best_crossing_node, iPatternLevel));
		}//if  (pc_best_crossing_node !=  NULL)



		 /*v_cross_infect_individual_by_tree(pcInd0, pcInd1, pcCrossingTree);
		 v_cross_infect_individual_by_tree(pcInd1, pcInd0, pcCrossingTree);


		 //second execute crossing for children nodes
		 for  (int i_child_tree = 0; i_child_tree < pcCrossingTree->pvGetChildren()->size(); i_child_tree++)
		 {
		 v_cross_individuals_by_tree(pcInd0, pcInd1, pcCrossingTree->pvGetChildren()->at(i_child_tree));
		 }//for  (i_child_tree = 0; i_child_tree < pcCrossingTree->pvGetChildren()->size(); i_child_tree++)*/
	}//if  (pcCrossingTree->bMarkedPhenotypeDifferences(pcInd0, pcInd1) == true)

	return(false);
}//void  C3LO::v_cross_individuals_by_tree(C3LOIndividual  *pcInd0, C3LOIndividual  *pcInd1, C3LOPattern *pcCrossingTree)




bool  C3LO::b_cross_infect_individual_by_tree(C3LOIndividual  *pcInd, C3LOIndividual  *pcDonator, C3LOIndividual  **pcOffspring, C3LOPattern *pcCrossingTree, int iPatternLevel)
{
	pcInd->dComputeFitness(iPatternLevel);
	pcDonator->dComputeFitness(iPatternLevel);

	*pcOffspring = new C3LOIndividual(i_templ_length, pc_problem, &v_optimization_orders, this);

	for (int i_gene = 0; i_gene < i_templ_length; i_gene++)
		(*pcOffspring)->pi_genotype[i_gene] = pcInd->pi_genotype[i_gene];

	for (int ii = 0; ii < pcCrossingTree->pvGetPattern()->size(); ii++)
		(*pcOffspring)->pi_genotype[pcCrossingTree->pvGetPattern()->at(ii).iGenePos()] = pcDonator->pi_genotype[pcCrossingTree->pvGetPattern()->at(ii).iGenePos()];

	(*pcOffspring)->b_optimized = false;
	(*pcOffspring)->d_fit_value = 0;



	C3LOIndividual  *pc_inserted_individual;
	pc_inserted_individual = pc_insert_into_pop(pv_population, *pcOffspring);

	i_all_crossings++;
	//if the result if crossing already exists then add new individual
	if (b_can_ind_be_added_at_any_level(pc_inserted_individual) == false)
	{
		i_crossings_with_effect_in_the_pop++;
	}//if  (b_can_ind_be_added_at_any_level(pc_inserted_individual)  ==  false)
	else
	{
		if (pc_inserted_individual->dComputeFitness(iPatternLevel) > pcInd->dComputeFitness(iPatternLevel))  i_upgraded_new_ind++;
	}//else  if  (b_can_ind_be_added_at_any_level(pc_inserted_individual)  ==  false)


	if (pc_inserted_individual != (*pcOffspring))
	{
		delete  (*pcOffspring);
		*pcOffspring = pc_inserted_individual;

		return(false);
	}//if  (b_insert_into_pop(pc_indiv)  ==  false)

	return(true);
}//void  C3LO::v_cross_infect_individual_by_tree(C3LOIndividual  *pcInd, C3LOIndividual  *pcDonator, C3LOPattern *pcCrossingTree)






void  C3LO::v_remove_from_levels(C3LOIndividual *pcInd)
{
	for (int i_lvl = 0; i_lvl < v_population_levels.size(); i_lvl++)
	{
		for (int i_ind = 0; i_ind < v_population_levels.at(i_lvl).size(); i_ind++)
		{
			if (v_population_levels.at(i_lvl).at(i_ind) == pcInd)
				v_population_levels.at(i_lvl).erase
				(
					v_population_levels.at(i_lvl).begin() + i_ind
				);

		}//for  (int ii = 0; ii < v_population_levels.at(iLevel).size(); ii++)
	}//for  (int i_lvl = 0; i_lvl < v_population_levels.size(); i_lvl++)

}//void  C3LO::v_remove_from_levels(C3LOIndividual *pcInd)




void  C3LO::v_build_pattern_tree(vector<C3LOPattern  *>  *pvGenePatternsParts, vector<C3LOPattern  *>  *pvGenePatternsTrees, int  iLevel)
{
	vector<C3LOPattern  *>  v_parts_buffer;

	v_parts_buffer = *pvGenePatternsParts;

	//first build pattern pairs similarity
	vector<C3LOPatternPair>  v_pattern_pairs;
	int  i_common_positions;
	C3LOPatternPair  c_buffer;

	for (int i_first = 0; i_first < v_parts_buffer.size(); i_first++)
	{
		for (int i_second = i_first + 1; i_second < v_parts_buffer.size(); i_second++)
		{
			i_common_positions =
				v_parts_buffer.at(i_first)->iCommonPositions
				(
					v_parts_buffer.at(i_second), false, false
				);

			if (i_common_positions > 0)
			{
				c_buffer.d_similarity = i_common_positions;
				c_buffer.pc_first = v_parts_buffer.at(i_first);
				c_buffer.pc_second = v_parts_buffer.at(i_second);

				v_pattern_pairs.push_back(c_buffer);
			}//if  (i_common_positions > 0)

		}//for  (int  i_second = i_first + 1; i_second < v_parts_buffer.size(); i_second++)
	}//for  (int  i_first = 0; i_first < v_parts_buffer.size(); i_first++)


	double  d_most_similar;
	int  i_most_similar_offset = -1;
	d_most_similar = d_get_most_similar_pattern_pair_offset(&i_most_similar_offset, &v_pattern_pairs);

	int  i_common_pos, i_uncommon_pos, i_unmarked_pos;
	C3LOPattern  *pc_joined_pattern;
	while (i_most_similar_offset >= 0)
	{
		v_pattern_pairs.at(i_most_similar_offset).pc_first->vGetCommonAndUNcommonPositions(v_pattern_pairs.at(i_most_similar_offset).pc_second, &i_common_pos, &i_uncommon_pos, &i_unmarked_pos);


		if ((i_unmarked_pos == 0) || (i_uncommon_pos == 0))
		{
			if (i_unmarked_pos == 0)
			{
				pc_joined_pattern = v_pattern_pairs.at(i_most_similar_offset).pc_first;
				pc_joined_pattern->vJoinSinglePatternAdd(v_pattern_pairs.at(i_most_similar_offset).pc_second);


				//v_remove_pattern_from_buffer(&v_parts_buffer, v_pattern_pairs.at(i_most_similar_offset).pc_first);
				//v_remove_pattern_from_pairs_buffer(&v_pattern_pairs, v_pattern_pairs.at(i_most_similar_offset).pc_first);
			}//if  (i_unmarked_pos  ==  0)
			else
			{
				pc_joined_pattern = v_pattern_pairs.at(i_most_similar_offset).pc_second;
				pc_joined_pattern->vJoinSinglePatternAdd(v_pattern_pairs.at(i_most_similar_offset).pc_first);


				//v_remove_pattern_from_buffer(&v_parts_buffer, v_pattern_pairs.at(i_most_similar_offset).pc_second);
				//v_remove_pattern_from_pairs_buffer(&v_pattern_pairs, v_pattern_pairs.at(i_most_similar_offset).pc_second);
			}//else  if  (i_unmarked_pos  ==  0)

			v_remove_pattern_from_buffer(&v_parts_buffer, pc_joined_pattern);
			v_remove_pattern_from_pairs_buffer(&v_pattern_pairs, pc_joined_pattern);
		}//if  ((i_unmarked_pos  ==  0)||(i_uncommon_pos  ==  0))
		else
		{
			pc_joined_pattern = new C3LOPattern(i_templ_length);
			pc_joined_pattern->vJoinTwoPatterns(v_pattern_pairs.at(i_most_similar_offset).pc_first, v_pattern_pairs.at(i_most_similar_offset).pc_second);
		}//else  if  ((i_unmarked_pos  ==  0)||(i_uncommon_pos  ==  0))

		 //PRW FINISHED HERE


		 //now remove joined patterns from buffer (but DO NOT DELETE, the parts buffer IS NOT the owner)


		 /*FILE  *pf_test;
		 pf_test = fopen("tesdt.txt", "w+");

		 //fprintf(pf_test,"similarity: %.2lf\n\n\n", (v_pattern_pairs.at(i_most_similar_offset).d_similarity));
		 //v_pattern_pairs.at(i_most_similar_offset).pc_first->vSavePattern(pf_test, pc_fitness);
		 //v_pattern_pairs.at(i_most_similar_offset).pc_second->vSavePattern(pf_test, pc_fitness);

		 //fprintf(pf_test,"AFTER JOIN: \n\n\n");

		 pc_joined_pattern->vSavePattern(pf_test, pc_fitness);

		 fclose(pf_test);

		 ::Tools::vShow(i_most_similar_offset);//*/


		for (int i_child = 0; i_child < pc_joined_pattern->pvGetChildren()->size(); i_child++)
		{
			v_remove_pattern_from_buffer(&v_parts_buffer, pc_joined_pattern->pvGetChildren()->at(i_child));
			v_remove_pattern_from_pairs_buffer(&v_pattern_pairs, pc_joined_pattern->pvGetChildren()->at(i_child));
		}//for  (int  i_child = 0; i_child < pc_joined_pattern->pvGetChildren()->size(); i_child++)


		 //now add pairs for a new part
		for (int i_other = 0; i_other < v_parts_buffer.size(); i_other++)
		{
			i_common_positions =
				v_parts_buffer.at(i_other)->iCommonPositions
				(
					pc_joined_pattern, false, false
				);

			if (i_common_positions > 0)
			{
				c_buffer.d_similarity = i_common_positions;
				c_buffer.pc_first = pc_joined_pattern;
				c_buffer.pc_second = v_parts_buffer.at(i_other);

				v_pattern_pairs.push_back(c_buffer);
			}//if  (i_common_positions > 0)
		}//for  (int  i_other = 0; i_other < v_parts_buffer.size(); i_other++)

		v_parts_buffer.push_back(pc_joined_pattern);

		d_most_similar = d_get_most_similar_pattern_pair_offset(&i_most_similar_offset, &v_pattern_pairs);
	}//while  (i_most_similar_offset >= 0)




	 /*FILE  *pf_test;
	 pf_test = fopen("tesdt.txt", "w+");


	 for  (int  ii = 0; ii < v_parts_buffer.size(); ii++)
	 {
	 v_parts_buffer.at(ii)->vSavePattern(pf_test, pc_fitness);
	 }//for  (int  ii = 0; ii < v_parts_buffer.size(); ii++)

	 fclose(pf_test);

	 ::Tools::vShow(v_parts_buffer.size());//*/

	*pvGenePatternsTrees = v_parts_buffer;

	v_add_linkage_covering_at_level(iLevel);
	for (int i_tree = 0; i_tree < pvGenePatternsTrees->size(); i_tree++)
	{
		for (int i_gene_offset = 0; i_gene_offset < pvGenePatternsTrees->at(i_tree)->pvGetPattern()->size(); i_gene_offset++)
		{
			v_genes_marked_by_linkage.at(iLevel)[pvGenePatternsTrees->at(i_tree)->pvGetPattern()->at(i_gene_offset).iGenePos()] = 1;
			//pi_genes_marked_by_linkage[pvGenePatternsTrees->at(i_tree)->pvGetPattern()->at(i_gene_offset).iGenePos()] = 1;
		}//for  (int i_gene_offset = 0; i_gene_offset < pvGenePatternsTrees->at(i_tree)->pvGetPattern()->size(); i_gene_offset++)
	}//for  (int i_tree = 0; i_tree < pvGenePatternsTrees->size(); i_tree++)
}//void  C3LO::v_build_pattern_tree(vector<C3LOPattern  *>  *pvGenePatternsParts, vector<C3LOPattern  *>  *pvGenePatternsTrees)





void  C3LO::v_update_high_lvl_genes_and_trees()
{
	vector<C3LOPattern *> v_gene_candidates;
	C3LOPattern  *pc_pattern;


	for (int i_lvl = 1; i_lvl < v_gene_patterns_trees.size(); i_lvl++)
	{
		if (i_lvl >= v_higher_level_trees_genes.size())  b_add_higher_level_gene(NULL, i_lvl);

		if (i_lvl == 2)
		{
			int ig = 0;
			ig++;
		}//if  (i_lvl  == 2)


		v_gene_candidates.clear();

		for (int i_tree = 0; i_tree < v_gene_patterns_trees.at(i_lvl - 1).size(); i_tree++)
			v_gene_patterns_trees.at(i_lvl - 1).at(i_tree)->vGetBestCovering(&v_gene_candidates, NULL, i_lvl - 1);

		for (int i_candidate = 0; i_candidate < v_gene_candidates.size(); i_candidate++)
		{
			pc_pattern = new C3LOPattern(i_templ_length);
			pc_pattern->i_pattern_level = v_gene_candidates.at(i_candidate)->iGetPatternLevel() + 1;
			pc_pattern->v_pattern = v_gene_candidates.at(i_candidate)->v_pattern;

			b_add_higher_level_gene(pc_pattern, i_lvl);
		}//for  (int i_candidate = 0; i_candidate < v_gene_candidates.size(); i_candidate++)
	}//for  (int  i_lvl = 1; i_lvl < v_gene_patterns_trees.size(); i_lvl++)


	v_count_higher_genes_freq();
	/*
	vector<C3LOPattern *> v_diffr_covering_patterns;
	C3LOPattern *pc_best_covering_pattern;


	for  (int i_tree = 0; i_tree < v_gene_patterns_trees.at(pcCrossingTree->iGetPatternLevel()).size(); i_tree++)
	v_gene_patterns_trees.at(pcCrossingTree->iGetPatternLevel()).at(i_tree)->vGetBestCovering(&v_diffr_covering_patterns, pi_differences, pcCrossingTree->iGetPatternLevel());
	*/

}//void  C3LO::v_update_high_lvl_genes_and_trees()



void  C3LO::v_create_trees_from_ind(C3LOIndividual  *pcIndiv, vector<C3LOPattern *>  *pvTreesDest, int iPatternLevel)
{
	if (pcIndiv->bGetTreesGenerated(iPatternLevel) == false)
	{
		v_insert_gene_pattern_part_level(iPatternLevel);
		pcIndiv->vGeneratePatternSingle(&(v_gene_patterns_parts.at(iPatternLevel)), &(v_gene_patterns_parts_original.at(iPatternLevel)), iPatternLevel);
		v_build_pattern_tree(&(pcIndiv->v_gene_patterns_parts.at(iPatternLevel)), &(pcIndiv->v_gene_patterns_trees.at(iPatternLevel)), iPatternLevel);

		for (int i_new_tree = 0; i_new_tree < pcIndiv->v_gene_patterns_trees.at(iPatternLevel).size(); i_new_tree++)
			pvTreesDest->push_back(pcIndiv->v_gene_patterns_trees.at(iPatternLevel).at(i_new_tree));
	}//if  (pv_population->at(ii)->bGetTreesGenerated() ==  false)

}//void  C3LO::v_create_trees_from_ind_high_lvl(C3LOIndividual  *pcIndiv, vector<C3LOPattern *>  *pvTreesDest, int iPatternLevel)




void  C3LOIndividual::vGeneratePatternSingle(vector<C3LOPattern  *>  *pvGenePatternsParts, vector<C3LOPattern  *>  *pvGenePatternsPartsOriginal, int iPatternLevel)
{
	if (iPatternLevel  >  0)  b_optimized = false;//in case high level genes have changed (if so then this may lead to the wrong linkage
	dComputeFitness(iPatternLevel, true);//force phenotype creation

	if (iPatternLevel  <  v_gene_patterns_parts.size())
	{
		if (v_gene_patterns_parts.at(iPatternLevel).size() > 0)  return;
	}//if  (iPatternLevel  <  v_gene_patterns_parts.size())
	else
	{
		while (iPatternLevel >= v_gene_patterns_parts.size())  v_gene_patterns_parts.push_back(vector<C3LOPattern *>());
		while (iPatternLevel >= v_gene_patterns_trees.size())  v_gene_patterns_trees.push_back(vector<C3LOPattern *>());
	}//else  if  (iPatternLevel  <  v_gene_patterns_parts.size())

	vGetPatternsParts(&v_gene_patterns_parts.at(iPatternLevel), iPatternLevel);
	
	C3LOPattern  *pc_pattern;
	for (int ii = 0; ii < v_gene_patterns_parts.at(iPatternLevel).size(); ii++)
	{
		pc_pattern = new C3LOPattern(i_templ_length);
		pc_pattern->v_pattern = v_gene_patterns_parts.at(iPatternLevel).at(ii)->v_pattern;
		pvGenePatternsPartsOriginal->push_back(pc_pattern);
	}//for (int ii = 0; ii < v_gene_patterns_parts.at(iPatternLevel).size(); ii++)
	


	for (int ii = 0; ii < v_gene_patterns_parts.at(iPatternLevel).size(); ii++)
	{
		if (v_gene_patterns_parts.at(iPatternLevel).at(ii)->bAmIThere(pvGenePatternsParts) == false)
			pvGenePatternsParts->push_back(v_gene_patterns_parts.at(iPatternLevel).at(ii));
	}//for  (int  ii = 0; ii < v_gene_patterns_parts.size(); ii++)


	while (iPatternLevel >= v_pattern_generated.size())  v_pattern_generated.push_back(false);
	v_pattern_generated.at(iPatternLevel) = true;
}//void  C3LOIndividual::vGeneratePatternSingle(vector<C3LOPattern  *>  *pvGenePatternsParts, vector<C3LOPattern  *>  *pvGenePatternsPartsOriginal, int iPatternLevel)




void  C3LOIndividual::vGetPatternsParts(vector<C3LOPattern  *>  *pvGenePatternsParts, int iPatternLevel)
{
	if (iPatternLevel == 0)
		v_get_patterns_parts_zero_level(pvGenePatternsParts);
	else
		v_get_patterns_parts_high_level(pvGenePatternsParts, iPatternLevel);
}//void  C3LOIndividual::vGetMaskedPatternsParts(vector<C3LOPattern  *>  *pvGenePatternsParts, vector<CMessyGene>  *pvMask)






bool  C3LOIndividual::b_phenotypes_the_same(int  iPosition, C3LOIndividual *pcOther)
{
	CString  s_buf;

	for (int i_order = 0; i_order < pv_optimization_orders->size(); i_order++)
	{
		//s_buf.Format("ORDERS: %d order %d   pos: %d", pv_optimization_orders->size(), i_order, iPosition);
		//::Tools::vReportInFile("test.txt", s_buf);

		if (pi_optimized_genotypes[i_order][iPosition] != pcOther->pi_optimized_genotypes[i_order][iPosition])  return(false);
	}//for  (int  i_order = 0; i_order < pv_optimization_orders->size(); i_order++)

	return(true);
}//bool  C3LOIndividual::b_phenotypes_the_same(int  iPosition)




void  C3LOIndividual::v_get_patterns_parts_zero_level(vector<C3LOPattern  *>  *pvGenePatternsParts)
{
	dComputeFitness(0);//force phenotype creation

	vector<CMessyGene>  v_new_pattern;
	C3LOPattern  *pc_pattern;


	int i_gene_val;
	C3LOIndividual  c_disturbed(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);


	for (int i_gene_pos = 0; i_gene_pos < i_templ_length; i_gene_pos++)
	{
		vCopyTo(&c_disturbed);

		i_gene_val = pi_genotype[i_gene_pos];

		if (i_gene_val == 0)
			i_gene_val = 1;
		else
			i_gene_val = 0;

		c_disturbed.pi_genotype[i_gene_pos] = i_gene_val;
		c_disturbed.b_optimized = false;
		c_disturbed.dComputeFitness(0);

		v_new_pattern.clear();
		for (int i_gene_offset = 0; i_gene_offset < i_templ_length; i_gene_offset++)
		{
			if (b_phenotypes_the_same(i_gene_offset, &c_disturbed) == false)
			{
				if (c_disturbed.dComputeFitness(0) > dComputeFitness(0))
					v_new_pattern.push_back(CMessyGene(c_disturbed.pi_genotype[i_gene_offset], i_gene_offset));
				else
					v_new_pattern.push_back(CMessyGene(pi_genotype[i_gene_offset], i_gene_offset));
			}//if  (b_phenotypes_the_same(i_gene_pos_for_check, &c_disturbed)  ==  false)
		}//for  (int  i_gene_offset = 0; i_gene_offset < pvMask->size(); i_gene_offset++)

		 /*if  (ii  ==  15)
		 {
		 FILE  *pf_test;
		 pf_test = fopen("test.txt", "w+");
		 c_disturbed.vSave(pf_test);
		 fclose(pf_test);
		 }//if  (ii  ==  15)*/

		if (v_new_pattern.size() > 1)
		{
			pc_pattern = new C3LOPattern(i_templ_length);
			pc_pattern->v_pattern = v_new_pattern;
			pc_pattern->i_pattern_level = 0;
			pvGenePatternsParts->push_back(pc_pattern);


			/*FILE  *pf_test;
			pf_test = fopen("test.txt", "w+");

			pc_pattern->vSavePattern(pf_test, pc_fitness);
			this->vSave(pf_test);
			c_disturbed.vSave(pf_test);
			fclose(pf_test);

			::vShow(0);//*/
		}//if  (v_new_pattern.size() > 1)


	}//for  (int  ii = 0; ii < pvMask->size(); ii++)
}//void  C3LOIndividual::v_get_patterns_parts_zero_level(vector<C3LOPattern  *>  *pvGenePatternsParts, int iPatternLevel)



void  C3LOIndividual::v_get_patterns_parts_high_level(vector<C3LOPattern  *>  *pvGenePatternsParts, int iPatternLevel)
{
	if (iPatternLevel >= pc_parent->pvGetHigherLevelTreesGenes()->size())  return;

	dComputeFitness(iPatternLevel);//force phenotype creation

	C3LOPattern  *pc_pattern;
	int  *pi_pattern;
	bool  b_pat_with_at_least_one_val;

	int i_gene_pos_for_check;
	int i_gene_val;
	C3LOIndividual  c_disturbed(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
	vector<C3LOHighLvlGeneFreq  *>  *pv_gene_freq;

	pi_pattern = new int[i_templ_length];

	for (int i_high_gene_offset = 0; i_high_gene_offset < pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).size(); i_high_gene_offset++)
	{
		pv_gene_freq = pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).at(i_high_gene_offset)->pvGetHighLevelGeneFreq();

		for (int i_gene_freq = 0; (i_gene_freq < pv_gene_freq->size()) && (i_gene_freq < C3LO_INDIVIDUAL_MAX_HIGH_LEVEL_GENES_VALUES); i_gene_freq++)
		{
			vCopyTo(&c_disturbed);
			b_pat_with_at_least_one_val = false;
			for (int ii = 0; ii < i_templ_length; ii++)
				pi_pattern[ii] = 0;

			pv_gene_freq->at(i_gene_freq)->vInfect(&c_disturbed);
			c_disturbed.b_optimized = false;
			c_disturbed.dComputeFitness(iPatternLevel);

			for (int i_gene_offset = 0; i_gene_offset < i_templ_length; i_gene_offset++)
			{
				if (b_phenotypes_the_same(i_gene_offset, &c_disturbed) == false)
				{
					pi_pattern[i_gene_offset] = 1;
					b_pat_with_at_least_one_val = true;
				}//if  (b_phenotypes_the_same(i_gene_pos_for_check, &c_disturbed)  ==  false)
			}//for  (int  i_gene_offset = 0; i_gene_offset < pvMask->size(); i_gene_offset++)


			 //pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).at(0)->bCommonPositionsWithTableMark(pi_pattern);
			 //pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).at(0)->vInfectTableMark(pi_pattern);
			 /*if  (ii  ==  15)
			 {
			 FILE  *pf_test;
			 pf_test = fopen("test.txt", "w+");
			 c_disturbed.vSave(pf_test);
			 fclose(pf_test);
			 }//if  (ii  ==  15)*/

			if (b_pat_with_at_least_one_val == true)
			{



				pc_pattern = new C3LOPattern(i_templ_length);
				pc_pattern->i_pattern_level = iPatternLevel;
				for (int ii = 0; ii < i_templ_length; ii++)
				{
					if (pi_pattern[ii] == 1)  pc_pattern->v_pattern.push_back(CMessyGene(1, ii));
				}//for  (int  ii = 0; ii < i_templ_length; ii++)	


				int  i_common_pos, i_uncommon_pos, i_unmarked_pos;
				pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).at(i_high_gene_offset)->vGetCommonAndUNcommonPositions
				(pc_pattern, &i_common_pos, &i_uncommon_pos, &i_unmarked_pos);

				//we add new pattern only if the differences are more than the disturbed high level gene
				if (i_unmarked_pos  >  0)
					pvGenePatternsParts->push_back(pc_pattern);
				else
					delete  pc_pattern;


				/*FILE  *pf_test;
				pf_test = fopen("test.txt", "w+");

				pc_pattern->vSavePattern(pf_test, pc_fitness);
				this->vSave(pf_test);
				c_disturbed.vSave(pf_test);
				fclose(pf_test);

				::vShow(0);//*/
			}//if  (b_pat_with_at_least_one_val == true)
		}//for  (int  i_gene_freq = 0; i_gene_freq < pv_gene_freq->size(); i_gene_freq++)		
	}//for  (int  i_high_gene_offset = 0; i_high_gene_offset < pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).size(); i_high_gene_offset++)

	delete  pi_pattern;
}//void  C3LOIndividual::v_get_patterns_parts_zero_level(vector<C3LOPattern  *>  *pvGenePatternsParts, int iPatternLevel)






void  C3LO::v_save_trees_and_patterns(CString  sPatternFile)
{
	FILE  *pf_test;

	pf_test = fopen(sPatternFile, "w+");
	fprintf(pf_test, "\n\nPATTERNS:\n");
	for (int i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)
	{
		fprintf(pf_test, "\n\nPATTERN LEVEL: %d\n", i_pat_lvl);

		//for (int ii = 0; ii < v_gene_patterns_trees.at(i_pat_lvl).size(); ii++)
			//v_gene_patterns_trees.at(i_pat_lvl).at(ii)->vSavePattern(pf_test, NULL, "", true);

		for (int ii = 0; ii < v_gene_patterns_parts_original.at(i_pat_lvl).size(); ii++)
			v_gene_patterns_parts_original.at(i_pat_lvl).at(ii)->vSavePattern(pf_test, NULL, "", false);



		if (i_pat_lvl < v_higher_level_trees_genes.size())
		{
			fprintf(pf_test, "\n\nPATTERN LEVEL GENES: %d\n", i_pat_lvl);

			for (int ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
			{
				v_higher_level_trees_genes.at(i_pat_lvl).at(ii)->vSavePattern(pf_test, NULL, "", true);
			}//for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
		}//if  (i_pat_lvl < v_higher_level_trees_genes.size())
	}//for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)


	fprintf(pf_test, "\n\nHIGH LEVEL GENES FREQ:\n");
	for (int i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)
	{
		if (i_pat_lvl < v_higher_level_trees_genes.size())
		{
			for (int ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
			{
				v_higher_level_trees_genes.at(i_pat_lvl).at(ii)->vSaveHighLevelGene(pf_test, NULL);
				fprintf(pf_test, "\n");
			}//for  (int  ii = 0; ii < v_higher_level_trees_genes.at(i_pat_lvl).size(); ii++)
		}//if  (i_pat_lvl < v_higher_level_trees_genes.size())
	}//for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)



	fprintf(pf_test, "\n\nPOPULATION: %d\n", v_population_levels.at(0).size());
	for (int i_ind = 0; i_ind < v_population_levels.at(0).size(); i_ind++)
	{
		v_population_levels.at(0).at(i_ind)->vSave(pf_test, NULL, true);
	}//for  (int  i_ind = 0; i_ind < v_population_levels.at(0).size(); i_ind++)

	fclose(pf_test);//*/
}//void  C3LO::v_save_trees_and_patterns(CString  sPatternFile)





double C3LO::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_compute_fitness_value(piBits);
	return(d_fitness_value);
}//double C3LO::dComputeFitness(int32_t *piBits)




 //---------------------------------------------C3LOIndividual-------------------------------------------------------
C3LOIndividual::C3LOIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, vector<vector<int>> *pvOptimizationOrders, C3LO  *pcParent)
{
	i_templ_length = iTemplLength;

	pi_genotype = new int[i_templ_length];


	pc_problem = pcProblem;

	pv_optimization_orders = pvOptimizationOrders;

	pi_optimized_genotypes = new int*[pv_optimization_orders->size()];
	for (int ii = 0; ii < pv_optimization_orders->size(); ii++)
	{
		pi_optimized_genotypes[ii] = new int[i_templ_length];
	}//for  (int  ii = 0; ii < pvOptimizationOrders->size(); ii++)

	pd_fit_values = new double[pvOptimizationOrders->size()];

	b_optimized = false;
	b_trees_generated = false;



	pc_parent = pcParent;
	i_level = 0;
	i_optimized_at_pattern_level = 0;
}//C3LOIndividual::C3LOIndividual(int  iTemplLength, gcroot<Random*> pcRandomGen, CConcatDecFunc  *pcFitness, vector<vector<int>> *pvOptimizationOrders)



C3LOIndividual::~C3LOIndividual()
{
	if (pi_genotype != NULL)  delete  pi_genotype;
	if (pd_fit_values != NULL)  delete  pd_fit_values;


	if (pi_optimized_genotypes != NULL)
	{
		//::Tools::vShow("kas");
		//::Tools::vShow(pv_optimization_orders->size());
		for (int ii = 0; ii < pv_optimization_orders->size(); ii++)
		{
			//::Tools::vShow(ii);
			delete[] pi_optimized_genotypes[ii];
		}//for  (int  ii = 0; ii < pvOptimizationOrders->size(); ii++)

		 //::Tools::vShow("delete  [] pi_optimized_genotypes;");
		delete[] pi_optimized_genotypes;
	}//if  (pi_optimized_genotype  !=  NULL)


	//for (int ii = 0; ii < v_gene_patterns_trees.size(); ii++)
		//delete  v_gene_patterns_trees.at(ii);
}//C3LOIndividual::~C3LOIndividual()





void C3LOIndividual::vRandomInit()
{
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		pi_genotype[ii] = RandUtils::iRandNumber(0, 1);
	}//for  (int ii = 0; ii < i_templ_length; ii++)
	b_optimized = false;
};//C3LOIndividual::vRandomInit()



double  C3LOIndividual::dComputeFitnessOfCurrentPhenotype(int  iPhenotype)
{
	if (b_optimized == true)  return(d_fit_value);


	d_fit_value = pc_parent->dComputeFitness(pi_optimized_genotypes[iPhenotype]);
	//pc_fitness->eGetFuncValue(pi_optimized_genotypes[iPhenotype], i_templ_length, &d_fit_value);

	pd_fit_values[iPhenotype] = d_fit_value;
	b_optimized = true;

	return(d_fit_value);
}//double  C3LOIndividual::dComputeFitnessOfCurrentPhenotype(int  iPhenotype)






double  C3LOIndividual::dComputeFitness(int  iPatternLevel, bool  bOptimize /*= true*/)
{

	if (b_optimized == true)
	{
		if (i_optimized_at_pattern_level == iPatternLevel)  return(d_fit_value);
		b_optimized = false;
	}//if  (b_optimized == true)


	if (bOptimize == false)
	{
		d_fit_value = d_compute_fitness_at_level_zero(bOptimize);
		return(d_fit_value);
	}//if  (bOptimize == false)

	d_fit_value = d_compute_fitness_at_level_zero(bOptimize);
	for (int i_pat_lvl = 1; i_pat_lvl < iPatternLevel + 1; i_pat_lvl++)
	{
		d_fit_value = d_compute_fitness_at_level(i_pat_lvl);
	}//for  (int  i_pat_lvl = 0;  i_pat_lvl < iPatternLevel; i_pat_lvl++)


	return(d_fit_value);
}//double  C3LOIndividual::dComputeFitness()




double  C3LOIndividual::d_compute_fitness_at_level_zero(bool  bOptimize)
{
	double  d_result;

	d_result = d_compute_fitnesss_simple(bOptimize);
	i_optimized_at_pattern_level = 0;

	return(d_result);
}//double  C3LOIndividual::d_compute_fitness_at_level_zero(bool  bOptimize)



double  C3LOIndividual::d_compute_fitness_at_level(int  iPatternLevel)
{
	i_optimized_at_pattern_level = iPatternLevel;


	double  d_result;
	C3LOPattern  *pc_high_level_gene;

	if (iPatternLevel  <  pc_parent->pvGetHigherLevelTreesGenes()->size())
	{
		/*FILE  *pf_test;
		int i_got_in = 0;
		pf_test = fopen("zz_d_compute_fitness_at_level.txt", "w+");

		fprintf(pf_test, "START: \n");
		vSave(pf_test, true);*/

		C3LOIndividual  c_best(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
		C3LOIndividual  c_buffer(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
		vCopyTo(&c_best);
		vCopyTo(&c_buffer);


		for (int i_high_gene_offset = 0; i_high_gene_offset < pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).size(); i_high_gene_offset++)
		{
			pc_high_level_gene = pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).at(i_high_gene_offset);

			for (int i_high_gene_value = 0; (i_high_gene_value < pc_high_level_gene->pvGetHighLevelGeneFreq()->size()) && (i_high_gene_value < C3LO_INDIVIDUAL_MAX_HIGH_LEVEL_GENES_VALUES); i_high_gene_value++)
			{
				/*i_got_in++;
				fprintf(pf_test, "\nGENE %d VALUE:%d: \n", i_high_gene_offset, i_high_gene_value);
				pc_high_level_gene->vSavePattern(pf_test, pc_fitness, " ", true)
				pc_high_level_gene->pvGetHighLevelGeneFreq()->at(i_high_gene_value)->vSave(pf_test);*/


				pc_high_level_gene->pvGetHighLevelGeneFreq()->at(i_high_gene_value)->vInfectPhenotype(&c_buffer, 0);
				c_buffer.vSetNotOptimized();
				if (c_buffer.dComputeFitnessOfCurrentPhenotype(0)  >  c_best.dComputeFitnessOfCurrentPhenotype(0))
				{
					//fprintf(pf_test, "IMPROVED! \n");
					//c_buffer.vSave(pf_test, true);

					c_buffer.vCopyTo(&c_best);
				}//if  (c_buffer.dComputeFitness(-1, false)  >  c_best.dComputeFitness(-1, false))
				else
				{
					//fprintf(pf_test, "WORSE! \n");
					//c_buffer.vSave(pf_test, true);

					c_best.vCopyTo(&c_buffer);
				}//else if  (c_buffer.dComputeFitness(-1, false)  >  c_best.dComputeFitness(-1, false))


			}//for  (i_high_gene_value = 0; i_high_gene_value < pc_high_level_gene->pvGetHighLevelGeneFreq()->size(); i_high_gene_value++)

		}//for  (int  i_high_gene_offset = 0; i_high_gene_offset < pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).size();  i_high_gene_offset++)	

		c_best.vCopyTo(this);
		d_result = c_best.dComputeFitnessOfCurrentPhenotype(0);

		/*fprintf(pf_test, "\n\nFINAL:\n");
		vSave(pf_test, true);

		fclose(pf_test);
		if  (i_got_in > 4)  ::vShow("high lvl opt");*/
	}//if  (iPatternLevel  <  pc_parent->pvGetHigherLevelTreesGenes()->size())
	else
		d_result = d_fit_value;




	return(d_result);
}//double  C3LOIndividual::d_compute_fitness_at_level(int  iPatternLevel)




double  C3LOIndividual::d_compute_fitnesss_simple(bool  bOptimize /*= true*/)
{
	if (b_optimized == true)  return(d_fit_value);

	if (bOptimize == false)
	{
		for (int ii = 0; ii < i_templ_length; ii++)
			pi_optimized_genotypes[0][ii] = pi_genotype[ii];

		d_fit_value = pc_parent->dComputeFitness(pi_optimized_genotypes[0]);
		pd_fit_values[0] = d_fit_value;
		b_optimized = true;

		return(d_fit_value);
	}//if  (bOptimize == false)



	d_fit_value = 0;
	for (int ii = 0; ii < pv_optimization_orders->size(); ii++)
	{
		pd_fit_values[ii] = d_optimize_genotype(ii);

		if (d_fit_value < pd_fit_values[ii])  d_fit_value = pd_fit_values[ii];
	}//for  (int  ii = 0; ii < pv_optimization_orders->size(); ii++)

	b_optimized = true;


	return(d_fit_value);
};//double  C3LOIndividual::dComputeFitness()




double  C3LOIndividual::d_optimize_genotype(int  iOrder)
{
	if (b_optimized == true)  return(pd_fit_values[iOrder]);


	double  d_best_fitness, d_fit_buf;
	int  i_best_fitnes_gene_value;
	int  i_original_gene_value;
	int  i_genes_number_optimized;


	vector  <int>  v_possible_gene_values;

	for (int ii = 0; ii < i_templ_length; ii++)
		pi_optimized_genotypes[iOrder][ii] = pi_genotype[ii];

	d_best_fitness = pc_parent->dComputeFitness(pi_optimized_genotypes[iOrder]);


	i_genes_number_optimized = 0;
	int  i_gene_pos;
	for (int i_ordered_gene_pos = 0; i_ordered_gene_pos < pv_optimization_orders->at(iOrder).size(); i_ordered_gene_pos++)
	{
		i_gene_pos = pv_optimization_orders->at(iOrder).at(i_ordered_gene_pos);

		i_original_gene_value = pi_genotype[i_gene_pos];
		i_best_fitnes_gene_value = i_original_gene_value;
		//first get other possible gene values from template and genotype
		v_possible_gene_values.clear();

		//this is prepared for more than binary coding...
		if (i_original_gene_value == 0)
			v_possible_gene_values.push_back(1);
		else
			v_possible_gene_values.push_back(0);



		for (int ii = 0; ii < v_possible_gene_values.size(); ii++)
		{
			pi_optimized_genotypes[iOrder][i_gene_pos] = v_possible_gene_values.at(ii);
			d_fit_buf = pc_parent->dComputeFitness(pi_optimized_genotypes[iOrder]);
			//pc_fitness->eGetFuncValue(pi_optimized_genotypes[iOrder], i_templ_length, &d_fit_buf);

			if (d_fit_buf  >  d_best_fitness)
			{
				i_genes_number_optimized++;

				d_best_fitness = d_fit_buf;
				i_best_fitnes_gene_value = v_possible_gene_values.at(ii);
			}//if  (d_fit_buf  >  d_best_fitness)
		}//for  (int  ii = 0; ii < v_possible_gene_values.size(); ii++)

		pi_optimized_genotypes[iOrder][i_gene_pos] = i_best_fitnes_gene_value;
	}//for  (int  i_genotype_iterator = v_genotype.size() - 1; i_genotype_iterator >= 0; i_genotype_iterator--)


	 //for  (int ii = 0; ii < i_templ_length; ii++)
	 //	pi_genotype[ii] = pi_optimized_genotypes[iOrder][ii];


	return(d_best_fitness);
}//void  C3LOIndividual::v_optimize_genotype()



bool  C3LOIndividual::bGetTreesGenerated(int  iPatternLevel)
{
	if (iPatternLevel >= v_pattern_generated.size())  return(false);

	return(v_pattern_generated.at(iPatternLevel));
}//bool  C3LOIndividual::bGetTreesGenerated(int  iPatternLevel)




void  C3LOIndividual::vCopyPhenotypeTo(C3LOIndividual  *pcOther)
{
	for (int i_order = 0; i_order < pv_optimization_orders->size(); i_order++)
	{
		pcOther->pd_fit_values[i_order] = pd_fit_values[i_order];

		for (int ii = 0; ii < i_templ_length; ii++)
		{
			pcOther->pi_optimized_genotypes[i_order][ii] = pi_optimized_genotypes[i_order][ii];
		}//for  (int  ii = 0; ii < i_templ_length; ii++)
	}//for  (int  i_order = 0; i_order < pv_optimization_orders->size(); i_order++)
}//void  C3LOIndividual::vCopyPhenotypeTo(C3LOIndividual  *pcOther)



void  C3LOIndividual::vCopyTo(C3LOIndividual  *pcOther)
{
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		pcOther->pi_genotype[ii] = pi_genotype[ii];
	}//for  (int  ii = 0; ii < i_templ_length; ii++)

	vCopyPhenotypeTo(pcOther);

	pcOther->b_optimized = b_optimized;
	pcOther->d_fit_value = d_fit_value;
	pcOther->pv_optimization_orders = pv_optimization_orders;

	pcOther->i_optimized_at_pattern_level = i_optimized_at_pattern_level;
}//void  C3LOIndividual::vCopyTo(C3LOIndividual  *pcOther)




bool  C3LOIndividual::bComparePhenotype(C3LOIndividual  *pcOther)
{
	for (int i_order = 0; i_order < pv_optimization_orders->size(); i_order++)
	{
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			if (pcOther->pi_optimized_genotypes[i_order][ii] != pi_optimized_genotypes[i_order][ii])  return(false);
		}//for  (int  ii = 0; ii < i_templ_length; ii++)
	}//for  (int  i_order = 0; i_order < pv_optimization_orders->size(); i_order++)

	return(true);
}//bool  C3LOIndividual::bComparePhenotype(C3LOIndividual  *pcOther)



bool  C3LOIndividual::bCompareGenotype(C3LOIndividual  *pcOther)
{
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pcOther->pi_genotype[ii] != pi_genotype[ii])  return(false);
	}//for  (int  ii = 0; ii < i_templ_length; ii++)

	return(true);
}//bool  C3LOIndividual::bCompareGenotype(C3LOIndividual  *pcOther)



int*  C3LOIndividual::piGetPhenotype(int  iPhenotype)
{
	if (iPhenotype < 0)  return(NULL);
	if (iPhenotype >= pv_optimization_orders->size()) return(NULL);

	d_optimize_genotype(iPhenotype);

	return(pi_optimized_genotypes[iPhenotype]);
}//int*  C3LOIndividual::piGetPhenotype(int  iPhenotype)



double  C3LOIndividual::dUnitation(int  iOptimizedGenotype /*=-1*/)
{
	if (iOptimizedGenotype == -1)  iOptimizedGenotype = 0;

	d_fit_value = d_optimize_genotype(iOptimizedGenotype);

	double  d_unitation;
	d_unitation = 0;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (iOptimizedGenotype >= 0)
		{
			if (pi_optimized_genotypes[iOptimizedGenotype][ii] == 1)  d_unitation++;
		}//if  (bOptimizedGenotype  ==  true)
		else
		{
			if (pi_genotype[ii] == 1)  d_unitation++;
		}//else  if  (bOptimizedGenotype  ==  true)

	}//for  (int  ii = 0; ii < i_templ_length; ii++)



	d_unitation = d_unitation / i_templ_length;

	return(d_unitation);
}//double  C3LOIndividual::dUnitation()




void  C3LOIndividual::vSaveGenePatternParts(CString  sDebugName)
{
	FILE  *pf_test;


	pf_test = fopen(sDebugName, "w+");
	fprintf(pf_test, "\n\nPATTERNS:\n");
	for (int i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_parts.size(); i_pat_lvl++)
	{
		fprintf(pf_test, "\n\nPATTERN LEVEL: %d\n", i_pat_lvl);

		for (int ii = 0; ii < v_gene_patterns_parts.at(i_pat_lvl).size(); ii++)
			v_gene_patterns_parts.at(i_pat_lvl).at(ii)->vSavePattern(pf_test, NULL, "", true);
	}//for  (int  i_pat_lvl = 0; i_pat_lvl < v_gene_patterns_trees.size(); i_pat_lvl++)


	fclose(pf_test);//*/
}//void  C3LOIndividual::vSaveGenePatternParts(CString  sDebugName)




void  C3LOIndividual::vSave(FILE  *pfReport, int  *piProblemBlockStructure, bool bDoNotForcePhenotype)
{
	if (bDoNotForcePhenotype == false)  dComputeFitness(-1);

	fprintf(pfReport, "%.8lf \t lvl: %d %.5lf \t %.5lf\n", d_fit_value, i_level, dUnitation(0), dUnitation());

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		fprintf(pfReport, "%d", pi_genotype[ii]);
		//if (pc_fitness->bLastBitOfSubfunction(ii) == true)  fprintf(pfReport, " ");
		if (piProblemBlockStructure != NULL)
		{
			if (piProblemBlockStructure[ii] == true)  fprintf(pfReport, " ");
		}//if (piProblemBlockStructure != NULL)
	}//for  (int ii = 0; ii < i_templ_length; ii++)
	fprintf(pfReport, "\n");


	for (int i_opt_gen = 0; i_opt_gen < pv_optimization_orders->size(); i_opt_gen++)
	{
		for (int ii = 0; ii < i_templ_length; ii++)
		{
			fprintf(pfReport, "%d", pi_optimized_genotypes[i_opt_gen][ii]);
			//if (pc_fitness->bLastBitOfSubfunction(ii) == true)  fprintf(pfReport, " ");
			if (piProblemBlockStructure != NULL)
			{
				if (piProblemBlockStructure[ii] == true)  fprintf(pfReport, " ");
			}//if (piProblemBlockStructure != NULL)
		}//for  (int ii = 0; ii < i_templ_length; ii++)
		fprintf(pfReport, "\n");
	}//for  (int  i_opt_gen = 0; i_opt_gen < pv_optimization_orders->size(); i_opt_gen++)


	 //for  (int i_pat = 0; i_pat < v_gene_patterns_parts.size(); i_pat++)
	 //	v_gene_patterns_parts.at(i_pat)->vSavePattern(pfReport, pc_fitness);


}//void  C3LOIndividual::vSave(FILE  *pfReport)




void  C3LOIndividual::vIncrementalBrutalUpdate(vector<C3LOPattern *> *pvGenePatterns, vector<C3LOPattern *> *pvGenePatternPartsOriginal, int iPatternLevel)
{
	vector<C3LOPattern *> v_patterns_buf, v_patterns_shuffled;

	v_patterns_buf = *pvGenePatterns;
	int  i_pattern_offset;
	while (v_patterns_buf.size() > 0)
	{
		
		//i_pattern_offset = pc_random_gen->Next(0, v_patterns_buf.size());
		i_pattern_offset = RandUtils::iRandNumber(0, v_patterns_buf.size() - 1);
		v_patterns_shuffled.push_back(v_patterns_buf.at(i_pattern_offset));
		v_patterns_buf.erase(v_patterns_buf.begin() + i_pattern_offset);
	}//while  (v_patterns_buf.size() > 0)


	C3LOIndividual  *pc_best_update;
	C3LOIndividual  *pc_best_different_ind;
	C3LOPattern  *pc_pattern;

	/*FILE  *pf_test;
	pf_test = fopen("zz_init.txt", "w+");
	fprintf(pf_test, "\nSTART:\n");
	vSave(pf_test);//*/

	while (v_patterns_shuffled.size()  >  0)
	{
		pc_pattern = v_patterns_shuffled.at(0);
		v_patterns_shuffled.erase(v_patterns_shuffled.begin());

		pc_best_update = NULL;
		pc_best_different_ind = NULL;
		if (bLinkedGenesBrutalSearch(pc_pattern, iPatternLevel, pvGenePatternPartsOriginal, &pc_best_update, &pc_best_different_ind) == true)  pc_best_update->vCopyTo(this);

		if (pc_best_update != NULL)  delete  pc_best_update;
		if (pc_best_different_ind != NULL)  delete  pc_best_different_ind;

	}//while  (v_patterns_shuffled.size()  >  0)


	 /*fprintf(pf_test, "\nAFTER:\n");
	 vSave(pf_test);
	 fclose(pf_test);//*/
}//void  C3LOIndividual::vIncrementalBrutalUpdate(vector<C3LOPattern> *pvGenePatterns, int iPatternLevel, C3LOIndividual  **pcBestUpdate)



bool  C3LOIndividual::bLinkedGenesBrutalSearch(C3LOPattern *pcLinkedGenes, int iPatternLevel, vector<C3LOPattern *> *pvGenePatternPartsOriginal, C3LOIndividual  **pcBestUpdate, C3LOIndividual  **pcBestButDifferent)
{
	//return(false);
	/*FILE  *pf_test;
	pf_test = fopen("z_bLinkedGenesBrutalSearch.txt", "w+");
	fprintf(pf_test, "%d\n", i_global_counter++);
	fclose(pf_test);*/

	dComputeFitness(iPatternLevel);


	*pcBestButDifferent = NULL;
	*pcBestUpdate = NULL;
	bool  b_result;

	if (iPatternLevel == 0)
	{
		b_result = bLinkedGenesBrutalSearchZero(pcLinkedGenes, pvGenePatternPartsOriginal, pcBestUpdate, pcBestButDifferent);

		/*pf_test = fopen("z_bLinkedGenesBrutalSearch.txt", "a");
		fprintf(pf_test, "ENDED\n", i_global_counter++);
		fclose(pf_test);*/

		pc_parent->i_brutal_random_search++;
		if (b_result == true)  pc_parent->i_brutal_random_search_effective++;


		return(b_result);
	}//if  (iPatternLevel == 0)  

	b_result = bLinkedGenesBrutalSearchHigher(pcLinkedGenes, iPatternLevel, pcBestUpdate, pcBestButDifferent);

	/*pf_test = fopen("z_bLinkedGenesBrutalSearch.txt", "a");
	fprintf(pf_test, "ENDED\n", i_global_counter++);
	fclose(pf_test);*/

	pc_parent->i_brutal_random_search++;
	if (b_result == true)  pc_parent->i_brutal_random_search_effective++;
	return(b_result);

	return(false);
}//void  C3LOIndividual::vLinkedGenesBrutalSearch(C3LOPattern *pcLinkedGenes, int iPatternLevel)



C3LOPattern*  C3LOIndividual::pc_get_pattern_part(int  iGenePosition, int *piFilledGenes, vector<C3LOPattern *> *pvGenePatternPartsOriginal)
{
	vector<C3LOPattern*>  v_possible_patterns;
	bool  b_pattern_possible;

	for (int i_pattern = 0; i_pattern < pvGenePatternPartsOriginal->size(); i_pattern++)
	{
		if (pvGenePatternPartsOriginal->at(i_pattern)->bGeneThere(iGenePosition) == true)
		{
			b_pattern_possible = false;
			for (int ii = 0; (ii < pvGenePatternPartsOriginal->at(i_pattern)->v_pattern.size())&&(b_pattern_possible == false); ii++)
			{
				if  (piFilledGenes[pvGenePatternPartsOriginal->at(i_pattern)->v_pattern.at(ii).iGenePos()] < 1)  b_pattern_possible = true;
			}//for (int ii = 0; (ii < pvGenePatternPartsOriginal->at(i_pattern)->v_pattern.size())&&(b_pattern_possible == false); ii++)

			if (b_pattern_possible == true)  v_possible_patterns.push_back(pvGenePatternPartsOriginal->at(i_pattern));		
		}//if (pvGenePatternPartsOriginal->at(i_pattern)->bGeneThere(iGenePosition) == true)
	}//for (int i_pattern = 0; i_pattern < pvGenePatternPartsOriginal->size(); i_pattern++)

	if (v_possible_patterns.size() == 0)  return(NULL);

	int  i_pat_offset;
	i_pat_offset = RandUtils::iRandNumber(0, v_possible_patterns.size() - 1);

	return(v_possible_patterns.at(i_pat_offset));
}//C3LOPattern*  C3LOIndividual::pc_get_pattern_part(int  iGenePosition, int *piFilledGenes, vector<C3LOPattern *> *pvGenePatternPartsOriginal)



bool  C3LOIndividual::bLinkedGenesBrutalSearchZero(C3LOPattern *pcLinkedGenes, vector<C3LOPattern *> *pvGenePatternPartsOriginal, C3LOIndividual  **pcBestUpdate, C3LOIndividual  **pcBestButDifferent)
{
	if (pcLinkedGenes->pvGetPattern()->size() == 0)  return(false);



	int  *pi_genes_included;
	pi_genes_included = new  int[i_templ_length];

	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genes_included[ii] = 0;

	for (int ii = 0; ii < pcLinkedGenes->pvGetPattern()->size(); ii++)
	{
		pi_genes_included[pcLinkedGenes->pvGetPattern()->at(ii).iGenePos()] = 1;
	}//for  (int  ii = 0; ii < pcLinkedGenes->v_pattern.size(); ii++)


	vector<int>  v_genes_included;
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genes_included[ii] > 0)  v_genes_included.push_back(ii);
	}//for  (int  ii = 0; ii < i_templ_length; ii++)


	//use it again for a different purpose - gene marking in brutal search pattern set
	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genes_included[ii] = 0;

	C3LOPattern  *pc_gene_pattern_part;
	vector<int>  v_genes_shuffled;
	vector<CMessyGene>  v_genes_directly_connected;
	int  i_gene_offset, i_gene_position, i_gene_pos_new;
	int  i_current_gene_offset = -1;
	while ((v_genes_included.size() > 0) && (v_genes_shuffled.size() < C3LO_INDIVIDUAL_MAX_GENES_FOR_BS))
	{
		//i_gene_offset = pc_random_gen->Next(0, v_genes_included.size());
		i_gene_offset = RandUtils::iRandNumber(0, v_genes_included.size() - 1);
		i_gene_position = v_genes_included.at(i_gene_offset);
		v_genes_included.erase(v_genes_included.begin() + i_gene_offset);


		if (pi_genes_included[i_gene_position] == 0)
		{
			v_genes_shuffled.push_back(i_gene_position);
			i_current_gene_offset = v_genes_shuffled.size() - 1;
			pi_genes_included[i_gene_position] = 1;

			//now get genes directly dependent on the selected gene
			pc_gene_pattern_part = pc_get_pattern_part(i_gene_position, pi_genes_included, pvGenePatternPartsOriginal);

			while ((pc_gene_pattern_part != NULL)&&(v_genes_directly_connected.size() > 0) && (v_genes_shuffled.size() < C3LO_INDIVIDUAL_MAX_GENES_FOR_BS))
			{
				v_genes_directly_connected = pc_gene_pattern_part->v_pattern;

				while ((v_genes_directly_connected.size() > 0) && (v_genes_shuffled.size() < C3LO_INDIVIDUAL_MAX_GENES_FOR_BS))
				{
					i_gene_offset = RandUtils::iRandNumber(0, v_genes_directly_connected.size() - 1);
					i_gene_pos_new = v_genes_directly_connected.at(i_gene_offset).iGenePos();
					v_genes_directly_connected.erase(v_genes_directly_connected.begin() + i_gene_offset);

					if (pi_genes_included[i_gene_pos_new] == 0)
					{
						v_genes_shuffled.push_back(i_gene_pos_new);
						pi_genes_included[i_gene_pos_new] = 1;
					}//if (pi_genes_included[i_gene_pos_new] == 0)
				}//while ((v_genes_directly_connected.size() > 0) && (v_genes_shuffled.size() < C3LO_INDIVIDUAL_MAX_GENES_FOR_BS))

				pc_gene_pattern_part = pc_get_pattern_part(i_gene_position, pi_genes_included, pvGenePatternPartsOriginal);

				while ((pc_gene_pattern_part == NULL) && (i_current_gene_offset >= 0))
				{
					i_current_gene_offset++;
					if (i_current_gene_offset < v_genes_shuffled.size())
					{
						i_gene_position = v_genes_shuffled.at(i_current_gene_offset);
						pc_gene_pattern_part = pc_get_pattern_part(i_gene_position, pi_genes_included, pvGenePatternPartsOriginal);
					}//if (i_current_gene_offset < v_genes_shuffled.size())
					else
						i_current_gene_offset = -1;
				}//while ((pc_gene_pattern_part == NULL) && (i_current_gene_offset >= 0))
			}//if  (pc_gene_pattern_part != NULL)
		}//if  (pi_genes_included[i_gene_position] == 0)
	}//while (v_genes_included.size() > 0)	


	



	delete  pi_genes_included;//DONT REMOVE during updates!
	
	/*vector<int>  v_genes_shuffled;
	int  i_gene_offset;
	while ((v_genes_included.size() > 0) && (v_genes_shuffled.size() < C3LO_INDIVIDUAL_MAX_GENES_FOR_BS))
	{
		//i_gene_offset = pc_random_gen->Next(0, v_genes_included.size());
		i_gene_offset = RandUtils::iRandNumber(0, v_genes_included.size()-1);
		v_genes_shuffled.push_back(v_genes_included.at(i_gene_offset));
		v_genes_included.erase(v_genes_included.begin() + i_gene_offset);
	}//while (v_genes_included.size() > 0)*/



	C3LOIndividual  c_coptimized(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
	C3LOIndividual  c_best_and_different(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
	vCopyTo(&c_coptimized);
	vCopyTo(&c_best_and_different);
	int  i_best_but_different_found;

	i_best_but_different_found = 0;
	if (b_brutal_check(&v_genes_shuffled, &c_coptimized, &c_best_and_different, &i_best_but_different_found, 0) == true)
	{
		*pcBestUpdate = new  C3LOIndividual(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
		c_coptimized.vCopyTo(*pcBestUpdate);
		(*pcBestUpdate)->b_optimized = false;

		double  d_opt_fitness, d_opt_fitness_bald, d_curr_fit;
		d_opt_fitness = c_coptimized.dComputeFitnessOfCurrentPhenotype(0);
		d_opt_fitness_bald = (*pcBestUpdate)->dComputeFitness(0);
		d_curr_fit = dComputeFitness(0);

		if (d_opt_fitness > d_opt_fitness_bald)
		{
			for (int ii = 0; ii < i_templ_length; ii++)
				((*pcBestUpdate)->pi_genotype)[ii] = c_coptimized.pi_optimized_genotypes[0][ii];

			if (pc_parent->bCanIndBeAddedAtAnyLevel((*pcBestUpdate)) == true)
			{
				(*pcBestUpdate)->b_optimized = false;
				return(true);
			}//if (pc_parent->bCanIndBeAddedAtAnyLevel((*pcBestUpdate)) == true)


			return(false);
			//CString  s_buf;

			//s_buf.Format("opt: %.4lf > %.4lf  (curr: %.4lf)", d_opt_fitness, d_opt_fitness_bald, d_curr_fit);
			//::MessageBox(NULL, s_buf, s_buf, MB_OK);
		}//if (d_opt_fitness < d_opt_fitness_bald)

		return(true);
	}//if  (b_brutal_check(&v_genes_shuffled, &c_coptimized, 0) == true)
	else
	{
		if (i_best_but_different_found != 0)
		{
			if (bComparePhenotype(&c_best_and_different) == false)
			{
				*pcBestButDifferent = new  C3LOIndividual(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
				c_best_and_different.vCopyTo(*pcBestButDifferent);
				(*pcBestButDifferent)->b_optimized = false;
			}//if  (bComparePhenotype(&c_coptimized)  ==  false)
		}//if  (i_best_but_different_found  !=  0)
	}//else  if  (b_brutal_check(&v_genes_shuffled, &c_coptimized, 0) == true)



	return(false);
}//void  C3LOIndividual::vLinkedGenesBrutalSearch(C3LOPattern *pcHighLvlGene)



bool  C3LOIndividual::b_brutal_check(vector<int>  *pvGenesShuffled, C3LOIndividual  *pcOptimizationBuf, C3LOIndividual  *pcBestThatFar, int  *piBestThatFarInitialized, int  iPos)
{
	if (iPos >= pvGenesShuffled->size())
	{
		pcOptimizationBuf->b_optimized = false;
		//pcOptimizationBuf->dComputeFitness(0);
		pcOptimizationBuf->dComputeFitnessOfCurrentPhenotype(0);

		if (pc_parent->bCanIndBeAddedAtAnyLevel(pcOptimizationBuf) == true)
		{
			if (*piBestThatFarInitialized == 0)
			{
				*piBestThatFarInitialized = 1;
				pcOptimizationBuf->vCopyTo(pcBestThatFar);
			}//if  (*piBestThatFarInitialized  ==  0)
			else
			{
				if (pcBestThatFar->d_fit_value  <  pcOptimizationBuf->d_fit_value)  pcOptimizationBuf->vCopyTo(pcBestThatFar);
			}//else  if  (*piBestThatFarInitialized  ==  0)

			if (d_fit_value  <  pcOptimizationBuf->d_fit_value)  return(true);
		}//if  (b_can_ind_be_added_at_any_level(pcOptimizationBuf) == true)

		return(false);
	}//if  (iPos  >= pvGenesShuffled->size())

	int  i_val;
	//i_val = pc_random_gen->Next(0, 2);
	i_val = RandUtils::iRandNumber(0,1);

	pcOptimizationBuf->pi_genotype[pvGenesShuffled->at(iPos)] = i_val;
	pcOptimizationBuf->pi_optimized_genotypes[0][pvGenesShuffled->at(iPos)] = i_val;
	if (b_brutal_check(pvGenesShuffled, pcOptimizationBuf, pcBestThatFar, piBestThatFarInitialized, iPos + 1) == true)  return(true);

	if (i_val == 1)
		i_val = 0;
	else
		i_val = 1;

	pcOptimizationBuf->pi_genotype[pvGenesShuffled->at(iPos)] = i_val;
	pcOptimizationBuf->pi_optimized_genotypes[0][pvGenesShuffled->at(iPos)] = i_val;
	if (b_brutal_check(pvGenesShuffled, pcOptimizationBuf, pcBestThatFar, piBestThatFarInitialized, iPos + 1) == true)  return(true);


	return(false);
}//bool  C3LOIndividual::b_brutal_check(vector<int>  *pvGenesShuffled, C3LOIndividual  *pcOptimizationBuf, int  iPos)




bool  C3LOIndividual::bLinkedGenesBrutalSearchHigher(C3LOPattern *pcLinkedGenes, int iPatternLevel, C3LOIndividual  **pcBestUpdate, C3LOIndividual  **pcBestButDifferent)
{
	if (pc_parent->pvGetHigherLevelTreesGenes()->size() <= iPatternLevel)  return(false);
	if (pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).size() == 0)  return(false);



	vector<C3LOPattern  *>  v_high_level_genes_included;
	int  i_common, i_uncommon, i_unmarked;
	for (int ii = 0; ii < pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).size(); ii++)
	{
		pcLinkedGenes->vGetCommonAndUNcommonPositions
		(
			pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).at(ii),
			&i_common, &i_uncommon, &i_unmarked
		);

		if (
			(i_common  >  0) && (i_unmarked == 0)
			)
			v_high_level_genes_included.push_back(pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).at(ii));
	}//for  (int  ii = 0; ii < pc_parent->pvGetHigherLevelTreesGenes()->at(iPatternLevel).size(); ii++)


	vector<C3LOPattern  *>  v_high_level_genes_shuffled;
	int  i_gene_offset;
	while ((v_high_level_genes_included.size() > 0) && (v_high_level_genes_shuffled.size() < C3LO_INDIVIDUAL_MAX_GENES_FOR_BS))
	{
		//i_gene_offset = pc_random_gen->Next(0, v_high_level_genes_included.size());
		i_gene_offset = RandUtils::iRandNumber(0, v_high_level_genes_included.size() - 1);
		v_high_level_genes_shuffled.push_back(v_high_level_genes_included.at(i_gene_offset));
		v_high_level_genes_included.erase(v_high_level_genes_included.begin() + i_gene_offset);
	}//while (v_genes_included.size() > 0)


	 /*FILE  *pf_test;
	 pf_test = fopen("z_brutal_test.txt", "a");

	 fprintf(pf_test, "\n\nBEFORE:\n");
	 vSave(pf_test);

	 fprintf(pf_test, "\n\nPATTERN:\n");
	 pcLinkedGenes->vSavePattern(pf_test, pc_fitness, "", true);//*/



	C3LOIndividual  c_coptimized(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
	C3LOIndividual  c_best_and_different(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
	vCopyTo(&c_coptimized);
	vCopyTo(&c_best_and_different);
	int  i_best_but_different_found;



	i_best_but_different_found = 0;
	if (b_brutal_check_high_level(&v_high_level_genes_shuffled, &c_coptimized, &c_best_and_different, &i_best_but_different_found, iPatternLevel, 0) == true)
	{
		*pcBestUpdate = new  C3LOIndividual(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);

		c_coptimized.vCopyTo(*pcBestUpdate);

		/*fprintf(pf_test, "\n\nOPTIMIZED AFTER:\n");
		vSave(pf_test);
		fclose(pf_test);*/

		return(true);
	}//if  (b_brutal_check(&v_genes_shuffled, &c_coptimized, 0) == true)
	else
	{
		if (i_best_but_different_found != 0)
		{
			if (bComparePhenotype(&c_best_and_different) == false)
			{
				*pcBestButDifferent = new  C3LOIndividual(i_templ_length, pc_problem, pv_optimization_orders, pc_parent);
				c_best_and_different.vCopyTo(*pcBestButDifferent);
			}//if  (bComparePhenotype(&c_coptimized)  ==  false)
		}//if  (i_best_but_different_found  !=  0)
	}//else  if  (b_brutal_check(&v_genes_shuffled, &c_coptimized, 0) == true)

	return(false);
}//void  C3LOIndividual::vLinkedGenesBrutalSearchHigher(C3LOPattern *pcLinkedGenes, int iPatternLevel)




bool  C3LOIndividual::b_brutal_check_high_level(vector<C3LOPattern  *>  *pvHighLevelGenesShuffled, C3LOIndividual  *pcOptimizationBuf, C3LOIndividual  *pcBestThatFar, int  *piBestThatFarInitialized, int iPatternLevel, int  iPos)
{
	if (iPos >= pvHighLevelGenesShuffled->size())
	{
		pcOptimizationBuf->b_optimized = false;
		pcOptimizationBuf->dComputeFitness(iPatternLevel, false);

		if (pc_parent->bCanIndBeAddedAtAnyLevel(pcOptimizationBuf) == true)
		{
			if (*piBestThatFarInitialized == 0)
			{
				*piBestThatFarInitialized = 1;
				pcOptimizationBuf->vCopyTo(pcBestThatFar);
			}//if  (*piBestThatFarInitialized  ==  0)
			else
			{
				if (pcBestThatFar->d_fit_value  <  pcOptimizationBuf->d_fit_value)  pcOptimizationBuf->vCopyTo(pcBestThatFar);
			}//else  if  (*piBestThatFarInitialized  ==  0)

			if (d_fit_value  <  pcOptimizationBuf->d_fit_value)  return(true);
		}//if  (b_can_ind_be_added_at_any_level(pcOptimizationBuf) == true)

		return(false);
	}//if  (iPos  >= pvGenesShuffled->size())





	if (pvHighLevelGenesShuffled->at(iPos)->pvGetHighLevelGeneFreq()->size() == 0)  return(false);


	if (pvHighLevelGenesShuffled->at(iPos)->pvGetHighLevelGeneFreq()->size() == 1)
	{
		pvHighLevelGenesShuffled->at(iPos)->pvGetHighLevelGeneFreq()->at(0)->vInfect(pcOptimizationBuf);
		if (b_brutal_check_high_level(pvHighLevelGenesShuffled, pcOptimizationBuf, pcBestThatFar, piBestThatFarInitialized, iPatternLevel, iPos + 1) == true)  return(true);
	}//if  (pvHighLevelGenesShuffled->at(iPos)->pvGetHighLevelGeneFreq()->size() == 1)


	if (pvHighLevelGenesShuffled->at(iPos)->pvGetHighLevelGeneFreq()->size() > 1)
	{
		int  i_val;
		//i_val = pc_random_gen->Next(0, 2);
		i_val = RandUtils::iRandNumber(0,1);

		pvHighLevelGenesShuffled->at(iPos)->pvGetHighLevelGeneFreq()->at(i_val)->vInfect(pcOptimizationBuf);
		if (b_brutal_check_high_level(pvHighLevelGenesShuffled, pcOptimizationBuf, pcBestThatFar, piBestThatFarInitialized, iPatternLevel, iPos + 1) == true)  return(true);


		if (i_val == 1)
			i_val = 0;
		else
			i_val = 1;


		pvHighLevelGenesShuffled->at(iPos)->pvGetHighLevelGeneFreq()->at(i_val)->vInfect(pcOptimizationBuf);
		if (b_brutal_check_high_level(pvHighLevelGenesShuffled, pcOptimizationBuf, pcBestThatFar, piBestThatFarInitialized, iPatternLevel, iPos + 1) == true)  return(true);

	}//if  (pvHighLevelGenesShuffled->at(iPos)->pvGetHighLevelGeneFreq()->size() == 1)



	return(false);
}//bool  C3LOIndividual::b_brutal_check(vector<int>  *pvGenesShuffled, C3LOIndividual  *pcOptimizationBuf, int  iPos)








 //---------------------------------------------C3LOPattern-------------------------------------------------------

C3LOPattern::C3LOPattern(int iTemplLength)
{
	i_templ_length = iTemplLength;
	i_pattern_level = 0;
}//C3LOPattern::C3LOPattern()


C3LOPattern::~C3LOPattern()
{
	/*FILE  *pf_test;
	pf_test = fopen("zz_pat_del", "a+");
	vSavePattern(pf_test, NULL, "", true);
	fclose(pf_test);

	for  (int ii = 0; ii < v_children.size(); ii++)
	delete  v_children.at(ii);*/


	for (int ii = 0; ii < v_high_level_gene_freq.size(); ii++)
		delete  v_high_level_gene_freq.at(ii);
}//C3LOPattern::~C3LOPattern()



 //common: we have both the same; uncommon: this has it, pcOther doues not; Unmarked: this does not have it, pcOther does have it
void  C3LOPattern::vGetCommonAndUNcommonPositions(C3LOPattern  *pcOther, int *piCommonPos, int *piUncommonPos, int *piUnmarkedPos)
{
	int  *pi_differences;
	pi_differences = new int[i_templ_length];

	for (int ii = 0; ii < i_templ_length; ii++)  pi_differences[ii] = 0;

	for (int ii = 0; ii < pcOther->v_pattern.size(); ii++)
	{
		pi_differences[pcOther->v_pattern.at(ii).iGenePos()] = 1;
	}//for  (int  ii = 0; ii < v_pattern.size(); ii++)

	vGetCommonAndUNcommonPositions(pi_differences, piCommonPos, piUncommonPos, piUnmarkedPos);

	delete  pi_differences;
}//void  C3LOPattern::vGetCommonAndUNcommonPositions(C3LOPattern  *pcOther, int *piCommonPos, int *piUncommonPos, int *piUnmarkedPos)


void  C3LOPattern::vGetCommonAndUNcommonPositions(int  *piDifferences, int *piCommonPos, int *piUncommonPos, int *piUnmarkedPos)
{
	int  *pi_tool;
	int  i_uncommon_pos, i_common_pos;

	pi_tool = new int[i_templ_length];
	for (int ii = 0; ii < i_templ_length; ii++)
		pi_tool[ii] = piDifferences[ii];



	for (int ii = 0; ii < v_pattern.size(); ii++)
	{
		if (pi_tool[v_pattern.at(ii).iGenePos()] == 0)
		{
			pi_tool[v_pattern.at(ii).iGenePos()] = -1;
		}//if  (pi_tool[v_pattern.at(ii).iGenePos()] == 0)


		if (pi_tool[v_pattern.at(ii).iGenePos()] == 1)
		{
			pi_tool[v_pattern.at(ii).iGenePos()] = 2;
		}//if  (pi_tool[v_pattern.at(ii).iGenePos()] == 1)

	}//for  (int  i_my_offset = 0; i_my_offset < v_pattern.size(); i_my_offset++)


	*piCommonPos = 0;
	*piUncommonPos = 0;
	*piUnmarkedPos = 0;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_tool[ii] == -1) (*piUncommonPos)++;
		if (pi_tool[ii] == 1) (*piUnmarkedPos)++;
		if (pi_tool[ii] == 2) (*piCommonPos)++;
	}//for  (int ii = 0; ii < i_templ_length; ii++)


	delete  pi_tool;

}//int  C3LOPattern::iGetUNcommonPositions(int  *piDifferences)



int  C3LOPattern::iCommonPositions(C3LOPattern  *pcOther, bool  bCheckValues /*= false*/, bool  bAllMustBeTheSame /*= true*/)
{
	if (bAllMustBeTheSame == true)
	{
		if (v_pattern.size() != pcOther->v_pattern.size())  return(0);
	}//if  (bBreakAtTheFirstDifference == true)

	int  i_result;
	bool  b_found;

	i_result = 0;
	for (int i_my_offset = 0; i_my_offset < v_pattern.size(); i_my_offset++)
	{
		b_found = false;
		for (int i_other_offset = 0; (i_other_offset < pcOther->v_pattern.size()) && (b_found == false); i_other_offset++)
		{
			if (bCheckValues == true)
			{
				if (
					(v_pattern.at(i_my_offset).iGenePos() == pcOther->v_pattern.at(i_other_offset).iGenePos()) &&
					(v_pattern.at(i_my_offset).iGeneVal() == pcOther->v_pattern.at(i_other_offset).iGeneVal())
					)
					b_found = true;
			}//if  (bCheckValues == true)
			else
			{
				if (
					(v_pattern.at(i_my_offset).iGenePos() == pcOther->v_pattern.at(i_other_offset).iGenePos())
					)
					b_found = true;
			}//else  if  (bCheckValues == true)
		}//for  (int  i_other_offset = 0; (i_other_offset < pcOther->v_pattern.size())&&(b_found = false); i_other_offset++)

		if (b_found == false)
		{
			if (bAllMustBeTheSame == true)
			{
				return(0);
			}//if  (bBreakAtTheFirstDifference == true)
		}//if  (b_found == false)
		else
		{
			i_result++;
		}//else  if  (b_found == false)
	}//for  (int  i_my_offset = 0; i_my_offset < v_pattern.size(); i_my_offset++)


	return(i_result);
}//bool  C3LOPattern::bIsTheSame(C3LOPattern  *pcOther)




int  C3LOPattern::iDifferentPositions(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int iPatternLevel)
{
	int  i_result;


	pcInd0->dComputeFitness(iPatternLevel);//phenotype creation forcing...
	pcInd1->dComputeFitness(iPatternLevel);//phenotype creation forcing...

	int  *pi_phenotype_0, *pi_phenotype_1;
	pi_phenotype_0 = pcInd0->piGetPhenotype(0);
	pi_phenotype_1 = pcInd1->piGetPhenotype(0);

	i_result = 0;
	for (int ii = 0; ii < v_pattern.size(); ii++)
	{
		if (pi_phenotype_0[v_pattern.at(ii).iGenePos()] != pi_phenotype_1[v_pattern.at(ii).iGenePos()])  i_result++;
	}//for  (int  ii = 0; ii < v_pattern.size(); ii++)

	return(i_result);
}//int  C3LOPattern::iDifferentPositions(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1)





bool bGeneFreqGreater(C3LOHighLvlGeneFreq *elem1, C3LOHighLvlGeneFreq *elem2)
{
	return elem1->iGetGeneNumber() > elem2->iGetGeneNumber();
}//bool bGeneFreqGreater (C3LOHighLvlGeneFreq *elem1, C3LOHighLvlGeneFreq *elem2)


void  C3LOPattern::vCountHighLvlGeneFreq(vector<C3LOIndividual *>  *pvPopoulation, int iPatternLevel)
{
	for (int ii = 0; ii < v_high_level_gene_freq.size(); ii++)
		delete  v_high_level_gene_freq.at(ii);
	v_high_level_gene_freq.clear();


	for (int ii = 0; ii < pvPopoulation->size(); ii++)
	{
		v_check_high_level_gene_for_ind(pvPopoulation->at(ii), iPatternLevel);
	}//for  (int  ii = 0; ii < v_high_level_gene_freq.size(); ii++)


	std::sort(v_high_level_gene_freq.begin(), v_high_level_gene_freq.end(), bGeneFreqGreater);
}//void  C3LOPattern::vCountHighLvlGeneFreq(vector<C3LOIndividual *>  *pvPopoulation)



void  C3LOPattern::v_check_high_level_gene_for_ind(C3LOIndividual *pcInd, int iPatternLevel)
{
	for (int ii = 0; ii < v_high_level_gene_freq.size(); ii++)
	{
		if (v_high_level_gene_freq.at(ii)->bCheckHighLevelGene(pcInd, iPatternLevel) == true)  return;
	}//for  (int  ii = 0; ii < v_high_level_gene_freq.size(); ii++)

	 //create high level gene
	C3LOHighLvlGeneFreq  *pc_new_gene_val_freq;

	pc_new_gene_val_freq = new C3LOHighLvlGeneFreq(i_templ_length);
	pc_new_gene_val_freq->vCreate(this, pcInd, iPatternLevel);

	v_high_level_gene_freq.push_back(pc_new_gene_val_freq);
}//void  C3LOPattern::v_check_high_level_gene_for_ind(C3LOIndividual *pcInd)



void  C3LOPattern::vGetBestCovering(vector<C3LOPattern*> *pvDiffrCoveringPatterns, int  *piDifferences, int iAcceptableLevel)
{
	if (i_pattern_level <= iAcceptableLevel)
	{
		int  i_common_pos, i_uncommon_pos, i_unmarked_pos;

		if (piDifferences != NULL)
		{
			vGetCommonAndUNcommonPositions(piDifferences, &i_common_pos, &i_uncommon_pos, &i_unmarked_pos);

			//if  (i_uncommon_pos == 0)
			if (i_common_pos > 0)
			{
				pvDiffrCoveringPatterns->push_back(this);
				return;
			}//if  (i_uncommon_pos == 0)
		}//	if  (piDifferences  !=  NULL)
		else
		{
			pvDiffrCoveringPatterns->push_back(this);
			return;
		}//else  if  (piDifferences  !=  NULL)
	}//if  (i_pattern_level <= iAcceptableLevel)


	 //for  (int i_child = 0; i_child < v_children.size(); i_child++)
	 //	v_children.at(i_child)->vGetBestCovering(pvDiffrCoveringPatterns, piDifferences, iAcceptableLevel);	

}//void  C3LOPattern::vGetBestCovering(vector<C3LOPattern*> *pvDiffrCoveringPatterns, int  *piDifferences, int iAcceptableLevel)




C3LOPattern*  C3LOPattern::pcGetLongestReasonableBranch(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int *piDifferenceSearchTool, int iPatternLevel)
{
	if (bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == false)  return(NULL);
	if (bUnMarkedPhenotypeDifferences(pcInd0, pcInd1, piDifferenceSearchTool, iPatternLevel) == true)  return(this);


	vector<C3LOPattern *>  v_candidates;
	C3LOPattern *pc_candidate;


	for (int i_child = 0; i_child < v_children.size(); i_child++)
	{
		pc_candidate = v_children.at(i_child)->pcGetLongestReasonableBranch(pcInd0, pcInd1, piDifferenceSearchTool, iPatternLevel);
		if (pc_candidate != NULL)  v_candidates.push_back(pc_candidate);
	}//for  (int i_child = 0; i_child < v_children.size(); i_child++)


	/*vector<C3LOPattern *>  v_candidates;

	for (int i_child = 0; i_child < v_children.size(); i_child++)
	{
		if (v_children.at(i_child)->bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == true)
		{
			if (v_children.at(i_child)->bUnMarkedPhenotypeDifferences(pcInd0, pcInd1, piDifferenceSearchTool, iPatternLevel) == true)  v_candidates.push_back(v_children.at(i_child));
		}//if (v_children.at(i_child)->bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == true)		
	}//for  (int i_child = 0; i_child < v_children.size(); i_child++)*/

	if (v_candidates.size() > 0)
	{
		int  i_chosen_candidate;
		i_chosen_candidate = RandUtils::iRandNumber(0, v_candidates.size() - 1);

		return(v_candidates.at(i_chosen_candidate));
	}//if (v_candidates.size() > 0)


	return(NULL);
}//C3LOPattern  C3LOPattern::pcGetLongestReasonableBranch(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int iPatternLevel)



void  C3LOPattern::vGetRandomTreeBranch(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, vector<C3LOPattern  *>  *pvTreeBranch, int iPatternLevel)
{
	if (pvTreeBranch == NULL)  return;

	if (pvTreeBranch->size() == 0)
	{
		if (bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == false)  return;
		pvTreeBranch->push_back(this);
	}//if  (pvTreeBranch->size() ==  0)

	vector<C3LOPattern *>  v_allowed_children;
	for (int i_child = 0; i_child < v_children.size(); i_child++)
	{
		if (v_children.at(i_child)->bMarkedPhenotypeDifferences(pcInd0, pcInd1, iPatternLevel) == true)  v_allowed_children.push_back(v_children.at(i_child));
	}//for  (int i_child = 0; i_child < v_children.size(); i_child++)

	if (v_allowed_children.size() == 0)  return;

	int  i_chosen_node;
	//i_chosen_node = pc_random_gen->Next(0, v_allowed_children.size());
	i_chosen_node = RandUtils::iRandNumber(0, v_allowed_children.size() - 1);
	if (i_chosen_node >= v_allowed_children.size())  i_chosen_node = v_allowed_children.size() - 1;

	pvTreeBranch->push_back(v_allowed_children.at(i_chosen_node));
	v_allowed_children.at(i_chosen_node)->vGetRandomTreeBranch(pcInd0, pcInd1, pvTreeBranch, iPatternLevel);
}//void  C3LOPattern::vGetRandomTreeBranch(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, vector<C3LOPattern  *>  *pvTreeBranch)




C3LOPattern  *C3LOPattern::pcGetBestCrossingNode(int iPatternLevel, C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int *piDiffrentPositions, double  *pdDifrPosPerc)
{
	int  i_diffr_pos_my, i_diffr_pos_other, i_diffr_pos_best;
	double  d_diffr_pos_perc_my, d_diffr_pos_perc_other, d_diffr_pos_perc_best;

	i_diffr_pos_my = iDifferentPositions(pcInd0, pcInd1, iPatternLevel);
	d_diffr_pos_perc_my = i_diffr_pos_my;
	d_diffr_pos_perc_my = d_diffr_pos_perc_my / v_pattern.size();


	C3LOPattern  *pc_node_best, *pc_node_other;

	pc_node_best = this;
	i_diffr_pos_best = i_diffr_pos_my;
	d_diffr_pos_perc_best = d_diffr_pos_perc_my;


	for (int i_child = 0; i_child < v_children.size(); i_child++)
	{
		pc_node_other = v_children.at(i_child)->pcGetBestCrossingNode(iPatternLevel, pcInd0, pcInd1, &i_diffr_pos_other, &d_diffr_pos_perc_other);

		if (d_diffr_pos_perc_other > d_diffr_pos_perc_best)
		{
			pc_node_best = pc_node_other;
			i_diffr_pos_best = i_diffr_pos_other;
			d_diffr_pos_perc_best = d_diffr_pos_perc_other;
		}//if  (d_diffr_pos_perc_other > d_diffr_pos_perc_best)		
	}//for  (int i_child = 0; i_child < v_children.size(); i_child++)


	if (piDiffrentPositions != NULL)  *piDiffrentPositions = i_diffr_pos_best;
	if (pdDifrPosPerc != NULL)  *pdDifrPosPerc = d_diffr_pos_perc_best;


	return(pc_node_best);
}//C3LOPattern  *C3LOPattern::pcGetBestCrossingNode(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1)




bool  C3LOPattern::bUnMarkedPhenotypeDifferences(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int *piDifferenceSearchTool, int iPatternLevel)
{
	pcInd0->dComputeFitness(iPatternLevel);//phenotype creation forcing...
	pcInd1->dComputeFitness(iPatternLevel);//phenotype creation forcing...

	int  *pi_phenotype_0, *pi_phenotype_1;
	pi_phenotype_0 = pcInd0->piGetPhenotype(0);
	pi_phenotype_1 = pcInd1->piGetPhenotype(0);



	for (int ii = 0; ii < i_templ_length; ii++)
		piDifferenceSearchTool[ii] = -1;

	for (int ii = 0; ii < v_pattern.size(); ii++)
		piDifferenceSearchTool[v_pattern.at(ii).iGenePos()] = 1;
	
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		//we consider genes unmarked by tree
		if (piDifferenceSearchTool[ii] < 0)
		{
			if (pi_phenotype_0[ii] != pi_phenotype_1[ii])  return(true);
		}//if (piDifferenceSearchTool[ii] > 0)
	}//for (int ii = 0; ii < i_templ_length; ii++)

	return(false);
}//bool  C3LOPattern::bUnMarkedPhenotypeDifferences(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int *piDifferenceSearchTool, int iPatternLevel)



bool  C3LOPattern::bMarkedPhenotypeDifferences(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1, int iPatternLevel)
{
	pcInd0->dComputeFitness(iPatternLevel);//phenotype creation forcing...
	pcInd1->dComputeFitness(iPatternLevel);//phenotype creation forcing...

	int  *pi_phenotype_0, *pi_phenotype_1;
	pi_phenotype_0 = pcInd0->piGetPhenotype(0);
	pi_phenotype_1 = pcInd1->piGetPhenotype(0);

	for (int ii = 0; ii < v_pattern.size(); ii++)
	{
		if (pi_phenotype_0[v_pattern.at(ii).iGenePos()] != pi_phenotype_1[v_pattern.at(ii).iGenePos()])  return(true);
	}//for  (int  ii = 0; ii < v_pattern.size(); ii++)

	return(false);
}//bool  C3LOPattern::bMarkedPhenotypeDifferences(C3LOIndividual *pcInd0, C3LOIndividual  *pcInd1)





void  C3LOPattern::vJoinSinglePatternAdd(C3LOPattern  *pcPatOther)
{
	int  i_my_size_on_start;
	i_my_size_on_start = v_pattern.size();

	bool  b_found;
	for (int i_pat_other_offset = 0; i_pat_other_offset < pcPatOther->v_pattern.size(); i_pat_other_offset++)
	{
		b_found = false;

		for (int i_my_offset = 0; (i_my_offset < i_my_size_on_start) && (b_found == false); i_my_offset++)
		{
			if (v_pattern.at(i_my_offset).iGenePos() == pcPatOther->v_pattern.at(i_pat_other_offset).iGenePos())  b_found = true;
		}//for  (int  i_pat1_offset = 0; (i_pat1_offset < pcPat1->v_pattern.size())&&(b_found == false); i_pat1_offset++)

		if (b_found == false)  v_pattern.push_back(pcPatOther->v_pattern.at(i_pat_other_offset));

	}//for  (int  i_pat0_offset = 0; i_pat0_offset < pcPat0->v_pattern.size(); i_pat0_offset++)


	v_children.push_back(pcPatOther);
	pcPatOther->v_parents.push_back(this);
}//void  C3LOPattern::vJoinPattern(C3LOPattern  *pcPatOther)



void  C3LOPattern::vJoinTwoPatterns(C3LOPattern  *pcPat0, C3LOPattern  *pcPat1)
{
	if (v_pattern.size() == 0)
	{
		for (int i_pat0_offset = 0; i_pat0_offset < pcPat0->v_pattern.size(); i_pat0_offset++)
		{
			v_pattern.push_back(pcPat0->v_pattern.at(i_pat0_offset));
		}//for  (int  i_pat0_offset = 0; i_pat0_offset < pcPat0->v_pattern.size(); i_pat0_offset++)

		v_children.push_back(pcPat0);
		pcPat0->v_parents.push_back(this);
	}//if (v_pattern.size() == 0)
	else
		vJoinSinglePatternAdd(pcPat0);


	vJoinSinglePatternAdd(pcPat1);

	i_pattern_level = pcPat0->i_pattern_level;
	if (i_pattern_level < pcPat1->i_pattern_level)  i_pattern_level = pcPat1->i_pattern_level;

}//void  C3LOPattern::vJoinTwoPatterns(C3LOPattern  *pcPat0, C3LOPattern  *pcPat1)




bool  C3LOPattern::bAmIThere(vector<C3LOPattern  *>  *pvGenePatternsParts, bool  bCheckValues /*= false*/)
{
	for (int ii = 0; ii < pvGenePatternsParts->size(); ii++)
	{
		if (pvGenePatternsParts->at(ii)->iCommonPositions(this) > 0)  return(true);
	}//for  (int ii = 0; ii < pvGenePatternsParts->size(); ii++)

	return(false);
}//bool  C3LOPattern::bAmIThere(vector<C3LOPattern  *>  *pvGenePatternsParts)



bool  C3LOPattern::bGeneThere(int  iGenePosition)
{
	for (int ii = 0; ii < v_pattern.size(); ii++)
	{
		if (v_pattern.at(ii).iGenePos() == iGenePosition)  return(true);
	}//for  (int ii = 0; ii < pvGenePatternsParts->size(); ii++)

	return(false);
}//bool  C3LOPattern::bGeneThere(int  iGenePosition)




void  C3LOPattern::vSavePattern(FILE  *pfDest, int  *piProblemBlockStructure, CString  sTab /*=""*/, bool bOnlyRoot /*= false*/)
{
	bool  b_gene_pos_found;
	int  i_gene_val;

	fprintf(pfDest, "%s", sTab);

	fprintf(pfDest, "[%d]", i_pattern_level);

	int  i_offset_min, i_offset_max;

	i_offset_min = -1;
	i_offset_max = -1;

	for (int ii = 0; ii < v_pattern.size(); ii++)
	{
		if (i_offset_min == -1)  i_offset_min = v_pattern.at(ii).iGenePos();
		if (i_offset_max == -1)  i_offset_max = v_pattern.at(ii).iGenePos();

		if (i_offset_min  >  v_pattern.at(ii).iGenePos())  i_offset_min = v_pattern.at(ii).iGenePos();
		if (i_offset_max  <  v_pattern.at(ii).iGenePos())  i_offset_max = v_pattern.at(ii).iGenePos();

	}//for  (int  ii = 0; ii < v_pattern.size(); ii++)

	fprintf(pfDest, " (%d->%d)", i_offset_min, i_offset_max);



	for (int i_gene_pos = 0; i_gene_pos < i_templ_length; i_gene_pos++)
	{
		b_gene_pos_found = false;
		for (int ii = 0; (ii < v_pattern.size()) && (b_gene_pos_found == false); ii++)
		{
			if (i_gene_pos == v_pattern.at(ii).iGenePos())
			{
				i_gene_val = v_pattern.at(ii).iGeneVal();
				b_gene_pos_found = true;
			}//if  (i_gene_pos == v_disturbance_for_this.at(ii).iGenePos())  
		}//for  (int  ii = 0; (ii < v_distrub_candidates.size())&&(b_gene_pos_found == false); ii++)

		if (b_gene_pos_found == true)
			fprintf(pfDest, "%d", i_gene_val);
		else
			fprintf(pfDest, "*");

		/*if (pcFitness != NULL)
		{
			if (pcFitness->bLastBitOfSubfunction(i_gene_pos) == true)  fprintf(pfDest, " ");
		}//if  (pcFitness != NULL)*/


		if (piProblemBlockStructure != NULL)
		{
			if (piProblemBlockStructure[i_gene_pos] == 1)  fprintf(pfDest, " ");
		}//if (piProblemBlockStructure != NULL)

		
	}//for  (int ii = 0; ii < i_templ_length; ii++)

	fprintf(pfDest, "\n");

	if (bOnlyRoot == true)  return;


	sTab += C3LO_PATTERN_TAB_INCREASE;
	for (int ii = 0; ii < v_children.size(); ii++)
	{
		v_children.at(ii)->vSavePattern(pfDest, piProblemBlockStructure, sTab);
	}//for  (int  ii = 0; ii < v_children.size();  ii++)

}//void  C3LO::v_save_pattern(FILE  *pfDest, vector<CMessyGene> *pvPattern)



void  C3LOPattern::vSaveHighLevelGene(FILE  *pfDest, int  *piProblemBlockStructure)
{
	vSavePattern(pfDest, piProblemBlockStructure);

	for (int ii = 0; ii < v_high_level_gene_freq.size(); ii++)
	{
		v_high_level_gene_freq.at(ii)->vSave(pfDest, " ");
	}//for  (int  ii = 0; ii < v_high_level_gene_freq.size(); ii++)
}//void  C3LOPattern::vSaveHighLevelGene(FILE  *pfDest, CConcatDecFunc *pcFitness)





 //---------------------------------------------C3LOHighLvlGeneFreq-------------------------------------------------------
C3LOHighLvlGeneFreq::C3LOHighLvlGeneFreq(int  iTemplLength)
{
	pi_gene_def = NULL;
	i_templ_length = -1;
	i_gene_number = 0;

	vSetTemplLen(iTemplLength);
}//C3LOHighLvlGeneFreq::C3LOHighLvlGeneFreq()


C3LOHighLvlGeneFreq::~C3LOHighLvlGeneFreq()
{
	if (pi_gene_def != NULL)  delete  pi_gene_def;
}//C3LOHighLvlGeneFreq::~C3LOHighLvlGeneFreq()



void  C3LOHighLvlGeneFreq::vSetTemplLen(int  iTemplLength)
{
	if (iTemplLength <= 0)  return;
	i_templ_length = iTemplLength;

	if (pi_gene_def != NULL)  delete  pi_gene_def;
	pi_gene_def = new int[i_templ_length];
}//void  C3LOHighLvlGeneFreq::vSetTemplLen(int  iTemplLength)



void  C3LOHighLvlGeneFreq::vSave(FILE  *pfDest, CString  sTab /*= " "*/)
{
	CString  s_line, s_genotype, s_buf;

	s_genotype = "";

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_gene_def[ii]  <  0)
			s_buf = "*";
		else
			s_buf.Format("%d", pi_gene_def[ii]);

		s_genotype += s_buf;
	}//for  (int  ii = 0; ii < i_templ_length; ii++)


	s_line.Format("%d\t %s\n", i_gene_number, s_genotype);
	fprintf(pfDest, s_line);

}//void  C3LOHighLvlGeneFreq::vSave(FILE  *pfDest, CString  sTab /*= " "*/)



void  C3LOHighLvlGeneFreq::vInfect(C3LOIndividual  *pcInd)
{
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_gene_def[ii] >= 0)  pcInd->pi_genotype[ii] = pi_gene_def[ii];
	}//for  (int  ii = 0; ii < i_templ_length; ii++)

}//void  C3LOHighLvlGeneFreq::vInfect(C3LOIndividual  *pcInd)



void  C3LOHighLvlGeneFreq::vInfectPhenotype(C3LOIndividual  *pcInd, int iPhenotype)
{
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_gene_def[ii] >= 0)  pcInd->pi_optimized_genotypes[iPhenotype][ii] = pi_gene_def[ii];
	}//for  (int  ii = 0; ii < i_templ_length; ii++)
}//void  C3LOHighLvlGeneFreq::vInfectPhenotype(C3LOIndividual  *pcInd, int iPhenotype)



bool  C3LOHighLvlGeneFreq::bCheckHighLevelGene(C3LOIndividual *pcInd, int iPatternLevel)
{
	pcInd->dComputeFitness(iPatternLevel);//force phenotype creation

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_gene_def[ii] >= 0)
		{
			if (pcInd->piGetPhenotype(0)[ii] != pi_gene_def[ii])  return(false);
		}//if  (pi_gene_def[ii]  >=  0)
	}//for  (int  ii = 0; ii < i_templ_length; ii++)

	i_gene_number++;
	return(true);
}//bool  C3LOHighLvlGeneFreq::bCheckHighLevelGene(C3LOIndividual *pcInd)



void  C3LOHighLvlGeneFreq::vCreate(C3LOPattern  *pcPattern, C3LOIndividual *pcInd, int iPatternLevel)
{
	pcInd->dComputeFitness(iPatternLevel);//to force phenotype construction...

	for (int ii = 0; ii < i_templ_length; ii++)
		pi_gene_def[ii] = -1;

	for (int ii = 0; ii < pcPattern->pvGetPattern()->size(); ii++)
		pi_gene_def[pcPattern->pvGetPattern()->at(ii).iGenePos()] = pcInd->piGetPhenotype(0)[pcPattern->pvGetPattern()->at(ii).iGenePos()];

	i_gene_number = 1;
}//void  C3LOHighLvlGeneFreq::vCreate(C3LOPattern  *pcPattern, C3LOIndividual)







 //---------------------------class  CMessyGene--------------------------------------

CMessyGene::CMessyGene()
{
	i_gene_pos = 0;
	i_gene_val = 0;
}//CMessyGene::CMessyGene()


CMessyGene::CMessyGene(int  iGeneVal, int  iGenePos)
{
	i_gene_pos = iGenePos;
	i_gene_val = iGeneVal;
}//CMessyGene::CMessyGene(int  iGeneVal,  int  iGenePos)


CMessyGene::CMessyGene(CMessyGene  *pcOther)
{
	i_gene_pos = pcOther->i_gene_pos;
	i_gene_val = pcOther->i_gene_val;
}//CMessyGene::CMessyGene(CMessyGene  *pcOther)


CMessyGene::~CMessyGene()
{

};//CMessyGene::~CMessyGene()



int i_func_call(int iArg0, int iArg1)
{
	int *pi_result;

	pi_result = new int();
	*pi_result = iArg0 + iArg1;

	return(*pi_result);
};//int i_func_call(int iArg0, int iArg1)






  //---------------------------------------------CGenotypeInfoNode-------------------------------------------------------
CGenotypeInfoNode::CGenotypeInfoNode()
{
	int  i_value = -1;
	i_succ_opt = 0;
};//CGenotypeInfoNode::CGenotypeInfoNode()

CGenotypeInfoNode::~CGenotypeInfoNode()
{
	for (int ii = 0; ii < v_children.size(); ii++)
		delete  v_children.at(ii);
};//CGenotypeInfoNode::CGenotypeInfoNode()



C3LOIndividual *CGenotypeInfoNode::pcCheckIndividual(C3LOIndividual *pcIndToCheck)
{
	CGenotypeInfoNode  *pc_node;
	pc_node = pc_get_child_node(pcIndToCheck->pi_genotype[0]);

	C3LOIndividual *pc_result;
	pc_result = pc_node->pc_check_individual(pcIndToCheck, 1);

	if (pc_result != NULL)  i_succ_opt++;

	return(pc_result);
};//C3LOIndividual *CGenotypeInfoNode::pcCheckIndividual(C3LOIndividual *pcIndToCheck)



C3LOIndividual *CGenotypeInfoNode::pc_check_individual(C3LOIndividual *pcIndToCheck, int  iPos)
{
	//if (iPos >= pcIndToCheck->pc_fitness->iGetProblemBitLength())
	if (iPos >= pcIndToCheck->pc_problem->pcGetEvaluation()->iGetNumberOfElements())
	{
		if (v_individuals.size()  >  0)
			return(v_individuals.at(0));
		else
		{
			v_individuals.push_back(pcIndToCheck);
			return(NULL);
		}//else  if  (v_individuals.size()  >  0)  
	}//if  (iPos >= pc_fitness->iGetProblemBitLength())

	CGenotypeInfoNode  *pc_node;
	pc_node = pc_get_child_node(pcIndToCheck->pi_genotype[iPos]);

	return(pc_node->pc_check_individual(pcIndToCheck, ++iPos));
};//C3LOIndividual *CGenotypeInfoNode::pc_check_individual(C3LOIndividual *pcIndToCheck, int  iPos)



CGenotypeInfoNode  *CGenotypeInfoNode::pc_get_child_node(int  iVal)
{
	for (int ii = 0; ii < v_children.size(); ii++)
	{
		if (v_children.at(ii)->i_value == iVal)  return(v_children.at(ii));
	}//for  (int  ii = 0; ii < v_children.size(); ii++)

	CGenotypeInfoNode  *pc_new_node;
	pc_new_node = new CGenotypeInfoNode();
	pc_new_node->i_value = iVal;

	v_children.push_back(pc_new_node);

	return(pc_new_node);
};//CGenotypeInfoNode  *CGenotypeInfoNode::pc_get_child_node(int  iVal)

