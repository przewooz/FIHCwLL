#include "cGomea.h"



using  namespace nC_Gomea;



uint32_t C_CGomea::iERROR_PARENT_C_CGomea = CError::iADD_ERROR_PARENT("iERROR_PARENT_C_CGomea");
uint32_t C_CGomea::iERROR_CODE_C_CGomea_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_C_CGomea_GENOTYPE_LEN_BELOW_0");





//---------------------------------------------C_CGomea-------------------------------------------------------
C_CGomea::C_CGomea(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	pc_gomea_config = NULL;
	pc_cgomea_best_p3 = NULL;
	pi_bits = NULL;
};//C_CGomea::C_CGomea(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



C_CGomea::C_CGomea(C_CGomea *pcOther) : CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "Brak implementacji: C_CGomea::C_CGomea(C_CGomea *pcOther) : CBinaryOptimizer(pcOther)", "BRAK", MB_OK);
}//C_CGomea::C_CGomea(C_CGomea *pcOther) : CBinaryOptimizer(pcOther)



C_CGomea::~C_CGomea()
{
	if (pc_gomea_config != NULL)  delete  pc_gomea_config;
	if (pc_cgomea_best_p3 != NULL)  delete  pc_cgomea_best_p3;
	if (pi_bits != NULL)  delete  pi_bits;
}//C_CGomea::~C_CGomea()


void  C_CGomea::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();


	pc_gomea_config = new C_CGomea_Config();

	pc_gomea_config->conditionalGOM = 1;
	pc_gomea_config->populationScheme = 2;
	pc_gomea_config->FOSIndex = 4;
	pc_gomea_config->rng.seed(i_random_seed);
	pc_gomea_config->folder = "";

	pc_gomea_config->conditionalGOM = 1; //CGOM
	pc_gomea_config->populationScheme = 2; //P3
	pc_gomea_config->FOSIndex = 4; //Efficient Filtered LTFOS for P3 (without tournament selection)
	pc_gomea_config->hillClimber = 1; //single-iteration HC
	pc_gomea_config->donorSearch = 1; //turns on exhaustive donor search
	pc_gomea_config->orderFOS = 0; //ascending order by element sizes
	pc_gomea_config->similarityMeasure = 1; //NMI instead of MI

	pc_gomea_config->useForcedImprovements = 0; //no FI
	pc_gomea_config->tournamentSelection = 0; //no tournament selection, FOSIndex=4 can be used only when tournament isn't used
	pc_gomea_config->MI_threshold = 0.8; //threshold value for CGOM*/

	


	pc_gomea_config->problemIndex = 10;
	pc_gomea_config->numberOfVariables = i_templ_length;
	pc_gomea_config->problemInstancePath = "";
	pc_gomea_config->pc_external_problem_computer = pc_problem;
	

	pc_cgomea_best_p3 = new C_CGomea_gomeaP3_MI(pc_gomea_config);
}//void  C_CGomea::vInitialize(time_t tStartTime)



void  C_CGomea::vCopyFrom(C_CGomea *pcOther)
{
	i_templ_length = pcOther->i_templ_length;
}//void  C_CGomea::vCopyForm(C3LOscrapped *pcOther)



CError C_CGomea::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_C_CGomea);


	c_err = CBinaryOptimizer::eConfigure(psSettings);


	/*CUIntCommandParam p_pop_size(OPTIMIZER_ARGUMENT_POP_SIZE);
	i_pop_size = p_pop_size.iGetValue(psSettings, &c_err);
	if (p_pop_size.bHasValue() == false)  i_pop_size = 0;
	if (c_err)  return(c_err);*/

	return c_err;
};//CError C_CGomea::eConfigure(istream *psSettings)




bool C_CGomea::bRunIteration(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_C_CGomea);

	CString  s_buf;

	pc_cgomea_best_p3->vRunSingleIteration();

	v_get_best_genotype(&(pc_cgomea_best_p3->pcGetBestInd()->genotype));
	b_update_best_individual(iIterationNumber, pi_bits, pc_cgomea_best_p3->pcGetBestInd()->fitness);
	d_time_last_time = c_optimizer_timer.dGetTimePassed();


	s_buf.Format
	(
		"%.8lf gomeasNum: %d largestGomea: %d [time: %.8lf] [FFE:%.0lf]",
		//pc_cgomea_best_p3->pcGetBestInd()->fitness, pc_cgomea_best_p3->GOMEAs.size(), pc_cgomea_best_p3->GOMEAs.at(pc_cgomea_best_p3->GOMEAs.size() - 1)->population.size(),
		pc_cgomea_best_p3->pcGetBestInd()->fitness, pc_cgomea_best_p3->GOMEAs.size(), pc_cgomea_best_p3->GOMEAs.at(0)->population.size(),
		
		d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE()
	);
	pc_log->vPrintLine(s_buf, true);



	return(true);
}//bool C_CGomea::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)


void  C_CGomea::v_get_best_genotype(vector<char>  *pvGenotype)
{
	if (pi_bits == NULL)
		pi_bits = new int32_t[i_templ_length];

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pvGenotype->at(ii) == 1)
			pi_bits[ii] = 1;
		else
			pi_bits[ii] = 0;
	}//for (int ii = 0; ii < numberOfVariables; ii++)
}//void  C_CGomea::v_get_best_genotype(vector<char>  *pvGenotype)




double C_CGomea::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_compute_fitness_value(piBits);
	return(d_fitness_value);
}//double C_CGomea::dComputeFitness(int32_t *piBits)




CString  C_CGomea::sAdditionalSummaryInfo()
{
	CString  s_buf;

	return(s_buf);
};//CString  CDarkGrayGA::sAdditionalSummaryInfo() 
