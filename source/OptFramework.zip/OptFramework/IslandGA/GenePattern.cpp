#include "GenePattern.h"

#include <algorithm>

CGenePattern::CGenePattern()
{
	pv_pattern = new vector<uint16_t>();
	pd_differences = new vector<double>();
	pd_means = new vector<double>();
	pd_standard_deviations = new vector<double>();
	pi_bits = new vector<int32_t>();

	pc_parent_pattern = nullptr;
	pv_nested_patterns = new vector<CGenePattern*>();
}//CGenePattern::CGenePattern()

CGenePattern::CGenePattern(uint16_t iSignificantIndex)
	: CGenePattern()
{
	i_significant_index = iSignificantIndex;
}//CGenePattern::CGenePattern(uint16_t iSignificantIndex)

CGenePattern::~CGenePattern()
{
	pv_pattern->clear();
	delete pv_pattern;

	pd_differences->clear();
	delete pd_differences;

	pd_means->clear();
	delete pd_means;

	pd_standard_deviations->clear();
	delete pd_standard_deviations;

	pi_bits->clear();
	delete pi_bits;

	for (uint32_t i = 0; i < (uint32_t)pv_nested_patterns->size(); i++)
	{
		delete pv_nested_patterns->at(i);
	}//for (uint32_t i = 0; i < (uint32_t)pv_nested_patterns->size(); i++)

	pv_nested_patterns->clear();
	delete pv_nested_patterns;
}//CGenePattern::~CGenePattern()

void CGenePattern::vAdd(uint16_t iIndex, double dDifference, double dMean, double dStandardDeviation, int32_t iBit)
{
	pv_pattern->push_back(iIndex);
	pd_differences->push_back(dDifference);
	pd_means->push_back(dMean);
	pd_standard_deviations->push_back(dStandardDeviation);
	pi_bits->push_back(iBit);
}//void CGenePattern::vAdd(uint16_t iIndex, double dDifference, double dMean, double dStandardDeviation, int32_t iBit)

void CGenePattern::vAdd(CGenePattern *pcGenePattern)
{
	pv_pattern->reserve(pv_pattern->size() + (size_t)pcGenePattern->iGetSize());
	pd_differences->reserve(pd_differences->size() + (size_t)pcGenePattern->iGetSize());
	pd_means->reserve(pd_means->size() + (size_t)pcGenePattern->iGetSize());
	pd_standard_deviations->reserve(pd_standard_deviations->size() + (size_t)pcGenePattern->iGetSize());
	pi_bits->reserve(pi_bits->size() + (size_t)pcGenePattern->iGetSize());

	for (uint16_t i = 0; i < pcGenePattern->iGetSize(); i++)
	{
		vAdd(*(pcGenePattern->piGetPattern() + i), *(pcGenePattern->pdGetDifferences() + i), *(pcGenePattern->pdGetMeans() + i), 
			*(pcGenePattern->pdGetStandardDeviations() + i), *(pcGenePattern->piGetBits() + i));
	}//for (uint16_t i = 0; i < pcGenePattern->iGetSize(); i++)
}//void CGenePattern::vAdd(CGenePattern *pcGenePattern)

void CGenePattern::vAddNestedPattern(CGenePattern *pcNestedPattern)
{
	if (pcNestedPattern->pc_parent_pattern)
	{
		vector<CGenePattern*>::iterator it_begin = pcNestedPattern->pc_parent_pattern->pv_nested_patterns->begin();
		vector<CGenePattern*>::iterator it_end = pcNestedPattern->pc_parent_pattern->pv_nested_patterns->end();

		vector<CGenePattern*>::iterator it_value = find(it_begin, it_end, pcNestedPattern);

		if (it_value != it_end)
		{
			pcNestedPattern->pc_parent_pattern->pv_nested_patterns->erase(it_value);
		}//if (it_value != it_end)
	}//if (pcNestedPattern->pc_parent_pattern)

	pcNestedPattern->pc_parent_pattern = this;
	pv_nested_patterns->push_back(pcNestedPattern);
}//void CGenePattern::vAddNestedPattern(CGenePattern *pcNestedPattern)

void CGenePattern::vPopNestedPattern()
{
	delete pv_nested_patterns->at(pv_nested_patterns->size() - 1);
	pv_nested_patterns->pop_back();
}//void CGenePattern::vPopNestedPattern()

#include <iostream>

void CGenePattern::vSortNestedPatterns()
{
	sort(pv_nested_patterns->begin(), pv_nested_patterns->end(), [](CGenePattern *pcGenePattern0, CGenePattern *pcGenePattern1)
	{
		return pcGenePattern0->iGetSize() < pcGenePattern1->iGetSize();
	});//sort(pv_nested_patterns->begin(), pv_nested_patterns->end(), [](CGenePattern *pcGenePattern0, CGenePattern *pcGenePattern1)
}//void CGenePattern::vSortNestedPatterns()

CString CGenePattern::sToString()
{
	CString s_pattern;

	for (uint16_t i = 0; i < (uint16_t)pv_pattern->size(); i++)
	{
		s_pattern.AppendFormat("%d ", pv_pattern->at(i));
	}//for (uint16_t i = 0; i < (uint16_t)pv_pattern->size(); i++)

	return s_pattern;
}//CString CGenePattern::sToString()