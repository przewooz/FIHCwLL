#pragma once

#include <vector>
#include <unordered_map>
#include <string>
#include <fstream>
#include <deque>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <cassert>
#include <filesystem>

//#include <Python.h>

using namespace std;

#include "lkGomea_Individual.h"
#include "lkGomea_utils.h"

class C_lkGomea_Config;
#include "lkGomea_Config.h"

class C_lkGomea_Problem
{
public:
	int numberOfVariables;
	int usePartialEvaluations;
	vector<vector<int> > graph;
	
	C_lkGomea_Problem(){};
	virtual ~C_lkGomea_Problem(){};
	virtual void initializeProblem(C_lkGomea_Config *config, int numberOfVariables)=0;
	virtual double calculateFitness(C_lkGomea_Individual *solution)=0;
	virtual int getEvals(){return -1;};
	virtual double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
	virtual bool isKeySolution(vector<char> &genotype, double fitness)
	{
		static bool warnOnce = true;
		if (warnOnce)
		{
			cout << "[WARNING] Chosen problem does NOT provide any key solutions." << endl;
			warnOnce = false;
		}
		return false;
	};
	virtual vector<vector<int>> getProblemFOS()
	{
		cerr << "Problem used does not define a problem specific FOS.\n";
		cerr << "Please define within the problem class, or avoid using this mode." << endl;
		exit(0);
	}
};

class C_lkGomea_oneMax:public C_lkGomea_Problem
{
public:
	C_lkGomea_oneMax(){cout<<"creating oneMax\n";}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_)
	{
		numberOfVariables = numberOfVariables_;
	};
	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

// TODO: Rename this. This is the name of another function
// (which alternates 010101 for the optimum)
class C_lkGomea_zeroOneMax:public C_lkGomea_Problem
{
public:
	C_lkGomea_zeroOneMax(){cout<<"creating zeroOneMax\n";}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_)
	{
		numberOfVariables = numberOfVariables_;
	};
	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

class C_lkGomea_closestDistanceToGridPoints:public C_lkGomea_Problem
{
private:
	int k;
public:
	C_lkGomea_closestDistanceToGridPoints(int k_): k(k_)
	{
		cout<<"creating closestDistanceToGridPoints" << endl;
	}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_)
	{
		numberOfVariables = numberOfVariables_;
	};
	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

class C_lkGomea_bimodalModifiedTrap: public C_lkGomea_Problem
{
	int k, s;
	// This bimodal
	vector<vector<int>> trapsForVariable_a; //determines traps which each variables belongs to
	vector<vector<int>> trapsForVariable_b;
public:
	C_lkGomea_bimodalModifiedTrap(int k_, int s_): k(k_), s(s_)
	{
		cout<<"creating bimodalModifiedTrap" << endl;
	}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);
	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
	bool isKeySolution(vector<char> &genotype, double fitness);
};

class C_lkGomea_maxConcatenatedPermutedTraps: public C_lkGomea_Problem
{
	// Block size
	int k;
	// Seed (for rng)
	int s;
	// Number of functions.
	int fn;

	vector<vector<size_t>> permutations;
	vector<vector<char>> optima;

public:
	C_lkGomea_maxConcatenatedPermutedTraps(int k_, int s_, int fn_): k(k_), s(s_), fn(fn_)
	{
		cout<<"creating maxConcatenatedPermutedTraps" << endl;
	}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);
	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
	bool isKeySolution(vector<char> &genotype, double fitness);
	vector<vector<int>> getProblemFOS();

private:
	vector<double> calculateFitnessSubfunctions(vector<char> &genotype);
};

class C_lkGomea_concatenatedDeceptiveTrap:public C_lkGomea_Problem
{
	int k, s;
	bool bimodal;
	vector<vector<int> > trapsForVariable; //determines traps which each variables belongs to
public:
	C_lkGomea_concatenatedDeceptiveTrap(int k_, int s_, bool bimodal_): k(k_), s(s_), bimodal(bimodal_)
	{
		if (bimodal_ != true)
			cout<<"creating concatenated Deceptive Trap with trap size=" << k << " and shift=" << s << endl;
		else
		{
			if (k != 10 && k != 6)
			{
				cout << "Bimodal trap with k=" << k << " not implemented!" << endl;
				exit(0);
			}
			cout<<"creating bimodal concatenated Deceptive Trap with trap size=" << k << " and shift=" << s << endl;
		}
	}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);
	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

struct C_lkGomea_NKSubfunction
{
	vector<int> variablesPositions;
	vector<double> valuesTable;
};

class C_lkGomea_ADF:public C_lkGomea_Problem
{
	string problemInstanceFilename;
	vector<C_lkGomea_NKSubfunction> subfunctions;
	vector<vector<int> > subfunctionsForVariable;

public:
	C_lkGomea_ADF(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating ADF\n";
	}

	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);

	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
	vector<vector<int>> getProblemFOS();
};

class C_lkGomea_hierarchialDeceptiveTrap:public C_lkGomea_Problem
{
	int k;
	vector<int> transform;
public:
	C_lkGomea_hierarchialDeceptiveTrap(int k_): k(k_)
	{
		cout<<"creating hierarchialDeceptiveTrap\n";
	}

	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_)
	{
		numberOfVariables = numberOfVariables_;
		if (!C_lkGomea_isPowerOfK(numberOfVariables, k))
		{
			cerr << "Number of bits should be a power of k! " << numberOfVariables << " is not a power of " << k << endl;
			exit(0);
		}
		transform.resize(numberOfVariables);		
	};

	double generalTrap(int unitation, double leftPeak, double rightPeak);
	double calculateFitness(C_lkGomea_Individual *solution);
	//double calculateFitnessPartialEvaluations(Individual *solution, Individual *solutionBefore, vector<double> &touchedGenes, double fitnessBefore);
};

class C_lkGomea_hierarchialIfAndOnlyIf:public C_lkGomea_Problem
{
public:
	C_lkGomea_hierarchialIfAndOnlyIf()
	{
		cout<<"creating hierarchialIfAndOnlyIf\n";
	}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_)
	{
		numberOfVariables = numberOfVariables_;
		if (!C_lkGomea_isPowerOfK(numberOfVariables, 2))
		{
			cerr << "Number of bits should be a power of 2! " << numberOfVariables<< " is not a power of 2" << endl;
			exit(0);
		}

		graph.resize(numberOfVariables);
		for (int i = 0; i < numberOfVariables; ++i)
		{
			for (int j = 0; j < numberOfVariables; ++j)
			{
				if (i == j)
					continue;
				graph[i].push_back(j);
			}
		}

	};

	double calculateFitness(C_lkGomea_Individual *solution);
};

class C_lkGomea_maxCut:public C_lkGomea_Problem
{
	string problemInstanceFilename;
	vector<pair<pair<int, int>, double > > edges;
	vector<vector<int> > edgesForVariable;

public:
	C_lkGomea_maxCut(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating maxCut\n";
	}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);
	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};


class C_lkGomea_Clustering:public C_lkGomea_Problem
{
	string problemInstanceFilename;
	vector<vector<double> > points;
	vector<vector<double> > distances;
	
	int Dim;
public:
	C_lkGomea_Clustering(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating Clustering\n";
	}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);
	double calculateFitness(C_lkGomea_Individual *solution);
};

class C_lkGomea_MAXSAT:public C_lkGomea_Problem
{
	string problemInstanceFilename;
	vector<vector<int> > subfunctions;
	vector<vector<int> > signs;
	
	vector<vector<int> > subfunctionsForVariable;

public:
	C_lkGomea_MAXSAT(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating MAXSAT\n";
	}

	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);

	double calculateFitness(C_lkGomea_Individual *solution);

	vector<vector<int>> getProblemFOS();
};

class C_lkGomea_SpinGlass:public C_lkGomea_Problem
{
	string problemInstanceFilename;
	vector<vector<int> > subfunctions;
	
	vector<vector<int> > subfunctionsForVariable;

public:
	C_lkGomea_SpinGlass(string problemInstanceFilename_): problemInstanceFilename(problemInstanceFilename_)
	{
		cout<<"creating SpinGlass\n";
	}

	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);

	double calculateFitness(C_lkGomea_Individual *solution);
};

// BEGIN Best-of-Traps

// Definition
struct C_lkGomea_PermutedRandomTrap
{
    int number_of_parameters;
    int block_size;
    std::vector<size_t> permutation;
    std::vector<char> optimum;
};

struct C_lkGomea_BestOfTraps
{
    std::vector<C_lkGomea_PermutedRandomTrap> permutedRandomTraps;
};

class C_lkGomea_BestOfTrapsProblem:public C_lkGomea_Problem
{
private:
	std::string instance;
	C_lkGomea_BestOfTraps bot;

public:
	C_lkGomea_BestOfTrapsProblem(std::string _instance): instance(_instance)
	{
		cout<<"creating BestOfTraps" << endl;
	}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);
	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

class C_lkGomea_WorstOfTrapsProblem:public C_lkGomea_Problem
{
private:
	std::string instance;
	C_lkGomea_BestOfTraps bot;

public:
	C_lkGomea_WorstOfTrapsProblem(std::string _instance): instance(_instance)
	{
		cout<<"creating BestOfTraps" << endl;
	}
	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);
	double calculateFitness(C_lkGomea_Individual *solution);
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore);
};

struct C_lkGomea_MaxCutInstance
{
	size_t l;
	std::vector<std::tuple<size_t, size_t, long>> edges;
};

class C_lkGomea_WorstOfMaxcutProblem : public C_lkGomea_Problem
{
  private:
	std::vector<C_lkGomea_MaxCutInstance> maxcut_instances;
	size_t l;

  public:
	  C_lkGomea_WorstOfMaxcutProblem(std::string instance_str);

        void initializeProblem(C_lkGomea_Config * /* config */, int numberOfVariables_);

        double calculateFitness(C_lkGomea_Individual *solution);
        double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution,
			C_lkGomea_Individual *solutionBefore,
                                                  vector<int> &touchedGenes,
                                                  double fitnessBefore);
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////


/*class C_lkGomea_PythonFunction:public C_lkGomea_Problem
{
	string functionName, instancePath;
	C_lkGomea_PyObject *module, *functionClass, *functionInstance, *fitnessFunction, *getEvalsFunction;

public:
	C_lkGomea_PythonFunction(string functionName_, string instancePath_): functionName(functionName_), instancePath(instancePath_)
	{
		cout<<"creating Python Function " << functionName << endl;
	}
	~C_lkGomea_PythonFunction()
	{
		Py_DECREF(module);
		Py_DECREF(functionClass);
		Py_DECREF(functionInstance);
	}

	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);
	double calculateFitness(C_lkGomea_Individual *solution);
	int getEvals();
};*/


class C_lkGomea_External :public C_lkGomea_Problem
{

public:
	C_lkGomea_External(CProblem<CBinaryCoding, CBinaryCoding> *pcExternalProblem)
	{
		pc_external_problem = pcExternalProblem;
		//cout << "creating C_CGomea_External\n";
	}

	~C_lkGomea_External();

	void initializeProblem(C_lkGomea_Config *config, int numberOfVariables_);

	double calculateFitness(C_lkGomea_Individual *solution);

	int getEvals() { return pc_external_problem->pcGetEvaluation()->iGetFFE(); };
	double calculateFitnessPartialEvaluations(C_lkGomea_Individual *solution, C_lkGomea_Individual *solutionBefore, vector<int> &touchedGenes, double fitnessBefore) { ::Tools::vShow("virtual double C_lkGomea_External::calculateFitnessPartialEvaluations"); return 0; }

private:
	CProblem<CBinaryCoding, CBinaryCoding>  *pc_external_problem;
	CIndividual<CBinaryCoding, CBinaryCoding> *pc_evaluation_individual;
	int32_t *pi_bits;

};


double C_lkGomea_deceptiveTrap(int unitation, int k);
double C_lkGomea_bimodalDeceptiveTrap(int unitation, int k);

void createProblemInstance(int problemIndex, int numberOfVariables, C_lkGomea_Config *config, C_lkGomea_Problem **problemInstance, string &instancePath, int k = 1, int s = 1);
bool problemNameByIndex(C_lkGomea_Config *config, string &problemName);

