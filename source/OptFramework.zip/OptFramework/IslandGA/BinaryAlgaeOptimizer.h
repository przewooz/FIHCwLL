#pragma once
#include "PopulationSizingOptimizer.h"
#include "StringCommandParam.h"
#include <vector>
#include <math.h>
#include <random>
#include <algorithm>

#define BINARY_ALGAE_OPTIMIZER_ARGUMENT_POPULATION_SIZE "population_size"
#define BINARY_ALGAE_OPTIMIZER_ARGUMENT_NR "nr"
#define BINARY_ALGAE_OPTIMIZER_ARGUMENT_ENERGY_LOSS "energy_loss"
#define BINARY_ALGAE_OPTIMIZER_ARGUMENT_ADAPTATION "adaptation"
#define BINARY_ALGAE_OPTIMIZER_ARGUMENT_STALE_DETECTION "stale_detection"

class CBinaryAlgaeIndividual;


class CBinaryAlgaeOptimizer :
	public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>
{
public:
	static uint32_t iERROR_PARENT_CBinaryAlgaeOptimizer;
	static const uint32_t I_DEFAULT_POPULATION_SIZE;
	static const float F_DEFAULT_NR;
	static const float F_DEFAULT_ENERGY_LOSS;
	static const float F_DEFAULT_ADAPTATION;

	CBinaryAlgaeOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog* pcLog, uint32_t iRandomSeed);
	CBinaryAlgaeOptimizer(CBinaryAlgaeOptimizer* pcOther);
	virtual ~CBinaryAlgaeOptimizer();

	COptimizer<CBinaryCoding, CBinaryCoding>* pcCopy() override;
	CError eConfigure(istream* psSettings) override;

	bool bRunIteration(uint32_t iIterationNumber) override;
	void vInitialize() override;
	void vEvaluate();

	bool bIsSteadyState() override;
	double dComputeAverageFitnessValue() override;
	uint32_t iGetPopulationSize() override { return i_population_size; }
	void vSetPopulationSize(uint32_t iPopulationSize) override { i_population_size = iPopulationSize; };

protected:
	void v_delete_population();
	void v_initialize_population();
	double d_evaluate(CBinaryAlgaeIndividual* pc_individual);
	void v_update_best();
	void v_helical_movement_phase();
	void v_evaluation_phase();
	void v_adaptation_phase();
	void v_calculate_energy();
	void v_calculate_size();

	uniform_real_distribution<double> c_uniform_distribution;
	default_random_engine c_random_engine;

	vector<CBinaryAlgaeIndividual*> v_population;
	uint16_t i_genotype_length;
	uint32_t i_population_size;
	double d_nr;
	double d_energy_loss;
	double d_adaptation;
	bool b_use_stale_detection;
	CBinaryAlgaeIndividual* pc_best;
	double d_best_fitness;
};//class CBinaryAlgaeOptimizer

class CBinaryAlgaeIndividual
{
public:
	friend class CBinaryAlgaeOptimizer;

	CBinaryAlgaeIndividual(uint16_t iGenotypeLength);
	CBinaryAlgaeIndividual(CBinaryAlgaeIndividual *pcOther);

	static CBinaryAlgaeIndividual* pcGetRandomIndividual(
		uint16_t iGenotypeLength,
		uniform_real_distribution<double>& cUniformDistribution,
		default_random_engine& cRandomEngine);

	void vUpdateRelativeFitness(double dBestFitness, double dWorstFitness);
	void vUpdateSize();

protected:
	double d_fitness;
	double d_size;
	uint16_t i_starvation;
	double d_relative_fitness; // from an article, this is how good individual fitness is compared to other solutions in population
	double d_energy;
	
	vector<int32_t> v_genotype;
};//class CBinaryAlgaeIndividual
