#include "LTDE.h"

#include "PointerUtils.h"

#include <cfloat>

CLTDE::CLTDE(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	:	CPopulationOptimizer<CRealCoding, CRealCoding>(pcProblem, pcLog, iRandomSeed), 
		c_mutation_factor_adaptation(pcProblem->pcGetEvaluation()->iGetNumberOfElements(), pcLog)
{
	v_init();

	pc_mutation = nullptr;
	pc_dsm_creation = nullptr;
}//CLTDE::CLTDE(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

CLTDE::CLTDE(CLTDE *pcOther)
	:	CPopulationOptimizer<CRealCoding, CRealCoding>(pcOther), 
		c_mutation_factor_adaptation(pcOther->c_mutation_factor_adaptation)
{
	v_init();

	pc_mutation = pcOther->pc_mutation;;
	pc_dsm_creation = pcOther->pc_dsm_creation;
}//CLTDE::CLTDE(CLTDE *pcOther)

CLTDE::~CLTDE()
{
	delete ppc_genotypes;

	uint32_t i_number_of_elements = (uint32_t)pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	PointerUtils::vDelete(ppd_dsm, i_number_of_elements);
	PointerUtils::vDelete(ppd_mutation_factor_adaptation, i_number_of_elements);

	v_clear_params();
}//CLTDE::~CLTDE()

CError CLTDE::eConfigure(istream *psSettings)
{
	v_clear_params();

	CError c_error = CPopulationOptimizer<CRealCoding, CRealCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		pc_dsm_creation = DSMCreationUtils::pcGetDSMCreation<CRealCoding>
			(
				psSettings, 
				pc_problem->pcGetEvaluation()->iGetNumberOfElements(),
				pc_log,
				&c_error
			);
	}//if (!c_error)

	if (!c_error)
	{
		c_error = c_mutation_factor_adaptation.eConfigure(psSettings);
	}//if (!c_error)

	if (!c_error)
	{
		pc_mutation = MutationUtils::pcGetRealFactorMutation(pl_gene_patterns, psSettings, &c_error);
	}//if (!c_error)

	return c_error;
}//CError CLTDE::eConfigure(istream *psSettings)

void CLTDE::vInitialize()
{
	CPopulationOptimizer<CRealCoding, CRealCoding>::vInitialize();

	delete ppc_genotypes;
	ppc_genotypes = new CRealCoding*[i_population_size];

	v_fill_genotypes();

	pc_mutation->vUpdatePopulation(i_population_size, ppc_genotypes);
}//void CLTDE::vInitialize(time_t tStartTime)

bool CLTDE::bRunIteration(uint32_t iIterationNumber)
{
	uint16_t i_number_of_elements = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	pc_dsm_creation->vFillDSM(ppc_genotypes, i_population_size, ppd_dsm);
	c_mutation_factor_adaptation.vFillDSM(ppc_genotypes, i_population_size, ppd_mutation_factor_adaptation);

	CString s_buf;

	pc_log->vPrintLine("DSM");

	for (size_t i = 0; i < i_number_of_elements; i++)
	{
		for (size_t j = 0; j < i_number_of_elements; j++)
		{
			s_buf.AppendFormat("%f ", ppd_dsm[i][j]);
		}

		s_buf.Append("\n");
	}

	//pc_log->vPrintLine(s_buf);

	CHierarchicalClustering c_clustering((uint32_t)i_number_of_elements, ppd_dsm, pc_log);
	c_clustering.vRun();

	CGenePatternTree c_gene_pattern_tree(c_clustering.pvGetClusterIndexes());

	for (uint32_t i = 0; i < i_population_size; i++)
	{
		v_run_iteration(ppc_population + i, i, c_gene_pattern_tree.pvGetAllGenePatterns());
	}//for (uint32_t i = 0; i < i_population_size; i++)

	pc_mutation->vUpdatePopulation(i_population_size, ppc_genotypes);

	//pc_log->vPrintLine("iteration", true);

	bool b_updated = b_update_best_individual(iIterationNumber);

	if (b_updated)
	{
		//pc_log->vPrintLine("!!! NEW BEST !!!", true);
	}//if (b_updated)

	CString s_log_message;

	s_log_message.Format
	(
		"iteration: %u; time: %.2lf; ffe: %u; best: %f; population_size: %u", 
		iIterationNumber, 
		c_optimizer_timer.dGetTimePassed(), 
		pc_problem->pcGetEvaluation()->iGetFFE(), 
		pc_best_individual->dGetFitnessValue(),
		i_population_size
	);
	
	pc_log->vPrintLine(s_log_message, true);

	return b_updated;
}//bool CLTDE::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

void CLTDE::v_init()
{
	ppc_genotypes = nullptr;
	ppd_dsm = c_mutation_factor_adaptation.ppdCreateEmptyDSM();
	ppd_mutation_factor_adaptation = c_mutation_factor_adaptation.ppdCreateEmptyDSM();
}//void CLTDE::v_init()

void CLTDE::v_clear_params()
{
	if (b_own_params)
	{
		delete pc_mutation;
		pc_mutation = nullptr;

		delete pc_dsm_creation;
		pc_dsm_creation = nullptr;
	}//if (b_own_params)
}//void CLTDE::v_clear_params()

void CLTDE::v_run_iteration(CIndividual<CRealCoding, CRealCoding> **ppcIndividual, uint32_t iIndividualIndex, vector<CGenePattern*> *pvGenePatterns)
{
	//v_run_iteration(ppcIndividual, iIndividualIndex, pvGenePatterns->at(RandUtils::iRandIndex(pvGenePatterns->size() - 1)));

	//uint16_t i_number_of_elements = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	for (size_t i = 0; i < pvGenePatterns->size(); i++)
	{
		v_run_iteration(ppcIndividual, iIndividualIndex, pvGenePatterns->at(i));
	}//for (size_t i = 0; i < pvGenePatterns->size(); i++)
}//void CLTDE::v_run_iteration(CIndividual<CRealCoding, CRealCoding> **ppcIndividual, uint32_t iIndividualIndex, vector<CGenePattern*> *pvGenePatterns)

void CLTDE::v_run_iteration(CIndividual<CRealCoding, CRealCoding> **ppcIndividual, uint32_t iIndividualIndex, CGenePattern *pcGenePattern)
{
	//pc_log->vPrintLine(pcGenePattern->sToString(), true);

	CIndividual<CRealCoding, CRealCoding> *pc_individual = *ppcIndividual;
	CIndividual<CRealCoding, CRealCoding> *pc_mutant = new CIndividual<CRealCoding, CRealCoding>(pc_individual);
	CIndividual<CRealCoding, CRealCoding> *pc_clone = new CIndividual<CRealCoding, CRealCoding>(pc_individual);
	
	//pc_mutation->bMutate(pc_mutant->pcGetGenotype(), iIndividualIndex);
	
	v_mutation(pc_mutant, iIndividualIndex, pcGenePattern);
	v_crossover(pc_clone, pc_mutant, pcGenePattern);

	pc_clone->vIsEvaluated(false);
	pc_clone->vEvaluate();

	if (!pc_problem->bIsBetterIndividual(pc_individual, pc_clone))
	{
		delete pc_individual;
		*ppcIndividual = pc_clone;

		*(ppc_genotypes + iIndividualIndex) = pc_clone->pcGetGenotype();

		b_update_best_individual(1);

		//pc_log->vPrintLine("BETTER", true);
	}//if (!pc_problem->bIsBetterIndividual(pc_individual, pc_clone))
	else
	{
		delete pc_clone;
	}//else if (!pc_problem->bIsBetterIndividual(pc_individual, pc_clone))

	pc_mutation->vUpdatePopulation(i_population_size, ppc_genotypes);

	delete pc_mutant;
}//void CLTDE::v_run_iteration(CIndividual<CRealCoding, CRealCoding> **ppcIndividual, uint32_t iIndividualIndex, CGenePattern *pcGenePattern)

void CLTDE::v_mutation(CIndividual<CRealCoding, CRealCoding> *pcIndividual, uint32_t iIndividualIndex, CGenePattern *pcGenePattern)
{
	unordered_set<uint32_t> s_indexes(REAL_MUTATION_RAND_1_NUMBER_OF_RANDOM_INDEXES + 1);
	s_indexes.insert(iIndividualIndex);

	uint32_t pi_rand_indexes[REAL_MUTATION_RAND_1_NUMBER_OF_RANDOM_INDEXES];

	for (uint32_t i = 0; i < REAL_MUTATION_RAND_1_NUMBER_OF_RANDOM_INDEXES; i++)
	{
		*(pi_rand_indexes + i) = RandUtils::iRandUniqueIndex(i_population_size, &s_indexes);
		s_indexes.insert(*(pi_rand_indexes + i));
	}//for (uint32_t i = 0; i < REAL_MUTATION_RAND_1_NUMBER_OF_RANDOM_INDEXES; i++)

	CIndividual<CRealCoding, CRealCoding> *pc_rand_individual_0 = *(ppc_population + *(pi_rand_indexes + 0));
	CIndividual<CRealCoding, CRealCoding> *pc_rand_individual_1 = *(ppc_population + *(pi_rand_indexes + 1));
	CIndividual<CRealCoding, CRealCoding> *pc_rand_individual_2 = *(ppc_population + *(pi_rand_indexes + 2));

	CRealCoding *pc_rand_genotype_0 = pc_best_individual->pcGetGenotype(); //pc_rand_individual_0->pcGetGenotype();
	CRealCoding *pc_rand_genotype_1 = pc_rand_individual_1->pcGetGenotype();
	CRealCoding *pc_rand_genotype_2 = pc_rand_individual_2->pcGetGenotype();

	CRealCoding *pc_genotype = pcIndividual->pcGetGenotype();

	double d_mutation_factor;
	uint16_t i_gene_index;

	for (uint16_t i = 0; i < pcGenePattern->iGetSize(); i++)
	{
		i_gene_index = *(pcGenePattern->piGetPattern() + i);
		d_mutation_factor = d_get_mutation_factor(i_gene_index, pcGenePattern);

		CString s_buf;
		s_buf.AppendFormat("%f", d_mutation_factor);

		//pc_log->vPrintLine(s_buf, true);

		*(pc_genotype->pdGetValues() + i_gene_index) = (*(pc_rand_genotype_0->pdGetValues() + i_gene_index)) +
			d_mutation_factor * (*(pc_rand_genotype_1->pdGetValues() + i_gene_index) - *(pc_rand_genotype_2->pdGetValues() + i_gene_index));
	}//for (uint16_t i = 0; i < pcGenePattern->iGetSize(); i++)

	pc_genotype->vRepair();
}//void CLTDE::v_mutation(CIndividual<CRealCoding, CRealCoding> *pcIndividual, uint32_t iIndividualIndex, CGenePattern *pcGenePattern)

void CLTDE::v_crossover(CIndividual<CRealCoding, CRealCoding> *pcSource, CIndividual<CRealCoding, CRealCoding> *pcDonor, CGenePattern *pcGenePattern)
{
	//uint16_t i_number_of_elements = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	//for (uint16_t i = 0; i < i_number_of_elements; i++)
	//{
	//	if (RandUtils::bSatisfyProbability(0.5))
	//	{
	//		*(pcSource->pcGetGenotype()->pdGetValues() + i) = *(pcDonor->pcGetGenotype()->pdGetValues() + i);
	//	}//if (RandUtils::bSatisfyProbability(0.5))
	//}//for (uint16_t i = 0; i < i_number_of_elements; i++)

	uint16_t i_pattern_index;

	for (uint16_t i = 0; i < pcGenePattern->iGetSize(); i++)
	{
		i_pattern_index = *(pcGenePattern->piGetPattern() + i);
		*(pcSource->pcGetGenotype()->pdGetValues() + i_pattern_index) = *(pcDonor->pcGetGenotype()->pdGetValues() + i_pattern_index);
	}//for (uint16_t i = 0; i < pcGenePattern->iGetSize(); i++)
}//void CLTDE::v_crossover(CIndividual<CRealCoding, CRealCoding> *pcSource, CIndividual<CRealCoding, CRealCoding> *pcDonor, CGenePattern *pcGenePattern)

double CLTDE::d_get_mutation_factor(uint16_t iGeneIndex, CGenePattern *pcGenePattern)
{
	double d_mutation_factor = DBL_MAX;

	if (pcGenePattern->iGetSize() > 1)
	{
		uint16_t i_gene_index_buf;
		double d_mutation_factor_adaptation;

		for (uint16_t i = 0; i < pcGenePattern->iGetSize(); i++)
		{
			i_gene_index_buf = *(pcGenePattern->piGetPattern() + i);

			if (i_gene_index_buf != iGeneIndex)
			{
				d_mutation_factor_adaptation = *(*(ppd_mutation_factor_adaptation + iGeneIndex) + i_gene_index_buf);

				if (d_mutation_factor_adaptation < d_mutation_factor)
				{
					d_mutation_factor = d_mutation_factor_adaptation;
				}//if (d_mutation_factor_adaptation < d_mutation_factor)
			}//if (i_gene_index_buf != iGeneIndex)
		}//for (uint16_t i = 0; i < pcGenePattern->iGetSize(); i++)

		d_mutation_factor *= 0.5;
		d_mutation_factor += 0.5;
	}//if (pcGenePattern->iGetSize() > 1)
	else
	{
		d_mutation_factor = 0.5;
	}//else if (pcGenePattern->iGetSize() > 1)

	//d_mutation_factor = 0.5;

	return d_mutation_factor;
}//double CLTDE::d_get_mutation_factor(uint16_t iGeneIndex, CGenePattern *pcGenePattern)

void CLTDE::v_fill_genotypes()
{
	for (uint32_t i = 0; i < i_population_size; i++)
	{
		*(ppc_genotypes + i) = (*(ppc_population + i))->pcGetGenotype();
	}//for (uint32_t i = 0; i < i_population_size; i++)
}//void CLTDE::v_fill_genotypes()
