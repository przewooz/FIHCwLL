#include "EmPFDec.h"
#include "P3.h"

#include "CommandParam.h"
#include "FloatCommandParam.h"
#include "UIntCommandParam.h"
#include "StringUtils.h"

#include <algorithm>
#include <functional>
#include <vector>


using namespace EmPfDec;

//---------------------------------------------CMO_EmPfDec-------------------------------------------------------
uint32_t CMO_EmPfDec::iERROR_PARENT_CMO_EmPfDec_Optimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_CMO_EmPfDec_Optimizer");
uint32_t CMO_EmPfDec::iERROR_CODE_CMO_EmPfDec_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_CMO_EmPfDec_GENOTYPE_LEN_BELOW_0");
uint32_t CMO_EmPfDec::iERROR_CODE_CMO_EmPfDec_UNKNOWN_DECOMPOSITION_TYPE = CError::iADD_ERROR("iERROR_CODE_CMO_EmPfDec_UNKNOWN_DECOMPOSITION_TYPE");



CMO_EmPfDec::CMO_EmPfDec(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryMultiObjectiveOptimizer(pcProblem, pcLog, iRandomSeed)
	//: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	//pc_problem = (CBinaryMultiObjectiveProblem *) pcProblem;

};//CMO_EmPfDec::CMO_EmPfDec(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)


CMO_EmPfDec::CMO_EmPfDec(CMO_EmPfDec *pcOther) : CBinaryMultiObjectiveOptimizer(pcOther)//CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "No implementation: CMO_MPP3::CMO_MPP3(CMO_MPP3 *pcOther) : CBinaryMultiObjectiveOptimizer(pcOther)//CBinaryOptimizer(pcOther)", "Implementation missing", MB_OK);
};//CMO_EmPfDec::CMO_EmPfDec(CMO_MPP3 *pcOther) : CBinaryMultiObjectiveOptimizer(pcOther)//CBinaryOptimizer(pcOther)


CMO_EmPfDec::~CMO_EmPfDec()
{
	delete  pc_clear_p3;
	for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
		delete  v_directed_optimizers.at(ii);

	for (int ii = 0; ii < v_decomposition_population.size(); ii++)
		delete  v_decomposition_population.at(ii);

	for (int ii = 0; ii < v_pop_orderings.size(); ii++)
		delete  v_pop_orderings.at(ii);
	
}//CMO_MPP3::~CMO_MPP3()



CError CMO_EmPfDec::eConfigure(istream *psSettings)
{
	CError  c_err(iERROR_PARENT_CMO_EmPfDec_Optimizer);
	CString  s_buf;

	c_err = CBinaryOptimizer::eConfigureNSGA2(psSettings);



	i_ordering_individuals_number = 0;
	if (!c_err)
	{
		CUIntCommandParam p_ordering_inds_number(EMPIRICAL_PF_DECOMPOSER_ARGUMENT_ORDERING_INDIVIDUALS_NUMBER);
		i_ordering_individuals_number = p_ordering_inds_number.iGetValue(psSettings, &c_err);
	}//if (!c_err)


	i_orderings_number = 0;
	if (!c_err)
	{
		CUIntCommandParam p_orderings_number(EMPIRICAL_PF_DECOMPOSER_ARGUMENT_ORDERINGS_NUMBER);
		i_orderings_number = p_orderings_number.iGetValue(psSettings, &c_err);
	}//if (!c_err)
	


	i_decomposition_type = -1;
	if (!c_err)
	{
		CStringCommandParam p_decomposition_type(EMPIRICAL_PF_DECOMPOSER_ARGUMENT_DECOMPOSITION_TYPE);

		CString  s_decom_type;
		s_decom_type = p_decomposition_type.sGetValue(psSettings, &c_err);

		if (s_decom_type == EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_UNIFORM_TEXT)
			i_decomposition_type = EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_UNIFORM;

		if (s_decom_type == EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_EMPIRICAL_TEXT)
			i_decomposition_type = EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_EMPIRICAL;

		if (i_decomposition_type < 0)
		{
			s_buf.Format("Unknown decomposition type (%s)", s_decom_type);
			c_err.vSetError(iERROR_CODE_CMO_EmPfDec_UNKNOWN_DECOMPOSITION_TYPE, s_buf);
			return(c_err);			
		}//if (i_decomposition_type < 0)

	}//if (!c_err)

	

	pc_clear_p3 = new CP3(pc_problem, pc_log, i_random_seed);
	c_err = pc_clear_p3->eConfigure(psSettings);

	return(c_err);
}//virtual CError CMO_EmPfDec::eConfigure(istream *psSettings)


void CMO_EmPfDec::vInitialize()
{
	CBinaryOptimizer::vInitialize();

	CError  c_err(iERROR_PARENT_CMO_EmPfDec_Optimizer);
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	if (i_templ_length <= 0)
	{
		c_err.vSetError(CMO_MPP3::iERROR_CODE_CMO_MPP3_GENOTYPE_LEN_BELOW_0);
		return;
	}//if  (i_templ_length  <=  0)


	pc_log->vPrintLine("Initializing...", true);

	pc_clear_p3->vInitialize();

	/*i_pop_p3_number = 2;

	for (int ii = 0; ii < i_pop_p3_number; ii++)
	{
		v_p3.push_back((CP3 *)pc_clear_p3->pcCopy());
		v_p3.at(ii)->vInitialize(tStartTime);

		v_improved_pf_tool.push_back(0);
	}//for (int ii = 0; ii < i_pop_p3_number; ii++)*/


	pc_log->vPrintLine("DONE...", true);

	c_time_counter.vSetStartNow();


	v_generate_ordering_individuals(i_ordering_individuals_number);
	v_generate_orderings(i_orderings_number);
	//v_generate_directed_populations();
	v_generate_directed_populations_simple();

	i_pops_analysis_frequency = 200;
	i_pops_analysis_remaining_iters = i_pops_analysis_frequency;
	b_pops_unlocked = false;
};//void CMO_EmPfDec::vInitialize(time_t tStartTime);




void  CMO_EmPfDec::v_add_pop_ordering(CBinaryMultiObjectiveProblem  *pcMultiProblem, vector<CEmPFDec_Ordering*>  *pvPopOrderings, vector<CEmPFDec_Individual *>  *pvDecompositionPopulation, double  dWeight0, double dWeight1)
{
	CEmPFDec_Ordering  *pc_new_pop_order;

	pc_new_pop_order = new CEmPFDec_Ordering(pcMultiProblem, pvDecompositionPopulation);
	pc_new_pop_order->d_weight_0 = dWeight0;
	pc_new_pop_order->d_weight_1 = dWeight1;
	pc_new_pop_order->vGetPopOrder();


	for (int ii = 0; ii < pvPopOrderings->size(); ii++)
	{
		if (dWeight0 < pvPopOrderings->at(ii)->d_weight_0)
		{
			pvPopOrderings->insert(pvPopOrderings->begin() + ii, pc_new_pop_order);
			return;
		}//if (dWeight0 < pvPopOrderings->at(ii)->d_weight_0)
	}//for (int ii = 0; ii < pvPopOrderings->size(); ii++)

	pvPopOrderings->push_back(pc_new_pop_order);
}//void  CMO_EmPfDec::v_add_pop_ordering(CBinaryMultiObjectiveProblem  *pc_multi_problem, vector<CEmPFDec_Ordering*>  *pvPopOrders, vector<CEmPFDec_Individual *>  *pvDecompositionPopulation, double  dWeight0, double dWeight1)




void  CMO_EmPfDec::v_generate_ordering_individuals(int iOrderingIndividualsNumber)
{
	CString  s_buf;
	double  d_time_passed;

	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();

	vector<CMultiObjectiveMeasure*>  *pv_mesaures;
	pv_mesaures = pc_multi_problem->pvGetMeasures();

	pv_mesaures->at(0)->dWeight = 0.5;
	pv_mesaures->at(1)->dWeight = 0.5;

	CString  s_rep_file = "__ind_ordering.txt";
	if (EMPF_IND_DEBUG)  ::Tools::vReportInFile(s_rep_file, "", true);


	CEmPFDec_Individual  *pc_new_individual;
	for (int ii = 0; ii < iOrderingIndividualsNumber; ii++)
	{
		pc_new_individual = new CEmPFDec_Individual(pc_problem->pcGetEvaluation()->iGetNumberOfElements(), pc_problem, this);
		pc_new_individual->vRandomInit();

		pv_mesaures->at(0)->dWeight = RandUtils::dRandNumber(0, 1);
		pv_mesaures->at(1)->dWeight = 1.0 - pv_mesaures->at(0)->dWeight;

		//pv_mesaures->at(0)->dWeight = 0.6570024719992675;
		//pv_mesaures->at(1)->dWeight = 1.0 - pv_mesaures->at(0)->dWeight;


		pc_new_individual->dGetFitness();

		if (EMPF_IND_DEBUG)
		{
			vector<double>  v_measure_values;
			pc_multi_problem->vEvaluateParetoFront(&v_measure_values, pc_new_individual->pc_genotype);

			s_buf.Format("%.16lf \t %.16lf \t VALUES: %.16lf \t %.16lf", pv_mesaures->at(0)->dWeight, pv_mesaures->at(1)->dWeight, v_measure_values.at(0), v_measure_values.at(1));
			::Tools::vReportInFile(s_rep_file, s_buf);
		}//if (EMPF_IND_DEBUG)

		v_decomposition_population.push_back(pc_new_individual);
	}//for (int ii = 0; ii < i_add_factor; ii++)
}//void  CMO_EmPfDec::v_generate_ordering_individuals(int iOrderingIndividualsNumber)



void  CMO_EmPfDec::v_generate_orderings(int iMaxOrderingsNumnber)
{
	if (i_decomposition_type == EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_UNIFORM)  v_generate_orderings_uniform(iMaxOrderingsNumnber);
	if (i_decomposition_type == EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_EMPIRICAL)  v_generate_orderings_empirical(iMaxOrderingsNumnber);
}//void  CMO_EmPfDec::v_generate_orderings(int iMaxOrderingsNumnber)




void  CMO_EmPfDec::v_generate_orderings_uniform(int iMaxOrderingsNumnber)
{
	CString  s_buf;
	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();


	CEmPFDec_Ordering  *pc_new_pop_order;


	double  d_weight;
	for (double i_step = 0; i_step < iMaxOrderingsNumnber; i_step++)
	{
		d_weight = 1.0 / (iMaxOrderingsNumnber - 1);
		d_weight *= i_step;

		if (i_step == iMaxOrderingsNumnber)  d_weight = 1.0;

		v_add_pop_ordering(pc_multi_problem, &v_pop_orderings, &v_decomposition_population, d_weight, 1.0 - d_weight);
	}//for (double d_weight = 0; d_weight < 1.0 - d_step; d_weight += d_step)*/

	
	int  i_dist, i_dist_max, i_dist_offset;

	for (int i_first = 0; i_first < v_pop_orderings.size() - 1; i_first++)
	{
		i_dist = v_pop_orderings.at(i_first)->iCompare(v_pop_orderings.at(i_first + 1));
		if (i_dist_max < i_dist)
		{
			i_dist_max = i_dist;
			i_dist_offset = i_first;
		}//if (i_dist_max < i_dist)
	}//for (int i_first = 0; i_first < v_pop_orderings.size() - 1; i_first++)



	CString  s_file_pf_decom_test;
	s_file_pf_decom_test.Format("_pf_decom_uniform_test_weight_ordering_pop_%.3d_orderings_%.4d.txt", v_decomposition_population.size(), iMaxOrderingsNumnber);

	if (EMPF_IND_DEBUG)  ::Tools::vReportInFile(s_file_pf_decom_test, "", true);

	//	int  i_dist;
	CString  s_line;
	i_dist_max = 0;
	double  d_dist_avr = 0;
	for (int ii = 0; ii < v_pop_orderings.size() - 1; ii++)
	{
		s_line = v_pop_orderings.at(ii)->sToString();
		s_line += "  |||  ";
		s_line += v_pop_orderings.at(ii + 1)->sToString();

		i_dist = v_pop_orderings.at(ii)->iCompare(v_pop_orderings.at(ii + 1));
		s_buf.Format("\t DIST: \t %d", i_dist);
		s_line += s_buf;

		if (EMPF_IND_DEBUG)  ::Tools::vReportInFile(s_file_pf_decom_test, s_line);

		d_dist_avr += i_dist;
		if (i_dist_max < i_dist)  i_dist_max = i_dist;
	}//for (int ii = 0; ii < v_pop_orders.size(); ii++)

	d_dist_avr = d_dist_avr / (v_pop_orderings.size() - 1);
	s_line.Format("\t DISTavr: \t %.4lf  \t DISTmax: \t %d", d_dist_avr, i_dist_max);
	if (EMPF_IND_DEBUG)  ::Tools::vReportInFile(s_file_pf_decom_test, s_line);

	//s_buf.Format("%d", v_decomposition_population.size());
	//::Tools::vShow(s_buf);
}//void  CMO_EmPfDec::v_generate_orderings(int iMaxOrderingsNumnber)





void  CMO_EmPfDec::v_generate_orderings_empirical(int iMaxOrderingsNumnber)
{
	CString  s_buf;
	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();


	CEmPFDec_Ordering  *pc_new_pop_order;


	double  d_step = 0.01;
	for (double d_weight = 0; d_weight <= 1.0001; d_weight += d_step)
	{
		pc_new_pop_order = new CEmPFDec_Ordering(pc_multi_problem, &v_decomposition_population);
		pc_new_pop_order->d_weight_0 = d_weight;
		pc_new_pop_order->d_weight_1 = 1.0 - pc_new_pop_order->d_weight_0;
		pc_new_pop_order->vGetPopOrder();

		v_pop_orderings.push_back(pc_new_pop_order);
	}//for (double d_weight = 0; d_weight < 1.0 - d_step; d_weight += d_step)*/



	v_add_pop_ordering(pc_multi_problem, &v_pop_orderings, &v_decomposition_population, 0, 1);
	v_add_pop_ordering(pc_multi_problem, &v_pop_orderings, &v_decomposition_population, 1, 0);

	int  i_dist, i_dist_max, i_dist_offset;

	bool  b_finished = false;
	while (b_finished == false)
	{
		i_dist_max = 0;

		for (int i_first = 0; i_first < v_pop_orderings.size() - 1; i_first++)
		{
			i_dist = v_pop_orderings.at(i_first)->iCompare(v_pop_orderings.at(i_first + 1));
			if (i_dist_max < i_dist)
			{
				i_dist_max = i_dist;
				i_dist_offset = i_first;
			}//if (i_dist_max < i_dist)
		}//for (int i_first = 0; i_first < v_pop_orderings.size() - 1; i_first++)

		if (i_dist_max == 0)
			b_finished = true;
		else
		{
			v_add_pop_ordering
			(
				pc_multi_problem, &v_pop_orderings, &v_decomposition_population,
				(v_pop_orderings.at(i_dist_offset)->d_weight_0 + v_pop_orderings.at(i_dist_offset + 1)->d_weight_0) / 2,
				(v_pop_orderings.at(i_dist_offset)->d_weight_1 + v_pop_orderings.at(i_dist_offset + 1)->d_weight_1) / 2
			);
		}//else  if (i_dist_max == 0)

		if (v_pop_orderings.size() >= iMaxOrderingsNumnber)  b_finished = true;

	}//while (b_finished == false)*/



	CString  s_file_pf_decom_test;
	s_file_pf_decom_test.Format("_pf_decom_smart_test_weight_ordering_pop_%.3d_orderings_%.4d.txt", v_decomposition_population.size(), iMaxOrderingsNumnber);

	if (EMPF_IND_DEBUG)  ::Tools::vReportInFile(s_file_pf_decom_test, "", true);

	//	int  i_dist;
	CString  s_line;
	i_dist_max = 0;
	double  d_dist_avr = 0;
	for (int ii = 0; ii < v_pop_orderings.size() - 1; ii++)
	{
		s_line = v_pop_orderings.at(ii)->sToString();
		s_line += "  |||  ";
		s_line += v_pop_orderings.at(ii + 1)->sToString();

		i_dist = v_pop_orderings.at(ii)->iCompare(v_pop_orderings.at(ii + 1));
		s_buf.Format("\t DIST: \t %d", i_dist);
		s_line += s_buf;

		if (EMPF_IND_DEBUG)  ::Tools::vReportInFile(s_file_pf_decom_test, s_line);

		d_dist_avr += i_dist;
		if (i_dist_max < i_dist)  i_dist_max = i_dist;
	}//for (int ii = 0; ii < v_pop_orders.size(); ii++)

	d_dist_avr = d_dist_avr / (v_pop_orderings.size() - 1);
	s_line.Format("\t DISTavr: \t %.4lf  \t DISTmax: \t %d", d_dist_avr, i_dist_max);
	if (EMPF_IND_DEBUG)  ::Tools::vReportInFile(s_file_pf_decom_test, s_line);

	//s_buf.Format("%d", v_decomposition_population.size());
	//::Tools::vShow(s_buf);
}//void  CMO_EmPfDec::v_generate_orderings(int iMaxOrderingsNumnber)



void  CMO_EmPfDec::v_generate_directed_populations_simple()
{
	CString  s_buf;
	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();



	CEmPFDec_DirectedOptimizer  *pc_new_directed_optimizer;

	pc_new_directed_optimizer = new CEmPFDec_DirectedOptimizer(pc_clear_p3, pc_multi_problem, this);
	pc_new_directed_optimizer->d_weight_0_start = 0;
	pc_new_directed_optimizer->d_weight_0_end = 0;
	pc_new_directed_optimizer->d_weight_1_start = 1;
	pc_new_directed_optimizer->d_weight_1_end = 1;
	pc_new_directed_optimizer->d_weight_0_direction = 0;
	pc_new_directed_optimizer->d_weight_1_direction = 1;
	v_directed_optimizers.push_back(pc_new_directed_optimizer);

	/*pc_new_directed_optimizer = new CEmPFDec_DirectedOptimizer(pc_clear_p3, pc_multi_problem, this);
	pc_new_directed_optimizer->d_weight_0_start = 0.5;
	pc_new_directed_optimizer->d_weight_0_end = 0.5;
	pc_new_directed_optimizer->d_weight_1_start = 0.5;
	pc_new_directed_optimizer->d_weight_1_end = 0.5;
	pc_new_directed_optimizer->d_weight_0_direction = 0.5;
	pc_new_directed_optimizer->d_weight_1_direction = 0.5;
	v_directed_optimizers.push_back(pc_new_directed_optimizer);//*/

	pc_new_directed_optimizer = new CEmPFDec_DirectedOptimizer(pc_clear_p3, pc_multi_problem, this);
	pc_new_directed_optimizer->d_weight_0_start = 1;
	pc_new_directed_optimizer->d_weight_0_end = 1;
	pc_new_directed_optimizer->d_weight_1_start = 0;
	pc_new_directed_optimizer->d_weight_1_end = 0;
	pc_new_directed_optimizer->d_weight_0_direction = 1;
	pc_new_directed_optimizer->d_weight_1_direction = 0;
	v_directed_optimizers.push_back(pc_new_directed_optimizer);//*/
}//void  CMO_EmPfDec::v_generate_directed_populations_simple()



void  CMO_EmPfDec::v_compute_cumulative_distributions_and_create_a_new_pop()
{
	for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
	{
		v_directed_optimizers.at(ii)->vComputeCumulativeDistribution();
		//v_directed_optimizers.at(ii)->vReportCumulativeDistribution();
		v_directed_optimizers.at(ii)->vUpgradeCumulativeDistribution();
		//v_directed_optimizers.at(ii)->vReportCumulativeDistribution();
	}//for (int ii = 0; ii < v_directed_optimizers.size(); ii++)


	CEmPFDec_DirectedLastResult   c_result_buf((CBinaryMultiObjectiveProblem *) pc_problem->pcGetEvaluation(), NULL);
	c_result_buf.v_weights.push_back(0);
	c_result_buf.v_weights.push_back(0);

	double d_min = 1;
	int  i_min_offset = -1;
	for (int i_dir_opt = 0; i_dir_opt < v_directed_optimizers.size() - 1; i_dir_opt++)
	{
		v_directed_optimizers.at(i_dir_opt)->vCumDistrGetMin(v_directed_optimizers.at(i_dir_opt + 1), &c_result_buf);

		if ( 
			(c_result_buf.d_cumulative_distribution >= 0)&&
			(c_result_buf.v_weights.at(0) != 0) &&
			(c_result_buf.v_weights.at(0) != 1)
			)
		{
			if (d_min > c_result_buf.d_cumulative_distribution)
			{
				d_min = c_result_buf.d_cumulative_distribution;
				i_min_offset = i_dir_opt;
			}//if (d_min > c_result_buf.d_cumulative_distribution)
		}//if (c_result_buf.d_cumulative_distribution >= 0)
	}//for (int i_dir_opt = 0; i_dir_opt < v_directed_optimizers.size(); i_dir_opt++)


	if ((d_min < 0.3) && (i_min_offset >= 0))
	{
		v_directed_optimizers.at(i_min_offset)->vCumDistrGetMin(v_directed_optimizers.at(i_min_offset + 1), &c_result_buf);

		CBinaryMultiObjectiveProblem  *pc_multi_problem;
		pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();

		CEmPFDec_DirectedOptimizer *pc_new_directed_optimizer;
		pc_new_directed_optimizer = new CEmPFDec_DirectedOptimizer(pc_clear_p3, pc_multi_problem, this);
		pc_new_directed_optimizer->d_weight_0_start = c_result_buf.v_weights.at(0);
		pc_new_directed_optimizer->d_weight_0_end = c_result_buf.v_weights.at(0);
		pc_new_directed_optimizer->d_weight_1_start = c_result_buf.v_weights.at(1);
		pc_new_directed_optimizer->d_weight_1_end = c_result_buf.v_weights.at(1);
		pc_new_directed_optimizer->d_weight_0_direction = c_result_buf.v_weights.at(0);
		pc_new_directed_optimizer->d_weight_1_direction = c_result_buf.v_weights.at(1);
		v_directed_optimizers.push_back(pc_new_directed_optimizer);//*/
	}//if (c_result_buf.d_cumulative_distribution < 0.4)
	else
	{
		b_pops_unlocked = true;

		for (int i_dir_opt = 0; i_dir_opt < v_directed_optimizers.size() - 1; i_dir_opt++)
		{
			v_directed_optimizers.at(i_dir_opt)->vCumDistrGetMin(v_directed_optimizers.at(i_dir_opt + 1), &c_result_buf);

			if (
				(c_result_buf.d_cumulative_distribution >= 0)
				)
			{
				v_directed_optimizers.at(i_dir_opt)->d_weight_0_end = c_result_buf.v_weights.at(0);
				v_directed_optimizers.at(i_dir_opt)->d_weight_1_end = 1.0 - v_directed_optimizers.at(i_dir_opt)->d_weight_0_end;

				v_directed_optimizers.at(i_dir_opt + 1)->d_weight_0_start = c_result_buf.v_weights.at(0);
				v_directed_optimizers.at(i_dir_opt + 1)->d_weight_1_start = 1.0 - v_directed_optimizers.at(i_dir_opt + 1)->d_weight_0_start;
			}//if (c_result_buf.d_cumulative_distribution >= 0)
		}//for (int i_dir_opt = 0; i_dir_opt < v_directed_optimizers.size(); i_dir_opt++)


		for (int i_dir_opt = 0; i_dir_opt < v_directed_optimizers.size(); i_dir_opt++)
		{
			if (v_directed_optimizers.at(i_dir_opt)->d_weight_0_end - v_directed_optimizers.at(i_dir_opt)->d_weight_0_start == 0)
			{
				delete  v_directed_optimizers.at(i_dir_opt);
				v_directed_optimizers.erase(v_directed_optimizers.begin() + i_dir_opt);
				i_dir_opt--;
			}//if (v_directed_optimizers.at(i_dir_opt)->d_weight_0_end - v_directed_optimizers.at(i_dir_opt)->d_weight_0_start == 0)
		}//for (int i_dir_opt = 0; i_dir_opt < v_directed_optimizers.size() - 1; i_dir_opt++)


		CString  s_buf;
		s_buf.Format("POPs: %d\n", v_directed_optimizers.size());
		::Tools::vReportInFile("__pops.txt", s_buf);
		for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
		{
			s_buf = v_directed_optimizers.at(ii)->sToStringRange();
			::Tools::vReportInFile("__pops.txt", s_buf);

			if (ii < v_directed_optimizers.size() - 1)
			{
				v_directed_optimizers.at(ii)->vCumDistrGetMin(v_directed_optimizers.at(ii + 1), &c_result_buf);
				s_buf.Format("\t\t DIST: %.4lf \t (%.4lf  %.4lf)", c_result_buf.d_cumulative_distribution, c_result_buf.v_weights.at(0), c_result_buf.v_weights.at(1));
				::Tools::vReportInFile("__pops.txt", s_buf);
			}//if  (ii  < v_directed_optimizers.size() - 1)

		}//for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
		::Tools::vReportInFile("__pops.txt", "\n\n\n");

		::Tools::vShow("UNLOCKED");
	}//else if (c_result_buf.d_cumulative_distribution < 0.4)


	std::sort(v_directed_optimizers.begin(), v_directed_optimizers.end(), [](const CEmPFDec_DirectedOptimizer *pcDir0, const CEmPFDec_DirectedOptimizer *pcDir1) -> bool { return(pcDir0->d_weight_0_direction < pcDir1->d_weight_0_direction); });

	CString  s_buf;
	s_buf.Format("POPs: %d\n", v_directed_optimizers.size());
	::Tools::vReportInFile("__pops.txt", s_buf);
	for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
	{
		s_buf = v_directed_optimizers.at(ii)->sToStringSimple();
		::Tools::vReportInFile("__pops.txt", s_buf);

		if (ii < v_directed_optimizers.size() - 1)
		{
			v_directed_optimizers.at(ii)->vCumDistrGetMin(v_directed_optimizers.at(ii + 1), &c_result_buf);
			s_buf.Format("\t\t DIST: %.4lf \t (%.4lf  %.4lf)", c_result_buf.d_cumulative_distribution, c_result_buf.v_weights.at(0), c_result_buf.v_weights.at(1));
			::Tools::vReportInFile("__pops.txt", s_buf);
		}//if  (ii  < v_directed_optimizers.size() - 1)

	}//for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
	::Tools::vReportInFile("__pops.txt", "\n\n\n");

	//::Tools::vShow("asdasdas");
	


	//for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
		//v_directed_optimizers.at(ii)->vUpdateDirections();

	//for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
		//v_directed_optimizers.at(ii)->vDeleteLastResults();

	i_pops_analysis_remaining_iters = i_pops_analysis_frequency;

	//::Tools::vShow("REPOETED");
}//void  CMO_EmPfDec::v_compute_cumulative_distributions_and_create_a_new_pop()



void  CMO_EmPfDec::v_generate_directed_populations()
{
	CString  s_buf;
	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();


	
	CEmPFDec_DirectedOptimizer  *pc_new_directed_optimizer;

	pc_new_directed_optimizer = new CEmPFDec_DirectedOptimizer(pc_clear_p3, pc_multi_problem, this);
	pc_new_directed_optimizer->d_weight_0_start = v_pop_orderings.at(0)->d_weight_0;
	pc_new_directed_optimizer->d_weight_0_end = v_pop_orderings.at(0)->d_weight_0;
	pc_new_directed_optimizer->d_weight_1_start = v_pop_orderings.at(0)->d_weight_1;
	pc_new_directed_optimizer->d_weight_1_end = v_pop_orderings.at(0)->d_weight_1;
	pc_new_directed_optimizer->d_weight_0_direction = (pc_new_directed_optimizer->d_weight_0_start + pc_new_directed_optimizer->d_weight_0_end) / 2.0;
	pc_new_directed_optimizer->d_weight_1_direction = (pc_new_directed_optimizer->d_weight_1_start + pc_new_directed_optimizer->d_weight_1_end) / 2.0;
	v_directed_optimizers.push_back(pc_new_directed_optimizer);

	int  i_dist;
	for (int ii = 0; ii < v_pop_orderings.size() - 1; ii++)
	{

		i_dist = v_pop_orderings.at(ii)->iCompare(v_pop_orderings.at(ii + 1));
		
		if (i_dist == 0)
		{
			pc_new_directed_optimizer->d_weight_0_end = v_pop_orderings.at(ii + 1)->d_weight_0;
			pc_new_directed_optimizer->d_weight_1_end = v_pop_orderings.at(ii + 1)->d_weight_1;
		}//if (i_dist == 0)
		else
		{
			pc_new_directed_optimizer = new CEmPFDec_DirectedOptimizer(pc_clear_p3, pc_multi_problem, this);
			pc_new_directed_optimizer->d_weight_0_start = v_pop_orderings.at(ii + 1)->d_weight_0;
			pc_new_directed_optimizer->d_weight_0_end = v_pop_orderings.at(ii + 1)->d_weight_0;
			
			pc_new_directed_optimizer->d_weight_1_start = v_pop_orderings.at(ii + 1)->d_weight_1;
			pc_new_directed_optimizer->d_weight_1_end = v_pop_orderings.at(ii + 1)->d_weight_1;

			//pc_new_directed_optimizer->d_weight_0_direction = (pc_new_directed_optimizer->d_weight_0_start + pc_new_directed_optimizer->d_weight_0_end) / 2.0;
			//pc_new_directed_optimizer->d_weight_1_direction = (pc_new_directed_optimizer->d_weight_1_start + pc_new_directed_optimizer->d_weight_1_end) / 2.0;
			
			v_directed_optimizers.push_back(pc_new_directed_optimizer);
		}//else if (i_dist == 0)

		pc_new_directed_optimizer->d_weight_0_direction = (pc_new_directed_optimizer->d_weight_0_start + pc_new_directed_optimizer->d_weight_0_end) / 2.0;
		pc_new_directed_optimizer->d_weight_1_direction = (pc_new_directed_optimizer->d_weight_1_start + pc_new_directed_optimizer->d_weight_1_end) / 2.0;

	}//for (int ii = 0; ii < v_pop_orders.size(); ii++)


	for (int ii = 0; ii < v_directed_optimizers.size() - 1; ii++)
	{
		v_directed_optimizers.at(ii)->d_weight_0_end = (v_directed_optimizers.at(ii)->d_weight_0_direction + v_directed_optimizers.at(ii + 1)->d_weight_0_direction) / 2.0;
		v_directed_optimizers.at(ii)->d_weight_1_end = 1.0 - v_directed_optimizers.at(ii)->d_weight_0_end;

		v_directed_optimizers.at(ii + 1)->d_weight_0_start = (v_directed_optimizers.at(ii)->d_weight_0_direction + v_directed_optimizers.at(ii + 1)->d_weight_0_direction) / 2.0;
		v_directed_optimizers.at(ii + 1)->d_weight_1_start = 1.0 - v_directed_optimizers.at(ii + 1)->d_weight_0_start;
	}//for (int ii = 0; ii < v_directed_optimizers.size(); ii++)*/


	CString  s_file_dir_opts;
	CString  s_line;

	s_file_dir_opts.Format("___dir_opts.txt");
	s_line.Format("%d", v_directed_optimizers.size());
	if (EMPF_IND_DEBUG)  ::Tools::vReportInFile(s_file_dir_opts, s_line, true);

	for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
	{
		s_line = v_directed_optimizers.at(ii)->sToString();
		if (EMPF_IND_DEBUG)  ::Tools::vReportInFile(s_file_dir_opts, s_line);
	}//for (int ii = ii < v_directed_optimizers.size(); ii++)


	if (EMPF_IND_DEBUG)  ::Tools::vShow("aaaaaaaaaaa");

}//void  CMO_EmPfDec::v_generate_directed_populations()



bool CMO_EmPfDec::bRunIteration(uint32_t iIterationNumber)
{
	CString  s_buf;

	for (int ii = 0; ii < v_directed_optimizers.size(); ii++)
	{
		if (b_pops_unlocked == true)
		{
			s_buf.Format("Opt %d/%d  (%.16lf / %.16lf)  %.8lf FFE: %.0lf", ii, v_directed_optimizers.size(), v_directed_optimizers.at(ii)->d_weight_0_direction, v_directed_optimizers.at(ii)->d_weight_1_direction, pc_get_multi_problem()->dPFQualityInverseGenerationalDistance(), (double)pc_problem->pcGetEvaluation()->iGetFFE());
			pc_log->vPrintLine(s_buf, true);
			v_directed_optimizers.at(ii)->bRunIteration(iIterationNumber);
		}//if (b_pops_unlocked == true)
		else
		{
			if (v_directed_optimizers.at(ii)->v_last_results.size() < i_pops_analysis_frequency)
			{
				s_buf.Format("Opt %d/%d  (%.16lf / %.16lf)  %.8lf FFE: %.0lf", ii, v_directed_optimizers.size(), v_directed_optimizers.at(ii)->d_weight_0_direction, v_directed_optimizers.at(ii)->d_weight_1_direction, pc_get_multi_problem()->dPFQualityInverseGenerationalDistance(), (double)pc_problem->pcGetEvaluation()->iGetFFE());
				pc_log->vPrintLine(s_buf, true);
				v_directed_optimizers.at(ii)->bRunIteration(iIterationNumber);
			}//if (v_directed_optimizers.at(ii)->v_last_results.size() < i_pops_analysis_frequency)
		}//else  if (b_pops_unlocked == true)
	}//for (int ii = 0; ii < v_directed_optimizers.size(); ii++)


	if (b_pops_unlocked == false)
	{
		i_pops_analysis_remaining_iters--;
		if (i_pops_analysis_remaining_iters == 0)
		{
			v_compute_cumulative_distributions_and_create_a_new_pop();
		}//if (i_pops_analysis_remaining_iters)
	}//if (b_pops_unlocked == false)
	
	
	//CBinaryOptimizer::b_update_best_individual(iIterationNumber, tStartTime, v_decomposition_population.at(0)->pc_phenotype->piGetBits(), v_decomposition_population.at(0)->dGetFitness());
	CBinaryOptimizer::b_update_best_individual(iIterationNumber, v_directed_optimizers.at(0)->pcGetBestIndividual()->pcGetFenotype()->piGetBits(), 15);

	
	return(true);
}//bool CMO_EmPfDec::bRunIteration(uint32_t iIterationNumber)


bool CMO_EmPfDec::bRunIteration_test_vector(uint32_t iIterationNumber)
{
	CString  s_buf;
	double  d_time_passed;

	c_time_counter.bGetTimePassed(&d_time_passed);
	

	CBinaryCoding c_genotype(i_templ_length);

	
	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();

	
	vector<CMultiObjectiveMeasure*>  *pv_mesaures;
	pv_mesaures = pc_multi_problem->pvGetMeasures();

	pv_mesaures->at(0)->dWeight = 0.5;
	pv_mesaures->at(1)->dWeight = 0.5;

	double  d_fit;

	CString  s_file_pf_decom_test = "_pf_decom_test_tchebychev.txt";
	for (int i_step = 0; i_step < i_templ_length + 1; i_step++)
	{
		for (int ii = 0; ii < i_templ_length; ii++)
			c_genotype.piGetBits()[ii] = 0;
			//c_genotype.piGetBits()[ii] = RandUtils::iRandNumber(0, 1);

		for (int ii = 0; ii < i_step; ii++)
			c_genotype.piGetBits()[ii] = 1;
			

		
		d_fit = pc_multi_problem->dEvaluate(&c_genotype);

		s_buf.Format("%.2d \t %.2lf \n", i_step, d_fit);
		if (i_step == 0)  
			::Tools::vReportInFile(s_file_pf_decom_test, s_buf, true);
		else
			::Tools::vReportInFile(s_file_pf_decom_test, s_buf);
	}//for  (int  i_step = 0; i_step < i_templ_length; i_step++)
	::Tools::vShow(1);
	

	//s_buf.Format("iteration: %d  pop: %d; GenSize:%d PFsize:%d HyperVolume: %.8lf InvGenDist: %.8lf [time:%.2lf]", iIterationNumber, v_population.size(), v_non_dominated_pfs.at(0).at(0)->pc_genotype->iGetNumberOfBits(), (int)dPFQualityPointNum(), dPFQualityHyperVolume(), dPFQualityInverseGenerationalDistance(), d_time_passed);
	s_buf.Format("iteration: %d  PFsize:%d HyperVolume: %.8lf InvGenDist: %.8lf [time:%.2lf]", iIterationNumber, (int)dPFQualityPointNum(), dPFQualityHyperVolume(), dPFQualityInverseGenerationalDistance(), d_time_passed);
	pc_log->vPrintLine(s_buf, true);

	CBinaryOptimizer::b_update_best_individual(iIterationNumber, c_genotype.piGetBits(), d_fit);

	return(true);


	
	double  d_hyper_before, d_hyper_after;

	bool b_hyper_improved;

	b_hyper_improved = false;
	for (int i_opt = 0; i_opt < v_directed_optimizers.size(); i_opt++)
	{
		d_hyper_before = pc_multi_problem->dPFQualityHyperVolume();
		v_directed_optimizers.at(i_opt)->bRunIteration(iIterationNumber);
		d_hyper_after = pc_multi_problem->dPFQualityHyperVolume();

		if (d_hyper_before > d_hyper_after)
		{
			v_improved_pf_tool.at(i_opt) = 1;
			b_hyper_improved = true;
		}//if (d_hyper_before > d_hyper_after)
		else
			v_improved_pf_tool.at(i_opt) = 0;
	}//for (int i_opt = 0; i_opt < v_directed_optimizers.size(); i_opt++)


	bool b_updated = b_update_best_individual(iIterationNumber);


	if (b_hyper_improved == true)
	{
		int  i_pop_offset = -1;
		for (int i_opt = 0; i_opt < v_directed_optimizers.size(); i_opt++)
		{
			i_pop_offset++;
			if (v_improved_pf_tool.at(i_opt) == 0)
			{
				CString s_log;
				s_log.Format("remove pop: %d  iteration: %d; time: [%.2lf];", i_pop_offset, iIterationNumber, c_time_counter.dGetTimePassed());
				pc_log->vPrintLine(s_log, true);

				delete  v_directed_optimizers.at(i_opt);
				//v_p3.at(i_p3) = (CP3 *)pc_clear_p3->pcCopy();
				v_directed_optimizers.at(i_opt)->vInitialize();

				//v_improved_pf_tool.erase(v_improved_pf_tool.begin() + i_p3);
				//i_p3--;
			}//if (v_improved_pf_tool.at(i_pop_offset) == 0)
		}//for (int i_p3 = 0; i_p3 < v_p3.size(); i_p3++)


		/*CP3  *pc_new_p3;
		while (v_p3.size() < i_pop_p3_number)
		{
			pc_new_p3 = (CP3 *) pc_clear_p3->pcCopy();
			pc_new_p3->vInitialize(tStartTime);
			v_p3.push_back(pc_new_p3);
		}//while (v_p3.size() < i_pop_p3_number)*/
	}//if (b_hyper_improved == true)
	/*else
	{
		CP3  *pc_new_p3;
		pc_new_p3 = (CP3 *) pc_clear_p3->pcCopy();
		pc_new_p3->vInitialize(tStartTime);
		v_p3.push_back(pc_new_p3);
		v_improved_pf_tool.push_back(0);
	}//else  if (b_hyper_improved == true)*/

	CString  s_improved;
	if (b_hyper_improved == true)
		s_improved = "IMPROVED";
	else
		s_improved = "NOT improved";

	CString s_log;
	s_log.Format("iteration: %d; %s; pop number:%d(%d);  time: [%.2lf];", iIterationNumber, s_improved, v_directed_optimizers.size(), v_improved_pf_tool.size(), c_time_counter.dGetTimePassed());

	pc_log->vPrintLine(s_log, true);
	pc_log->vPrintEmptyLine(true);

	return b_updated;

	//return(bRunIteration_dummy(iIterationNumber, tStartTime));
};//bool CMO_EmPfDec::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)




bool CMO_EmPfDec::b_update_best_individual(uint32_t iIterationNumber)
{
	CIndividual<CBinaryCoding, CBinaryCoding> *pc_optimizer_best_individual;

	bool b_updated = false;


	for (uint8_t i = 0; i < (uint8_t)v_directed_optimizers.size(); i++)
	{
		pc_optimizer_best_individual = v_directed_optimizers.at(i)->pcGetBestIndividual();

		if (pc_optimizer_best_individual)
		{
			//if (CBinaryOptimizer::b_update_best_individual(iIterationNumber, tStartTime, pc_optimizer_best_individual->pcGetGenotype()->piGetBits(), 0))
			if (CBinaryOptimizer::b_update_best_individual(iIterationNumber, pc_optimizer_best_individual))
			{
				b_updated = true;
			}//if (b_update_best_individual(iIterationNumber, tStartTime, pc_optimizer_best_individual))
		}//if (pc_optimizer_best_individual)
	}//for (uint8_t i = 0; i < (uint8_t)v_populations.size(); i++)

	if (b_updated)
	{
		d_best_time = c_time_counter.dGetTimePassed();
		i_best_ffe = pc_problem->pcGetEvaluation()->iGetFFE();

		CString s_log;
		s_log.Format("new best found: %f", pc_optimizer_best_individual->dGetFitnessValue());

		pc_log->vPrintEmptyLine(true);
		pc_log->vPrintLine(s_log, true);
		pc_log->vPrintEmptyLine(true);
		pc_log->vPrintLine(pc_optimizer_best_individual->pcGetFenotype()->sToString(), false);
		pc_log->vPrintEmptyLine(false);
	}//if (b_updated)*/

	return b_updated;
}//bool CMO_EmPfDec::b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime)



bool CMO_EmPfDec::bRunIteration_dummy(uint32_t iIterationNumber)
{
	CString  s_buf;
	double  d_time_passed;

	c_time_counter.bGetTimePassed(&d_time_passed);


	CBinaryCoding c_genotype(i_templ_length);

	for (int ii = 0; ii < i_templ_length; ii++)
		c_genotype.piGetBits()[ii] = RandUtils::iRandNumber(0, 1);


	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();


	double  d_fit;
	d_fit = pc_multi_problem->dEvaluate(&c_genotype);


	//s_buf.Format("iteration: %d  pop: %d; GenSize:%d PFsize:%d HyperVolume: %.8lf InvGenDist: %.8lf [time:%.2lf]", iIterationNumber, v_population.size(), v_non_dominated_pfs.at(0).at(0)->pc_genotype->iGetNumberOfBits(), (int)dPFQualityPointNum(), dPFQualityHyperVolume(), dPFQualityInverseGenerationalDistance(), d_time_passed);
	s_buf.Format("iteration: %d  PFsize:%d HyperVolume: %.8lf InvGenDist: %.8lf [time:%.2lf]", iIterationNumber, (int)dPFQualityPointNum(), dPFQualityHyperVolume(), dPFQualityInverseGenerationalDistance(), d_time_passed);
	pc_log->vPrintLine(s_buf, true);

	CBinaryOptimizer::b_update_best_individual(iIterationNumber, c_genotype.piGetBits(), d_fit);

	return(true);
};//bool CMO_EmPfDec::bRunIteration_dummy(uint32_t iIterationNumber, time_t tStartTime)




/*
i_pop_p3_number = 2;

	for (int ii = 0; ii < i_pop_p3_number; ii++)
	{
		v_p3.push_back((CP3 *)pc_clear_p3->pcCopy());
		v_p3.at(ii)->vInitialize(tStartTime);

		v_improved_pf_tool.push_back(0);
	}//for (int ii = 0; ii < i_pop_p3_number; ii++)


lass  CEmPFDec_DirectedOptimizer
{
public:
	CEmPFDec_DirectedOptimizer(CP3  *pcClearP3, CBinaryMultiObjectiveProblem  *pcProblem);
	~CEmPFDec_DirectedOptimizer();

	bool  bRunIteration();
	void  vInitialize();

private:
	CBinaryMultiObjectiveProblem  *pc_problem;
	CP3  *pc_p3;

	double  d_weight_0_start, d_weight_0_end;
	double  d_weight_1_start, d_weight_1_end;
};//class  CEmPFDec_DirectedOptimizer*/



CEmPFDec_DirectedOptimizer::CEmPFDec_DirectedOptimizer(CP3  *pcClearP3, CBinaryMultiObjectiveProblem  *pcProblem, CMO_EmPfDec *pcParent)
{
	pc_problem = pcProblem;
	pc_p3 = (CP3 *) pcClearP3->pcCopy();
	pc_p3->vInitialize();
	pc_best = NULL;
	pc_parent = pcParent;
	//pc_p3->vSetMultiObjDominationWeightVec(false);
}//CEmPFDec_DirectedOptimizer::CEmPFDec_DirectedOptimizer(CP3  *pcClearP3, CBinaryMultiObjectiveProblem  *pcProblem)



CEmPFDec_DirectedOptimizer::~CEmPFDec_DirectedOptimizer()
{
	delete  pc_p3;
	vDeleteLastResults();
}//CEmPFDec_DirectedOptimizer::~CEmPFDec_DirectedOptimizer()



void CEmPFDec_DirectedOptimizer::vInitialize()
{

}//void CEmPFDec_DirectedOptimizer::vInitialize()



bool CEmPFDec_DirectedOptimizer::bRunIteration(uint32_t iIterationNumber)
{
	vector<CMultiObjectiveMeasure*>  *pv_mesaures;
	pv_mesaures = pc_problem->pvGetMeasures();

	

	//pv_mesaures->at(0)->dWeight = d_weight_0_direction;
	//pv_mesaures->at(1)->dWeight = d_weight_1_direction;

	pv_mesaures->at(0)->dWeight = RandUtils::dRandNumber(d_weight_0_start, d_weight_0_end);
	pv_mesaures->at(1)->dWeight = 1.0 - pv_mesaures->at(0)->dWeight;

	pc_p3->bRunIteration(iIterationNumber);
	pc_best = pc_p3->pcGetBestIndividual();


	if (pc_p3->pvGetLastAdded()->size() > 0)
	{
		CEmPFDec_DirectedLastResult  *pc_new_last_result;
		pc_new_last_result = new CEmPFDec_DirectedLastResult(pc_problem, this);
		pc_new_last_result->vSetGenotype(pc_p3->pvGetLastAdded());
		pc_new_last_result->vComputeObjAndWeights();

		if  (pc_new_last_result->v_weights.size() > 0)  v_last_results.push_back(pc_new_last_result);
	}//if (pc_p3->pvGetLastAdded()->size() > 0)

	//v_report_weights_cumulative_distribution();

}//bool CEmPFDec_DirectedOptimizer::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



int  CEmPFDec_DirectedOptimizer::iCumDistr_GetLastResultOffset(double  dWeight)
{
	for (int ii = 0; ii < v_last_results.size(); ii++)
	{
		if (v_last_results.at(ii)->v_weights.at(0) == dWeight)  return(ii);

		if (v_last_results.at(ii)->v_weights.at(0) > dWeight)
		{
			if (ii == 0)  return(0);
			return(ii-1);
		}//if (v_last_results.at(ii)->v_weights.at(0) < dWeight)
	}//for (int ii = 0; ii < v_last_results.size(); ii++)


	return(v_last_results.size() - 1);
}//int  CEmPFDec_DirectedOptimizer::iCumDistr_GetLastResultOffset(double  dWeight)



void  CEmPFDec_DirectedOptimizer::vCumDistrGetMin(CEmPFDec_DirectedOptimizer *pcOther, CEmPFDec_DirectedLastResult  *pcDirection)
{
	double  d_start, d_end;

	if ((v_last_results.size() == 0) || (pcOther->v_last_results.size() == 0))
	{
		pcDirection->d_cumulative_distribution = -1;
		pcDirection->v_weights.at(0) = -1;
		pcDirection->v_weights.at(1) = -1;
		return;
	}//if ((v_last_results.size() == 0) || (pcOther->v_last_results.size() == 0))

	d_start = dCumDistrGetMiddleWeight();
	d_end = pcOther->dCumDistrGetMiddleWeight();

	if (d_start > d_end)
	{
		double  d_buf;
		d_buf = d_start;
		d_start = d_end;
		d_end = d_buf;
	}//if (d_start > d_end)

	int  i_this_last_res_offset, i_other_last_res_offset;


	i_this_last_res_offset = iCumDistr_GetLastResultOffset(d_start);
	i_other_last_res_offset = pcOther->iCumDistr_GetLastResultOffset(d_start);

	
	double  d_weight_this, d_weight_other;
	d_weight_this = v_last_results.at(i_this_last_res_offset)->v_weights.at(0);
	d_weight_other = pcOther->v_last_results.at(i_other_last_res_offset)->v_weights.at(0);


	pcDirection->d_cumulative_distribution = max(v_last_results.at(i_this_last_res_offset)->d_cumulative_distribution, pcOther->v_last_results.at(i_other_last_res_offset)->d_cumulative_distribution);
	pcDirection->v_weights.at(0) = d_start;
	pcDirection->v_weights.at(1) = 1.0 - d_start;

	if ((d_weight_this >= d_end) && (d_weight_other >= d_end))  return;


	CString  s_buf;
	//::Tools::vReportInFile("__log.txt", "", true);

	s_buf.Format("START: %.4lf  END: %.4lf\n", d_start, d_end);
	//::Tools::vReportInFile("__log.txt", s_buf);

	s_buf.Format("INIT: %.4lf (%d) / %.4lf (%d)  DIST: %.4lf (%.4lf/%.4lf)", v_last_results.at(i_this_last_res_offset)->v_weights.at(0), i_this_last_res_offset, pcOther->v_last_results.at(i_other_last_res_offset)->v_weights.at(0), i_other_last_res_offset, pcDirection->d_cumulative_distribution, pcDirection->v_weights.at(0), pcDirection->v_weights.at(1));
	//::Tools::vReportInFile("__log.txt", s_buf);


	bool  b_finished = false;
	double  d_cumulative_distribution_current;
	while (b_finished == false)
	{
		if (d_weight_this < d_weight_other)
		{
			i_this_last_res_offset++;
			if (i_this_last_res_offset >= v_last_results.size())  return;
			d_weight_this = v_last_results.at(i_this_last_res_offset)->v_weights.at(0);

			d_cumulative_distribution_current = max(v_last_results.at(i_this_last_res_offset)->d_cumulative_distribution, pcOther->v_last_results.at(i_other_last_res_offset)->d_cumulative_distribution);
			if (d_cumulative_distribution_current < pcDirection->d_cumulative_distribution)
			{
				pcDirection->d_cumulative_distribution = d_cumulative_distribution_current;
				pcDirection->v_weights.at(0) = d_weight_this;
				pcDirection->v_weights.at(1) = 1.0 - d_weight_this;
			}//if (d_cumulative_distribution_current < pcDirection->d_cumulative_distribution)

			if (d_weight_this > d_end)  return;

			s_buf.Format("IncThis: %.4lf (%d) / %.4lf (%d)  DIST: %.4lf (%.4lf/%.4lf)", v_last_results.at(i_this_last_res_offset)->v_weights.at(0), i_this_last_res_offset, pcOther->v_last_results.at(i_other_last_res_offset)->v_weights.at(0), i_other_last_res_offset, pcDirection->d_cumulative_distribution, pcDirection->v_weights.at(0), pcDirection->v_weights.at(1));
			//::Tools::vReportInFile("__log.txt", s_buf);
		}//if (d_weight_this < d_weight_other)
		else
		{
			i_other_last_res_offset++;
			if (i_other_last_res_offset >= pcOther->v_last_results.size())  return;
			d_weight_other = pcOther->v_last_results.at(i_other_last_res_offset)->v_weights.at(0);

			d_cumulative_distribution_current = max(v_last_results.at(i_this_last_res_offset)->d_cumulative_distribution, pcOther->v_last_results.at(i_other_last_res_offset)->d_cumulative_distribution);
			if (d_cumulative_distribution_current < pcDirection->d_cumulative_distribution)
			{
				pcDirection->d_cumulative_distribution = d_cumulative_distribution_current;
				pcDirection->v_weights.at(0) = d_weight_other;
				pcDirection->v_weights.at(1) = 1.0 - d_weight_other;
			}//if (d_cumulative_distribution_current < pcDirection->d_cumulative_distribution)

			if (d_weight_other > d_end)  return;

			s_buf.Format("IncOther: %.4lf (%d) / %.4lf (%d)  DIST: %.4lf (%.4lf/%.4lf)", v_last_results.at(i_this_last_res_offset)->v_weights.at(0), i_this_last_res_offset, pcOther->v_last_results.at(i_other_last_res_offset)->v_weights.at(0), i_other_last_res_offset, pcDirection->d_cumulative_distribution, pcDirection->v_weights.at(0), pcDirection->v_weights.at(1));
			//::Tools::vReportInFile("__log.txt", s_buf);
		}//else  if (d_weight_this < d_weight_other)
	}//while (b_finished == false)



	return;
}//double  CEmPFDec_DirectedOptimizer::dCumDistrGetMin(CEmPFDec_DirectedOptimizer *pcOther, CEmPFDec_DirectedLastResult  *pcDirection)


double  CEmPFDec_DirectedOptimizer::dCumDistrGetMiddleWeight()
{
	double  d_result;

	if (v_last_results.size() % 2 == 0)
	{
		d_result =
			v_last_results.at(v_last_results.size() / 2)->v_weights.at(0) +
			v_last_results.at(v_last_results.size() / 2 - 1)->v_weights.at(0);

		d_result = d_result / 2.0;
	}//if (v_last_results.size() % 2 == 0)
	else
		d_result = v_last_results.at(v_last_results.size() / 2)->v_weights.at(0);


	return(d_result);
}//double  CEmPFDec_DirectedOptimizer::dCumDistrGetMiddleWeight()


double  CEmPFDec_DirectedOptimizer::dCumDistrGet(double  dWeight)
{
	if (v_last_results.size() <= 0)  return(-1);

	if (
		(d_weight_0_direction <= dWeight) && (dWeight <= dCumDistrGetMiddleWeight()) ||
		(dCumDistrGetMiddleWeight() <= dWeight) && (dWeight <= d_weight_0_direction)
		)
	{
		return(0.5);
	}//if (


	if (dWeight < v_last_results.at(0)->v_weights.at(0))  return(0);
	if (dWeight > v_last_results.at(v_last_results.size() - 1)->v_weights.at(0))  return(0);

	for (int ii = 0; ii < v_last_results.size(); ii++)
	{
		if (v_last_results.at(0)->v_weights.at(0) <= dWeight)
		{
			if (v_last_results.at(0)->d_cumulative_distribution < 0.5)
				return(v_last_results.at(0)->d_cumulative_distribution);

			if (v_last_results.at(0)->d_cumulative_distribution > 0.5)
				return(1.0 - v_last_results.at(0)->d_cumulative_distribution);			
		}//if (v_last_results.at(0)->v_weights.at(0) <= dWeight)
	}//for (int ii = 0; ii < v_last_results.size(); ii++)

	return(0);
}//double  CEmPFDec_DirectedOptimizer::dCumDistrGet(double  dWeight)



void  CEmPFDec_DirectedOptimizer::vComputeCumulativeDistribution()
{
	std::sort(v_last_results.begin(), v_last_results.end(), [](const CEmPFDec_DirectedLastResult *pcInd0, const CEmPFDec_DirectedLastResult *pcInd1) -> bool { return(pcInd0->v_weights.at(0) < pcInd1->v_weights.at(0)); });
	
	double  d_cum_distr = 0;
	double  d_current_weight;
	bool  b_the_same_weight_finished;
	
	for (int i_last_res = 0; i_last_res < v_last_results.size() / 2; i_last_res++)
	{
		d_current_weight = v_last_results.at(i_last_res)->v_weights.at(0);

		b_the_same_weight_finished = false;

		for (int i_the_same_res = i_last_res; (b_the_same_weight_finished == false) && (i_the_same_res < v_last_results.size()); i_the_same_res++)
		{
			if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
			{
				//i_last_res = i_the_same_res;
				d_cum_distr += 1;
			}//if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
			else
				b_the_same_weight_finished = true;
		}//for (int i_the_same_res = i_last_res; b_the_same_weight_finished == false; i_the_same_res++)


		b_the_same_weight_finished = false;
		for (int i_the_same_res = i_last_res; (b_the_same_weight_finished == false) && (i_the_same_res < v_last_results.size()); i_the_same_res++)
		{
			if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
			{
				v_last_results.at(i_the_same_res)->d_cumulative_distribution = d_cum_distr;
			}//if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
			else
				b_the_same_weight_finished = true;
		}//for (int i_the_same_res = i_last_res; b_the_same_weight_finished == false; i_the_same_res++)

	}//for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)


	d_cum_distr = 0;
	for (int i_last_res = v_last_results.size() - 1; i_last_res >= v_last_results.size() / 2; i_last_res--)
	{
		d_current_weight = v_last_results.at(i_last_res)->v_weights.at(0);

		b_the_same_weight_finished = false;

		for (int i_the_same_res = i_last_res; (b_the_same_weight_finished == false) && (i_the_same_res >= 0); i_the_same_res--)
		{
			if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
			{
				//i_last_res = i_the_same_res;
				d_cum_distr += 1;
			}//if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
			else
				b_the_same_weight_finished = true;
		}//for (int i_the_same_res = i_last_res; b_the_same_weight_finished == false; i_the_same_res++)


		b_the_same_weight_finished = false;
		for (int i_the_same_res = i_last_res; (b_the_same_weight_finished == false) && (i_the_same_res >= 0); i_the_same_res--)
		{
			if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
			{
				v_last_results.at(i_the_same_res)->d_cumulative_distribution = d_cum_distr;
			}//if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
			else
				b_the_same_weight_finished = true;
		}//for (int i_the_same_res = i_last_res; b_the_same_weight_finished == false; i_the_same_res++)

	}//for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)*/

}//void  CEmPFDec_DirectedOptimizer::vComputeCumulativeDistribution()



void  CEmPFDec_DirectedOptimizer::vUpgradeCumulativeDistribution()
{
	if (v_last_results.size() <= 0)  return;



	CEmPFDec_DirectedLastResult  *pc_border;

	pc_border = new CEmPFDec_DirectedLastResult(pc_problem, this);
	pc_border->v_objectives.push_back(0);
	pc_border->v_objectives.push_back(0);
	pc_border->v_weights.push_back(0);
	pc_border->v_weights.push_back(0);
	pc_border->d_cumulative_distribution = 0;
	v_last_results.insert(v_last_results.begin(), pc_border);

	pc_border = new CEmPFDec_DirectedLastResult(pc_problem, this);
	pc_border->v_objectives.push_back(0);
	pc_border->v_objectives.push_back(0);
	pc_border->v_weights.push_back(1);
	pc_border->v_weights.push_back(1);
	pc_border->d_cumulative_distribution = 0;
	v_last_results.push_back(pc_border);



	for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)
		v_last_results.at(i_last_res)->d_cumulative_distribution = v_last_results.at(i_last_res)->d_cumulative_distribution / v_last_results.size();

	for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)
	{
		if (
			(d_weight_0_direction <= v_last_results.at(i_last_res)->v_weights.at(0) && (v_last_results.at(i_last_res)->v_weights.at(0) <= dCumDistrGetMiddleWeight()) ||
			(dCumDistrGetMiddleWeight() <= v_last_results.at(i_last_res)->v_weights.at(0)) && (v_last_results.at(i_last_res)->v_weights.at(0) <= d_weight_0_direction)
			)
			)
			v_last_results.at(i_last_res)->d_cumulative_distribution = 0.5;


		if  (v_last_results.at(i_last_res)->d_cumulative_distribution > 0.5)  v_last_results.at(i_last_res)->d_cumulative_distribution = 0.5;
	}//for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)
}//void  CEmPFDec_DirectedOptimizer::vUpgradeCumulativeDistribution()



void  CEmPFDec_DirectedOptimizer::vReportCumulativeDistribution()
{
	CString  s_rep_file;
	CString  s_line, s_buf;

	//s_rep_file.Format("__pf_rep_%.3d_%.3d_%.5d.txt", (int)d_weight_0_direction * 100, (int)d_weight_1_direction * 100, v_last_results.size());
	s_rep_file.Format("__pfff_rep_%.3d_%.3d.txt", (int)(d_weight_0_direction * 100), (int)(d_weight_1_direction * 100));

	::Tools::vReportInFile(s_rep_file, "", true);

	s_buf.Format("ResNumber: %d", v_last_results.size());
	::Tools::vReportInFile(s_rep_file, s_buf);

	s_buf.Format("MiddleWeight: %.4lf", dCumDistrGetMiddleWeight());
	::Tools::vReportInFile(s_rep_file, s_buf);
	
	

	for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)
	{
		s_buf.Format("(%.4lf / %.4lf)", v_last_results.at(i_last_res)->v_weights.at(0), v_last_results.at(i_last_res)->v_weights.at(1));
		//s_line.Format("%.0lf (%.4lf):   ", v_last_results.at(i_last_res)->d_cumulative_distribution, v_last_results.at(i_last_res)->d_cumulative_distribution / v_last_results.size());
		s_line.Format("%.3d.  %.4lf :   ", i_last_res, v_last_results.at(i_last_res)->d_cumulative_distribution);
		s_line = s_line + s_buf;

		::Tools::vReportInFile(s_rep_file, s_line);
	}//for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)
}//void  CEmPFDec_DirectedOptimizer::vReportCumulativeDistribution()



void  CEmPFDec_DirectedOptimizer::vUpdateDirections()
{
	if (
		(v_last_results.size() > 0)
		&&
		(d_weight_0_direction != 0) && (d_weight_0_direction != 1)
		)
	{
		d_weight_0_direction = dCumDistrGetMiddleWeight();
		d_weight_1_direction = 1.0 - dCumDistrGetMiddleWeight();
	}//if  (
}//void  CEmPFDec_DirectedOptimizer::vUpdateDirections()


void  CEmPFDec_DirectedOptimizer::vDeleteLastResults()
{
	for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)
		delete  v_last_results.at(i_last_res);

	v_last_results.clear();
}//void  CEmPFDec_DirectedOptimizer::vDeleteLastResults()




void  CEmPFDec_DirectedOptimizer::v_report_weights_cumulative_distribution()
{

	if ((v_last_results.size() > 0) && (v_last_results.size() % 100 == 0))
	{
		CString  s_rep_file;
		CString  s_line, s_buf, s_report_line;

		//s_rep_file.Format("__pf_rep_%.3d_%.3d_%.5d.txt", (int)d_weight_0_direction * 100, (int)d_weight_1_direction * 100, v_last_results.size());
		s_rep_file.Format("__pf_rep_%.3d_%.3d.txt", (int) (d_weight_0_direction * 100), (int) (d_weight_1_direction * 100));

		if  (v_last_results.size() == 100) ::Tools::vReportInFile(s_rep_file, "", true);

		s_buf.Format("ResNumber: %d", v_last_results.size());
		//::Tools::vReportInFile(s_rep_file, s_buf);


		std::sort(v_last_results.begin(), v_last_results.end(), [](const CEmPFDec_DirectedLastResult *pcInd0, const CEmPFDec_DirectedLastResult *pcInd1) -> bool { return(pcInd0->v_weights.at(0) < pcInd1->v_weights.at(0)); });
		vector<double> v_show_cumlative_distributions;
		v_show_cumlative_distributions.push_back(0);
		v_show_cumlative_distributions.push_back(0.25);
		v_show_cumlative_distributions.push_back(0.5);
		v_show_cumlative_distributions.push_back(0.75);
		v_show_cumlative_distributions.push_back(0.999);

		double  d_cum_distr = 0;
		double  d_current_weight;
		bool  b_the_same_weight_finished;
		s_report_line = "";
		for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)
		{
			d_current_weight = v_last_results.at(i_last_res)->v_weights.at(0);

			b_the_same_weight_finished = false;
			s_line = "";
			for (int i_the_same_res = i_last_res; (b_the_same_weight_finished == false)&&(i_the_same_res < v_last_results.size()); i_the_same_res++)
			{
				if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
				{
					i_last_res = i_the_same_res;
					d_cum_distr += 1;

					s_buf.Format("(%.4lf / %.4lf)", v_last_results.at(i_the_same_res)->v_weights.at(0), v_last_results.at(i_the_same_res)->v_weights.at(1));
					s_line += s_buf + " + ";
				}//if (v_last_results.at(i_the_same_res)->v_weights.at(0) == d_current_weight)
				else
					b_the_same_weight_finished = true;
			}//for (int i_the_same_res = i_last_res; b_the_same_weight_finished == false; i_the_same_res++)


			if (v_show_cumlative_distributions.size() > 0)
			{
				if (v_show_cumlative_distributions.at(0) < d_cum_distr / v_last_results.size())
				{
					s_buf.Format("(%.4lf / %.4lf)", v_last_results.at(i_last_res)->v_weights.at(0), v_last_results.at(i_last_res)->v_weights.at(1));
					s_line.Format("%.0lf (%.4lf):   ", d_cum_distr, d_cum_distr / v_last_results.size());

					s_report_line += s_line + s_buf + "\t";

					v_show_cumlative_distributions.erase(v_show_cumlative_distributions.begin());
				}//if (v_show_cumlative_distributions.at(0) < d_cum_distr / v_last_results.size())
			}//if (v_show_cumlative_distributions.size() > 0)

			//s_buf.Format("%.0lf (%.4lf):   ", d_cum_distr, d_cum_distr / v_last_results.size());
			//s_line = s_buf + s_line;
			//::Tools::vReportInFile(s_rep_file, s_line);

		}//for (int i_last_res = 0; i_last_res < v_last_results.size(); i_last_res++)

		//::Tools::vReportInFile(s_rep_file, "\n\n\n");
		::Tools::vReportInFile(s_rep_file, s_report_line + "\n");
		//::Tools::vShow(s_rep_file);


	}//if ((v_last_results.size() > 0) && (v_last_results.size() % 100))

}//void  CEmPFDec_DirectedOptimizer::v_report_weights_cumulative_distribution()



CString  CEmPFDec_DirectedOptimizer::sToStringSimple()
{
	CString  s_res;

	if  (v_last_results.size() > 0)
		s_res.Format("%.4lf \t %.4lf \t %d \t %.4lf \t %.4lf", d_weight_0_direction, d_weight_1_direction, v_last_results.size(), dCumDistrGetMiddleWeight(), 1.0 - dCumDistrGetMiddleWeight());
	else
		s_res.Format("%.4lf \t %.4lf \t %d \t ", d_weight_0_direction, d_weight_1_direction, v_last_results.size());

	return(s_res);
}//CString  CEmPFDec_DirectedOptimizer::sToStringSimple()




CString  CEmPFDec_DirectedOptimizer::sToString()
{
	CString  s_res;

	s_res.Format("%.16lf \t %.16lf \t %.16lf \t ||| \t %.16lf \t %.16lf \t %.16lf \t", d_weight_0_start, d_weight_0_direction, d_weight_0_end, d_weight_1_start, d_weight_1_direction, d_weight_1_end);

	return(s_res);
}//CString  CEmPFDec_DirectedOptimizer::sToString()


CString  CEmPFDec_DirectedOptimizer::sToStringRange()
{
	CString  s_res;

	s_res.Format("%.16lf \t %.16lf \t ||| \t %.16lf \t %.16lf \t (%.16lf \t %.16lf)", d_weight_0_start, d_weight_0_end, d_weight_1_start, d_weight_1_end, d_weight_0_direction, d_weight_1_direction);

	return(s_res);
}//CString  CEmPFDec_DirectedOptimizer::sToString()



//---------------------------------------------CEmPFDec_Ordering-------------------------------------------------------

CEmPFDec_Ordering::CEmPFDec_Ordering(CBinaryMultiObjectiveProblem  *pcMultiProblem, vector<CEmPFDec_Individual *>  *pvPopulationOrder)
{ 
	pc_multi_problem = pcMultiProblem; 
	v_population_order = *pvPopulationOrder;
};//CEmPFDec_Ordering::CEmPFDec_Ordering(CBinaryMultiObjectiveProblem  *pcMultiProblem, vector<CEmPFDec_Individual *>  *pvPopulationOrder)


void  CEmPFDec_Ordering::vGetPopOrder()
{
	vector<CMultiObjectiveMeasure*>  *pv_mesaures;
	pv_mesaures = pc_multi_problem->pvGetMeasures();

	pv_mesaures->at(0)->dWeight = d_weight_0;
	pv_mesaures->at(1)->dWeight = d_weight_1;


	for (int ii = 0; ii < v_population_order.size(); ii++)
		v_population_order.at(ii)->dReevaluate(false);

	std::sort(v_population_order.begin(), v_population_order.end(), [](const CEmPFDec_Individual *pcInd0, const CEmPFDec_Individual *pcInd1) -> bool { return(pcInd0->d_fitness < pcInd1->d_fitness); });

	/*if (EMPF_IND_DEBUG)
	{
		CString  s_ordering_name = "__ind_ordering";
		CString  s_cur_name;

		s_cur_name.Format("_%.4d_%.4d", (int) (d_weight_0*1000), (int) (d_weight_1 * 1000));
		s_cur_name = s_ordering_name + s_cur_name + ".txt";

		::Tools::vReportInFile(s_cur_name, "", true);

		CString  s_buf;
		vector<double>  v_measure_values;

		for (int ii = 0; ii < v_population_order.size(); ii++)
		{
			pc_multi_problem->vEvaluateParetoFront(&v_measure_values, v_population_order.at(ii)->pc_phenotype);

			s_buf.Format("%.16lf \t %.16lf \t FIT: %.16lf VALUES: %.16lf \t %.16lf", pv_mesaures->at(0)->dWeight, pv_mesaures->at(1)->dWeight, v_population_order.at(ii)->dGetFitness(), v_measure_values.at(0), v_measure_values.at(1));
			::Tools::vReportInFile(s_cur_name, s_buf);


			double  d_ref_point_0, d_ref_point_1;
			d_ref_point_0 = pv_mesaures->at(0)->dWeight * MULTI_OBJECTIVE_PROBLEM_WEIGHTING_TCHEBYCHEV_MULTIPLIER;
			d_ref_point_1 = pv_mesaures->at(1)->dWeight * MULTI_OBJECTIVE_PROBLEM_WEIGHTING_TCHEBYCHEV_MULTIPLIER;

			s_buf.Format("\t\t Ref point: \t %.16lf %.16lf", d_ref_point_0, d_ref_point_1);
			::Tools::vReportInFile(s_cur_name, s_buf);


			double  d_res_0, d_res_1;
			d_res_0 = d_ref_point_0 - v_measure_values.at(0);
			d_res_1 = d_ref_point_1 - v_measure_values.at(1);

			s_buf.Format("\t\t Results: \t %.16lf %.16lf", d_res_0, d_res_1);
			::Tools::vReportInFile(s_cur_name, s_buf);

			d_res_0 *= pv_mesaures->at(0)->dWeight;
			d_res_1 *= pv_mesaures->at(1)->dWeight;

			s_buf.Format("\t\t ReWeght: \t %.16lf %.16lf", d_res_0, d_res_1);
			::Tools::vReportInFile(s_cur_name, s_buf);
			//(v_measures.at(i_measure)->dWeight * MULTI_OBJECTIVE_PROBLEM_WEIGHTING_TCHEBYCHEV_MULTIPLIER  - v_pf_buffer.at(i_measure)) * v_measures.at(i_measure)->dWeight;
		}//for (int ii = 0; ii < v_population_order.size(); ii++)
	}//if (EMPF_IND_DEBUG)*/

	//::Tools::vReportInFile("___oredr_test.txt", sToString());
}//void  CEmPFDec_Ordering::vGetPopOrder();


CString  CEmPFDec_Ordering::sToString()
{
	CString  s_result;

	s_result.Format("%.16lf \t %.16lf \t", d_weight_0, d_weight_1);

	return(s_result);

	CString  s_buf;
	for (int ii = 0; ii < v_population_order.size(); ii++)
	{
		s_buf = v_population_order.at(ii)->sToString();
		s_buf += " ";

		s_result += s_buf;
	}//for (int ii = 0; ii < v_population_order.size(); ii++)

	return(s_result);
}//CString  CEmPFDec_Ordering::sToString()


int  CEmPFDec_Ordering::iCompare(CEmPFDec_Ordering *pcOther)
{
	if (v_population_order.size() != pcOther->v_population_order.size())
	{
		::Tools::vShow("if (v_population_order.size() != pcOther->v_population_order.size())");
		return(false);
	}//if (v_population_order.size() != pcOther->v_population_order.size())


	int  i_result, i_dist;


	bool  b_first_found;
	i_result = 0;
	for (int i_first = 0; i_first < v_population_order.size(); i_first++)
	{
		b_first_found = false;

		for (int i_second = 0; (i_second < v_population_order.size())&&(b_first_found == false); i_second++)
		{
			if (v_population_order.at(i_first) == pcOther->v_population_order.at(i_second))
			{
				b_first_found = true;
				i_dist = i_first - i_second;
				if (i_dist < 0)  i_dist *= -1;

				i_result += i_dist;
			}//if (v_population_order.at(i_first) != pcOther->v_population_order.at(i_second))
		}//for (int i_second = 0; i_second < v_population_order.size(); i_second++)

		if (b_first_found == false)  return(-1);
	}//for (int ii = 0; ii < v_population_order.size(); ii++)

	return(i_result);
}//bool  CEmPFDec_Ordering::bCompare(CEmPFDec_Ordering *pcOther)




//---------------------------------------------CEmPFDec_DirectedLastResult-------------------------------------------------------

CEmPFDec_DirectedLastResult::CEmPFDec_DirectedLastResult(CBinaryMultiObjectiveProblem  *pcProblem, CEmPFDec_DirectedOptimizer *pcParent)
{
	pc_parent = pcParent;

	pc_problem = pcProblem;
	pc_genotype = new CBinaryCoding(pcProblem->iGetNumberOfElements());

	d_cumulative_distribution = 0;
}//CEmPFDec_DirectedLastResult::CEmPFDec_DirectedLastResult(CBinaryMultiObjectiveProblem  *pcProblem, CEmPFDec_DirectedOptimizer *pcParent)



CEmPFDec_DirectedLastResult::~CEmPFDec_DirectedLastResult()
{
	if (pc_genotype != NULL)  delete  pc_genotype;
}//CEmPFDec_DirectedLastResult::~CEmPFDec_DirectedLastResult()



void  CEmPFDec_DirectedLastResult::vSetGenotype(vector<bool>  *pvGenotype)
{
	for (int ii = 0; ii < pvGenotype->size(); ii++)
	{
		if (pvGenotype->at(ii) == true)
			pc_genotype->piGetBits()[ii] = 1;
		else
			pc_genotype->piGetBits()[ii] = 0;
	}//for (int ii = 0; ii < pvGenotype->size(); ii++)
}//void  CEmPFDec_DirectedLastResult::vSetGenotype(vector<bool>  *pvGenotype)


void  CEmPFDec_DirectedLastResult::vComputeObjAndWeights()
{
	pc_problem->vEvaluateParetoFront(&v_objectives, pc_genotype);

	double  d_sum;
	d_sum = 0;

	for (int i_obj = 0; i_obj < v_objectives.size(); i_obj++)
		d_sum += v_objectives.at(i_obj);


	double  d_weight;
	v_weights.clear();

	if (d_sum > 0)
	{
		for (int i_obj = 0; i_obj < v_objectives.size(); i_obj++)
		{
			d_weight = v_objectives.at(i_obj) / d_sum;
			v_weights.push_back(d_weight);
		}//for (int i_obj = 0; i_obj < v_objectives.size(); i_obj++)
	}//if (d_sum > 0)

}//void  CEmPFDec_DirectedLastResult::vComputeObjAndWeights()




//---------------------------------------------CEmPFDec_Individual-------------------------------------------------------

CEmPFDec_Individual::CEmPFDec_Individual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CMO_EmPfDec  *pcParent)
{
	i_templ_length = iTemplLength;
	pc_parent = pcParent;
	pc_problem = pcProblem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();
	pv_mesaures = pc_multi_problem->pvGetMeasures();

	b_fit_actual = false;
	d_fitness = -1;
	pc_genotype = new CBinaryCoding(i_templ_length);
	pc_phenotype = new CBinaryCoding(i_templ_length);

	vRandomInit();
}//CEmPFDec_Individual::CEmPFDec_Individual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CMO_EmPfDec  *pcParent, vector<int> *pvOptimizationOrder = NULL)


CEmPFDec_Individual::CEmPFDec_Individual(const CEmPFDec_Individual &pcOther)
{
	i_templ_length = pcOther.i_templ_length;
	pc_parent = pcOther.pc_parent;
	pc_problem = pcOther.pc_problem;
	pc_multi_problem = pcOther.pc_multi_problem;
	pv_mesaures = pcOther.pv_mesaures;

	b_fit_actual = pcOther.b_fit_actual;
	d_fitness = pcOther.d_fitness;
	pc_genotype = new CBinaryCoding(i_templ_length);
	pc_phenotype = new CBinaryCoding(i_templ_length);

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		pc_genotype->piGetBits()[ii] = pcOther.pc_genotype->piGetBits()[ii];
		pc_phenotype->piGetBits()[ii] = pcOther.pc_phenotype->piGetBits()[ii];
	}//for (int ii = 0; ii < i_templ_length; ii++)

	v_optimization_order = pcOther.v_optimization_order;
}//CEmPFDec_Individual::CEmPFDec_Individual(const CEmPFDec_Individual &pcOther)


CEmPFDec_Individual::~CEmPFDec_Individual()
{
	delete  pc_genotype;
	delete  pc_phenotype;
}//CEmPFDec_Individual::~CEmPFDec_Individual()



CString  CEmPFDec_Individual::sToString()
{
	CString  s_result, s_buf;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		//if (ii % 5 == 0)  s_result += " ";

		s_buf.Format("%d", pc_phenotype->piGetBits()[ii]);
		s_result += s_buf;		
	}//for (int ii = 0; ii < i_templ_length; ii++)

	//s_buf.Format("(%.16lf)", d_fitness);
	//s_result += s_buf;

	return(s_result);
}//CString  CEmPFDec_Individual::sToString()


double  CEmPFDec_Individual::dGetFitness()
{
	if  (b_fit_actual == true)  return(d_fitness);

	v_optimize_phenotype();
	d_fitness = pc_multi_problem->dEvaluate(pc_phenotype);
	b_fit_actual = true;

	return(d_fitness);
}//double  CEmPFDec_Individual::dGetFitness()


void  CEmPFDec_Individual::v_optimize_phenotype()
{
	CString  s_buf;
	CString  s_rep_file = "__ind_opt.txt";

	for (int ii = 0; ii < i_templ_length; ii++)
		pc_phenotype->piGetBits()[ii] = pc_genotype->piGetBits()[ii];

	double  d_fit_best, d_fit_cur;
	d_fit_best = pc_multi_problem->dEvaluate(pc_phenotype);

	if (EMPF_IND_DEBUG)
	{
		s_buf.Format("%.16lf \t", d_fit_best);
		s_buf += sToString();
		::Tools::vReportInFile(s_rep_file, s_buf, true);
	}//if (EMPF_IND_DEBUG)
		

	int  i_genes_number_optimized;
	int  i_gene_pos;
	bool  b_at_least_one_gene_optimized;
	int  i_best_fitnes_gene_value, i_alternative_value;


	i_genes_number_optimized = 0;
	b_at_least_one_gene_optimized = true;
	while (b_at_least_one_gene_optimized == true)
	{
		b_at_least_one_gene_optimized = false;

		for (int i_ordered_gene_pos = 0; i_ordered_gene_pos < v_optimization_order.size(); i_ordered_gene_pos++)
		{
			i_gene_pos = v_optimization_order.at(i_ordered_gene_pos);

			//i_original_gene_value = pi_genotype[i_gene_pos];
			i_best_fitnes_gene_value = pc_phenotype->piGetBits()[i_gene_pos];

			if (i_best_fitnes_gene_value == 0)
				i_alternative_value = 1;
			else
				i_alternative_value = 0;
			
			pc_phenotype->piGetBits()[i_gene_pos] = i_alternative_value;
			d_fit_cur = pc_multi_problem->dEvaluate(pc_phenotype);

			if (EMPF_IND_DEBUG)
			{
				s_buf.Format("%.16lf \t", d_fit_cur);
				s_buf += sToString();
				::Tools::vReportInFile(s_rep_file, s_buf);
			}//if (EMPF_IND_DEBUG)

			if (d_fit_cur > d_fit_best)
			{
				b_at_least_one_gene_optimized = true;

				i_genes_number_optimized++;

				d_fit_best = d_fit_cur;
				i_best_fitnes_gene_value = i_alternative_value;
			}//if  (d_fit_buf  >  d_best_fitness)

			pc_phenotype->piGetBits()[i_gene_pos] = i_best_fitnes_gene_value;
		}//for  (int  i_genotype_iterator = v_genotype.size() - 1; i_genotype_iterator >= 0; i_genotype_iterator--)
	}//while  (b_at_least_one_gene_optimized == true)

}//void  CEmPFDec_Individual::v_optimize_phenotype()


double  CEmPFDec_Individual::dReevaluate(bool  bOptimizePhenotype /*= true*/)
{
	if  (bOptimizePhenotype == true)  v_optimize_phenotype();
	//::Tools::vShow("reevaluate");
	//::Tools::vShow(d_fitness);
	d_fitness = pc_multi_problem->dEvaluate(pc_phenotype);
	//::Tools::vShow(d_fitness);
	b_fit_actual = true;

	return(d_fitness);
}//double  CEmPFDec_Individual::dReevaluate(bool  bOptimizePhenotype /*= true*/)


void  CEmPFDec_Individual::vRandomInit()
{
	vRandomInitGenotype();
	vRandomInitOptOrder();
};//void  CEmPFDec_Individual::vRandomInit()

void  CEmPFDec_Individual::vRandomInitGenotype()
{
	for (int ii = 0; ii < i_templ_length; ii++)
	{
		pc_genotype->piGetBits()[ii] = RandUtils::iRandNumber(0, 1);
	}//for  (int ii = 0; ii < i_templ_length; ii++)
};//void  CEmPFDec_Individual::vRandomInitGenotype()


void  CEmPFDec_Individual::vRandomInitOptOrder()
{
	v_optimization_order.clear();

	vector <int>  v_genotype_order;
	//vector <int>  v_new_order;

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		v_genotype_order.push_back(ii);
	}//for  (int ii = 0; ii < i_templ_length; ii++)

	int  i_gene_pos_offset;
	while (v_genotype_order.size() > 0)
	{
		i_gene_pos_offset = RandUtils::iRandNumber(0, v_genotype_order.size() - 1);
		//i_gene_pos_offset = 0;
		v_optimization_order.push_back(v_genotype_order.at(i_gene_pos_offset));

		v_genotype_order.erase(v_genotype_order.begin() + i_gene_pos_offset);
	}//while  (v_genotype_order.size() > 0)
};//void  CEmPFDec_Individual::vRandomInitOptOrder()