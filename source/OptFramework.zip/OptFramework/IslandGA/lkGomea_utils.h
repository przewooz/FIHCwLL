#pragma once

#include <vector>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <fstream>
#include <filesystem>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <exception>
using namespace std;

#include "lkGomea_Individual.h"

class C_lkGomea_customException: public exception
{
private:
    string message;

public:
	C_lkGomea_customException(string message_) : message(message_) { }
    const char * what () const throw ()
    {
        return message.c_str();
    }
};

struct C_lkGomea_archiveRecord
{
  bool isFound = false;
  double value = 0.0;
};

struct C_lkGomea_hashVector
{ 
	size_t operator()(const vector<char> &vec) const
	{ 
    	hash <char> hashChar; 
     	size_t hash_value = 0;
     	for (size_t i = 0; i < vec.size(); ++i)	
 	    	hash_value = hash_value*31 + hashChar(vec[i]); 
     	return hash_value; 
	} 
}; 

struct C_lkGomea_hash_int_vector
{ 
  size_t operator()(const vector<int> &vec) const
    { 
      size_t hash_value = 0;
        hash<int> hash_int;
        for(int i = 0; i < vec.size(); ++i)
          hash_value ^= hash_int(vec[i]);

        return hash_value; 
    } 
}; 

class C_lkGomea_solutionsArchive
{
	int maxArchiveSize;
public:
	C_lkGomea_solutionsArchive(int maxArchiveSize_): maxArchiveSize(maxArchiveSize_){};
	unordered_map<vector<char>, double, C_lkGomea_hashVector > archive;
	void checkAlreadyEvaluated(vector<char> &genotype, C_lkGomea_archiveRecord *result);
	void insertSolution(vector<char> &genotype, double fitness);
};

class C_lkGomea_Pyramid
{
public:
	vector<vector<C_lkGomea_Individual*> >levels;
	unordered_set<vector<char>, C_lkGomea_hashVector> hashset;
	bool checkAlreadyInPyramid(vector<char> &genotype);
	bool insertSolution(int level, vector<char> &genotype, double fitness);
	~C_lkGomea_Pyramid();
};

//void prepareFolder(string &folder);
//void initElitistFile(string &folder, int populationScheme, int populationSize);
//void writeElitistSolutionToFile(string &folder, long long numberOfEvaluations, long long time, C_lkGomea_Individual *solution);
//void writeElitistSolutionToFile(string &folder, long long numberOfEvaluations, long long time, C_lkGomea_Individual *solution, bool is_key, size_t populationSize);
//void writeSolutionToFile(string &folder, string &filename, C_lkGomea_Individual &solution);

bool C_lkGomea_isPowerOfK(int n, int k);
